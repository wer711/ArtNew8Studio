/**
 * Cryptographically Secure Token Generator
 *
 * Generates strong random tokens for use as SECRET_TOKEN and other security purposes.
 * Run with: bun run scripts/generate-token.ts
 */

import crypto from "crypto";

function generateToken(byteLength: number = 32): string {
  return crypto.randomBytes(byteLength).toString("hex");
}

function main(): void {
  const args = process.argv.slice(2);
  const byteLength = args[0] ? parseInt(args[0], 10) : 32;

  if (isNaN(byteLength) || byteLength < 16) {
    console.error("Error: Byte length must be a number >= 16");
    console.error("Usage: bun run scripts/generate-token.ts [byte_length]");
    process.exit(1);
  }

  const token = generateToken(byteLength);
  const bits = byteLength * 8;

  console.log("═══════════════════════════════════════════════════════");
  console.log(`  Secure Token Generated (${bits}-bit entropy)`);
  console.log("═══════════════════════════════════════════════════════");
  console.log();
  console.log(`  Token: ${token}`);
  console.log();
  console.log("  Add to your .env file:");
  console.log(`  SHEET_SECRET_TOKEN=${token}`);
  console.log();
  console.log("═══════════════════════════════════════════════════════");

  // Generate additional tokens if requested
  if (args.includes("--all")) {
    console.log();
    console.log("  Additional tokens:");
    console.log();
    console.log(`  HMAC_SECRET=${generateToken(32)}-hmac`);
    console.log(`  CRYPTO_MASTER_SALT=${generateToken(16)}`);
    console.log();
    console.log("═══════════════════════════════════════════════════════");
  }
}

main();
