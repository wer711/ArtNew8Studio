import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // ❌ لا تستخدم "standalone" مع Netlify
  // Netlify يستخدم runtime خاص به
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // السماح بعرض الموقع في iframe (Preview Panel)
  experimental: {},
};

export default nextConfig;
