import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { calculatePrice } from "@/lib/pricing";

// ─── Configuration ──────────────────────────────────────────
const MAX_FILE_SIZE = 15 * 1024 * 1024; // 15MB
const MAX_PAGES = 500;
const MAX_COPIES = 100;
const GOOGLE_SCRIPT_URL = process.env.GOOGLE_SCRIPT_URL || "";
const SHEET_SECRET_TOKEN = process.env.SHEET_SECRET_TOKEN;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

function generateOrderNumber(): string {
  return `ORD-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}

function sanitize(input: string): string {
  return input.replace(/\0/g, "").replace(/<[^>]*>/g, "").replace(/javascript\s*:/gi, "").replace(/\bon\w+\s*=/gi, "").trim().slice(0, 500);
}

function sanitizeInt(value: string | null, defaultValue: number, min: number = 1, max?: number): number {
  if (!value) return defaultValue;
  const p = parseInt(value, 10);
  if (isNaN(p) || p < min) return defaultValue;
  if (max !== undefined && p > max) return max;
  return p;
}

// ─── File Processing (IN-MEMORY ONLY) ──────────────────────
async function processFile(file: File, prefix: string) {
  if (file.size > MAX_FILE_SIZE) throw new Error(`حجم الملف "${file.name}" أكبر من الحد المسموح (15MB)`);
  const buffer = Buffer.from(await file.arrayBuffer());
  const safeName = file.name.replace(/[^\w\u0600-\u06FF.\-() ]/g, "").slice(0, 200) || "upload.bin";
  return {
    fileName: safeName,
    base64Data: buffer.toString("base64"),
    mimeType: file.type || "application/octet-stream",
    fileSize: file.size,
  };
}

// ─── Background Google Sync ────────────────────────────────
async function syncToGoogle(orderData: Record<string, string | number | null>): Promise<void> {
  if (!GOOGLE_SCRIPT_URL || !SHEET_SECRET_TOKEN) return;

  try {
    const payload = { _token: SHEET_SECRET_TOKEN, data: orderData };
    const body = JSON.stringify(payload);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);

    const firstRes = await fetch(GOOGLE_SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body,
      redirect: "manual",
      signal: controller.signal,
    });

    if (firstRes.status === 301 || firstRes.status === 302 || firstRes.status === 303) {
      const redirectUrl = firstRes.headers.get("location");
      if (redirectUrl) {
        const secondRes = await fetch(redirectUrl, { method: "GET", redirect: "follow", signal: controller.signal });
        clearTimeout(timeout);
        if (secondRes.ok) {
          const result = await secondRes.json();
          if (result.status === "success") {
            console.log(`✅ Order ${orderData.orderNumber} synced to Google Sheet`, result.driveLinks || "");
            return;
          }
          console.error(`❌ Google sync failed:`, result.message);
          return;
        }
      }
    }

    clearTimeout(timeout);
    if (firstRes.ok) {
      const result = await firstRes.json();
      if (result.status === "success") {
        console.log(`✅ Order ${orderData.orderNumber} synced to Google Sheet`);
      } else {
        console.error(`❌ Google sync failed:`, result.message);
      }
    } else {
      console.error(`❌ Google sync HTTP error: ${firstRes.status}`);
    }
  } catch (err) {
    console.error(`❌ Google sync error:`, err instanceof Error ? err.message : String(err));
  }
}

// ─── Save to local DB (optional) ───────────────────────────
async function saveToDatabase(data: Record<string, unknown>): Promise<void> {
  try {
    const { db } = await import("@/lib/db");
    await db.order.create({ data: data as Parameters<typeof db.order.create>[0]["data"] });
  } catch {
    // DB not available — that's fine
  }
}

// ─── Simple Rate Limiter ─────────────────────────────────────
interface RateLimitEntry { timestamps: number[]; }
const rateLimitMap = new Map<string, RateLimitEntry>();
const RATE_LIMIT_WINDOW = 60 * 1000;
const RATE_LIMIT_MAX = 10;

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(ip) || { timestamps: [] };
  entry.timestamps = entry.timestamps.filter((t) => now - t < RATE_LIMIT_WINDOW);
  if (entry.timestamps.length >= RATE_LIMIT_MAX) {
    rateLimitMap.set(ip, entry);
    return false;
  }
  entry.timestamps.push(now);
  rateLimitMap.set(ip, entry);
  if (rateLimitMap.size > 1000) {
    for (const [key, val] of rateLimitMap.entries()) {
      val.timestamps = val.timestamps.filter((t) => now - t < RATE_LIMIT_WINDOW);
      if (val.timestamps.length === 0) rateLimitMap.delete(key);
    }
  }
  return true;
}

// ─── POST Handler — One-step FormData upload ──────────────
export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    // 1. Rate limiting
    const clientIp = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "unknown";
    if (!checkRateLimit(clientIp)) {
      return NextResponse.json({ error: "طلبات كثيرة جداً. يرجى الانتظار قليلاً." }, { status: 429 });
    }

    // 2. Parse FormData (files + text in one request)
    const formData = await request.formData();

    // 3. Extract and sanitize text fields
    const fullName = sanitize((formData.get("fullName") as string) || "");
    const phone = sanitize((formData.get("phone") as string) || "");
    const pageCount = sanitizeInt(formData.get("pageCount") as string, 10, 1, MAX_PAGES);
    const paperSize = sanitize((formData.get("paperSize") as string) || "A4 - قياسي");
    const printSide = sanitize((formData.get("printSide") as string) || "وجه واحد فقط");
    const copies = sanitizeInt(formData.get("copies") as string, 1, 1, MAX_COPIES);
    const colorType = sanitize((formData.get("colorType") as string) || "أسود وأبيض");
    const bindingType = sanitize((formData.get("bindingType") as string) || "بدون تغليف");
    const payMethod = sanitize((formData.get("payMethod") as string) || "");
    const deliveryMethod = sanitize((formData.get("deliveryMethod") as string) || "استلام من المكتبة");
    const address = sanitize((formData.get("address") as string) || "");
    const notes = sanitize((formData.get("notes") as string) || "");

    // 4. Validation
    if (!fullName) return NextResponse.json({ error: "الرجاء إدخال الاسم الكامل" }, { status: 400 });
    const phoneClean = phone.replace(/\s/g, "");
    if (!phoneClean || !/^0\d{8,9}$/.test(phoneClean)) return NextResponse.json({ error: "الرجاء إدخال رقم هاتف صحيح" }, { status: 400 });
    if (pageCount < 1) return NextResponse.json({ error: "عدد الصفحات يجب أن يكون 1 على الأقل" }, { status: 400 });
    if (!payMethod) return NextResponse.json({ error: "الرجاء اختيار طريقة الدفع" }, { status: 400 });

    // 5. Process files (in-memory)
    const printFile = formData.get("printFile") as File | null;
    const receiptFile = formData.get("receiptFile") as File | null;

    if (!printFile || printFile.size === 0) {
      return NextResponse.json({ error: "الرجاء رفع ملف الطباعة" }, { status: 400 });
    }

    let printFileName: string | null = null;
    let printFileBase64: string | null = null;
    let printFileMime: string | null = null;

    if (printFile && printFile.size > 0) {
      const p = await processFile(printFile, "print");
      printFileName = p.fileName;
      printFileBase64 = p.base64Data;
      printFileMime = p.mimeType;
    }

    let receiptFileName: string | null = null;
    let receiptFileBase64: string | null = null;
    let receiptFileMime: string | null = null;

    if (payMethod !== "الدفع عند الاستلام") {
      if (!receiptFile || receiptFile.size === 0) {
        return NextResponse.json({ error: "الرجاء رفع صورة وصل التحويل" }, { status: 400 });
      }
      const p = await processFile(receiptFile, "receipt");
      receiptFileName = p.fileName;
      receiptFileBase64 = p.base64Data;
      receiptFileMime = p.mimeType;
    }

    if (deliveryMethod === "توصيل للمنزل" && !address) {
      return NextResponse.json({ error: "الرجاء إدخال عنوان التوصيل" }, { status: 400 });
    }

    // 6. Calculate price & generate order number
    const priceBreakdown = calculatePrice({ pageCount, copies, paperSize, printSide, colorType, bindingType, payMethod, deliveryMethod });
    const totalPrice = priceBreakdown.total;
    const orderNumber = generateOrderNumber();

    // 7. Save to database (don't block response)
    saveToDatabase({
      orderNumber, fullName, phone: phoneClean,
      printFileName, printFilePath: orderNumber + "/" + printFileName,
      pageCount, paperSize, printSide, copies, colorType, bindingType, payMethod,
      receiptFileName, receiptFilePath: receiptFileName ? orderNumber + "/" + receiptFileName : null,
      deliveryMethod, address: address || null, notes: notes || null,
      totalPrice, status: "جديد",
    }).catch(() => {});

    // 8. Google Sheets + Drive sync (fire-and-forget — instant response)
    const googleData: Record<string, string | number | null> = {
      orderNumber, fullName, phone: phoneClean, pageCount, paperSize, printSide,
      copies, colorType, bindingType, payMethod, totalPrice,
      printFileName, printFileData: printFileBase64, printFileMime,
      receiptFileName, receiptFileData: receiptFileBase64, receiptFileMime,
      deliveryMethod, address, notes, status: "جديد", saveToDrive: "true",
    };

    syncToGoogle(googleData)
      .then(() => console.log(`✅ Order ${orderNumber} fully synced`))
      .catch(() => console.log(`⚠️ Order ${orderNumber} sync had issues`));

    const elapsed = Date.now() - startTime;
    console.log(`⚡ Order ${orderNumber} responded in ${elapsed}ms`);

    return NextResponse.json({
      status: "success",
      order: { orderNumber, totalPrice, createdAt: new Date().toISOString() },
    });
  } catch (error) {
    console.error("[Order] Error:", error);
    const message = error instanceof Error && error.message.includes("حجم الملف")
      ? error.message
      : "حدث خطأ في معالجة الطلب. يرجى المحاولة لاحقاً.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

// ─── GET Handler (requires ADMIN_TOKEN) ────────────────────
export async function GET(request: NextRequest) {
  const authHeader = request.headers.get("authorization");
  const token = authHeader?.replace("Bearer ", "") || request.nextUrl.searchParams.get("token");

  if (!token || token !== ADMIN_TOKEN) {
    return NextResponse.json({ error: "غير مصرح بالوصول" }, { status: 401 });
  }

  try {
    const { db } = await import("@/lib/db");
    const orders = await db.order.findMany({ orderBy: { createdAt: "desc" }, take: 50 });
    return NextResponse.json({ orders });
  } catch {
    return NextResponse.json({ orders: [] }, { status: 200 });
  }
}
