"use client";

import React, { useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  User,
  FileText,
  CreditCard,
  ChevronLeft,
  Upload,
  X,
  Printer,
  MapPin,
  Phone,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles,
  ShieldCheck,
  Truck,
  Store,
  FileCheck,
  StickyNote,
  CloudUpload,
  Check,
  FolderArchive,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { calculatePrice, type PriceInput, type PriceBreakdown } from "@/lib/pricing";
import { toast } from "sonner";

// ─── Types ───────────────────────────────────────────────────
interface FormData {
  fullName: string;
  phone: string;
  pageCount: number;
  paperSize: string;
  printSide: string;
  copies: number;
  colorType: string;
  bindingType: string;
  payMethod: string;
  deliveryMethod: string;
  address: string;
  notes: string;
}

interface FieldErrors {
  [key: string]: string;
}

// ─── Client-side image compression (for receipt photos) ──────
function compressImage(file: File, maxWidth = 1200, quality = 0.7): Promise<File> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) { resolve(file); return; }
    if (file.size < 500 * 1024) { resolve(file); return; }

    const img = new Image();
    const url = URL.createObjectURL(file);

    img.onload = () => {
      URL.revokeObjectURL(url);
      const canvas = document.createElement("canvas");
      let width = img.width;
      let height = img.height;
      if (width > maxWidth) { height = Math.round((height * maxWidth) / width); width = maxWidth; }
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      if (!ctx) { resolve(file); return; }
      ctx.drawImage(img, 0, 0, width, height);
      canvas.toBlob(
        (blob) => {
          if (!blob) { resolve(file); return; }
          if (blob.size < file.size) {
            const compressedFile = new File([blob], file.name.replace(/\.[^.]+$/, ".jpg"), {
              type: "image/jpeg",
              lastModified: Date.now(),
            });
            console.log(`📷 Compressed: ${(file.size / 1024).toFixed(0)}KB → ${(blob.size / 1024).toFixed(0)}KB`);
            resolve(compressedFile);
          } else {
            resolve(file);
          }
        },
        "image/jpeg",
        quality
      );
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(file); };
    img.src = url;
  });
}

// ─── Constants ───────────────────────────────────────────────
const STEPS = [
  { id: 1, title: "معلومات التواصل", icon: User },
  { id: 2, title: "خيارات الطباعة", icon: FileText },
  { id: 3, title: "الدفع والاستلام", icon: CreditCard },
];

const INITIAL_FORM: FormData = {
  fullName: "",
  phone: "",
  pageCount: 10,
  paperSize: "A4 - قياسي",
  printSide: "وجه واحد فقط",
  copies: 1,
  colorType: "أسود وأبيض",
  bindingType: "بدون تغليف",
  payMethod: "",
  deliveryMethod: "استلام من المكتبة",
  address: "",
  notes: "",
};

// ─── Main Component ──────────────────────────────────────────
export default function OrderPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [direction, setDirection] = useState(1);
  const [form, setForm] = useState<FormData>(INITIAL_FORM);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successDialog, setSuccessDialog] = useState(false);
  const [errorDialog, setErrorDialog] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [orderNumber, setOrderNumber] = useState("");
  const [submitProgress, setSubmitProgress] = useState<{ stage: string; percent: number } | null>(null);

  const printFileRef = useRef<HTMLInputElement>(null);
  const receiptFileRef = useRef<HTMLInputElement>(null);
  const [printFile, setPrintFile] = useState<File | null>(null);
  const [receiptFile, setReceiptFile] = useState<File | null>(null);

  // ─── Price Calculation ───────────────────────────────────
  const priceBreakdown: PriceBreakdown = calculatePrice({
    pageCount: form.pageCount,
    copies: form.copies,
    paperSize: form.paperSize,
    printSide: form.printSide,
    colorType: form.colorType,
    bindingType: form.bindingType,
    payMethod: form.payMethod,
    deliveryMethod: form.deliveryMethod,
  });

  // ─── Field Updater ───────────────────────────────────────
  const updateField = useCallback(<K extends keyof FormData>(key: K, value: FormData[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => { const next = { ...prev }; delete next[key]; return next; });
  }, []);

  // ─── File Handlers ──────────────────────────────────────
  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>, field: "printFile" | "receiptFile") => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      toast.error("حجم الملف أكبر من 15MB", { description: "يرجى تصغير الملف وإعادة المحاولة" });
      return;
    }

    if (field === "printFile") {
      setPrintFile(file);
    } else {
      setReceiptFile(file);
    }
    setErrors((prev) => { const next = { ...prev }; delete next[field]; return next; });
  }, []);

  const clearFile = useCallback((field: "printFile" | "receiptFile") => {
    if (field === "printFile") {
      setPrintFile(null);
      if (printFileRef.current) printFileRef.current.value = "";
    } else {
      setReceiptFile(null);
      if (receiptFileRef.current) receiptFileRef.current.value = "";
    }
  }, []);

  // ─── Validation ──────────────────────────────────────────
  const validateStep = useCallback((step: number): boolean => {
    const newErrors: FieldErrors = {};

    if (step === 1) {
      if (!form.fullName.trim()) newErrors.fullName = "الرجاء إدخال الاسم الكامل";
      const phoneClean = form.phone.replace(/\s/g, "");
      if (!phoneClean || !/^0\d{8,9}$/.test(phoneClean)) newErrors.phone = "الرجاء إدخال رقم هاتف صحيح";
    }

    if (step === 2) {
      if (!printFile) newErrors.printFile = "الرجاء رفع ملف الطباعة";
      if (form.pageCount < 1) newErrors.pageCount = "عدد الصفحات يجب أن يكون 1 على الأقل";
    }

    if (step === 3) {
      if (!form.payMethod) newErrors.payMethod = "الرجاء اختيار طريقة الدفع";
      if (form.payMethod !== "الدفع عند الاستلام" && !receiptFile) newErrors.receiptFile = "الرجاء رفع صورة وصل التحويل";
      if (form.deliveryMethod === "توصيل للمنزل" && !form.address.trim()) newErrors.address = "الرجاء إدخال عنوان التوصيل";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [form, printFile, receiptFile]);

  // ─── Navigation ──────────────────────────────────────────
  const goNext = useCallback(() => {
    if (validateStep(currentStep)) {
      setDirection(1);
      setCurrentStep((s) => Math.min(s + 1, 3));
    }
  }, [currentStep, validateStep]);

  const goPrev = useCallback(() => {
    setDirection(-1);
    setCurrentStep((s) => Math.max(s - 1, 1));
  }, []);

  // ─── Submit (FormData with files — one request!) ────────
  const handleSubmit = useCallback(async () => {
    if (!validateStep(3)) return;
    if (!printFile) { toast.error("يرجى رفع ملف الطباعة أولاً"); return; }
    if (form.payMethod !== "الدفع عند الاستلام" && !receiptFile) { toast.error("يرجى رفع صورة وصل التحويل أولاً"); return; }

    setIsSubmitting(true);
    setSubmitProgress({ stage: "جاري تحضير الملفات...", percent: 5 });

    try {
      // Compress receipt image if needed
      let processedReceipt = receiptFile;
      if (receiptFile && receiptFile.type.startsWith("image/")) {
        setSubmitProgress({ stage: "جاري ضغط الصور...", percent: 10 });
        processedReceipt = await compressImage(receiptFile);
      }

      // Build FormData
      const fd = new FormData();
      fd.append("fullName", form.fullName.trim());
      fd.append("phone", form.phone.trim());
      fd.append("pageCount", String(form.pageCount));
      fd.append("paperSize", form.paperSize);
      fd.append("printSide", form.printSide);
      fd.append("copies", String(form.copies));
      fd.append("colorType", form.colorType);
      fd.append("bindingType", form.bindingType);
      fd.append("payMethod", form.payMethod);
      fd.append("deliveryMethod", form.deliveryMethod);
      fd.append("address", form.address.trim());
      fd.append("notes", form.notes.trim());
      fd.append("printFile", printFile);
      if (processedReceipt) fd.append("receiptFile", processedReceipt);

      // Send with XHR for progress tracking
      const result = await new Promise<{ status: string; order?: { orderNumber: string; totalPrice: number }; error?: string }>((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            const percent = Math.round((e.loaded / e.total) * 70) + 15; // 15-85% range
            setSubmitProgress({ stage: "جاري رفع الملفات...", percent });
          }
        };

        xhr.onload = () => {
          try {
            const data = JSON.parse(xhr.responseText);
            resolve(data);
          } catch {
            reject(new Error("حدث خطأ في قراءة استجابة الخادم"));
          }
        };

        xhr.onerror = () => reject(new Error("تعذر الاتصال بالخادم. تحقق من اتصالك بالإنترنت."));
        xhr.ontimeout = () => reject(new Error("انتهت مهلة الاتصال. يرجى المحاولة مرة أخرى."));

        setSubmitProgress({ stage: "جاري رفع الملفات...", percent: 15 });
        xhr.open("POST", "/api/orders");
        xhr.timeout = 300000; // 5 minutes for large files
        xhr.send(fd);
      });

      setSubmitProgress({ stage: "تم المعالجة!", percent: 100 });

      if (result.status === "success" && result.order) {
        setOrderNumber(result.order.orderNumber);
        setSuccessDialog(true);
      } else {
        const rawError = result.error || "حدث خطأ غير متوقع";
        setErrorMessage(rawError);
        setErrorDialog(true);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "تعذر الاتصال بالخادم. يرجى التحقق من اتصالك بالإنترنت.";
      setErrorMessage(msg);
      setErrorDialog(true);
    } finally {
      setIsSubmitting(false);
      setSubmitProgress(null);
    }
  }, [form, printFile, receiptFile, validateStep]);

  // ─── Reset Form ──────────────────────────────────────────
  const resetForm = useCallback(() => {
    setForm(INITIAL_FORM);
    setErrors({});
    setCurrentStep(1);
    setDirection(1);
    setSuccessDialog(false);
    setErrorDialog(false);
    setOrderNumber("");
    setPrintFile(null);
    setReceiptFile(null);
    setSubmitProgress(null);
    if (printFileRef.current) printFileRef.current.value = "";
    if (receiptFileRef.current) receiptFileRef.current.value = "";
  }, []);

  // ─── Can move to next step? ──────────────────────────────
  const canGoNext = (() => {
    if (currentStep === 1) return !!(form.fullName.trim() && /^0\d{8,9}$/.test(form.phone.replace(/\s/g, "")));
    if (currentStep === 2) return !!(printFile && form.pageCount >= 1);
    return false;
  })();

  const canSubmit = (() => {
    if (!printFile) return false;
    if (!form.payMethod) return false;
    if (form.payMethod !== "الدفع عند الاستلام" && !receiptFile) return false;
    if (form.deliveryMethod === "توصيل للمنزل" && !form.address.trim()) return false;
    return true;
  })();

  // ─── Animation Variants ──────────────────────────────────
  const slideVariants = {
    enter: (direction: number) => ({ x: direction > 0 ? -80 : 80, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (direction: number) => ({ x: direction > 0 ? 80 : -80, opacity: 0 }),
  };

  // ─── Render ──────────────────────────────────────────────
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* ── Header ──────────────────────────────────────────── */}
      <header className="bg-gradient-to-l from-emerald-600 to-teal-700 text-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 mb-4">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Printer className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white">
                فضاء الطباعة الرقمية
              </h1>
            </div>
            <p className="text-base sm:text-lg text-emerald-100 max-w-2xl mx-auto leading-relaxed">
              أرسل تفاصيل طلبك بسهولة واختر جميع خيارات الطباعة والتغليف والدفع.
              سيتم حساب السعر تلقائياً وحفظ طلبك مباشرةً وسنتواصل معك فوراً.
            </p>
          </motion.div>
        </div>
      </header>

      {/* ── Main Content ──────────────────────────────────── */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-10">
        {/* Step Indicator */}
        <StepIndicator steps={STEPS} currentStep={currentStep} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          {/* Form Area */}
          <div className="lg:col-span-2">
            <Card className="border-0 shadow-xl shadow-slate-200/50 dark:shadow-none dark:border dark:border-slate-800 rounded-2xl overflow-hidden">
              <CardContent className="p-5 sm:p-8">
                <AnimatePresence mode="wait" custom={direction}>
                  <motion.div
                    key={currentStep}
                    custom={direction}
                    variants={slideVariants}
                    initial="enter"
                    animate="center"
                    exit="exit"
                    transition={{ duration: 0.35, ease: "easeInOut" }}
                  >
                    {currentStep === 1 && (
                      <Step1Contact form={form} errors={errors} updateField={updateField} />
                    )}
                    {currentStep === 2 && (
                      <Step2PrintOptions
                        form={form}
                        errors={errors}
                        updateField={updateField}
                        printFile={printFile}
                        printFileRef={printFileRef}
                        onFileSelect={(e) => handleFileSelect(e, "printFile")}
                        onClearFile={() => clearFile("printFile")}
                      />
                    )}
                    {currentStep === 3 && (
                      <Step3Payment
                        form={form}
                        errors={errors}
                        updateField={updateField}
                        receiptFile={receiptFile}
                        receiptFileRef={receiptFileRef}
                        onFileSelect={(e) => handleFileSelect(e, "receiptFile")}
                        onClearFile={() => clearFile("receiptFile")}
                      />
                    )}
                  </motion.div>
                </AnimatePresence>

                {/* Navigation Buttons */}
                <div className="flex items-center justify-between mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">
                  {currentStep > 1 ? (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={goPrev}
                      className="gap-2 rounded-xl h-12 px-6"
                    >
                      <ChevronLeft className="w-4 h-4 rotate-180" />
                      السابق
                    </Button>
                  ) : (
                    <div />
                  )}

                  {currentStep < 3 ? (
                    <Button
                      type="button"
                      onClick={goNext}
                      disabled={!canGoNext}
                      className="gap-2 rounded-xl px-8 bg-gradient-to-l from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white h-12 text-base font-bold"
                    >
                      التالي
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      onClick={handleSubmit}
                      disabled={isSubmitting || !canSubmit}
                      className="gap-2 rounded-xl px-8 bg-gradient-to-l from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-lg shadow-emerald-600/25 h-12 text-base font-bold min-w-[200px]"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          جاري الإرسال...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-5 h-5" />
                          تأكيد وإرسال الطلب
                        </>
                      )}
                    </Button>
                  )}
                </div>

                {/* Upload Progress Bar */}
                <AnimatePresence>
                  {submitProgress && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-6 space-y-3"
                    >
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
                          <CloudUpload className="w-4 h-4 animate-pulse" />
                          {submitProgress.stage}
                        </span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-mono font-bold">
                          {submitProgress.percent}%
                        </span>
                      </div>
                      <Progress value={submitProgress.percent} className="h-3 rounded-full" />
                      <p className="text-xs text-muted-foreground text-center">
                        يرجى الانتظار وعدم إغلاق الصفحة حتى يكتمل الرفع...
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>

          {/* Price Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-6">
              <PriceSummary form={form} breakdown={priceBreakdown} hasFile={!!printFile} hasReceipt={!!receiptFile} />
            </div>
          </div>
        </div>
      </main>

      {/* ── Footer ────────────────────────────────────────── */}
      <footer className="mt-auto border-t border-slate-200 dark:border-slate-800 bg-white/60 dark:bg-slate-900/60 backdrop-blur-sm">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} فضاء الطباعة الرقمية — جميع الحقوق محفوظة
          </p>
          <a
            href="/download"
            download="project-source.tar.gz"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors border border-slate-200 dark:border-slate-700"
          >
            <FolderArchive className="w-4 h-4" />
            تحميل المشروع
          </a>
        </div>
      </footer>

      {/* ── Success Dialog ────────────────────────────────── */}
      <Dialog open={successDialog} onOpenChange={(open) => { if (!open) resetForm(); }}>
        <DialogContent className="sm:max-w-md rounded-2xl text-center">
          <DialogHeader className="items-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
              className="w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center mx-auto mb-4"
            >
              <CheckCircle2 className="w-12 h-12 text-emerald-600" />
            </motion.div>
            <DialogTitle className="text-2xl font-extrabold">تم إرسال طلبك بنجاح!</DialogTitle>
            <DialogDescription className="text-base leading-relaxed mt-2">
              رقم الطلب: <span className="font-mono font-bold text-emerald-600 text-lg">{orderNumber}</span>
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800">
            <p className="text-sm text-emerald-700 dark:text-emerald-300 leading-relaxed">
              سيتم مراجعة طلبك والتواصل معك قريباً. احتفظ برقم الطلب للمتابعة.
            </p>
          </div>
          <Button onClick={resetForm} className="mt-4 w-full rounded-xl h-12 bg-gradient-to-l from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold">
            إرسال طلب جديد
          </Button>
        </DialogContent>
      </Dialog>

      {/* ── Error Dialog ──────────────────────────────────── */}
      <Dialog open={errorDialog} onOpenChange={setErrorDialog}>
        <DialogContent className="sm:max-w-md rounded-2xl text-center">
          <DialogHeader className="items-center">
            <div className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-900/50 flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-10 h-10 text-red-600" />
            </div>
            <DialogTitle className="text-xl font-bold">حدث خطأ</DialogTitle>
            <DialogDescription className="text-base mt-2">{errorMessage}</DialogDescription>
          </DialogHeader>
          <Button onClick={() => setErrorDialog(false)} className="mt-4 w-full rounded-xl h-12">
            حسناً
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Step Indicator ──────────────────────────────────────────
function StepIndicator({ steps, currentStep }: { steps: typeof STEPS; currentStep: number }) {
  return (
    <div className="flex items-center justify-center gap-2 sm:gap-4">
      {steps.map((step, i) => {
        const isActive = step.id === currentStep;
        const isDone = step.id < currentStep;
        const Icon = step.icon;
        return (
          <React.Fragment key={step.id}>
            {i > 0 && <div className={`h-0.5 w-8 sm:w-16 rounded-full transition-colors ${isDone ? "bg-emerald-500" : "bg-slate-200 dark:bg-slate-700"}`} />}
            <div className="flex items-center gap-2">
              <motion.div
                animate={{ scale: isActive ? 1.1 : 1 }}
                className={`w-10 h-10 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center transition-all ${
                  isActive ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/25"
                  : isDone ? "bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-400"
                }`}
              >
                {isDone ? <Check className="w-5 h-5" /> : <Icon className="w-5 h-5" />}
              </motion.div>
              <span className={`text-sm font-bold hidden sm:inline ${isActive ? "text-emerald-700 dark:text-emerald-400" : "text-slate-400"}`}>
                {step.title}
              </span>
            </div>
          </React.Fragment>
        );
      })}
    </div>
  );
}

// ─── Step 1: Contact Info ────────────────────────────────────
function Step1Contact({ form, errors, updateField }: {
  form: FormData; errors: FieldErrors; updateField: <K extends keyof FormData>(key: K, value: FormData[K]) => void;
}) {
  return (
    <div className="space-y-5">
      <h2 className="text-xl font-extrabold flex items-center gap-2">
        <User className="w-5 h-5 text-emerald-600" />
        معلومات التواصل
      </h2>
      <div className="space-y-4">
        <div>
          <Label htmlFor="fullName" className="text-sm font-bold mb-1.5 block">الاسم الكامل</Label>
          <Input id="fullName" value={form.fullName} onChange={(e) => updateField("fullName", e.target.value)} placeholder="أدخل اسمك الكامل" className={`rounded-xl h-12 ${errors.fullName ? "border-red-400" : ""}`} />
          {errors.fullName && <p className="text-red-500 text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.fullName}</p>}
        </div>
        <div>
          <Label htmlFor="phone" className="text-sm font-bold mb-1.5 block">رقم الهاتف</Label>
          <div className="relative">
            <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input id="phone" type="tel" value={form.phone} onChange={(e) => updateField("phone", e.target.value)} placeholder="0XXXXXXXXX" className={`rounded-xl h-12 pr-10 ${errors.phone ? "border-red-400" : ""}`} dir="ltr" />
          </div>
          {errors.phone && <p className="text-red-500 text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.phone}</p>}
        </div>
      </div>
    </div>
  );
}

// ─── Step 2: Print Options ───────────────────────────────────
function Step2PrintOptions({ form, errors, updateField, printFile, printFileRef, onFileSelect, onClearFile }: {
  form: FormData; errors: FieldErrors; updateField: <K extends keyof FormData>(key: K, value: FormData[K]) => void;
  printFile: File | null; printFileRef: React.RefObject<HTMLInputElement | null>;
  onFileSelect: (e: React.ChangeEvent<HTMLInputElement>) => void; onClearFile: () => void;
}) {
  return (
    <div className="space-y-5">
      <h2 className="text-xl font-extrabold flex items-center gap-2">
        <FileText className="w-5 h-5 text-emerald-600" />
        خيارات الطباعة
      </h2>

      {/* File Upload */}
      <div>
        <Label className="text-sm font-bold mb-1.5 block">ملف الطباعة</Label>
        <p className="text-xs text-muted-foreground mb-2">
          الحد الأقصى لحجم الملف: <strong>15 ميجابايت</strong>. يدعم PDF — Word — PowerPoint — صور.
        </p>
        <FileUploadZone
          file={printFile}
          error={errors.printFile}
          onFileSelect={onFileSelect}
          onClear={onClearFile}
          fileRef={printFileRef}
          accept=".pdf,.doc,.docx,.ppt,.pptx,.jpg,.jpeg,.png,.gif,.webp"
          icon={<FileCheck className="w-7 h-7 text-emerald-600" />}
          title="اسحب الملف هنا أو اضغط للرفع"
          subtitle="PDF — Word — PowerPoint — صور (حد أقصى 15MB)"
          id="printFile"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="pageCount" className="text-sm font-bold mb-1.5 block">عدد الصفحات</Label>
          <Input id="pageCount" type="number" min={1} max={500} value={form.pageCount} onChange={(e) => updateField("pageCount", parseInt(e.target.value) || 1)} className={`rounded-xl h-12 ${errors.pageCount ? "border-red-400" : ""}`} />
          {errors.pageCount && <p className="text-red-500 text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.pageCount}</p>}
        </div>
        <div>
          <Label htmlFor="copies" className="text-sm font-bold mb-1.5 block">عدد النسخ</Label>
          <Input id="copies" type="number" min={1} max={100} value={form.copies} onChange={(e) => updateField("copies", parseInt(e.target.value) || 1)} className="rounded-xl h-12" />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label className="text-sm font-bold mb-1.5 block">حجم الورق</Label>
          <select value={form.paperSize} onChange={(e) => updateField("paperSize", e.target.value)} className="w-full h-12 rounded-xl border border-input bg-background px-3 text-sm">
            <option>A5 - صغير</option><option>A4 - قياسي</option><option>A3 - كبير</option>
          </select>
        </div>
        <div>
          <Label className="text-sm font-bold mb-1.5 block">طريقة الطباعة</Label>
          <select value={form.printSide} onChange={(e) => updateField("printSide", e.target.value)} className="w-full h-12 rounded-xl border border-input bg-background px-3 text-sm">
            <option>وجه واحد فقط</option><option>على الوجهين</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label className="text-sm font-bold mb-1.5 block">نوع الألوان</Label>
          <select value={form.colorType} onChange={(e) => updateField("colorType", e.target.value)} className="w-full h-12 rounded-xl border border-input bg-background px-3 text-sm">
            <option>أسود وأبيض</option><option>ملون</option>
          </select>
        </div>
        <div>
          <Label className="text-sm font-bold mb-1.5 block">نوع التغليف</Label>
          <select value={form.bindingType} onChange={(e) => updateField("bindingType", e.target.value)} className="w-full h-12 rounded-xl border border-input bg-background px-3 text-sm">
            <option>بدون تغليف</option><option>تغليف سلكي</option><option>تغليف حراري</option>
          </select>
        </div>
      </div>
    </div>
  );
}

// ─── Step 3: Payment & Delivery ──────────────────────────────
function Step3Payment({ form, errors, updateField, receiptFile, receiptFileRef, onFileSelect, onClearFile }: {
  form: FormData; errors: FieldErrors; updateField: <K extends keyof FormData>(key: K, value: FormData[K]) => void;
  receiptFile: File | null; receiptFileRef: React.RefObject<HTMLInputElement | null>;
  onFileSelect: (e: React.ChangeEvent<HTMLInputElement>) => void; onClearFile: () => void;
}) {
  const showReceipt = form.payMethod && form.payMethod !== "الدفع عند الاستلام";

  return (
    <div className="space-y-5">
      <h2 className="text-xl font-extrabold flex items-center gap-2">
        <CreditCard className="w-5 h-5 text-emerald-600" />
        الدفع والاستلام
      </h2>

      {/* Payment Method */}
      <div>
        <Label className="text-sm font-bold mb-1.5 block">طريقة الدفع</Label>
        <div className="grid grid-cols-2 gap-2">
          {[
            { value: "بريدي موب", label: "بريدي موب", discount: true },
            { value: "CCP", label: "CCP", discount: true },
            { value: "Baridimob", label: "بريدي موب", discount: true },
            { value: "الدفع عند الاستلام", label: "الدفع عند الاستلام", discount: false },
          ].map((method) => (
            <motion.button
              key={method.value}
              type="button"
              whileTap={{ scale: 0.97 }}
              onClick={() => updateField("payMethod", method.value)}
              className={`relative p-3 rounded-xl border-2 text-sm font-bold transition-all ${
                form.payMethod === method.value
                  ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300"
                  : "border-slate-200 dark:border-slate-700 hover:border-emerald-300"
              }`}
            >
              {method.label}
              {method.discount && (
                <Badge className="absolute -top-2 -left-2 text-[10px] bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300 border-0">
                  خصم 10%
                </Badge>
              )}
            </motion.button>
          ))}
        </div>
        {errors.payMethod && <p className="text-red-500 text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.payMethod}</p>}
      </div>

      {/* Receipt Upload */}
      {showReceipt && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}>
          <Label className="text-sm font-bold mb-1.5 block">صورة وصل التحويل</Label>
          <FileUploadZone
            file={receiptFile}
            error={errors.receiptFile}
            onFileSelect={onFileSelect}
            onClear={onClearFile}
            fileRef={receiptFileRef}
            accept=".jpg,.jpeg,.png,.pdf,.webp"
            icon={<StickyNote className="w-7 h-7 text-emerald-600" />}
            title="اسحب الصورة هنا أو اضغط للرفع"
            subtitle="JPG — PNG — PDF (سيتم ضغط الصور تلقائياً لرفع أسرع)"
            id="receiptFile"
          />
        </motion.div>
      )}

      {/* Delivery Method */}
      <div>
        <Label className="text-sm font-bold mb-1.5 block">طريقة الاستلام</Label>
        <div className="grid grid-cols-2 gap-2">
          <motion.button
            type="button"
            whileTap={{ scale: 0.97 }}
            onClick={() => updateField("deliveryMethod", "استلام من المكتبة")}
            className={`p-3 rounded-xl border-2 text-sm font-bold transition-all flex items-center justify-center gap-2 ${
              form.deliveryMethod === "استلام من المكتبة"
                ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300"
                : "border-slate-200 dark:border-slate-700 hover:border-emerald-300"
            }`}
          >
            <Store className="w-4 h-4" />
            استلام من المكتبة
          </motion.button>
          <motion.button
            type="button"
            whileTap={{ scale: 0.97 }}
            onClick={() => updateField("deliveryMethod", "توصيل للمنزل")}
            className={`p-3 rounded-xl border-2 text-sm font-bold transition-all flex items-center justify-center gap-2 ${
              form.deliveryMethod === "توصيل للمنزل"
                ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300"
                : "border-slate-200 dark:border-slate-700 hover:border-emerald-300"
            }`}
          >
            <Truck className="w-4 h-4" />
            توصيل للمنزل
          </motion.button>
        </div>
      </div>

      {/* Address (if delivery) */}
      {form.deliveryMethod === "توصيل للمنزل" && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}>
          <Label htmlFor="address" className="text-sm font-bold mb-1.5 block">عنوان التوصيل</Label>
          <div className="relative">
            <MapPin className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
            <Input id="address" value={form.address} onChange={(e) => updateField("address", e.target.value)} placeholder="أدخل عنوانك بالتفصيل" className={`rounded-xl pr-10 ${errors.address ? "border-red-400" : ""}`} />
          </div>
          {errors.address && <p className="text-red-500 text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.address}</p>}
        </motion.div>
      )}

      {/* Notes */}
      <div>
        <Label htmlFor="notes" className="text-sm font-bold mb-1.5 block">ملاحظات (اختياري)</Label>
        <Textarea id="notes" value={form.notes} onChange={(e) => updateField("notes", e.target.value)} placeholder="أي ملاحظات إضافية..." className="rounded-xl min-h-[80px]" />
      </div>
    </div>
  );
}

// ─── File Upload Zone ────────────────────────────────────────
function FileUploadZone({
  file,
  error,
  onFileSelect,
  onClear,
  fileRef,
  accept,
  icon,
  title,
  subtitle,
  id,
}: {
  file: File | null;
  error?: string;
  onFileSelect: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onClear: () => void;
  fileRef: React.RefObject<HTMLInputElement | null>;
  accept: string;
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  id: string;
}) {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(true); };
  const handleDragLeave = () => setIsDragging(false);
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) {
      const dt = new DataTransfer();
      dt.items.add(f);
      if (fileRef.current) {
        fileRef.current.files = dt.files;
        fileRef.current.dispatchEvent(new Event("change", { bubbles: true }));
      }
    }
  };

  const fileSize = file ? (file.size > 1024 * 1024 ? (file.size / (1024 * 1024)).toFixed(1) + " MB" : (file.size / 1024).toFixed(0) + " KB") : "";

  const getFileColor = (name: string) => {
    const ext = name.split(".").pop()?.toLowerCase();
    if (ext === "pdf") return "bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400";
    if (["doc", "docx"].includes(ext || "")) return "bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400";
    if (["ppt", "pptx"].includes(ext || "")) return "bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400";
    if (["jpg", "jpeg", "png", "gif", "webp"].includes(ext || "")) return "bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400";
    return "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400";
  };

  return (
    <div className="space-y-3">
      <input type="file" ref={fileRef} id={id} accept={accept} onChange={onFileSelect} className="hidden" />
      {!file ? (
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileRef.current?.click()}
          className={`relative border-2 border-dashed rounded-2xl p-6 sm:p-8 text-center cursor-pointer transition-all ${
            isDragging ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 scale-[1.02]"
            : error ? "border-red-300 bg-red-50/50 dark:bg-red-900/10"
            : "border-slate-300 dark:border-slate-600 bg-slate-50/50 dark:bg-slate-800/50 hover:border-emerald-400 hover:bg-emerald-50/50 dark:hover:bg-emerald-900/10"
          }`}
        >
          <div className="flex flex-col items-center gap-2">
            <motion.div animate={isDragging ? { scale: 1.1, y: -5 } : { scale: 1, y: 0 }} className="w-14 h-14 rounded-2xl bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center">
              {icon}
            </motion.div>
            <h3 className="font-bold text-emerald-800 dark:text-emerald-300">{title}</h3>
            <p className="text-xs text-muted-foreground">{subtitle}</p>
          </div>
        </div>
      ) : (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border-2 border-emerald-300 dark:border-emerald-700 bg-emerald-50/50 dark:bg-emerald-900/20 p-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold ${getFileColor(file.name)}`}>
              {file.name.split(".").pop()?.toUpperCase().slice(0, 3) || "?"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm truncate">{file.name}</p>
              <p className="text-xs text-muted-foreground">{fileSize} — جاهز للإرسال</p>
            </div>
            <button type="button" onClick={onClear} className="p-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-red-500 transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}
      {error && <p className="text-red-500 text-xs flex items-center gap-1"><AlertCircle className="w-3 h-3" />{error}</p>}
    </div>
  );
}

// ─── Price Summary Sidebar ───────────────────────────────────
function PriceSummary({ form, breakdown, hasFile, hasReceipt }: {
  form: FormData; breakdown: PriceBreakdown; hasFile: boolean; hasReceipt: boolean;
}) {
  return (
    <Card className="border-0 shadow-xl shadow-slate-200/50 dark:shadow-none dark:border dark:border-slate-800 rounded-2xl sticky top-6">
      <CardContent className="p-5 space-y-4">
        <h3 className="font-extrabold text-lg flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-emerald-600" />
          ملخص السعر
        </h3>
        <Separator />

        <div className="space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-muted-foreground">عدد الصفحات</span><span className="font-bold">{form.pageCount}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">عدد النسخ</span><span className="font-bold">{form.copies}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">حجم الورق</span><span className="font-bold">{form.paperSize}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">الطباعة</span><span className="font-bold">{form.printSide}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">الألوان</span><span className="font-bold">{form.colorType}</span></div>
          {form.bindingType !== "بدون تغليف" && (
            <div className="flex justify-between"><span className="text-muted-foreground">التغليف</span><span className="font-bold">{form.bindingType}</span></div>
          )}
          {form.deliveryMethod === "توصيل للمنزل" && (
            <div className="flex justify-between"><span className="text-muted-foreground">التوصيل</span><span className="font-bold">80 د.ج</span></div>
          )}
        </div>

        <Separator />

        <div className="flex justify-between items-center">
          <span className="text-base font-extrabold">الإجمالي</span>
          <motion.span
            key={breakdown.total}
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400"
          >
            {breakdown.total} د.ج
          </motion.span>
        </div>

        {/* File status badges */}
        <div className="space-y-2 pt-2">
          <div className="flex items-center gap-2">
            {hasFile ? (
              <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-0 gap-1">
                <CheckCircle2 className="w-3 h-3" /> ملف الطباعة جاهز
              </Badge>
            ) : (
              <Badge variant="outline" className="text-muted-foreground gap-1">
                <Upload className="w-3 h-3" /> لم يُرفع ملف
              </Badge>
            )}
          </div>
          {form.payMethod && form.payMethod !== "الدفع عند الاستلام" && (
            <div className="flex items-center gap-2">
              {hasReceipt ? (
                <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-0 gap-1">
                  <CheckCircle2 className="w-3 h-3" /> وصل التحويل جاهز
                </Badge>
              ) : (
                <Badge variant="outline" className="text-amber-600 border-amber-300 gap-1">
                  <AlertCircle className="w-3 h-3" /> يلزم رفع وصل التحويل
                </Badge>
              )}
            </div>
          )}
        </div>

        {/* Discount hint */}
        {form.payMethod !== "بريدي موب" && form.payMethod !== "CCP" && form.payMethod !== "Baridimob" && (
          <div className="p-3 rounded-lg bg-teal-50 dark:bg-teal-900/20 border border-teal-200 dark:border-teal-800">
            <p className="text-xs text-teal-700 dark:text-teal-300 font-medium flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              ادفع ببريدي موب أو CCP واحصل على خصم 10%
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
