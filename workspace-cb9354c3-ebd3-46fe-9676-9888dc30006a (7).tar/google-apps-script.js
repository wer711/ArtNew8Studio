/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  فضاء الطباعة الرقمية — سكريبت جوجل (Google Apps Script)
 *  ربط مع Google Sheets + Google Drive
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  ⚡ الإصدار الجديد — إصلاح تداخل الأعمدة:
 *  ─────────────────────────────────────────────────────────────────────────
 *  بدلاً من الاعتماد على ترتيب الأعمدة (الذي يسبب التداخل)،
 *  السكريبت الآن يبحث عن كل عمود بالاسم ويضع البيانات في المكان الصحيح.
 *  هذا يعني حتى لو تغير ترتيب الأعمدة أو أُضيفت أعمدة جديدة،
 *  البيانات ستذهب دائماً للعمود الصحيح!
 *  ─────────────────────────────────────────────────────────────────────────
 *
 *  📋 تعليمات النشر:
 *  ─────────────────────────────────────────────────────────────────────────
 *  1. افتح Google Apps Script: https://script.google.com
 *  2. افتح المشروع الحالي (لا تنشئ جديد)
 *  3. استبدل الكود بالكامل بهذا الكود
 *  4. ⚠️ تأكد أن SECRET_TOKEN يطابق SHEET_SECRET_TOKEN في .env
 *  5. اضغط "نشر" → "نشر كتطبيق ويب"
 *     - وصف الإصدار: "إصلاح تداخل الأعمدة"
 *     - تنفيذ باسم: أنا (حساب التاجر)
 *     - من يمكنه الوصول: أي شخص
 *  6. انشر وانتظر
 *  7. ⚠️ مهم: احذف أي صفوف قديمة بأعمدة متداخلة من الشيت يدوياً
 *
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ─── الإعدادات ──────────────────────────────────────────────────────────
var CONFIG = {
  SHEET_ID: "1-NhEn-Cg02mcPeAesfzqzmsH1bFS3hR3t791ityqOMw",
  SHEET_NAME: "الطلبات",
  DRIVE_FOLDER_ID: "16asJMEO7sGG9kb-Rqs2amSM0i3Z4qHEA",
  SECRET_TOKEN: "ffc0b9b5959d4a9149eed95327b88f02b1c6ee8b64a723d2",
};

// ─── تعريف الأعمدة المطلوبة (الترتيب مهم فقط عند إنشاء الشيت لأول مرة) ──
var COLUMNS = [
  { key: "orderNumber",    header: "رقم الطلب",         width: 150 },
  { key: "fullName",       header: "الاسم الكامل",      width: 180 },
  { key: "phone",          header: "رقم الهاتف",        width: 130 },
  { key: "pageCount",      header: "عدد الصفحات",       width: 100 },
  { key: "paperSize",      header: "حجم الورق",         width: 120 },
  { key: "printSide",      header: "طريقة الطباعة",     width: 120 },
  { key: "copies",         header: "عدد النسخ",         width: 100 },
  { key: "colorType",      header: "نوع الألوان",       width: 120 },
  { key: "bindingType",    header: "نوع التغليف",       width: 120 },
  { key: "payMethod",      header: "طريقة الدفع",       width: 120 },
  { key: "totalPrice",     header: "السعر الإجمالي",    width: 120 },
  { key: "printFileName",  header: "اسم ملف الطباعة",   width: 180 },
  { key: "printFileUrl",   header: "رابط ملف الطباعة",  width: 200 },
  { key: "receiptFileName",header: "اسم وصل التحويل",   width: 180 },
  { key: "receiptFileUrl", header: "رابط وصل التحويل",  width: 200 },
  { key: "deliveryMethod", header: "طريقة الاستلام",    width: 120 },
  { key: "address",        header: "العنوان",           width: 200 },
  { key: "notes",          header: "ملاحظات",           width: 200 },
  { key: "status",         header: "الحالة",            width: 100 },
  { key: "timestamp",      header: "التاريخ والوقت",    width: 180 },
];

// ─── معالجة طلبات POST ──────────────────────────────────────────────────
function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) {
      return sendResponse({ status: "error", message: "لا توجد بيانات" });
    }

    var payload;
    try {
      payload = JSON.parse(e.postData.contents);
    } catch (parseErr) {
      return sendResponse({ status: "error", message: "بيانات غير صالحة" });
    }

    var token = payload._token;
    var data = payload.data;

    if (token !== CONFIG.SECRET_TOKEN) {
      console.error("❌ التوكن غير متطابق!");
      return sendResponse({ status: "error", message: "رمز الأمان غير صالح" });
    }

    if (!data || !data.orderNumber) {
      return sendResponse({ status: "error", message: "البيانات غير مكتملة" });
    }

    console.log("✅ توكن صحيح — جاري معالجة الطلب: " + data.orderNumber);

    // حفظ الملفات في جوجل درايف
    var driveLinks = {};

    if (data.printFileData && data.saveToDrive) {
      try {
        var printUrl = saveFileToDrive(
          data.printFileData,
          data.printFileName || "print-file",
          data.printFileMime || "application/pdf",
          data.orderNumber
        );
        driveLinks.printFileUrl = printUrl;
        console.log("✅ تم رفع ملف الطباعة");
      } catch (driveErr) {
        console.error("❌ خطأ في حفظ ملف الطباعة: " + driveErr.toString());
      }
    }

    if (data.receiptFileData && data.saveToDrive) {
      try {
        var receiptUrl = saveFileToDrive(
          data.receiptFileData,
          data.receiptFileName || "receipt-file",
          data.receiptFileMime || "image/jpeg",
          data.orderNumber
        );
        driveLinks.receiptFileUrl = receiptUrl;
        console.log("✅ تم رفع وصل التحويل");
      } catch (driveErr) {
        console.error("❌ خطأ في حفظ وصل التحويل: " + driveErr.toString());
      }
    }

    // حفظ البيانات في الشيت (باستخدام mapping بالأسماء — لا تداخل!)
    saveToSheet(data, driveLinks);

    console.log("✅ تم حفظ الطلب بنجاح: " + data.orderNumber);

    return sendResponse({
      status: "success",
      message: "تم حفظ الطلب والملفات بنجاح",
      driveLinks: driveLinks,
    });
  } catch (error) {
    console.error("❌ خطأ عام: " + error.toString());
    return sendResponse({ status: "error", message: error.toString() });
  }
}

// ─── معالجة طلبات GET ───────────────────────────────────────────────────
function doGet(e) {
  return sendResponse({
    status: "ok",
    message: "خدمة فضاء الطباعة الرقمية تعمل بشكل طبيعي ✅",
    sheetId: CONFIG.SHEET_ID,
    driveFolder: CONFIG.DRIVE_FOLDER_ID,
  });
}

// ─── حفظ ملف في جوجل درايف ─────────────────────────────────────────────
function saveFileToDrive(base64Data, fileName, mimeType, orderNumber) {
  var folder = DriveApp.getFolderById(CONFIG.DRIVE_FOLDER_ID);

  var orderFolder;
  var existingFolders = folder.getFoldersByName(orderNumber);
  if (existingFolders.hasNext()) {
    orderFolder = existingFolders.next();
  } else {
    orderFolder = folder.createFolder(orderNumber);
  }

  var decoded = Utilities.base64Decode(base64Data);
  var blob = Utilities.newBlob(decoded, mimeType, fileName);
  var file = orderFolder.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

  return file.getUrl();
}

// ─── حفظ البيانات في الشيت (بـ header mapping — لا تداخل أبداً!) ────────
function saveToSheet(data, driveLinks) {
  var ss = SpreadsheetApp.openById(CONFIG.SHEET_ID);
  var sheet = ss.getSheetByName(CONFIG.SHEET_NAME);

  // إنشاء الورقة إذا لم تكن موجودة
  if (!sheet) {
    sheet = ss.insertSheet(CONFIG.SHEET_NAME);
  }

  // بناء خريطة الأعمدة: اسم العمود → رقم العمود
  var columnMap = buildColumnMap(sheet);

  // إضافة البيانات باستخدام الخريطة (كل قيمة في العمود الصحيح)
  var lastRow = sheet.getLastRow();
  var newRow = lastRow + 1;

  // تجهيز البيانات حسب المفاتيح
  var dataMap = {
    orderNumber:    data.orderNumber,
    fullName:       data.fullName,
    phone:          data.phone,
    pageCount:      data.pageCount,
    paperSize:      data.paperSize,
    printSide:      data.printSide,
    copies:         data.copies,
    colorType:      data.colorType,
    bindingType:    data.bindingType,
    payMethod:      data.payMethod,
    totalPrice:     data.totalPrice,
    printFileName:  data.printFileName || "",
    printFileUrl:   driveLinks.printFileUrl || "",
    receiptFileName: data.receiptFileName || "",
    receiptFileUrl: driveLinks.receiptFileUrl || "",
    deliveryMethod: data.deliveryMethod,
    address:        data.address || "",
    notes:          data.notes || "",
    status:         data.status || "جديد",
    timestamp:      new Date().toLocaleString("ar-DZ", { timeZone: "Africa/Algiers" }),
  };

  // كتابة كل قيمة في العمود الصحيح
  for (var key in dataMap) {
    if (dataMap.hasOwnProperty(key) && columnMap[key]) {
      var colNum = columnMap[key];
      var value = dataMap[key];

      // تحويل روابط درايف إلى روابط قابلة للنقر
      if ((key === "printFileUrl" || key === "receiptFileUrl") && value) {
        try {
          var label = key === "printFileUrl" ? "📎 فتح ملف الطباعة" : "📎 فتح وصل التحويل";
          sheet.getRange(newRow, colNum).setFormula(
            '=HYPERLINK("' + value + '", "' + label + '")'
          );
        } catch (e) {
          sheet.getRange(newRow, colNum).setValue(value);
        }
      } else {
        sheet.getRange(newRow, colNum).setValue(value);
      }
    }
  }

  console.log("✅ تم حفظ الطلب في الشيت - صف " + newRow);
}

// ─── بناء خريطة الأعمدة من العناوين الموجودة ────────────────────────────
// هذه الدالة تقرأ العناوين من الصف الأول وتبني خريطة:
// { "رقم الطلب": 1, "الاسم الكامل": 2, ... }
// هذا يضمن أن البيانات تذهب دائماً للعمود الصحيح
function buildColumnMap(sheet) {
  var lastRow = sheet.getLastRow();

  // إذا كانت الورقة فارغة، أنشئ العناوين أولاً
  if (lastRow === 0) {
    var headers = [];
    var widths = [];
    for (var i = 0; i < COLUMNS.length; i++) {
      headers.push(COLUMNS[i].header);
      widths.push(COLUMNS[i].width);
    }

    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);

    // تنسيق العناوين
    var headerRange = sheet.getRange(1, 1, 1, headers.length);
    headerRange.setFontWeight("bold");
    headerRange.setBackground("#059669");
    headerRange.setFontColor("#FFFFFF");
    sheet.setFrozenRows(1);

    // تعيين عرض الأعمدة
    for (var w = 0; w < widths.length; w++) {
      sheet.setColumnWidth(w + 1, widths[w]);
    }
  }

  // قراءة العناوين من الصف الأول
  var headerRow = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];

  // بناء خريطة: key → رقم العمود
  var columnMap = {};
  for (var i = 0; i < COLUMNS.length; i++) {
    var col = COLUMNS[i];
    var headerName = col.header;

    // البحث عن العمود بالاسم
    for (var j = 0; j < headerRow.length; j++) {
      if (headerRow[j] === headerName) {
        columnMap[col.key] = j + 1; // +1 لأن الأعمدة تبدأ من 1
        break;
      }
    }

    // إذا لم نجد العمود، أنشئه
    if (!columnMap[col.key]) {
      var newColNum = sheet.getLastColumn() + 1;
      sheet.getRange(1, newColNum).setValue(headerName);
      sheet.getRange(1, newColNum).setFontWeight("bold");
      sheet.getRange(1, newColNum).setBackground("#059669");
      sheet.getRange(1, newColNum).setFontColor("#FFFFFF");
      if (col.width) sheet.setColumnWidth(newColNum, col.width);
      columnMap[col.key] = newColNum;
    }
  }

  return columnMap;
}

// ─── إرسال الاستجابة ────────────────────────────────────────────────────
function sendResponse(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
