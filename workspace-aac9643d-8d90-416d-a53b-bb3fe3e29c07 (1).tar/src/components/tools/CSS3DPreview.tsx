'use client';

import React, { useState, useEffect, useMemo, useRef, useCallback, forwardRef, useImperativeHandle } from 'react';
import {
  Move3d, ZoomIn, ZoomOut, RefreshCw, RotateCw,
  Camera, Box, Layers, Grid3x3, Scan,
  ChevronLeft, ChevronRight, ChevronUp, ChevronDown,
  Diamond, Ruler, PanelRightOpen, PanelRightClose, X
} from 'lucide-react';
import { Slider } from '@/components/ui/slider';

// ─── Types ──────────────────────────────────────────────────────
interface Props {
  width: number;
  length: number;
  height: number;
  flapSize: number;
  glueTab: number;
  templateType: string;
  t?: (key: string) => string;
}

export interface CSS3DPreviewHandle {
  captureScreenshot: () => void;
}

type ViewMode = 'solid' | 'transparent' | 'wireframe' | 'xray';
type FaceType = 'top' | 'wall' | 'side' | 'dark' | 'base';

// ─── Component ──────────────────────────────────────────────────
export const CSS3DPreview = forwardRef<CSS3DPreviewHandle, Props>(function CSS3DPreview({ width, length, height, flapSize, glueTab, templateType, t }, ref) {
  // ─── State ──────────────────────────────────────────────────
  const [rotX, setRotX] = useState(55);
  const [rotZ, setRotZ] = useState(45);
  const [zoom, setZoom] = useState(1);
  const [isDragging, setIsDragging] = useState(false);
  const [autoRotate, setAutoRotate] = useState(false);
  const [showDimensions, setShowDimensions] = useState(false);
  const [foldProgress, setFoldProgress] = useState(100); // 0-100 slider
  const [viewMode, setViewMode] = useState<ViewMode>('solid');
  const [capturing, setCapturing] = useState(false);
  const [sidePanelOpen, setSidePanelOpen] = useState(false);
  const [hintVisible, setHintVisible] = useState(true);

  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<HTMLDivElement>(null);
  const lastTouchRef = useRef<{ x: number; y: number } | null>(null);
  const lastPinchDistRef = useRef<number | null>(null);
  const autoRotateRef = useRef(autoRotate);
  const animFrameRef = useRef<number | null>(null);

  // Derive fold angle from slider (0-100 → 0-90 degrees)
  const foldAngle = useMemo(() => (foldProgress / 100) * 90, [foldProgress]);

  // Reset fold when template params change
  const templateKey = useMemo(() => `${width}-${length}-${height}-${templateType}`, [width, length, height, templateType]);
  const [prevKey, setPrevKey] = useState(templateKey);
  if (prevKey !== templateKey) {
    setPrevKey(templateKey);
    setFoldProgress(100);
  }

  // ─── Auto-rotate effect ────────────────────────────────────
  useEffect(() => { autoRotateRef.current = autoRotate; }, [autoRotate]);

  useEffect(() => {
    let lastTime = 0;
    const animate = (time: number) => {
      if (lastTime && autoRotateRef.current) {
        const delta = time - lastTime;
        setRotZ(prev => prev + delta * 0.02);
      }
      lastTime = time;
      animFrameRef.current = requestAnimationFrame(animate);
    };
    animFrameRef.current = requestAnimationFrame(animate);
    return () => { if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current); };
  }, []);

  // ─── Drag hint auto-fade ────────────────────────────────────
  useEffect(() => {
    const timer = setTimeout(() => setHintVisible(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  // ─── Handlers ──────────────────────────────────────────────
  const stopProp = (e: React.MouseEvent | React.TouchEvent) => e.stopPropagation();

  const handleZoomIn = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setZoom(z => Math.min(5, z + 0.2)); };
  const handleZoomOut = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setZoom(z => Math.max(0.2, z - 0.2)); };
  const resetView = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setRotX(55); setRotZ(45); setZoom(1); };
  const toggleAutoRotate = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setAutoRotate(prev => !prev); };
  const toggleDimensions = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setShowDimensions(prev => !prev); };

  // Camera presets
  const setCameraFront = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setRotX(0); setRotZ(0); };
  const setCameraBack = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setRotX(0); setRotZ(180); };
  const setCameraTop = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setRotX(90); setRotZ(0); };
  const setCameraLeft = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setRotX(0); setRotZ(90); };
  const setCameraRight = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setRotX(0); setRotZ(-90); };
  const setCameraIso = (e: React.MouseEvent | React.TouchEvent) => { stopProp(e); setRotX(55); setRotZ(45); };

  // View mode handler
  const handleViewMode = (mode: ViewMode) => (e: React.MouseEvent | React.TouchEvent) => {
    stopProp(e);
    setViewMode(mode);
  };

  // ─── Screenshot capture — isometric 3D model + branded info ───
  // CSS3D transforms cannot be captured via SVG foreignObject or html2canvas.
  // We draw an isometric 3D representation of the model + branded info card.
  const drawBrandedScreenshot = useCallback(() => {
    const canvas = document.createElement('canvas');
    const scale = 2;
    const w = 800;
    const h = 600;
    canvas.width = w * scale;
    canvas.height = h * scale;
    const ctx = canvas.getContext('2d');
    if (!ctx) return canvas;

    ctx.scale(scale, scale);

    // ── Background gradient ──
    const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
    bgGrad.addColorStop(0, '#fdf6f0');
    bgGrad.addColorStop(1, '#f5ece3');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // ── Decorative grid dots ──
    ctx.fillStyle = 'rgba(201,123,110,0.06)';
    for (let gx = 20; gx < w; gx += 20) {
      for (let gy = 20; gy < h; gy += 20) {
        ctx.beginPath();
        ctx.arc(gx, gy, 1, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // ── Isometric 3D Model Drawing ──
    const cos30 = Math.cos(Math.PI / 6); // ≈0.866
    const sin30 = Math.sin(Math.PI / 6); // =0.5
    const modelCx = w / 2;
    const modelCy = h * 0.42;

    // Scale dimensions to fit nicely (max extent ~180px)
    const maxDim = Math.max(width, length, height, 1);
    const ms = 160 / maxDim;
    const mw = width * ms;
    const ml = length * ms;
    const mh = height * ms;

    // Isometric projection: x→right-down, y→left-down, z→up
    const iso = (x: number, y: number, z: number) => ({
      x: modelCx + (x - y) * cos30,
      y: modelCy - z + (x + y) * sin30,
    });

    // Face gradient fills for professional lighting simulation
    const topFillGrad = ctx.createLinearGradient(0, modelCy - 80, 0, modelCy + 80);
    topFillGrad.addColorStop(0, '#fffaF4');
    topFillGrad.addColorStop(0.3, '#fdf6ee');
    topFillGrad.addColorStop(0.7, '#f5ece3');
    topFillGrad.addColorStop(1, '#ede3d8');

    const wallFillGrad = ctx.createLinearGradient(0, modelCy - 80, 0, modelCy + 120);
    wallFillGrad.addColorStop(0, '#fdf6ee');
    wallFillGrad.addColorStop(0.3, '#f0e4d8');
    wallFillGrad.addColorStop(0.7, '#e5d5c5');
    wallFillGrad.addColorStop(1, '#d8c8b5');

    const sideFillGrad = ctx.createLinearGradient(0, modelCy - 80, 0, modelCy + 120);
    sideFillGrad.addColorStop(0, '#ede3d8');
    sideFillGrad.addColorStop(0.3, '#e2d2c2');
    sideFillGrad.addColorStop(0.7, '#d8c8b5');
    sideFillGrad.addColorStop(1, '#cab8a4');

    const darkFillGrad = ctx.createLinearGradient(0, modelCy - 80, 0, modelCy + 120);
    darkFillGrad.addColorStop(0, '#e2d2c2');
    darkFillGrad.addColorStop(0.3, '#d4c0ac');
    darkFillGrad.addColorStop(0.7, '#c5b09a');
    darkFillGrad.addColorStop(1, '#b8a48e');

    const strokeColor = '#c97b6e';
    const foldLineColor = 'rgba(201,123,110,0.5)';

    // Helper: draw filled+stroked polygon with gradient + edge highlight
    const drawFace = (pts: { x: number; y: number }[], fill: string | CanvasGradient, stroke?: string, showEdgeHL = true) => {
      ctx.beginPath();
      pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
      ctx.closePath();
      ctx.fillStyle = fill;
      ctx.fill();
      // Edge highlights: top-left edges lighter for bevel effect
      if (showEdgeHL && pts.length >= 2) {
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        ctx.lineTo(pts[1].x, pts[1].y);
        ctx.strokeStyle = 'rgba(255,255,255,0.45)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        // Left edge (last point to first point)
        ctx.beginPath();
        ctx.moveTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
        ctx.lineTo(pts[0].x, pts[0].y);
        ctx.strokeStyle = 'rgba(255,255,255,0.3)';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.restore();
      }
      ctx.strokeStyle = stroke || strokeColor;
      ctx.lineWidth = 1.2;
      ctx.stroke();
    };

    // Helper: draw dashed fold line
    const drawFoldLine = (p1: { x: number; y: number }, p2: { x: number; y: number }) => {
      ctx.beginPath();
      ctx.setLineDash([4, 3]);
      ctx.strokeStyle = foldLineColor;
      ctx.lineWidth = 1;
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
      ctx.setLineDash([]);
    };

    // Draw based on template type
    const fRatio = foldProgress / 100; // 0=open, 1=closed

    if (templateType === 'pyramid') {
      const halfBase = mw / 2;
      const slantH = Math.sqrt(mh * mh + halfBase * halfBase);
      // Base
      const b0 = iso(0, 0, 0);
      const b1 = iso(mw, 0, 0);
      const b2 = iso(mw, ml, 0);
      const b3 = iso(0, ml, 0);
      drawFace([b0, b1, b2, b3], topFillGrad);
      // Front face (triangle)
      const peak = iso(mw / 2, 0, slantH * fRatio);
      drawFace([b0, b1, peak], wallFillGrad);
      // Right face (triangle)
      const peakR = iso(mw, ml / 2, slantH * fRatio);
      drawFace([b1, b2, peakR], sideFillGrad);
      // Left face (triangle) - partially visible
      const peakL = iso(0, ml / 2, slantH * fRatio);
      drawFace([b3, b0, peakL], darkFillGrad);
    } else if (templateType === 'envelope') {
      const flapTop = ml * 0.55;
      const flapSide = mw * 0.45;
      const flapBottom = ml * 0.6;
      // Base
      const b0 = iso(0, 0, 0);
      const b1 = iso(mw, 0, 0);
      const b2 = iso(mw, ml, 0);
      const b3 = iso(0, ml, 0);
      drawFace([b0, b1, b2, b3], topFillGrad);
      // Left flap (triangle)
      const lfTip = iso(0, ml / 2, flapSide * fRatio * 0.7);
      drawFace([b3, b0, lfTip], sideFillGrad);
      // Right flap (triangle)
      const rfTip = iso(mw, ml / 2, flapSide * fRatio * 0.7);
      drawFace([b1, b2, rfTip], wallFillGrad);
      // Front flap (triangle)
      const ffTip = iso(mw / 2, ml, flapBottom * fRatio * 0.7);
      drawFace([b2, b3, ffTip], darkFillGrad);
      // Top flap (triangle)
      const tfTip = iso(mw / 2, 0, flapTop * fRatio * 0.7);
      drawFace([b0, b1, tfTip], wallFillGrad);
      // Fold lines on base
      drawFoldLine(b0, b2);
      drawFoldLine(b1, b3);
    } else if (templateType === 'cylinder' || templateType === 'cone') {
      // Approximate with ellipse + sides
      // Top ellipse with gradient
      const topGrad = ctx.createRadialGradient(modelCx, modelCy - mh * fRatio, 0, modelCx, modelCy - mh * fRatio, mw / 2);
      topGrad.addColorStop(0, '#fffaF4');
      topGrad.addColorStop(0.4, '#fdf6ee');
      topGrad.addColorStop(1, '#f0e4d8');
      ctx.beginPath();
      ctx.ellipse(modelCx, modelCy - mh * fRatio, mw / 2, ml / 4, 0, 0, Math.PI * 2);
      ctx.fillStyle = topGrad;
      ctx.fill();
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = 1.2;
      ctx.stroke();
      // Side panels
      const sideStartAngle = Math.PI * 0.15;
      const sideEndAngle = Math.PI * 0.85;
      ctx.beginPath();
      const tsX = modelCx + (mw / 2) * Math.cos(sideStartAngle);
      const tsY = modelCy - mh * fRatio + (ml / 4) * Math.sin(sideStartAngle);
      ctx.moveTo(tsX, tsY);
      ctx.lineTo(tsX, tsY + mh * fRatio);
      for (let a = sideStartAngle; a <= sideEndAngle; a += 0.05) {
        ctx.lineTo(modelCx + (mw / 2) * Math.cos(a), modelCy + (ml / 4) * Math.sin(a));
      }
      const teX = modelCx + (mw / 2) * Math.cos(sideEndAngle);
      const teY = modelCy - mh * fRatio + (ml / 4) * Math.sin(sideEndAngle);
      ctx.lineTo(teX, teY);
      ctx.lineTo(teX, teY + mh * fRatio);
      for (let a = sideEndAngle; a >= sideStartAngle; a -= 0.05) {
        ctx.lineTo(modelCx + (mw / 2) * Math.cos(a), modelCy + (ml / 4) * Math.sin(a));
      }
      ctx.closePath();
      ctx.fillStyle = sideFillGrad;
      ctx.fill();
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = 1.2;
      ctx.stroke();
    } else if (templateType === 'gable_box' || templateType === 'milk_carton' || templateType === 'heart_box') {
      // Box + gable top
      const gableH = mh * 0.55;
      const b0 = iso(0, 0, 0);
      const b1 = iso(mw, 0, 0);
      const b2 = iso(mw, ml, 0);
      const b3 = iso(0, ml, 0);
      const w0 = iso(0, 0, mh * fRatio);
      const w1 = iso(mw, 0, mh * fRatio);
      const w2 = iso(mw, ml, mh * fRatio);
      const w3 = iso(0, ml, mh * fRatio);
      // Top face
      drawFace([w0, w1, w2, w3], topFillGrad);
      // Front face
      drawFace([b0, b1, w1, w0], wallFillGrad);
      // Right face
      drawFace([b1, b2, w2, w1], sideFillGrad);
      // Left face
      drawFace([b3, b0, w0, w3], darkFillGrad);
      // Front gable
      const gPeak = iso(mw / 2, 0, (mh + gableH) * fRatio);
      drawFace([w0, w1, gPeak], wallFillGrad, strokeColor);
      // Right gable
      const gPeakR = iso(mw, ml / 2, (mh + gableH * 0.8) * fRatio);
      drawFace([w1, w2, gPeakR], sideFillGrad, strokeColor);
      // Fold line
      drawFoldLine(w0, w1);
    } else {
      // Default: standard box (also covers mailer, sleeve_box, tuck_end, display_box, hex_box, pillow)
      const b0 = iso(0, 0, 0);
      const b1 = iso(mw, 0, 0);
      const b2 = iso(mw, ml, 0);
      const b3 = iso(0, ml, 0);
      const w0 = iso(0, 0, mh * fRatio);
      const w1 = iso(mw, 0, mh * fRatio);
      const w2 = iso(mw, ml, mh * fRatio);
      const w3 = iso(0, ml, mh * fRatio);

      // Top face with radial gradient for light simulation
      const topRadialGrad = ctx.createRadialGradient(w0.x + (w2.x - w0.x) * 0.35, w0.y + (w2.y - w0.y) * 0.3, 0, (w0.x + w2.x) / 2, (w0.y + w2.y) / 2, mw);
      topRadialGrad.addColorStop(0, '#fffaF4');
      topRadialGrad.addColorStop(0.3, '#fdf6ee');
      topRadialGrad.addColorStop(0.7, '#f0e4d8');
      topRadialGrad.addColorStop(1, '#e8dace');
      drawFace([w0, w1, w2, w3], topRadialGrad);

      // Front face (left in isometric)
      drawFace([b0, b1, w1, w0], wallFillGrad);
      // Right face
      drawFace([b1, b2, w2, w1], sideFillGrad);
      // Left face (partially visible)
      drawFace([b3, b0, w0, w3], darkFillGrad);

      // Flap indicators (fold lines on top edges)
      if (templateType === 'box' || templateType === 'mailer' || templateType === 'tuck_end' || templateType === 'reverse_tuck' || templateType === 'auto_lock' || templateType === 'window_box' || templateType === 'favor_box' || templateType === 'pizza_box' || templateType === 'french_fry' || templateType === 'takeout') {
        const tH = mw * 0.25;
        // Front flap
        const fFlap0 = iso(0, 0, (mh + tH) * fRatio);
        const fFlap1 = iso(mw, 0, (mh + tH) * fRatio);
        drawFace([w0, w1, fFlap1, fFlap0], topFillGrad, strokeColor);
        drawFoldLine(w0, w1);
        // Right flap
        const rFlap0 = iso(mw, 0, (mh + tH * 0.8) * fRatio);
        const rFlap1 = iso(mw, ml, (mh + tH * 0.8) * fRatio);
        drawFace([w1, w2, rFlap1, rFlap0], sideFillGrad, strokeColor);
        drawFoldLine(w1, w2);
        // Left flap
        const lFlap0 = iso(0, 0, (mh + tH * 0.6) * fRatio);
        const lFlap1 = iso(0, ml, (mh + tH * 0.6) * fRatio);
        drawFace([w3, w0, lFlap0, lFlap1], darkFillGrad, strokeColor);
        drawFoldLine(w0, w3);
      }

      if (templateType === 'sleeve_box' || templateType === 'drawer_box') {
        // Draw sleeve overlay
        const sleeveH = mh * 0.35;
        const s0 = iso(-1, 0, (mh + sleeveH * 0.3) * fRatio);
        const s1 = iso(mw + 1, 0, (mh + sleeveH * 0.3) * fRatio);
        const s2 = iso(mw + 1, 0, (mh + sleeveH * 1.3) * fRatio);
        const s3 = iso(-1, 0, (mh + sleeveH * 1.3) * fRatio);
        drawFace([s0, s1, s2, s3], 'rgba(201,123,110,0.18)', strokeColor);
      }

      // Ground shadow ellipse — improved with larger softer shadow
      const shadowCx = modelCx + mw * cos30 * 0.3;
      const shadowCy = modelCy + (mw + ml) * sin30 * 0.5 + 5;
      ctx.beginPath();
      ctx.ellipse(shadowCx, shadowCy, mw * 0.9, ml * 0.35, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0,0,0,0.10)';
      ctx.fill();
      // Secondary tighter shadow
      ctx.beginPath();
      ctx.ellipse(shadowCx, shadowCy, mw * 0.5, ml * 0.18, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0,0,0,0.06)';
      ctx.fill();
    }

    // ── Dimension labels on the model ──
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    // Width label (along front-bottom edge)
    const wLblP = iso(mw / 2, 0, -12);
    ctx.fillStyle = '#6f8266';
    ctx.fillText(`${width}`, wLblP.x, wLblP.y);
    // Length label (along right-bottom edge)
    const lLblP = iso(mw, ml / 2, -12);
    ctx.fillText(`${length}`, lLblP.x, lLblP.y);
    // Height label (along front-left vertical edge)
    const hLblP = iso(-8, 0, mh * fRatio / 2);
    ctx.fillText(`${height}`, hLblP.x, hLblP.y);

    // ── Info card at bottom ──
    const cardW = Math.min(w * 0.65, 420);
    const cardH = 100;
    const cardX = (w - cardW) / 2;
    const cardY = h - cardH - 35;

    // Card shadow
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = 'rgba(0,0,0,0.10)';
    ctx.shadowBlur = 20;
    ctx.shadowOffsetY = 4;
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, cardH, 14);
    ctx.fill();
    ctx.shadowColor = 'transparent';

    // Card border
    ctx.strokeStyle = '#c97b6e';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, cardH, 14);
    ctx.stroke();

    // Top accent bar
    ctx.fillStyle = '#c97b6e';
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, 4, [14, 14, 0, 0]);
    ctx.fill();

    // Brand + template type
    ctx.fillStyle = '#9e4f44';
    ctx.font = 'bold 14px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('ArtNew8 Studio', w / 2, cardY + 28);

    ctx.fillStyle = '#c97b6e';
    ctx.font = 'bold 12px sans-serif';
    ctx.fillText(templateType.replace(/_/g, ' ').toUpperCase(), w / 2, cardY + 46);

    // Dimensions
    ctx.fillStyle = '#6f8266';
    ctx.font = 'bold 12px sans-serif';
    ctx.fillText(`${width} × ${length} × ${height} mm`, w / 2, cardY + 66);

    // Fold/view state
    ctx.fillStyle = '#9ca3af';
    ctx.font = '10px sans-serif';
    ctx.fillText(`Fold: ${Math.round(foldProgress)}% · View: ${viewMode}`, w / 2, cardY + 84);

    // Footer
    ctx.fillStyle = 'rgba(201,123,110,0.4)';
    ctx.font = '9px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Generated by ArtNew8 Studio · artnew8.com', w / 2, h - 14);

    return canvas;
  }, [templateType, width, length, height, foldProgress, viewMode]);

  const downloadScreenshot = useCallback(() => {
    const canvas = drawBrandedScreenshot();
    const link = document.createElement('a');
    link.download = `ArtNew8_${templateType}_3d_preview.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  }, [drawBrandedScreenshot, templateType]);

  const captureScreenshot = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    stopProp(e);
    if (capturing) return;
    setCapturing(true);
    try {
      downloadScreenshot();
    } catch {
      // Final fallback
      const canvas = document.createElement('canvas');
      canvas.width = 800;
      canvas.height = 600;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#fdf6f0';
        ctx.fillRect(0, 0, 800, 600);
        ctx.fillStyle = '#9e4f44';
        ctx.font = 'bold 20px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`${templateType} - ${width}×${length}×${height}mm`, 400, 300);
      }
      const link = document.createElement('a');
      link.download = `ArtNew8_${templateType}_3d_preview.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } finally {
      setCapturing(false);
    }
  }, [capturing, downloadScreenshot, templateType, width, length, height]);

  // Expose captureScreenshot via ref for parent components
  useImperativeHandle(ref, () => ({
    captureScreenshot: () => {
      if (capturing) return;
      setCapturing(true);
      try {
        downloadScreenshot();
      } catch {
        // fallback
      } finally {
        setCapturing(false);
      }
    },
  }), [capturing, downloadScreenshot]);

  // Touch handlers
  const getTouchDistance = useCallback((touches: React.TouchList): number => {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
  }, []);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      lastTouchRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    } else if (e.touches.length === 2) {
      lastPinchDistRef.current = getTouchDistance(e.touches);
    }
  }, [getTouchDistance]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    if (e.touches.length === 1 && lastTouchRef.current) {
      const dx = e.touches[0].clientX - lastTouchRef.current.x;
      const dy = e.touches[0].clientY - lastTouchRef.current.y;
      setRotZ(prev => prev + dx * 0.5);
      setRotX(prev => prev - dy * 0.5);
      lastTouchRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    } else if (e.touches.length === 2) {
      const currentDist = getTouchDistance(e.touches);
      if (lastPinchDistRef.current) {
        const delta = currentDist - lastPinchDistRef.current;
        setZoom(prev => Math.max(0.2, Math.min(5, prev + delta * 0.005)));
      }
      lastPinchDistRef.current = currentDist;
    }
  }, [getTouchDistance]);

  const handleTouchEnd = useCallback(() => {
    setIsDragging(false);
    lastTouchRef.current = null;
    lastPinchDistRef.current = null;
  }, []);

  // ─── Derived values ────────────────────────────────────────
  const maxDim = Math.max(width + height * 2.5, length + height * 2.5);
  const factor = Math.min(300 / maxDim, 1.2) * zoom;

  // Spring-like easing for fold animation
  const ts = 'transform 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)';

  // ─── View Mode Styling ─────────────────────────────────────
  // Professional craft paper tones with multi-stop gradients for realistic lighting
  const solidColors: Record<string, string> = {
    top: 'radial-gradient(ellipse at 40% 30%, rgba(255,248,240,0.99) 0%, rgba(253,246,238,0.97) 25%, rgba(248,236,228,0.95) 55%, rgba(240,228,218,0.93) 100%)',
    base: 'radial-gradient(ellipse at 45% 40%, rgba(253,248,242,0.97) 0%, rgba(248,236,228,0.95) 50%, rgba(240,228,218,0.92) 100%)',
    wall: 'linear-gradient(180deg, rgba(253,248,242,0.97) 0%, rgba(246,236,226,0.94) 35%, rgba(240,230,222,0.92) 65%, rgba(230,218,208,0.89) 100%)',
    side: 'linear-gradient(180deg, rgba(245,235,225,0.95) 0%, rgba(238,226,214,0.91) 35%, rgba(230,218,208,0.88) 65%, rgba(220,208,196,0.85) 100%)',
    dark: 'linear-gradient(180deg, rgba(235,225,215,0.93) 0%, rgba(228,216,204,0.89) 35%, rgba(220,208,196,0.86) 65%, rgba(210,198,186,0.83) 100%)',
    flap: 'linear-gradient(180deg, rgba(248,240,232,0.94) 0%, rgba(240,232,224,0.91) 50%, rgba(232,222,212,0.88) 100%)',
  };

  // Paper texture overlay using CSS (subtle noise for craft paper look)
  const paperTexture = `repeating-radial-gradient(circle at 17% 32%, rgba(180,160,140,0.03) 0px, transparent 1px), repeating-radial-gradient(circle at 73% 58%, rgba(180,160,140,0.02) 0px, transparent 1px), repeating-radial-gradient(circle at 45% 82%, rgba(180,160,140,0.025) 0px, transparent 1px)`;

  const getFaceStyle = (faceType: FaceType, extraStyle?: React.CSSProperties): React.CSSProperties => {
    let bg: string;
    let op: number;
    let bShadow: string;
    let borderStyle: string;
    let textureOverlay = '';

    switch (viewMode) {
      case 'solid': {
        const colorKey = faceType === 'top' ? 'top' : faceType;
        bg = solidColors[colorKey] || solidColors.wall;
        op = 1;
        // Multi-layer inset shadows for realistic depth:
        // 1) Top edge highlight (bevel)
        // 2) Left edge highlight (bevel)
        // 3) Inner top-down lighting
        // 4) Bottom inner shadow
        // 5) Side inner shadows
        // 6) Outer drop shadow
        bShadow = [
          'inset 0 1px 2px rgba(255,255,255,0.5)',     // top bevel highlight
          'inset 1px 0 2px rgba(255,255,255,0.3)',     // left bevel highlight
          'inset 0 3px 10px rgba(0,0,0,0.06)',          // top-down light diffusion
          'inset 0 -2px 8px rgba(0,0,0,0.07)',          // bottom shadow
          'inset 2px 0 6px rgba(0,0,0,0.04)',           // right inner shadow
          'inset -2px 0 6px rgba(0,0,0,0.04)',          // left inner shadow
          '0 2px 10px rgba(0,0,0,0.12)',                // outer drop shadow
        ].join(', ');
        textureOverlay = paperTexture;
        borderStyle = `1px solid ${faceType === 'dark' ? 'rgba(201,123,110,0.5)' : 'rgba(201,123,110,0.35)'}`;
        break;
      }
      case 'transparent':
        bg = solidColors[faceType] || solidColors.wall;
        op = 0.35;
        bShadow = [
          'inset 0 1px 3px rgba(255,255,255,0.2)',
          'inset 0 -1px 4px rgba(0,0,0,0.04)',
          '0 1px 6px rgba(0,0,0,0.06)',
        ].join(', ');
        borderStyle = `1.5px solid rgba(201,123,110,0.5)`;
        break;
      case 'wireframe':
        bg = 'transparent';
        op = 1;
        bShadow = 'none';
        borderStyle = '2px dashed #c97b6e';
        break;
      case 'xray':
        bg = solidColors[faceType] || solidColors.wall;
        op = 0.12;
        bShadow = [
          '0 0 12px rgba(201,123,110,0.35)',
          'inset 0 0 8px rgba(201,123,110,0.15)',
          'inset 0 0 2px rgba(255,200,180,0.2)',
        ].join(', ');
        borderStyle = '2px solid #e8907f';
        break;
    }

    const stroke = viewMode === 'xray' ? '#e8907f' : '#c97b6e';
    const bw = viewMode === 'wireframe' || viewMode === 'xray' ? '2px' : '1.5px';
    const bs = viewMode === 'wireframe' ? 'dashed' : 'solid';

    // For solid mode, use the enhanced borderStyle with bevel-aware colors
    const finalBorder = viewMode === 'solid' ? borderStyle : `${bw} ${bs} ${stroke}`;

    return {
      background: textureOverlay
        ? `${textureOverlay}, ${bg}`
        : bg,
      opacity: op,
      border: finalBorder,
      boxShadow: bShadow,
      position: 'absolute',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: viewMode === 'wireframe' ? '#c97b6e' : '#9e4f44',
      fontWeight: 'bold',
      fontFamily: "'Tajawal', 'Noto Sans Arabic', sans-serif",
      fontSize: '9px',
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
      backfaceVisibility: 'hidden',
      WebkitBackfaceVisibility: 'hidden',
      ...(viewMode === 'transparent' ? { backdropFilter: 'blur(2px)' } : {}),
      ...extraStyle,
    };
  };

  const stroke = '#c97b6e';

  // Translation helper
  const tr = (key: string) => t ? t(key) : key;

  // ─── Dimension label component ──────────────────────────────
  const DimensionLabel = ({ x, y, text, rotation }: { x: number; y: number; text: string; rotation?: string }) => (
    <div style={{
      position: 'absolute',
      left: x,
      top: y,
      fontSize: '8px',
      fontWeight: 'bold',
      color: '#6f8266',
      background: 'rgba(255,255,255,0.92)',
      padding: '1px 4px',
      borderRadius: '3px',
      border: '1px solid #a3b29c',
      whiteSpace: 'nowrap',
      pointerEvents: 'none',
      transform: rotation || 'none',
      zIndex: 10,
    }}>
      {text}
    </div>
  );

  // ─── Ground plane with grid ─────────────────────────────────
  const renderGroundPlane = (baseW: number, baseH: number) => {
    if (viewMode === 'wireframe') {
      return (
        <div style={{
          position: 'absolute',
          width: baseW * 1.8,
          height: baseH * 1.8,
          top: baseH * -0.4 + height * 1.1,
          left: baseW * -0.4,
          background: `
            repeating-linear-gradient(0deg, transparent, transparent 9px, rgba(201,123,110,0.15) 9px, rgba(201,123,110,0.15) 10px),
            repeating-linear-gradient(90deg, transparent, transparent 9px, rgba(201,123,110,0.15) 9px, rgba(201,123,110,0.15) 10px)
          `,
          transform: 'rotateX(90deg)',
          pointerEvents: 'none',
          opacity: 0.6,
        }} />
      );
    }

    return (
      <React.Fragment>
        {/* Primary ground shadow — large, soft, realistic */}
        <div style={{
          position: 'absolute',
          width: baseW * 2.0,
          height: baseH * 2.0,
          top: baseH * -0.5 + height * 1.12,
          left: baseW * -0.5,
          background: 'radial-gradient(ellipse at 55% 45%, rgba(0,0,0,0.16) 0%, rgba(0,0,0,0.08) 25%, rgba(0,0,0,0.03) 50%, transparent 75%)',
          transform: 'rotateX(90deg)',
          pointerEvents: 'none',
        }} />
        {/* Secondary contact shadow — tighter, darker near box base */}
        <div style={{
          position: 'absolute',
          width: baseW * 1.3,
          height: baseH * 1.3,
          top: baseH * -0.15 + height * 1.1,
          left: baseW * -0.15,
          background: 'radial-gradient(ellipse, rgba(0,0,0,0.12) 0%, rgba(0,0,0,0.04) 45%, transparent 70%)',
          transform: 'rotateX(90deg)',
          pointerEvents: 'none',
        }} />
        {/* Ground grid — subtle reference lines */}
        <div style={{
          position: 'absolute',
          width: baseW * 1.8,
          height: baseH * 1.8,
          top: baseH * -0.4 + height * 1.1,
          left: baseW * -0.4,
          background: `
            repeating-linear-gradient(0deg, transparent, transparent 14px, rgba(180,160,140,0.10) 14px, rgba(180,160,140,0.10) 15px),
            repeating-linear-gradient(90deg, transparent, transparent 14px, rgba(180,160,140,0.10) 14px, rgba(180,160,140,0.10) 15px)
          `,
          transform: 'rotateX(90deg)',
          pointerEvents: 'none',
          opacity: 0.45,
        }} />
      </React.Fragment>
    );
  };

  // ─── Specular highlight (light direction simulation) ────────
  const renderSpecularHighlight = (w: number, h: number) => {
    if (viewMode === 'wireframe') return null;
    return (
      <div style={{
        position: 'absolute',
        inset: 0,
        background: viewMode === 'xray'
          ? 'radial-gradient(ellipse at 35% 25%, rgba(232,144,127,0.18) 0%, rgba(232,144,127,0.06) 35%, transparent 65%)'
          : 'radial-gradient(ellipse at 35% 25%, rgba(255,255,255,0.45) 0%, rgba(255,255,255,0.15) 30%, transparent 60%)',
        pointerEvents: 'none',
        borderRadius: 'inherit',
      }} />
    );
  };

  // ─── Ambient occlusion corners ──────────────────────────────
  const renderAmbientOcclusion = (w: number, h: number) => {
    if (viewMode === 'wireframe' || viewMode === 'xray') return null;
    return (
      <React.Fragment>
        <div style={{ position: 'absolute', top: 0, left: 0, width: 18, height: 18, background: 'radial-gradient(circle at 0% 0%, rgba(0,0,0,0.10) 0%, rgba(0,0,0,0.03) 50%, transparent 100%)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', top: 0, right: 0, width: 18, height: 18, background: 'radial-gradient(circle at 100% 0%, rgba(0,0,0,0.10) 0%, rgba(0,0,0,0.03) 50%, transparent 100%)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: 0, left: 0, width: 18, height: 18, background: 'radial-gradient(circle at 0% 100%, rgba(0,0,0,0.10) 0%, rgba(0,0,0,0.03) 50%, transparent 100%)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: 0, right: 0, width: 18, height: 18, background: 'radial-gradient(circle at 100% 100%, rgba(0,0,0,0.10) 0%, rgba(0,0,0,0.03) 50%, transparent 100%)', pointerEvents: 'none' }} />
        {/* Bottom edge shadow band for depth */}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 8, background: 'linear-gradient(to top, rgba(0,0,0,0.06) 0%, transparent 100%)', pointerEvents: 'none' }} />
      </React.Fragment>
    );
  };

  // ─── Fold line on face (dashed line at fold edge) ──────────
  const renderFoldLineOnFace = (position: 'top' | 'bottom' | 'left' | 'right', length: number) => {
    if (viewMode === 'wireframe') return null;
    const foldColor = viewMode === 'xray' ? 'rgba(232,144,127,0.4)' : 'rgba(201,123,110,0.35)';
    const baseStyle: React.CSSProperties = {
      position: 'absolute',
      pointerEvents: 'none',
      zIndex: 5,
    };
    switch (position) {
      case 'top':
        return <div style={{ ...baseStyle, top: 0, left: 2, right: 2, height: 0, borderTop: `1px dashed ${foldColor}`, width: length - 4 }} />;
      case 'bottom':
        return <div style={{ ...baseStyle, bottom: 0, left: 2, right: 2, height: 0, borderBottom: `1px dashed ${foldColor}`, width: length - 4 }} />;
      case 'left':
        return <div style={{ ...baseStyle, top: 2, bottom: 2, left: 0, width: 0, borderLeft: `1px dashed ${foldColor}`, height: length - 4 }} />;
      case 'right':
        return <div style={{ ...baseStyle, top: 2, bottom: 2, right: 0, width: 0, borderRight: `1px dashed ${foldColor}`, height: length - 4 }} />;
    }
  };

  // ─── Edge highlight (bevel/chamfer effect on face) ──────────
  const renderEdgeHighlight = (w: number, h: number) => {
    if (viewMode !== 'solid') return null;
    return (
      <React.Fragment>
        {/* Top edge bevel */}
        <div style={{
          position: 'absolute', top: 0, left: 0, right: 0, height: 2,
          background: 'linear-gradient(to bottom, rgba(255,255,255,0.6) 0%, rgba(255,255,255,0.1) 60%, transparent 100%)',
          pointerEvents: 'none', zIndex: 4,
        }} />
        {/* Left edge bevel */}
        <div style={{
          position: 'absolute', top: 0, left: 0, bottom: 0, width: 2,
          background: 'linear-gradient(to right, rgba(255,255,255,0.45) 0%, rgba(255,255,255,0.08) 60%, transparent 100%)',
          pointerEvents: 'none', zIndex: 4,
        }} />
        {/* Bottom edge shadow line */}
        <div style={{
          position: 'absolute', bottom: 0, left: 2, right: 2, height: 1,
          background: 'rgba(0,0,0,0.06)',
          pointerEvents: 'none', zIndex: 4,
        }} />
        {/* Right edge shadow line */}
        <div style={{
          position: 'absolute', top: 2, right: 0, bottom: 2, width: 1,
          background: 'rgba(0,0,0,0.04)',
          pointerEvents: 'none', zIndex: 4,
        }} />
      </React.Fragment>
    );
  };

  // ─── Face label ────────────────────────────────────────────
  const renderFaceLabel = (label: string) => {
    if (viewMode === 'wireframe') {
      return (
        <span style={{
          position: 'absolute',
          top: 2,
          left: 4,
          fontSize: '7px',
          opacity: 0.6,
          pointerEvents: 'none',
          color: '#c97b6e',
        }}>
          {label}
        </span>
      );
    }
    return <span style={{ opacity: 0.7, pointerEvents: 'none' }}>{label}</span>;
  };

  // ─── Model renderers ───────────────────────────────────────
  const renderModel = () => {
    const sceneTransform = `rotateX(${rotX}deg) rotateZ(${rotZ}deg) scale(${factor})`;
    const transitionStyle = isDragging ? 'none' : 'transform 0.1s ease-out';

    if (templateType === 'box') {
      const fAngle = foldAngle;
      const tH = width * 0.5;
      const sH = length * 0.5;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          {/* Base */}
          <div style={getFaceStyle('base', { width, height: length })}>
            {renderFaceLabel(tr('base_label'))}
            {renderSpecularHighlight(width, length)}
            {renderAmbientOcclusion(width, length)}
            {renderEdgeHighlight(width, length)}
            {showDimensions && <><DimensionLabel x={width/2 - 12} y={-6} text={`W:${width}`} /><DimensionLabel x={width + 4} y={length/2 - 6} text={`L:${length}`} rotation="rotate(90deg)" /></>}
          </div>
          {/* Back wall + flap */}
          <div style={getFaceStyle('wall', { width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fAngle}deg)`, transition: ts })}>
            {showDimensions && <DimensionLabel x={width/2 - 10} y={height/2 - 6} text={`H:${height}`} />}
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('top', width)}
            <div style={getFaceStyle('top', { width, height: tH, top: -tH, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fAngle * 0.98}deg)`, transition: ts })}>
              {renderFaceLabel('FLAP')}
              {renderFoldLineOnFace('bottom', width)}
              {renderSpecularHighlight(width, tH)}
            </div>
          </div>
          {/* Front wall + flap */}
          <div style={getFaceStyle('wall', { width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fAngle}deg)`, transition: ts })}>
            {showDimensions && <DimensionLabel x={width/2 - 10} y={height/2 - 6} text={`H:${height}`} />}
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('bottom', width)}
            <div style={getFaceStyle('top', { width, height: tH, top: height, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fAngle * 0.95}deg)`, transition: ts })}>
              {renderFaceLabel('FLAP')}
              {renderFoldLineOnFace('top', width)}
              {renderSpecularHighlight(width, tH)}
            </div>
          </div>
          {/* Left wall + flap */}
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-fAngle}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
            {renderFoldLineOnFace('left', length)}
            <div style={getFaceStyle('side', { width: sH, height: length, top: 0, left: -sH, transformOrigin: 'right center', transform: `rotateY(${-fAngle * 0.9}deg)`, transition: ts })}>
              {renderFaceLabel('FLAP')}
            </div>
          </div>
          {/* Right wall + flap */}
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${fAngle}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
            {renderFoldLineOnFace('right', length)}
            <div style={getFaceStyle('side', { width: sH, height: length, top: 0, left: height, transformOrigin: 'left center', transform: `rotateY(${fAngle * 0.85}deg)`, transition: ts })}>
              {renderFaceLabel('FLAP')}
            </div>
          </div>
        </div>
      );
    }

    if (templateType === 'envelope') {
      const flapTop = length * 0.55;
      const flapBottom = length * 0.6;
      const flapSide = width * 0.45;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          <div style={getFaceStyle('base', { width, height: length })}>
            {renderAmbientOcclusion(width, length)}
            {renderEdgeHighlight(width, length)}
            {renderSpecularHighlight(width, length)}
          </div>
          <div style={getFaceStyle('side', { width: flapSide, height: length, top: 0, left: -flapSide, clipPath: 'polygon(100% 0%, 0% 50%, 100% 100%)', transformOrigin: 'right center', transform: `rotateY(${-foldAngle * 1.99}deg)`, transition: ts })}>
            {renderFoldLineOnFace('right', length)}
          </div>
          <div style={getFaceStyle('side', { width: flapSide, height: length, top: 0, left: width, clipPath: 'polygon(0% 0%, 100% 50%, 0% 100%)', transformOrigin: 'left center', transform: `rotateY(${foldAngle * 1.99}deg)`, transition: ts })}>
            {renderFoldLineOnFace('left', length)}
          </div>
          <div style={getFaceStyle('wall', { width, height: flapBottom, top: length, clipPath: 'polygon(0% 0%, 50% 100%, 100% 0%)', transformOrigin: 'top center', transform: `rotateX(${-foldAngle * 1.99}deg)`, transition: ts })}>
            {renderFoldLineOnFace('bottom', width)}
          </div>
          <div style={getFaceStyle('dark', { width, height: flapTop, top: -flapTop, clipPath: 'polygon(0% 100%, 50% 0%, 100% 100%)', transformOrigin: 'bottom center', transform: `rotateX(${foldAngle * 1.99}deg)`, transition: ts })}>
            {renderFaceLabel('FLAP')}
            {renderFoldLineOnFace('bottom', width)}
          </div>
        </div>
      );
    }

    if (templateType === 'pillow') {
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          <div style={getFaceStyle('base', { width, height: length })}>
            {renderFaceLabel(tr('base_label'))}
            {renderAmbientOcclusion(width, length)}
            {renderEdgeHighlight(width, length)}
          </div>
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-foldAngle}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
          </div>
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${foldAngle}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
            <div style={getFaceStyle('wall', { width, height: length, top: 0, left: height, transformOrigin: 'left center', transform: `rotateY(${foldAngle}deg)`, transition: ts })}>
              <div style={{ position: 'absolute', width, height, top: -height, left: 0, borderRadius: '100% 100% 0 0', background: viewMode === 'wireframe' ? 'transparent' : solidColors.flap, opacity: viewMode === 'wireframe' ? 1 : viewMode === 'transparent' ? 0.35 : viewMode === 'xray' ? 0.12 : 0.8, transformOrigin: 'bottom center', transform: `rotateX(${foldAngle * 0.95}deg)`, border: `${viewMode === 'wireframe' || viewMode === 'xray' ? '2px' : '1px'} ${viewMode === 'wireframe' ? 'dashed' : 'dashed'} ${viewMode === 'xray' ? '#e8907f' : stroke}`, transition: ts, boxShadow: viewMode === 'solid' ? 'inset 0 1px 3px rgba(255,255,255,0.4), inset 0 -2px 5px rgba(0,0,0,0.06)' : 'none' }} />
              <div style={{ position: 'absolute', width, height, top: length, left: 0, borderRadius: '0 0 100% 100%', background: viewMode === 'wireframe' ? 'transparent' : solidColors.flap, opacity: viewMode === 'wireframe' ? 1 : viewMode === 'transparent' ? 0.35 : viewMode === 'xray' ? 0.12 : 0.8, transformOrigin: 'top center', transform: `rotateX(${-foldAngle * 0.95}deg)`, border: `${viewMode === 'wireframe' || viewMode === 'xray' ? '2px' : '1px'} ${viewMode === 'wireframe' ? 'dashed' : 'dashed'} ${viewMode === 'xray' ? '#e8907f' : stroke}`, transition: ts, boxShadow: viewMode === 'solid' ? 'inset 0 1px 3px rgba(255,255,255,0.4), inset 0 -2px 5px rgba(0,0,0,0.06)' : 'none' }} />
            </div>
          </div>
          <div style={getFaceStyle('wall', { width, height, top: -height, left: 0, borderRadius: '100% 100% 0 0', transformOrigin: 'bottom center', transform: `rotateX(${foldAngle * 0.85}deg)`, transition: ts })}>
            {renderFoldLineOnFace('bottom', width)}
          </div>
          <div style={getFaceStyle('wall', { width, height, top: length, left: 0, borderRadius: '0 0 100% 100%', transformOrigin: 'top center', transform: `rotateX(${-foldAngle * 0.85}deg)`, transition: ts })}>
            {renderFoldLineOnFace('top', width)}
          </div>
        </div>
      );
    }

    if (templateType === 'mailer') {
      const fA = foldAngle;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          <div style={getFaceStyle('base', { width, height: length })}>
            {renderFaceLabel(tr('base_label'))}
            {renderSpecularHighlight(width, length)}
            {renderAmbientOcclusion(width, length)}
            {renderEdgeHighlight(width, length)}
            {showDimensions && <><DimensionLabel x={width/2 - 12} y={-6} text={`W:${width}`} /><DimensionLabel x={width + 4} y={length/2 - 6} text={`L:${length}`} rotation="rotate(90deg)" /></>}
          </div>
          <div style={getFaceStyle('wall', { width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('top', width)}
            <div style={getFaceStyle('top', { width, height: height * 0.9, top: -height * 0.9, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA * 0.98}deg)`, transition: ts })}>
              {renderFaceLabel('LID')}
              {renderSpecularHighlight(width, height * 0.9)}
            </div>
          </div>
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
          </div>
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
          </div>
          <div style={getFaceStyle('wall', { width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('bottom', width)}
            <div style={getFaceStyle('top', { width, height: length, top: height, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, transition: ts })}>
              {renderFaceLabel('FLAP')}
              {renderFoldLineOnFace('top', width)}
            </div>
          </div>
        </div>
      );
    }

    if (templateType === 'gable_box') {
      const fA = foldAngle;
      const gableH = height * 0.55;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          {/* Base */}
          <div style={getFaceStyle('base', { width, height: length })}>
            {renderSpecularHighlight(width, length)}
            {renderEdgeHighlight(width, length)}
            {showDimensions && <><DimensionLabel x={width/2 - 12} y={-6} text={`W:${width}`} /><DimensionLabel x={width + 4} y={length/2 - 6} text={`L:${length}`} rotation="rotate(90deg)" /></>}
          </div>
          {/* Back wall with gable peak */}
          <div style={getFaceStyle('wall', { width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA}deg)`, transition: ts })}>
            {showDimensions && <DimensionLabel x={width/2 - 10} y={height/2 - 6} text={`H:${height}`} />}
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('top', width)}
            <div style={{
              ...getFaceStyle('dark', { width, height: gableH, top: -gableH, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA * 0.5}deg)`, transition: ts }),
              clipPath: 'polygon(20% 100%, 50% 0%, 80% 100%)',
              border: `${viewMode === 'wireframe' || viewMode === 'xray' ? '2px' : '1px'} dashed ${viewMode === 'xray' ? '#e8907f' : stroke}`,
            }} />
          </div>
          {/* Front wall with gable peak */}
          <div style={getFaceStyle('wall', { width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, transition: ts })}>
            {showDimensions && <DimensionLabel x={width/2 - 10} y={height/2 - 6} text={`H:${height}`} />}
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('bottom', width)}
            <div style={{
              ...getFaceStyle('dark', { width, height: gableH, top: height, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA * 0.5}deg)`, transition: ts }),
              clipPath: 'polygon(20% 0%, 50% 100%, 80% 0%)',
              border: `${viewMode === 'wireframe' || viewMode === 'xray' ? '2px' : '1px'} dashed ${viewMode === 'xray' ? '#e8907f' : stroke}`,
            }} />
          </div>
          {/* Left wall */}
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
            <div style={{
              ...getFaceStyle('side', { width: height, height: gableH * 0.8, top: -gableH * 0.8, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA * 0.4}deg)`, transition: ts }),
              clipPath: 'polygon(15% 100%, 50% 0%, 85% 100%)',
              border: `${viewMode === 'wireframe' || viewMode === 'xray' ? '2px' : '1px'} dashed ${viewMode === 'xray' ? '#e8907f' : stroke}`,
            }} />
          </div>
          {/* Right wall */}
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
            <div style={{
              ...getFaceStyle('side', { width: height, height: gableH * 0.8, top: -gableH * 0.8, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA * 0.4}deg)`, transition: ts }),
              clipPath: 'polygon(15% 100%, 50% 0%, 85% 100%)',
              border: `${viewMode === 'wireframe' || viewMode === 'xray' ? '2px' : '1px'} dashed ${viewMode === 'xray' ? '#e8907f' : stroke}`,
            }} />
          </div>
        </div>
      );
    }

    if (templateType === 'sleeve_box') {
      const fA = foldAngle;
      const sleeveH = height * 0.35;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          {/* Inner tray base */}
          <div style={getFaceStyle('base', { width, height: length })}>
            {renderFaceLabel('TRAY')}
            {renderEdgeHighlight(width, length)}
            {showDimensions && <><DimensionLabel x={width/2 - 12} y={-6} text={`W:${width}`} /><DimensionLabel x={width + 4} y={length/2 - 6} text={`L:${length}`} rotation="rotate(90deg)" /></>}
          </div>
          {/* Tray walls */}
          <div style={getFaceStyle('wall', { width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(width, height)}
          </div>
          <div style={getFaceStyle('wall', { width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(width, height)}
          </div>
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
          </div>
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
          </div>
          {/* Outer sleeve */}
          <div style={{
            position: 'absolute',
            width: width + 2,
            height: sleeveH,
            top: -(height + sleeveH * 0.3),
            left: -1,
            transformOrigin: 'bottom center',
            transform: `rotateX(${fA * 0.95}deg)`,
            background: viewMode === 'wireframe' ? 'transparent' : viewMode === 'xray' ? 'rgba(201,123,110,0.08)' : 'linear-gradient(180deg, rgba(201,123,110,0.25) 0%, rgba(201,123,110,0.1) 100%)',
            opacity: viewMode === 'transparent' ? 0.25 : 1,
            border: `${viewMode === 'wireframe' || viewMode === 'xray' ? '2px' : '1.5px'} ${viewMode === 'wireframe' ? 'dashed' : 'solid'} ${viewMode === 'xray' ? '#e8907f' : stroke}`,
            transition: ts,
            boxShadow: viewMode === 'xray' ? '0 0 8px rgba(201,123,110,0.3)' : '0 2px 10px rgba(0,0,0,0.1)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: viewMode === 'xray' ? '#e8907f' : stroke,
            fontWeight: 'bold',
            fontSize: '8px',
            textTransform: 'uppercase',
            backfaceVisibility: 'hidden',
          }}>
            SLEEVE
          </div>
          {showDimensions && <DimensionLabel x={width/2 - 10} y={height/2 - 6} text={`H:${height}`} />}
        </div>
      );
    }

    if (templateType === 'pyramid') {
      const fA = foldAngle;
      const halfBase = width / 2;
      const slantH = Math.sqrt(height * height + halfBase * halfBase);
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: width, transition: transitionStyle }}>
          {renderGroundPlane(width, width)}
          <div style={getFaceStyle('base', { width, height: width })}>
            {renderFaceLabel(tr('base_label'))}
            {renderSpecularHighlight(width, width)}
            {renderEdgeHighlight(width, width)}
            {showDimensions && <><DimensionLabel x={width/2 - 12} y={-6} text={`W:${width}`} /><DimensionLabel x={width + 4} y={width/2 - 6} text={`L:${length}`} rotation="rotate(90deg)" /></>}
          </div>
          {/* Front face */}
          <div style={getFaceStyle('wall', { width, height: slantH, top: -slantH, left: 0, clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)', transformOrigin: 'bottom center', transform: `rotateX(${fA}deg)`, transition: ts })}>
            {renderFoldLineOnFace('bottom', width)}
          </div>
          {/* Back face */}
          <div style={getFaceStyle('wall', { width, height: slantH, top: width, left: 0, clipPath: 'polygon(0% 0%, 50% 100%, 100% 0%)', transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, transition: ts })}>
            {renderFoldLineOnFace('top', width)}
          </div>
          {/* Left face */}
          <div style={getFaceStyle('side', { width: slantH, height: width, top: 0, left: -slantH, clipPath: 'polygon(0% 50%, 100% 0%, 100% 100%)', transformOrigin: 'right center', transform: `rotateY(${-fA}deg)`, transition: ts })}>
            {renderFoldLineOnFace('right', width)}
          </div>
          {/* Right face */}
          <div style={getFaceStyle('side', { width: slantH, height: width, top: 0, left: width, clipPath: 'polygon(0% 0%, 0% 100%, 100% 50%)', transformOrigin: 'left center', transform: `rotateY(${fA}deg)`, transition: ts })}>
            {renderFoldLineOnFace('left', width)}
          </div>
        </div>
      );
    }

    if (templateType === 'hex_box') {
      const fA = foldAngle;
      const sideW = width * 0.55;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          <div style={getFaceStyle('base', { width, height: length, borderRadius: '50%' })}>
            {renderFaceLabel(tr('base_label'))}
            {renderSpecularHighlight(width, length)}
            {showDimensions && <><DimensionLabel x={width/2 - 12} y={-6} text={`W:${width}`} /><DimensionLabel x={width + 4} y={length/2 - 6} text={`L:${length}`} rotation="rotate(90deg)" /></>}
          </div>
          {/* Approximate hex sides with 6 faces */}
          {[0, 1, 2, 3, 4, 5].map(i => (
            <div key={i} style={getFaceStyle(i % 2 === 0 ? 'wall' : 'side', {
              width: sideW, height,
              top: -height,
              left: width / 2 - sideW / 2,
              transformOrigin: 'bottom center',
              transform: `rotateY(${i * 60}deg) translateZ(${width * 0.45}) rotateX(${fA}deg)`,
              transition: ts,
            })}>
              {renderFoldLineOnFace('bottom', sideW)}
            </div>
          ))}
        </div>
      );
    }

    if (templateType === 'milk_carton') {
      const fA = foldAngle;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          <div style={getFaceStyle('base', { width, height: length })}>
            {renderFaceLabel(tr('base_label'))}
            {renderSpecularHighlight(width, length)}
            {renderAmbientOcclusion(width, length)}
            {renderEdgeHighlight(width, length)}
            {showDimensions && <><DimensionLabel x={width/2 - 12} y={-6} text={`W:${width}`} /><DimensionLabel x={width + 4} y={length/2 - 6} text={`L:${length}`} rotation="rotate(90deg)" /></>}
          </div>
          {/* Back wall */}
          <div style={getFaceStyle('wall', { width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('top', width)}
            {/* Gable top */}
            <div style={{ ...getFaceStyle('dark', { width, height: height * 0.4, top: -height * 0.4, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA * 0.5}deg)`, transition: ts }), clipPath: 'polygon(20% 100%, 50% 0%, 80% 100%)' }} />
          </div>
          {/* Front wall */}
          <div style={getFaceStyle('wall', { width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('bottom', width)}
            <div style={{ ...getFaceStyle('dark', { width, height: height * 0.4, top: height, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA * 0.5}deg)`, transition: ts }), clipPath: 'polygon(20% 0%, 50% 100%, 80% 0%)' }} />
          </div>
          {/* Left wall */}
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
          </div>
          {/* Right wall */}
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
          </div>
        </div>
      );
    }

    if (templateType === 'cylinder' || templateType === 'cone') {
      const fA = foldAngle;
      const segments = 12;
      const segmentW = (Math.PI * width) / segments;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          <div style={getFaceStyle('base', { width, height: length, borderRadius: '50%' })}>
            {renderFaceLabel(tr('base_label'))}
            {renderSpecularHighlight(width, length)}
            {showDimensions && <><DimensionLabel x={width/2 - 12} y={-6} text={`⌀:${width}`} /><DimensionLabel x={width + 4} y={length/2 - 6} text={`L:${length}`} rotation="rotate(90deg)" /></>}
          </div>
          {/* Cylinder sides approximated with flat panels */}
          {Array.from({ length: segments }).map((_, i) => {
            const angle = (i / segments) * 360;
            const isVisible = Math.abs(Math.cos((angle + rotZ) * Math.PI / 180)) < 0.95;
            return (
              <div key={i} style={getFaceStyle(i % 2 === 0 ? 'wall' : 'side', {
                width: segmentW + 1,
                height,
                top: -height,
                left: width / 2 - segmentW / 2,
                transformOrigin: 'bottom center',
                transform: `rotateY(${angle}deg) translateZ(${width * 0.45}) rotateX(${fA}deg)`,
                transition: ts,
                opacity: viewMode === 'solid' ? (isVisible ? 0.95 : 0.9) : undefined,
              })}>
                {renderFoldLineOnFace('bottom', segmentW + 1)}
              </div>
            );
          })}
        </div>
      );
    }

    if (templateType === 'tuck_end') {
      const fA = foldAngle;
      const tuckH = height * 0.4;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          <div style={getFaceStyle('base', { width, height: length })}>
            {renderFaceLabel(tr('base_label'))}
            {renderSpecularHighlight(width, length)}
            {renderAmbientOcclusion(width, length)}
            {renderEdgeHighlight(width, length)}
            {showDimensions && <><DimensionLabel x={width/2 - 12} y={-6} text={`W:${width}`} /><DimensionLabel x={width + 4} y={length/2 - 6} text={`L:${length}`} rotation="rotate(90deg)" /></>}
          </div>
          {/* Back wall + tuck flap */}
          <div style={getFaceStyle('wall', { width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('top', width)}
            <div style={getFaceStyle('dark', { width, height: tuckH, top: -tuckH, left: 0, borderRadius: '50% 50% 0 0', transformOrigin: 'bottom center', transform: `rotateX(${fA * 0.95}deg)`, transition: ts })}>
              {renderFaceLabel('TUCK')}
              {renderFoldLineOnFace('bottom', width)}
            </div>
          </div>
          {/* Front wall */}
          <div style={getFaceStyle('wall', { width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('bottom', width)}
          </div>
          {/* Left wall */}
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
            {renderFoldLineOnFace('left', length)}
            <div style={getFaceStyle('side', { width: height * 0.4, height: length, top: 0, left: -height * 0.4, transformOrigin: 'right center', transform: `rotateY(${-fA * 0.9}deg)`, transition: ts })}>
              {renderFaceLabel('GLUE')}
            </div>
          </div>
          {/* Right wall */}
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
            {renderFoldLineOnFace('right', length)}
          </div>
        </div>
      );
    }

    if (templateType === 'display_box') {
      const fA = foldAngle;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
          {renderGroundPlane(width, length)}
          <div style={getFaceStyle('base', { width, height: length })}>
            {renderFaceLabel(tr('base_label'))}
            {renderSpecularHighlight(width, length)}
            {renderEdgeHighlight(width, length)}
            {showDimensions && <><DimensionLabel x={width/2 - 12} y={-6} text={`W:${width}`} /><DimensionLabel x={width + 4} y={length/2 - 6} text={`L:${length}`} rotation="rotate(90deg)" /></>}
          </div>
          {/* Back wall */}
          <div style={getFaceStyle('wall', { width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(width, height)}
            {renderFoldLineOnFace('top', width)}
            <div style={getFaceStyle('top', { width, height: height * 0.5, top: -height * 0.5, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA * 0.95}deg)`, transition: ts })}>
              {renderFaceLabel('LID')}
              {renderFoldLineOnFace('bottom', width)}
            </div>
          </div>
          {/* Front wall with display cutout */}
          <div style={{ ...getFaceStyle('wall', { width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, transition: ts }), clipPath: 'polygon(0% 0%, 15% 0%, 15% 40%, 85% 40%, 85% 0%, 100% 0%, 100% 100%, 0% 100%)' }} />
          {/* Left wall */}
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
          </div>
          {/* Right wall */}
          <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${fA}deg)`, transition: ts })}>
            {renderEdgeHighlight(height, length)}
          </div>
          {showDimensions && <DimensionLabel x={width/2 - 10} y={height/2 - 6} text={`H:${height}`} />}
        </div>
      );
    }

    // Fallback: simple box
    return (
      <div style={{ transformStyle: 'preserve-3d', transform: sceneTransform, position: 'relative', width, height: length, transition: transitionStyle }}>
        {renderGroundPlane(width, length)}
        <div style={getFaceStyle('base', { width, height: length })}>
          {renderAmbientOcclusion(width, length)}
          {renderEdgeHighlight(width, length)}
        </div>
        <div style={getFaceStyle('wall', { width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${foldAngle}deg)`, transition: ts })}>
          {renderEdgeHighlight(width, height)}
        </div>
        <div style={getFaceStyle('wall', { width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-foldAngle}deg)`, transition: ts })}>
          {renderEdgeHighlight(width, height)}
        </div>
        <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-foldAngle}deg)`, transition: ts })}>
          {renderEdgeHighlight(height, length)}
        </div>
        <div style={getFaceStyle('side', { width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${foldAngle}deg)`, transition: ts })}>
          {renderEdgeHighlight(height, length)}
        </div>
      </div>
    );
  };

  // ─── View modes & camera presets ───────────────────────────
  const viewModes: { key: ViewMode; label: string; icon: React.ReactNode }[] = [
    { key: 'solid', label: tr('view_solid'), icon: <Box size={12} /> },
    { key: 'transparent', label: tr('view_transparent'), icon: <Layers size={12} /> },
    { key: 'wireframe', label: tr('view_wireframe'), icon: <Grid3x3 size={12} /> },
    { key: 'xray', label: tr('view_xray'), icon: <Scan size={12} /> },
  ];

  const cameraPresets = [
    { key: 'front', label: tr('camera_front'), icon: <ChevronUp size={10} />, action: setCameraFront },
    { key: 'back', label: tr('camera_back'), icon: <ChevronDown size={10} />, action: setCameraBack },
    { key: 'left', label: tr('camera_left'), icon: <ChevronLeft size={10} />, action: setCameraLeft },
    { key: 'right', label: tr('camera_right'), icon: <ChevronRight size={10} />, action: setCameraRight },
    { key: 'top', label: tr('camera_top'), icon: <Diamond size={10} />, action: setCameraTop },
    { key: 'iso', label: tr('camera_iso'), icon: <Move3d size={10} />, action: setCameraIso },
  ];

  // ─── RENDER ─────────────────────────────────────────────────
  return (
    <div
      className="relative w-full h-full min-h-[350px] sm:min-h-[400px] md:min-h-[500px] overflow-hidden rounded-2xl sm:rounded-[2rem] bg-brand-50 border border-brand-200/50 touch-none select-none"
      suppressHydrationWarning
    >
      {/* ─── FULL 3D VIEWPORT ─── */}
      <div
        ref={containerRef}
        className="absolute inset-0 cursor-move"
        onMouseDown={() => { setIsDragging(true); setHintVisible(false); }}
        onMouseUp={() => setIsDragging(false)}
        onMouseLeave={() => setIsDragging(false)}
        onMouseMove={(e) => {
          if (!isDragging) return;
          setRotZ(prev => prev + e.movementX * 0.5);
          setRotX(prev => prev - e.movementY * 0.5);
        }}
        onTouchStart={(e) => { handleTouchStart(e); setHintVisible(false); }}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onWheel={(e) => {
          setZoom(prev => Math.max(0.2, Math.min(5, prev - e.deltaY * 0.002)));
        }}
      >
        {/* 3D Scene */}
        <div ref={sceneRef} className="absolute inset-0" style={{ perspective: '2500px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {renderModel()}
        </div>

        {/* Drag-to-rotate hint — fades away */}
        <div
          className={`absolute bottom-16 sm:bottom-20 left-1/2 -translate-x-1/2 flex items-center gap-1.5 text-brand-400 text-[10px] sm:text-xs font-medium bg-white/60 backdrop-blur-sm px-3 py-1.5 rounded-full border border-brand-100/50 pointer-events-none transition-opacity duration-700 ${hintVisible ? 'opacity-100' : 'opacity-0'}`}
        >
          <Move3d size={12} />
          <span>{tr('drag_to_rotate') || 'Drag to rotate'}</span>
        </div>

        {/* Compact type badge — top center */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 pointer-events-none z-10">
          <div className="flex items-center gap-1 text-[7px] sm:text-[8px] text-brand-400 font-bold bg-white/50 backdrop-blur-sm px-2 py-0.5 rounded-full border border-brand-100/30">
            <Box size={8} />
            <span className="uppercase tracking-wider">{templateType.replace('_', ' ')}</span>
          </div>
        </div>
      </div>

      {/* ─── BOTTOM TOOLBAR — Semi-transparent overlay ─── */}
      <div
        className="absolute bottom-0 inset-x-0 z-20"
        onClick={stopProp}
        onTouchStart={stopProp}
        onMouseDown={stopProp}
      >
        <div className="bg-white/85 backdrop-blur-md border-t border-brand-200/50 shadow-[0_-4px_20px_rgba(0,0,0,0.06)]">
          {/* Fold animation row */}
          <div className="px-2 sm:px-4 pt-1.5 sm:pt-2 pb-0.5 sm:pb-1">
            <div className="text-[7px] sm:text-[8px] font-bold text-brand-400 uppercase tracking-widest">{tr('fold_animation') || 'Fold Animation'}</div>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-4 pb-1.5 sm:pb-2">
            <button
              onClick={(e) => { stopProp(e); setFoldProgress(0); }}
              className="px-1.5 sm:px-2.5 py-0.5 sm:py-1 rounded-md text-[8px] sm:text-[10px] font-bold text-brand-600 bg-brand-50 hover:bg-brand-100 border border-brand-200 transition-colors active:scale-95 shrink-0"
              aria-label="Unfold model"
              title="Unfold to flat"
            >
              {tr('unfold_btn') || 'Open'}
            </button>
            <Slider
              value={[foldProgress]}
              min={0}
              max={100}
              step={1}
              onValueChange={(val) => setFoldProgress(val[0])}
              className="flex-1 min-w-[60px] [&_[data-slot=slider-track]]:h-2 [&_[data-slot=slider-track]]:bg-brand-100 [&_[data-slot=slider-range]]:bg-brand-600 [&_[data-slot=slider-thumb]]:size-4 [&_[data-slot=slider-thumb]]:border-brand-600"
            />
            <span className="text-[9px] sm:text-xs font-bold text-brand-800 tabular-nums shrink-0 w-8 text-center select-none bg-brand-50 py-0.5 rounded border border-brand-200">
              {Math.round(foldProgress)}%
            </span>
            <button
              onClick={(e) => { stopProp(e); setFoldProgress(100); }}
              className="px-1.5 sm:px-2.5 py-0.5 sm:py-1 rounded-md text-[8px] sm:text-[10px] font-bold text-white bg-brand-600 hover:bg-brand-700 border border-brand-600 transition-colors active:scale-95 shrink-0"
              aria-label="Fold model"
              title="Fold to 3D"
            >
              {tr('fold_3d_btn') || 'Fold'}
            </button>

            {/* Separator */}
            <div className="w-px h-5 bg-brand-200 shrink-0 hidden sm:block" />

            {/* Zoom controls */}
            <div className="hidden sm:flex items-center gap-0.5">
              <button onClick={handleZoomOut} className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-brand-100 text-brand-500 transition-all active:scale-90" aria-label="Zoom out" title="Zoom out">
                <ZoomOut size={13} />
              </button>
              <span className="text-[9px] font-bold text-brand-600 tabular-nums w-8 text-center select-none">
                {Math.round(zoom * 100)}%
              </span>
              <button onClick={handleZoomIn} className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-brand-100 text-brand-500 transition-all active:scale-90" aria-label="Zoom in" title="Zoom in">
                <ZoomIn size={13} />
              </button>
            </div>

            {/* Separator */}
            <div className="w-px h-5 bg-brand-200 shrink-0 hidden sm:block" />

            {/* Action buttons */}
            <div className="flex items-center gap-0.5">
              <button
                onClick={resetView}
                className="w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center rounded-md hover:bg-brand-100 text-brand-500 transition-all active:scale-90"
                aria-label="Reset view"
                title="Reset view"
              >
                <RefreshCw size={13} />
              </button>
              <button
                onClick={captureScreenshot}
                className={`w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center rounded-md transition-all active:scale-90 ${capturing ? 'bg-brand-200 text-brand-400' : 'hover:bg-brand-100 text-brand-500'}`}
                aria-label="Screenshot"
                title="Screenshot"
                disabled={capturing}
              >
                <Camera size={13} className={capturing ? 'animate-pulse' : ''} />
              </button>
              {/* Toggle side panel */}
              <button
                onClick={(e) => { stopProp(e); setSidePanelOpen(prev => !prev); }}
                className={`w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center rounded-md transition-all active:scale-90 ${sidePanelOpen ? 'bg-brand-600 text-white' : 'hover:bg-brand-100 text-brand-500'}`}
                aria-label="Toggle controls panel"
                title="Toggle controls"
              >
                {sidePanelOpen ? <PanelRightClose size={13} /> : <PanelRightOpen size={13} />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ─── SIDE PANEL — Right side, collapsible ─── */}
      {sidePanelOpen && (
        <>
          {/* Mobile backdrop */}
          <div
            className="fixed inset-0 bg-black/20 backdrop-blur-sm z-20 sm:hidden"
            onClick={(e) => { stopProp(e); setSidePanelOpen(false); }}
            onTouchStart={(e) => { stopProp(e); setSidePanelOpen(false); }}
          />

          {/* Panel */}
          <div
            className="absolute top-0 end-0 bottom-0 z-30 w-56 sm:w-52 bg-white/95 backdrop-blur-md border-s border-brand-200/60 shadow-[-4px_0_20px_rgba(0,0,0,0.08)] flex flex-col overflow-y-auto"
            onClick={stopProp}
            onTouchStart={stopProp}
            onMouseDown={stopProp}
          >
            {/* Panel header */}
            <div className="flex items-center justify-between px-3 py-2 border-b border-brand-100/60">
              <span className="text-[9px] sm:text-[10px] font-bold text-brand-400 uppercase tracking-widest">Controls</span>
              <button
                onClick={(e) => { stopProp(e); setSidePanelOpen(false); }}
                className="w-6 h-6 flex items-center justify-center rounded-md hover:bg-brand-100 text-brand-500 transition-all active:scale-90"
                aria-label="Close panel"
              >
                <X size={12} />
              </button>
            </div>

            {/* Camera presets */}
            <div className="px-3 py-2 border-b border-brand-100/40">
              <div className="text-[7px] sm:text-[8px] font-bold text-brand-400 uppercase tracking-widest mb-1.5">{tr('camera_label') || 'Camera'}</div>
              <div className="grid grid-cols-3 gap-1 place-items-center">
                {cameraPresets.map(cam => (
                  <button
                    key={cam.key}
                    onClick={cam.action}
                    className={`w-10 h-10 flex items-center justify-center rounded-lg transition-all active:scale-90 ${
                      cam.key === 'iso' ? 'bg-brand-100 text-brand-700 border border-brand-200' : 'hover:bg-brand-100 text-brand-500'
                    }`}
                    title={cam.label}
                    aria-label={cam.label}
                  >
                    {cam.icon}
                  </button>
                ))}
              </div>
            </div>

            {/* View modes */}
            <div className="px-3 py-2 border-b border-brand-100/40">
              <div className="text-[7px] sm:text-[8px] font-bold text-brand-400 uppercase tracking-widest mb-1.5">{tr('view_mode_label') || 'View Mode'}</div>
              <div className="grid grid-cols-2 gap-1">
                {viewModes.map(vm => (
                  <button
                    key={vm.key}
                    onClick={handleViewMode(vm.key)}
                    className={`flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg text-[8px] sm:text-[9px] font-bold transition-all active:scale-90 ${
                      viewMode === vm.key
                        ? 'bg-brand-700 text-white shadow-sm'
                        : 'bg-brand-50 text-brand-600 hover:bg-brand-100 border border-brand-100'
                    }`}
                    title={vm.label}
                    aria-label={vm.label}
                  >
                    {vm.icon}
                    <span className="hidden sm:inline">{vm.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Toggles */}
            <div className="px-3 py-2 space-y-1.5">
              <button
                onClick={toggleAutoRotate}
                className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-[9px] sm:text-[10px] font-bold transition-all active:scale-95 ${
                  autoRotate ? 'bg-sage-700 text-white' : 'bg-brand-50 text-brand-600 hover:bg-brand-100 border border-brand-100'
                }`}
                aria-label="Toggle auto-rotate"
                title="Auto-rotate"
              >
                <RotateCw size={12} className={autoRotate ? 'animate-spin' : ''} style={autoRotate ? { animationDuration: '3s' } : {}} />
                <span>{tr('auto_rotate') || 'Auto-rotate'}</span>
              </button>
              <button
                onClick={toggleDimensions}
                className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-[9px] sm:text-[10px] font-bold transition-all active:scale-95 ${
                  showDimensions ? 'bg-sage-700 text-white' : 'bg-brand-50 text-brand-600 hover:bg-brand-100 border border-brand-100'
                }`}
                aria-label="Toggle dimensions"
                title="Show dimensions"
              >
                <Ruler size={12} />
                <span>Dimensions</span>
              </button>
            </div>

            {/* Zoom (mobile-accessible) */}
            <div className="px-3 py-2 mt-auto border-t border-brand-100/40 sm:hidden">
              <div className="text-[7px] font-bold text-brand-400 uppercase tracking-widest mb-1.5">Zoom</div>
              <div className="flex items-center gap-1">
                <button onClick={handleZoomOut} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-brand-100 text-brand-500 transition-all active:scale-90" aria-label="Zoom out" title="Zoom out">
                  <ZoomOut size={14} />
                </button>
                <span className="flex-1 text-center text-[10px] font-bold text-brand-600 tabular-nums select-none">
                  {Math.round(zoom * 100)}%
                </span>
                <button onClick={handleZoomIn} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-brand-100 text-brand-500 transition-all active:scale-90" aria-label="Zoom in" title="Zoom in">
                  <ZoomIn size={14} />
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
});
