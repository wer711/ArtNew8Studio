'use client';

import { useState, useEffect } from 'react';
import { Sparkles, Copy, CheckCircle2, Loader2, PenTool, Type, Globe, AlignLeft, User, Heart, MessageSquare } from 'lucide-react';
import { ShareButtons } from './ShareButtons';

// These are the VALUE keys - the API still sends English values
const OCCASIONS = [
  { value: 'Wedding', key: 'occasion_wedding' },
  { value: 'Birthday', key: 'occasion_birthday' },
  { value: "Mother's Day", key: 'occasion_mothers_day' },
  { value: "Father's Day", key: 'occasion_fathers_day' },
  { value: 'Anniversary', key: 'occasion_anniversary' },
  { value: 'Thank You', key: 'occasion_thank_you' },
  { value: 'Sympathy', key: 'occasion_sympathy' },
  { value: 'Graduation', key: 'occasion_graduation' },
  { value: 'New Baby', key: 'occasion_new_baby' },
  { value: 'Get Well Soon', key: 'occasion_get_well' },
];

const RECIPIENTS = [
  { value: 'Friend', key: 'recipient_friend' },
  { value: 'Mother', key: 'recipient_mother' },
  { value: 'Father', key: 'recipient_father' },
  { value: 'Partner', key: 'recipient_partner' },
  { value: 'Colleague', key: 'recipient_colleague' },
  { value: 'Sibling', key: 'recipient_sibling' },
  { value: 'Client', key: 'recipient_client' },
  { value: 'Teacher', key: 'recipient_teacher' },
  { value: 'Child', key: 'recipient_child' },
];

const TONES = [
  { value: 'Heartfelt', key: 'tone_heartfelt' },
  { value: 'Funny', key: 'tone_funny' },
  { value: 'Formal', key: 'tone_formal' },
  { value: 'Poetic', key: 'tone_poetic' },
  { value: 'Short & Sweet', key: 'tone_short_sweet' },
  { value: 'Inspirational', key: 'tone_inspirational' },
];

const LANGUAGES_LIST = [
  { value: 'English', key: 'msg_lang_english' },
  { value: 'Arabic', key: 'msg_lang_arabic' },
  { value: 'French', key: 'msg_lang_french' },
  { value: 'Spanish', key: 'msg_lang_spanish' },
  { value: 'German', key: 'msg_lang_german' },
  { value: 'Italian', key: 'msg_lang_italian' },
];

const LENGTHS = ['Short', 'Medium', 'Long'];

interface MessageGeneratorProps {
  lang: 'en' | 'ar' | 'fr';
  t: (key: string) => string;
  canUse: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => boolean;
  consumeAttempt: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => boolean;
  getRemaining: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => number;
}

export function MessageGenerator({ lang, t, canUse, consumeAttempt, getRemaining }: MessageGeneratorProps) {
  const [occasion, setOccasion] = useState(OCCASIONS[1].value);
  const [recipient, setRecipient] = useState(RECIPIENTS[0].value);
  const [tone, setTone] = useState(TONES[0].value);
  const [language, setLanguage] = useState(LANGUAGES_LIST[0].value);
  const [length, setLength] = useState(LENGTHS[1]);
  const [context, setContext] = useState('');
  const [generatedMessage, setGeneratedMessage] = useState('');
  const [copied, setCopied] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const remainingAI = getRemaining('ai_message');
  const isLimited = !canUse('ai_message');

  // Auto-select Arabic message language when UI is Arabic
  useEffect(() => {
    if (lang === 'ar') {
      setLanguage('Arabic');
    } else if (lang === 'fr') {
      setLanguage('French');
    }
  }, [lang]);

  const handleGenerate = async () => {
    // Check usage limit first
    if (!consumeAttempt('ai_message')) return;

    setIsLoading(true);
    setGeneratedMessage('');
    try {
      const res = await fetch('/api/generate-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ occasion, recipient, tone, language, length, context })
      });
      const data = await res.json();
      setGeneratedMessage(data.message || t('error_failed'));
    } catch {
      setGeneratedMessage(t('error_generate'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Detect if the generated message is RTL
  const isMessageRTL = language === 'Arabic';

  return (
    <div className="space-y-4 sm:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div>
        <h2 className="text-2xl sm:text-3xl font-display font-bold text-slate-800 tracking-tight flex items-center gap-2 sm:gap-3">
          <div className="p-2 sm:p-2.5 bg-brand-100 rounded-lg sm:rounded-xl">
            <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-brand-600" />
          </div>
          {t('msg_title')}
        </h2>
        <p className="text-slate-500 mt-2 max-w-2xl leading-relaxed text-xs sm:text-sm">{t('msg_desc')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-8">
        <div className="lg:col-span-7 xl:col-span-8 space-y-4 sm:space-y-6">
          <div className="bg-white p-4 sm:p-6 md:p-8 rounded-2xl sm:rounded-[2rem] shadow-[0_10px_40px_-15px_rgba(0,0,0,0.05)] border border-slate-100/60 ring-1 ring-slate-100 space-y-4 sm:space-y-6 md:space-y-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-brand-50 rounded-full blur-xl opacity-50 pointer-events-none"></div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-6 relative z-10">
              <div className="space-y-1.5 sm:space-y-2">
                <label className="text-xs sm:text-sm font-bold text-slate-700 flex items-center gap-1.5 sm:gap-2">
                  <Heart size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('occasion')}
                </label>
                <select value={occasion} onChange={(e) => setOccasion(e.target.value)}
                  className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-slate-700 rounded-lg sm:rounded-xl px-3 py-2.5 sm:px-4 sm:py-3 outline-none appearance-none font-medium transition-all text-xs sm:text-sm">
                  {OCCASIONS.map(o => <option key={o.value} value={o.value}>{t(o.key)}</option>)}
                </select>
              </div>
              <div className="space-y-1.5 sm:space-y-2">
                <label className="text-xs sm:text-sm font-bold text-slate-700 flex items-center gap-1.5 sm:gap-2">
                  <User size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('recipient')}
                </label>
                <select value={recipient} onChange={(e) => setRecipient(e.target.value)}
                  className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-slate-700 rounded-lg sm:rounded-xl px-3 py-2.5 sm:px-4 sm:py-3 outline-none appearance-none font-medium transition-all text-xs sm:text-sm">
                  {RECIPIENTS.map(r => <option key={r.value} value={r.value}>{t(r.key)}</option>)}
                </select>
              </div>
              <div className="space-y-1.5 sm:space-y-2">
                <label className="text-xs sm:text-sm font-bold text-slate-700 flex items-center gap-1.5 sm:gap-2">
                  <Type size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('tone')}
                </label>
                <select value={tone} onChange={(e) => setTone(e.target.value)}
                  className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-slate-700 rounded-lg sm:rounded-xl px-3 py-2.5 sm:px-4 sm:py-3 outline-none appearance-none font-medium transition-all text-xs sm:text-sm">
                  {TONES.map(tn => <option key={tn.value} value={tn.value}>{t(tn.key)}</option>)}
                </select>
              </div>
              <div className="space-y-1.5 sm:space-y-2">
                <label className="text-xs sm:text-sm font-bold text-slate-700 flex items-center gap-1.5 sm:gap-2">
                  <Globe size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('language_label')}
                </label>
                <select value={language} onChange={(e) => setLanguage(e.target.value)}
                  className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-slate-700 rounded-lg sm:rounded-xl px-3 py-2.5 sm:px-4 sm:py-3 outline-none appearance-none font-medium transition-all text-xs sm:text-sm">
                  {LANGUAGES_LIST.map(l => <option key={l.value} value={l.value}>{t(l.key)}</option>)}
                </select>
              </div>
            </div>

            <div className="space-y-1.5 sm:space-y-2 relative z-10">
              <label className="text-xs sm:text-sm font-bold text-slate-700 flex items-center gap-1.5 sm:gap-2">
                <AlignLeft size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('msg_length')}
              </label>
              <div className="flex gap-1.5 sm:gap-2 bg-slate-100 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl">
                {LENGTHS.map(l => (
                  <button key={l} onClick={() => setLength(l)}
                    className={`flex-1 py-2 sm:py-2.5 px-2 sm:px-3 rounded-lg sm:rounded-xl text-[10px] sm:text-xs font-bold transition-all active:scale-95 ${
                      length === l ? 'bg-white text-brand-700 shadow-sm ring-1 ring-black/5' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'
                    }`}>
                    {t(l.toLowerCase() as any)}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5 sm:space-y-2 relative z-10">
              <label className="text-xs sm:text-sm font-bold text-slate-700 flex items-center gap-1.5 sm:gap-2 flex-wrap">
                <MessageSquare size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('specific_details')}
                <span className="text-slate-400 font-normal text-[10px] sm:text-xs ms-auto">{t('details_hint')}</span>
              </label>
              <textarea value={context} onChange={(e) => setContext(e.target.value)}
                placeholder={t('details_ph')}
                className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-slate-700 rounded-lg sm:rounded-xl px-3 py-3 sm:px-5 sm:py-4 outline-none font-medium transition-all resize-none h-20 sm:h-24 text-xs sm:text-sm"
                dir={isMessageRTL ? 'rtl' : 'ltr'}
              />
            </div>

            <button onClick={handleGenerate} disabled={isLoading || isLimited}
              className="w-full bg-brand-600 hover:bg-brand-500 text-white shadow-[0_4px_20px_-5px_rgba(201,123,110,0.5)] py-3 sm:py-4 rounded-lg sm:rounded-xl font-bold transition-all disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2 sm:gap-3 relative z-10 text-xs sm:text-sm cursor-pointer active:scale-95">
              {isLoading ? <Loader2 size={18} className="animate-spin sm:w-5 sm:h-5" /> : <Sparkles size={18} className="sm:w-5 sm:h-5" />}
              {isLoading ? t('drafting') : isLimited ? (lang === 'ar' ? 'تم الوصول للحد اليومي' : lang === 'fr' ? 'Limite Quotidienne Atteinte' : 'Daily Limit Reached') : t('generate_msg')}
              {!isLimited && !isLoading && (
                <span className="bg-white/20 px-2 py-0.5 rounded-md text-[10px]">{remainingAI}/5</span>
              )}
            </button>
          </div>
        </div>

        <div className="lg:col-span-5 xl:col-span-4 flex flex-col gap-4 sm:gap-6">
          <div className="bg-slate-900 border border-slate-800 p-5 sm:p-8 rounded-2xl sm:rounded-[2rem] shadow-xl relative overflow-hidden flex-1 flex flex-col items-center justify-center min-h-[300px] sm:min-h-[400px]">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-400 via-purple-500 to-brand-600"></div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-brand-500/10 blur-[100px] rounded-full pointer-events-none"></div>

            {isLoading ? (
              <div className="flex flex-col items-center text-brand-400 gap-3 sm:gap-4 relative z-10">
                <div className="p-3 sm:p-4 bg-brand-900/50 rounded-full border border-brand-500/30">
                  <PenTool size={28} className="animate-bounce sm:w-9 sm:h-9" />
                </div>
                <span className="text-[10px] sm:text-sm font-bold tracking-widest uppercase animate-pulse">{t('writing_thoughts')}</span>
              </div>
            ) : generatedMessage ? (
              <div className="w-full h-full flex flex-col justify-between relative z-10 animate-in zoom-in-95 duration-500 fade-in">
                <div className="flex-1 flex flex-col justify-center items-center text-center px-3 sm:px-4">
                  <p className="text-base sm:text-xl md:text-2xl font-display font-medium text-white leading-relaxed text-balance"
                     dir={isMessageRTL ? 'rtl' : 'ltr'}
                     style={{ fontFamily: isMessageRTL ? "'Tajawal', 'Noto Sans Arabic', 'Segoe UI', Tahoma, sans-serif" : undefined }}>
                    &ldquo;{generatedMessage}&rdquo;
                  </p>
                </div>
                <div className="mt-4 sm:mt-8 flex flex-col items-center gap-3">
                  <button onClick={handleCopy}
                    className="bg-white/10 hover:bg-white/20 text-white rounded-full px-4 sm:px-6 py-2.5 sm:py-3 font-bold flex items-center gap-1.5 sm:gap-2 border border-white/10 transition-all font-display text-xs sm:text-sm tracking-wide active:scale-95">
                    {copied ? <CheckCircle2 size={16} className="text-green-400 sm:w-[18px] sm:h-[18px]" /> : <Copy size={16} className="sm:w-[18px] sm:h-[18px]" />}
                    {copied ? t('copied') : t('copy_clipboard')}
                  </button>
                  <ShareButtons lang={lang} t={t} variant="compact" text={generatedMessage ? `"${generatedMessage.slice(0, 100)}..." — Made with ArtNew8 Studio` : undefined} />
                </div>
              </div>
            ) : (
              <div className="text-center relative z-10 space-y-3 sm:space-y-4">
                <div className="inline-flex items-center justify-center p-3 sm:p-4 bg-slate-800 rounded-full text-slate-500 mb-2">
                  <MessageSquare size={24} className="sm:w-8 sm:h-8" />
                </div>
                <p className="text-slate-400 max-w-[200px] mx-auto text-xs sm:text-sm leading-relaxed">{t('msg_placeholder')}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
