'use client';

import { useState } from 'react';
import { Share2, Twitter, Facebook, MessageCircle, Send, Link2, Check, Linkedin, Pin, Mail } from 'lucide-react';

interface ShareButtonsProps {
  lang: 'en' | 'ar' | 'fr';
  t: (key: string) => string;
  title?: string;
  text?: string;
  className?: string;
  variant?: 'default' | 'compact';
}

export function ShareButtons({ lang, t, title, text, className = '', variant = 'default' }: ShareButtonsProps) {
  const [copied, setCopied] = useState(false);

  const shareTitle = title || t('share_title');
  const shareText = text || t('share_text');
  const shareUrl = typeof window !== 'undefined' ? window.location.href : 'https://artnew8.studio';
  const isRTL = lang === 'ar';

  const shareTwitter = () => {
    window.open(
      `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`,
      '_blank',
      'width=550,height=420'
    );
  };

  const shareFacebook = () => {
    window.open(
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`,
      '_blank',
      'width=550,height=420'
    );
  };

  const shareWhatsApp = () => {
    window.open(
      `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`,
      '_blank'
    );
  };

  const shareTelegram = () => {
    window.open(
      `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`,
      '_blank',
      'width=550,height=420'
    );
  };

  const shareLinkedIn = () => {
    window.open(
      `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`,
      '_blank',
      'width=550,height=420'
    );
  };

  const sharePinterest = () => {
    window.open(
      `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(shareUrl)}&description=${encodeURIComponent(shareText)}`,
      '_blank',
      'width=550,height=420'
    );
  };

  const shareEmail = () => {
    const subject = encodeURIComponent(t('share_email_subject'));
    const body = encodeURIComponent(shareText + '\n\n' + shareUrl);
    window.open(
      `mailto:?subject=${subject}&body=${body}`,
      '_self'
    );
  };

  const copyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const buttons = [
    { icon: <Twitter size={variant === 'compact' ? 14 : 16} />, label: t('share_twitter'), onClick: shareTwitter, color: 'bg-sky-500 hover:bg-sky-600' },
    { icon: <Facebook size={variant === 'compact' ? 14 : 16} />, label: t('share_facebook'), onClick: shareFacebook, color: 'bg-blue-600 hover:bg-blue-700' },
    { icon: <Linkedin size={variant === 'compact' ? 14 : 16} />, label: t('share_linkedin'), onClick: shareLinkedIn, color: 'bg-blue-700 hover:bg-blue-800' },
    { icon: <Pin size={variant === 'compact' ? 14 : 16} />, label: t('share_pinterest'), onClick: sharePinterest, color: 'bg-red-600 hover:bg-red-700' },
    { icon: <MessageCircle size={variant === 'compact' ? 14 : 16} />, label: t('share_whatsapp'), onClick: shareWhatsApp, color: 'bg-green-500 hover:bg-green-600' },
    { icon: <Send size={variant === 'compact' ? 14 : 16} />, label: t('share_telegram'), onClick: shareTelegram, color: 'bg-sky-600 hover:bg-sky-700' },
    { icon: <Mail size={variant === 'compact' ? 14 : 16} />, label: t('share_email'), onClick: shareEmail, color: 'bg-amber-600 hover:bg-amber-700' },
    { icon: copied ? <Check size={variant === 'compact' ? 14 : 16} /> : <Link2 size={variant === 'compact' ? 14 : 16} />, label: copied ? t('share_copied') : t('share_link'), onClick: copyLink, color: copied ? 'bg-green-500' : 'bg-slate-600 hover:bg-slate-700' },
  ];

  if (variant === 'compact') {
    return (
      <div className={`flex items-center gap-1.5 flex-wrap ${className}`}>
        {buttons.map((btn) => (
          <button
            key={btn.label}
            onClick={btn.onClick}
            className={`w-8 h-8 flex items-center justify-center rounded-lg text-white transition-all active:scale-90 ${btn.color}`}
            title={btn.label}
          >
            {btn.icon}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className={`space-y-3 ${className}`}>
      <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
        <Share2 size={12} /> {t('share_result')}
      </h4>
      <div className="flex flex-wrap gap-2">
        {buttons.map((btn) => (
          <button
            key={btn.label}
            onClick={btn.onClick}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-white text-xs font-bold transition-all active:scale-95 ${btn.color}`}
          >
            {btn.icon}
            <span className="hidden sm:inline">{btn.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
