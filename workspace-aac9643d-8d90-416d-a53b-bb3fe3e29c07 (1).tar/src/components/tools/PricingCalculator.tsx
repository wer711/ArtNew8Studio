'use client';

import { useState } from 'react';
import { Plus, Trash2, Calculator, Briefcase, Scissors, Clock, DollarSign, Activity, Percent, Truck, Download } from 'lucide-react';
import { ShareButtons } from './ShareButtons';

interface Material {
  id: string;
  name: string;
  cost: number;
  quantityUsed: number;
}

interface PricingCalculatorProps {
  lang: 'en' | 'ar' | 'fr';
  t: (key: string) => string;
  canUse: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => boolean;
  consumeAttempt: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => boolean;
  getRemaining: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => number;
}

export function PricingCalculator({ lang, t, canUse, consumeAttempt, getRemaining }: PricingCalculatorProps) {
  const [name, setName] = useState('');
  const [materials, setMaterials] = useState<Material[]>([{ id: '1', name: '', cost: 0, quantityUsed: 1 }]);
  const [hourlyRate, setHourlyRate] = useState(20);
  const [hoursSpent, setHoursSpent] = useState(1.5);
  const [packagingCost, setPackagingCost] = useState(1.50);
  const [overheadPercentage, setOverheadPercentage] = useState(10);
  const [profitMargin, setProfitMargin] = useState(40);
  const [platformFeeType, setPlatformFeeType] = useState<'none' | 'etsy' | 'shopify' | 'amazon' | 'custom'>('etsy');
  const [customFeePercent, setCustomFeePercent] = useState(5);
  const [customFeeFixed, setCustomFeeFixed] = useState(0);
  const [freeShippingCost, setFreeShippingCost] = useState(0);
  const [discountPercentage, setDiscountPercentage] = useState(0);
  const [taxPercentage, setTaxPercentage] = useState(0);

  const addMaterial = () => {
    setMaterials([...materials, { id: Math.random().toString(), name: '', cost: 0, quantityUsed: 1 }]);
  };
  const updateMaterial = (id: string, field: keyof Material, value: string | number) => {
    setMaterials(materials.map(m => m.id === id ? { ...m, [field]: value } : m));
  };
  const removeMaterial = (id: string) => {
    setMaterials(materials.filter(m => m.id !== id));
  };

  const calculateTotalCost = () => {
    const rawMaterialCost = materials.reduce((acc, m) => acc + (m.cost * m.quantityUsed), 0);
    const laborCost = hourlyRate * hoursSpent;
    const directCost = rawMaterialCost + laborCost + packagingCost;
    const overheadCost = directCost * (overheadPercentage / 100);
    const baseCost = directCost + overheadCost + freeShippingCost;
    const wholesalePrice = baseCost * (1 + (profitMargin / 100));

    let feePercent = 0;
    let feeFixed = 0;
    if (platformFeeType === 'etsy') { feePercent = 0.095; feeFixed = 0.25; }
    else if (platformFeeType === 'shopify') { feePercent = 0.029; feeFixed = 0.30; }
    else if (platformFeeType === 'amazon') { feePercent = 0.15; feeFixed = 0; }
    else if (platformFeeType === 'custom') { feePercent = customFeePercent / 100; feeFixed = customFeeFixed; }

    const priceAfterDiscount = (wholesalePrice + feeFixed) / (1 - feePercent);
    const retailPricePreTax = priceAfterDiscount / (1 - (discountPercentage / 100));
    const taxAmount = retailPricePreTax * (taxPercentage / 100);
    const retailPrice = retailPricePreTax + taxAmount;
    const platformFeeAmount = priceAfterDiscount - wholesalePrice;
    const discountAmount = retailPricePreTax - priceAfterDiscount;

    return { rawMaterialCost, laborCost, overheadCost, baseCost, wholesalePrice, platformFeeAmount, discountAmount, taxAmount, retailPrice };
  };

  const { rawMaterialCost, laborCost, overheadCost, baseCost, wholesalePrice, platformFeeAmount, discountAmount, taxAmount, retailPrice } = calculateTotalCost();

  const downloadSummary = () => {
    if (!consumeAttempt('pricing_download')) return;
    import('jspdf').then(({ jsPDF }) => {
      const doc = new jsPDF();
      doc.setFontSize(20);
      doc.text('Pricing Summary - ArtNew8 Studio', 20, 20);
      doc.setFontSize(14);
      doc.text(`Project: ${name || 'Unnamed Project'}`, 20, 30);
      doc.setFontSize(12);
      doc.text('--- Cost Breakdown ---', 20, 45);
      doc.text(`Materials: $${rawMaterialCost.toFixed(2)}`, 20, 55);
      doc.text(`Labor & Overhead: $${(laborCost + overheadCost + packagingCost + freeShippingCost).toFixed(2)}`, 20, 65);
      doc.text(`Platform Fees: $${platformFeeAmount.toFixed(2)}`, 20, 75);
      if (discountAmount > 0) doc.text(`Discount Absorbed: -$${discountAmount.toFixed(2)}`, 20, 85);
      if (taxAmount > 0) doc.text(`Tax: $${taxAmount.toFixed(2)}`, 20, 95);
      let y = taxAmount > 0 || discountAmount > 0 ? 105 : 85;
      doc.text('--- Final Pricing ---', 20, y + 10);
      doc.text(`Wholesale Price: $${wholesalePrice.toFixed(2)}`, 20, y + 20);
      doc.setFontSize(16);
      doc.text(`Retail Price: $${retailPrice.toFixed(2)}`, 20, y + 35);
      doc.setFontSize(12);
      doc.text(`Net Profit: $${(wholesalePrice - baseCost).toFixed(2)}`, 20, y + 45);
      doc.save(`Pricing_Summary_${name.replace(/\s+/g, '_') || 'Project'}.pdf`);
    });
  };

  const remainingDownloads = getRemaining('pricing_download');
  const isDownloadLimited = !canUse('pricing_download');

  return (
    <div className="space-y-4 sm:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-slate-800 tracking-tight flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-brand-100 rounded-lg sm:rounded-xl">
              <Calculator className="w-5 h-5 sm:w-6 sm:h-6 text-brand-600" />
            </div>
            {t('pricing_title')}
          </h2>
          <p className="text-slate-500 mt-2 max-w-2xl leading-relaxed text-xs sm:text-sm">{t('pricing_desc')}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-8">
        <div className="lg:col-span-7 xl:col-span-8 space-y-4 sm:space-y-6">
          <div className="bg-white p-4 sm:p-6 md:p-8 rounded-2xl sm:rounded-[2rem] shadow-[0_10px_40px_-15px_rgba(0,0,0,0.05)] border border-slate-100/60 ring-1 ring-slate-100 space-y-5 sm:space-y-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-brand-50 rounded-full blur-xl opacity-50 pointer-events-none"></div>

            <div className="relative z-10">
              <label className="block text-xs sm:text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                <Briefcase size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('project_name')}
              </label>
              <input type="text" value={name} onChange={(e) => setName(e.target.value)}
                placeholder={t('project_name_ph')}
                className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 rounded-xl sm:rounded-2xl px-4 py-3 sm:px-5 sm:py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-sm"
              />
            </div>

            <div className="relative z-10 space-y-3 sm:space-y-4">
              <h4 className="text-[10px] sm:text-sm font-bold tracking-widest text-slate-400 uppercase flex items-center gap-2">
                <Scissors size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('materials_list')}
              </h4>
              <div className="space-y-2 sm:space-y-3">
                {materials.map((mat) => (
                  <div key={mat.id} className="flex flex-wrap gap-2 sm:gap-3 items-center bg-slate-50 p-2.5 sm:p-3 rounded-xl sm:rounded-2xl border border-slate-100 hover:border-brand-200 transition-colors">
                    <div className="w-full sm:w-[50%]">
                      <input type="text" placeholder="Cardstock..." value={mat.name} onChange={(e) => updateMaterial(mat.id, 'name', e.target.value)} className="w-full bg-white border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-xs sm:text-sm rounded-lg sm:rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 transition-all" />
                    </div>
                    <div className="w-[calc(50%-0.5rem)] sm:w-[20%]">
                      <input type="number" placeholder="Cost" value={mat.cost || ''} onChange={(e) => updateMaterial(mat.id, 'cost', Number(e.target.value))} className="w-full bg-white border-0 ring-1 ring-slate-200 focus:ring-2 focus:ring-brand-500 text-xs sm:text-sm rounded-lg sm:rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 transition-all" />
                    </div>
                    <div className="w-[calc(50%-2rem)] sm:w-[20%]">
                      <input type="number" placeholder="Qty" value={mat.quantityUsed || ''} onChange={(e) => updateMaterial(mat.id, 'quantityUsed', Number(e.target.value))} className="w-full bg-white border-0 ring-1 ring-slate-200 focus:ring-2 focus:ring-brand-500 text-xs sm:text-sm rounded-lg sm:rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 transition-all" />
                    </div>
                    <button onClick={() => removeMaterial(mat.id)} className="w-9 h-9 sm:w-10 sm:h-10 ml-auto text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg sm:rounded-xl flex items-center justify-center transition-all bg-white ring-1 ring-slate-200 shrink-0 active:scale-95">
                      <Trash2 size={16} className="sm:w-[18px] sm:h-[18px]" />
                    </button>
                  </div>
                ))}
              </div>
              <button onClick={addMaterial} className="text-xs sm:text-sm bg-brand-50 hover:bg-brand-100 text-brand-700 font-bold flex items-center justify-center gap-2 w-full py-3 sm:py-3.5 rounded-xl sm:rounded-2xl transition-colors border border-brand-100/50 active:scale-95">
                <Plus size={16} strokeWidth={2.5} /> {t('add_material')}
              </button>
            </div>

            <div className="border-t border-slate-100 pt-5 sm:pt-8 relative z-10 space-y-4 sm:space-y-6">
              <h4 className="text-[10px] sm:text-sm font-bold tracking-widest text-slate-400 uppercase flex items-center gap-2">
                <Clock size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('labor_overhead')}
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-2 gap-2 sm:gap-4">
                <div className="bg-slate-50 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-[9px] sm:text-xs font-bold text-slate-500 px-2 sm:px-3 pt-1.5 sm:pt-2">{t('hourly_rate')}</label>
                  <input type="number" value={hourlyRate} onChange={(e) => setHourlyRate(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium text-sm px-2 sm:px-3 py-1.5 sm:py-2" />
                </div>
                <div className="bg-slate-50 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-[9px] sm:text-xs font-bold text-slate-500 px-2 sm:px-3 pt-1.5 sm:pt-2">{t('time_spent')}</label>
                  <input type="number" value={hoursSpent} onChange={(e) => setHoursSpent(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium text-sm px-2 sm:px-3 py-1.5 sm:py-2" />
                </div>
                <div className="bg-slate-50 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-[9px] sm:text-xs font-bold text-slate-500 px-2 sm:px-3 pt-1.5 sm:pt-2">{t('packaging_cost')}</label>
                  <input type="number" value={packagingCost} onChange={(e) => setPackagingCost(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium text-sm px-2 sm:px-3 py-1.5 sm:py-2" />
                </div>
                <div className="bg-slate-50 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-[9px] sm:text-xs font-bold text-slate-500 px-2 sm:px-3 pt-1.5 sm:pt-2">{t('studio_overhead')}</label>
                  <input type="number" value={overheadPercentage} onChange={(e) => setOverheadPercentage(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium text-sm px-2 sm:px-3 py-1.5 sm:py-2" />
                </div>
                <div className="col-span-2 sm:col-span-1 bg-slate-50 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-[9px] sm:text-xs font-bold text-slate-500 px-2 sm:px-3 pt-1.5 sm:pt-2 flex items-center gap-1">{t('shipped_free')} <Truck size={10} className="sm:w-3 sm:h-3" /></label>
                  <input type="number" value={freeShippingCost} onChange={(e) => setFreeShippingCost(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium text-sm px-2 sm:px-3 py-1.5 sm:py-2" />
                </div>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-5 sm:pt-8 relative z-10 space-y-4 sm:space-y-6">
              <h4 className="text-[10px] sm:text-sm font-bold tracking-widest text-slate-400 uppercase flex items-center gap-2">
                <Activity size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('marketplace_margin')}
              </h4>
              <div className="flex flex-wrap gap-1.5 sm:gap-2 bg-slate-100 p-1 sm:p-1.5 rounded-xl sm:rounded-[1.25rem]">
                {(['none', 'etsy', 'shopify', 'amazon', 'custom'] as const).map(type => (
                  <button key={type} onClick={() => setPlatformFeeType(type)}
                    className={`flex-1 py-1.5 sm:py-2 px-2 sm:px-3 rounded-lg sm:rounded-xl text-[10px] sm:text-xs font-bold capitalize transition-all min-w-0 ${platformFeeType === type ? 'bg-white text-brand-700 shadow-sm ring-1 ring-black/5' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'}`}>
                    {type}
                  </button>
                ))}
              </div>
              {platformFeeType === 'custom' && (
                <div className="grid grid-cols-2 gap-2 sm:gap-4 animate-in fade-in slide-in-from-top-2">
                  <div className="bg-slate-50 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl ring-1 ring-slate-200">
                    <label className="block text-[9px] sm:text-xs font-bold text-slate-500 px-2 sm:px-3 pt-1.5 sm:pt-2">Custom Fee (%)</label>
                    <input type="number" value={customFeePercent} onChange={(e) => setCustomFeePercent(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium text-sm px-2 sm:px-3 py-1.5 sm:py-2" />
                  </div>
                  <div className="bg-slate-50 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl ring-1 ring-slate-200">
                    <label className="block text-[9px] sm:text-xs font-bold text-slate-500 px-2 sm:px-3 pt-1.5 sm:pt-2">Custom Fixed Fee ($)</label>
                    <input type="number" value={customFeeFixed} onChange={(e) => setCustomFeeFixed(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium text-sm px-2 sm:px-3 py-1.5 sm:py-2" />
                  </div>
                </div>
              )}
              <div className="bg-slate-50 p-3 sm:p-5 rounded-xl sm:rounded-2xl ring-1 ring-slate-200 mt-3 sm:mt-4">
                <div className="flex justify-between items-end mb-3 sm:mb-4">
                  <label className="block text-xs sm:text-sm font-bold text-slate-600">{t('target_margin')}</label>
                  <span className="text-xl sm:text-2xl font-black font-display text-brand-600">{profitMargin}%</span>
                </div>
                <input type="range" min="10" max="150" value={profitMargin} step="5"
                  onChange={(e) => setProfitMargin(Number(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded-full appearance-none cursor-pointer accent-brand-500 touch-manipulation"
                />
              </div>
            </div>

            <div className="border-t border-slate-100 pt-5 sm:pt-8 relative z-10 space-y-4 sm:space-y-6">
              <h4 className="text-[10px] sm:text-sm font-bold tracking-widest text-slate-400 uppercase flex items-center gap-2">
                <Percent size={14} className="text-brand-500 sm:w-4 sm:h-4" /> {t('advanced_strategy')}
              </h4>
              <div className="grid grid-cols-2 gap-2 sm:gap-4">
                <div className="bg-slate-50 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-[9px] sm:text-xs font-bold text-slate-500 px-2 sm:px-3 pt-1.5 sm:pt-2">{t('sim_discount')}</label>
                  <input type="number" min="0" max="90" value={discountPercentage} onChange={(e) => setDiscountPercentage(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium text-sm px-2 sm:px-3 py-1.5 sm:py-2" />
                </div>
                <div className="bg-slate-50 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-[9px] sm:text-xs font-bold text-slate-500 px-2 sm:px-3 pt-1.5 sm:pt-2">{t('tax_vat')}</label>
                  <input type="number" min="0" max="50" value={taxPercentage} onChange={(e) => setTaxPercentage(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium text-sm px-2 sm:px-3 py-1.5 sm:py-2" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-5 xl:col-span-4 flex flex-col gap-4 sm:gap-6">
          <div className="bg-slate-900 border border-slate-800 text-white p-5 sm:p-8 rounded-2xl sm:rounded-[2rem] shadow-xl relative overflow-hidden flex-1 shrink-0 flex flex-col items-center">
            <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-brand-500/20 blur-[100px] rounded-full pointer-events-none translate-x-1/2 -translate-y-1/2"></div>
            <div className="w-full text-center space-y-4 sm:space-y-6 relative z-10 flex-1 flex flex-col justify-center">
              <div className="inline-flex items-center justify-center p-3 sm:p-4 bg-brand-500/20 rounded-2xl sm:rounded-3xl mx-auto mb-2 text-brand-400">
                <DollarSign size={32} className="sm:w-12 sm:h-12" />
              </div>
              <div className="space-y-1">
                <p className="text-[10px] sm:text-sm font-bold tracking-widest text-slate-400 uppercase">{t('recommended_retail')}</p>
                <div className="text-4xl sm:text-6xl lg:text-7xl font-black font-display tracking-tighter text-white">
                  ${retailPrice.toFixed(2)}
                </div>
              </div>
              <div className="bg-slate-800/50 rounded-xl sm:rounded-[1.5rem] p-4 sm:p-5 w-full space-y-3 sm:space-y-4 border border-slate-700/50 backdrop-blur-xl mt-4 sm:mt-8">
                <div className="flex justify-between items-center pb-2 sm:pb-3 border-b border-white/5">
                  <span className="text-slate-400 text-xs sm:text-sm font-medium">{t('p_wholesale')}</span>
                  <span className="font-bold text-slate-200 text-base sm:text-lg">${wholesalePrice.toFixed(2)}</span>
                </div>
                <div className="space-y-1.5 sm:space-y-2 text-xs sm:text-sm text-slate-400">
                  <div className="flex justify-between items-center">
                    <span>{t('materials')}</span>
                    <span>${rawMaterialCost.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>{t('labor_overhead_ship')}</span>
                    <span>${(laborCost + overheadCost + packagingCost + freeShippingCost).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center text-amber-400/80">
                    <span>{t('platform_fees')}</span>
                    <span>${platformFeeAmount.toFixed(2)}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between items-center text-red-400/80">
                      <span>{t('discount_absorbed')}</span>
                      <span>-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  {taxAmount > 0 && (
                    <div className="flex justify-between items-center text-blue-300">
                      <span>{t('tax')}</span>
                      <span>${taxAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="border-t border-white/10 pt-2 mt-2 flex justify-between items-center text-brand-300 font-bold">
                    <span>{t('p_profit')}</span>
                    <span>${(wholesalePrice - baseCost).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="w-full mt-4 sm:mt-6 relative z-10">
              <button onClick={downloadSummary} disabled={!name.trim() || isDownloadLimited}
                className="w-full bg-brand-600 hover:bg-brand-500 text-white py-3 sm:py-4 px-4 sm:px-6 rounded-xl sm:rounded-2xl font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_4px_20px_-5px_rgba(201,123,110,0.5)] flex items-center justify-center gap-2 text-xs sm:text-sm active:scale-95">
                <Download size={18} />
                {isDownloadLimited ? (lang === 'ar' ? 'تم الوصول للحد اليومي' : lang === 'fr' ? 'Limite Atteinte' : 'Daily Limit Reached') : t('btn_save')}
                {!isDownloadLimited && <span className="bg-white/20 px-2 py-0.5 rounded-md text-[10px]">{remainingDownloads}/3</span>}
              </button>
              <ShareButtons 
                lang={lang} 
                t={t} 
                variant="compact" 
                text={`${lang === 'ar' ? 'سعر بيع مقترح' : lang === 'fr' ? 'Prix de détail recommandé' : 'Recommended retail price'}: $${retailPrice.toFixed(2)} — ${name || 'Project'} — ArtNew8 Studio`}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
