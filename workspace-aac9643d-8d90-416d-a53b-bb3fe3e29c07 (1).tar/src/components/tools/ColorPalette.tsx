'use client';

import { useState } from 'react';
import { Palette, Copy, CheckCircle2, Sparkles, Loader2, FileImage, FileDown } from 'lucide-react';
import { ShareButtons } from './ShareButtons';

const PALETTES = [
  { name: 'Warm Spring', colors: ['#f4a261', '#e76f51', '#2a9d8f', '#e9c46a', '#264653'] },
  { name: 'Soft Pastel', colors: ['#ffb5a7', '#fcd5ce', '#f8edeb', '#f1faee', '#a8dadc'] },
  { name: 'Royal Elegance', colors: ['#1d3557', '#457b9d', '#e63946', '#f1faee', '#a8dadc'] },
  { name: 'Forest Nature', colors: ['#386641', '#6a994e', '#a7c957', '#f2e8cf', '#bc4749'] },
  { name: 'Japanese Vintage', colors: ['#9c6644', '#b08968', '#ddb892', '#e6ccb2', '#ede0d4'] },
  { name: 'Summer Nights', colors: ['#03045e', '#0077b6', '#00b4d8', '#90e0ef', '#caf0f8'] },
  { name: 'Romantic Sunset', colors: ['#ff7b00', '#ff9500', '#ffea00', '#ff006e', '#8338ec'] },
  { name: 'Greyscale Chic', colors: ['#d5bdaf', '#e3d5ca', '#f5ebe0', '#edede9', '#d6ccc2'] },
  { name: 'Desert Bloom', colors: ['#e07a5f', '#3d405b', '#81b29a', '#f2cc8f', '#f4f1de'] },
  { name: 'Nordic Frost', colors: ['#5e6472', '#939b9f', '#b8c0bb', '#d8e0d4', '#fafaf6'] },
  { name: 'Berry Garden', colors: ['#6b2737', '#c97b84', '#e8b4b8', '#f5e6cc', '#a2d2df'] },
  { name: 'Mediterranean', colors: ['#264653', '#2a9d8f', '#e9c46a', '#f4a261', '#e76f51'] },
];

interface ColorPaletteProps {
  lang: 'en' | 'ar' | 'fr';
  t: (key: string) => string;
  canUse: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => boolean;
  consumeAttempt: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => boolean;
  getRemaining: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => number;
}

export function ColorPalette({ lang, t, canUse, consumeAttempt, getRemaining }: ColorPaletteProps) {
  const [activePalette, setActivePalette] = useState(PALETTES[0]);
  const [copiedColor, setCopiedColor] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const remainingAI = getRemaining('ai_palette');
  const isAILimited = !canUse('ai_palette');

  const generateRandom = () => {
    let idx;
    do {
      idx = Math.floor(Math.random() * PALETTES.length);
    } while (PALETTES[idx].name === activePalette.name && PALETTES.length > 1);
    setActivePalette(PALETTES[idx]);
  };

  const generateAIPalette = async () => {
    // Check usage limit first
    if (!consumeAttempt('ai_palette')) return;

    setIsGenerating(true);
    try {
      const res = await fetch('/api/generate-palette', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ style: activePalette.name })
      });
      const data = await res.json();
      if (data.colors && data.colors.length > 0) {
        setActivePalette({ name: data.name || 'AI Generated', colors: data.colors });
      }
    } catch {
      generateRandom();
    } finally {
      setIsGenerating(false);
    }
  };

  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  const copyColor = (color: string) => {
    navigator.clipboard.writeText(color);
    setCopiedColor(color);
    setTimeout(() => setCopiedColor(''), 2000);
  };

  const handleDownloadPNG = () => {
    const colors = activePalette.colors;
    const swatchWidth = 200;
    const swatchHeight = 250;
    const textHeight = 60;
    const titleHeight = 60;
    const padding = 30;
    const canvasWidth = colors.length * swatchWidth + padding * 2;
    const canvasHeight = titleHeight + swatchHeight + textHeight + padding * 2;

    const canvas = document.createElement('canvas');
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    // Palette name title
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 28px Inter, system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(activePalette.name, canvasWidth / 2, padding + 35);

    // Color swatches
    colors.forEach((color, i) => {
      const x = padding + i * swatchWidth;
      const y = padding + titleHeight;

      // Swatch rectangle with rounded corners
      const radius = 12;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + swatchWidth - 20 - radius, y);
      ctx.quadraticCurveTo(x + swatchWidth - 20, y, x + swatchWidth - 20, y + radius);
      ctx.lineTo(x + swatchWidth - 20, y + swatchHeight - radius);
      ctx.quadraticCurveTo(x + swatchWidth - 20, y + swatchHeight, x + swatchWidth - 20 - radius, y + swatchHeight);
      ctx.lineTo(x + radius, y + swatchHeight);
      ctx.quadraticCurveTo(x, y + swatchHeight, x, y + swatchHeight - radius);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
      ctx.fill();

      // Hex code text
      ctx.fillStyle = '#334155';
      ctx.font = 'bold 18px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(color.toUpperCase(), x + (swatchWidth - 20) / 2, y + swatchHeight + 30);

      // RGB text
      const rgb = hexToRgb(color);
      if (rgb) {
        ctx.fillStyle = '#64748b';
        ctx.font = '14px monospace';
        ctx.fillText(`R:${rgb.r} G:${rgb.g} B:${rgb.b}`, x + (swatchWidth - 20) / 2, y + swatchHeight + 50);
      }
    });

    // Footer branding
    ctx.fillStyle = '#94a3b8';
    ctx.font = '12px Inter, system-ui, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText('ArtNew8 Studio', canvasWidth - padding, canvasHeight - 10);

    canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ArtNew8_Palette_${activePalette.name.replace(/\s+/g, '_')}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  };

  const handleDownloadPDF = () => {
    import('jspdf').then(({ jsPDF }) => {
      const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
      const colors = activePalette.colors;
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 20;
      const swatchWidth = (pageWidth - margin * 2 - (colors.length - 1) * 6) / colors.length;
      const swatchHeight = 70;
      const startY = 45;

      // Title
      doc.setFontSize(24);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text(activePalette.name, pageWidth / 2, 28, { align: 'center' });

      // Subtitle line
      doc.setDrawColor(148, 163, 184);
      doc.setLineWidth(0.3);
      doc.line(margin, 33, pageWidth - margin, 33);

      // Color swatches
      colors.forEach((color, i) => {
        const x = margin + i * (swatchWidth + 6);
        const rgb = hexToRgb(color);

        // Swatch with rounded corners
        if (rgb) {
          doc.setFillColor(rgb.r, rgb.g, rgb.b);
        }
        doc.roundedRect(x, startY, swatchWidth, swatchHeight, 3, 3, 'F');

        // Hex code
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(51, 65, 85);
        doc.text(color.toUpperCase(), x + swatchWidth / 2, startY + swatchHeight + 10, { align: 'center' });

        // RGB values
        if (rgb) {
          doc.setFontSize(9);
          doc.setFont('helvetica', 'normal');
          doc.setTextColor(100, 116, 139);
          doc.text(`R: ${rgb.r}  G: ${rgb.g}  B: ${rgb.b}`, x + swatchWidth / 2, startY + swatchHeight + 17, { align: 'center' });
        }
      });

      // Footer branding
      doc.setFontSize(9);
      doc.setFont('helvetica', 'italic');
      doc.setTextColor(148, 163, 184);
      doc.text('ArtNew8 Studio', pageWidth / 2, pageHeight - 10, { align: 'center' });

      doc.save(`ArtNew8_Palette_${activePalette.name.replace(/\s+/g, '_')}.pdf`);
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-2xl sm:text-3xl font-display font-bold text-sage-800 tracking-tight">{t('col_title')}</h2>
        <p className="text-sage-500 mt-2 leading-relaxed text-xs sm:text-sm">{t('col_desc')}</p>
      </div>

      <div className="glass-card p-4 sm:p-10 rounded-2xl sm:rounded-3xl shadow-sm border border-sage-100 flex flex-col items-center text-center">
        <div className="inline-flex items-center justify-center p-2.5 sm:p-3.5 rounded-full bg-brand-50 text-brand-600 mb-4 sm:mb-6 shadow-sm">
          <Palette size={22} className="sm:w-7 sm:h-7" />
        </div>
        <h3 className="text-lg sm:text-2xl font-display font-bold text-sage-800 mb-5 sm:mb-8 tracking-tight">{activePalette.name}</h3>

        <div className="flex flex-col sm:flex-row w-full h-[280px] sm:h-64 rounded-2xl sm:rounded-3xl overflow-hidden shadow-inner mb-6 sm:mb-10 ring-1 ring-sage-900/5">
          {activePalette.colors.map(color => (
            <div
              key={color}
              style={{ backgroundColor: color }}
              className="flex-1 flex items-center justify-center relative group cursor-pointer hover:flex-[1.5] transition-all duration-500 ease-out min-h-[56px] sm:min-h-0"
              onClick={() => copyColor(color)}
            >
              <div className="opacity-0 group-hover:opacity-100 bg-black/60 text-white text-[10px] sm:text-sm font-mono px-3 py-1.5 sm:px-4 sm:py-2 rounded-full flex items-center gap-1.5 sm:gap-2 backdrop-blur-md transition-opacity shadow-lg">
                {copiedColor === color ? <CheckCircle2 size={14} className="text-green-400 sm:w-4 sm:h-4" /> : <Copy size={14} className="sm:w-4 sm:h-4" />}
                {color}
              </div>
            </div>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 w-full sm:w-auto">
          <button onClick={generateRandom}
            className="flex items-center justify-center gap-2 sm:gap-3 w-full sm:w-auto bg-gradient-to-r from-sage-700 to-sage-800 hover:from-sage-600 hover:to-sage-700 text-white shadow-xl hover:shadow-2xl py-3 sm:py-4 px-6 sm:px-10 rounded-full font-bold transition-all transform hover:-translate-y-0.5 text-xs sm:text-sm active:scale-95">
            <Palette size={18} className="sm:w-5 sm:h-5" />
            {t('discover_palette')}
          </button>
          <button onClick={generateAIPalette} disabled={isGenerating || isAILimited}
            className="flex items-center justify-center gap-2 sm:gap-3 w-full sm:w-auto bg-gradient-to-r from-brand-500 to-brand-600 hover:from-brand-400 hover:to-brand-500 text-white shadow-xl hover:shadow-2xl py-3 sm:py-4 px-6 sm:px-10 rounded-full font-bold transition-all transform hover:-translate-y-0.5 disabled:opacity-70 text-xs sm:text-sm active:scale-95">
            {isGenerating ? <Loader2 size={18} className="animate-spin sm:w-5 sm:h-5" /> : <Sparkles size={18} className="sm:w-5 sm:h-5" />}
            {isAILimited ? (lang === 'ar' ? 'تم الوصول للحد' : lang === 'fr' ? 'Limite Atteinte' : 'Limit Reached') : t('ai_palette')}
            {!isAILimited && !isGenerating && (
              <span className="bg-white/20 px-2 py-0.5 rounded-md text-[10px]">{remainingAI}/3</span>
            )}
          </button>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 w-full sm:w-auto mt-2">
          <button onClick={handleDownloadPNG}
            className="flex items-center justify-center gap-2 sm:gap-3 w-full sm:w-auto border-2 border-sage-300 hover:border-sage-400 hover:bg-sage-50 text-sage-700 py-2.5 sm:py-3 px-5 sm:px-8 rounded-full font-bold transition-all text-xs sm:text-sm active:scale-95">
            <FileImage size={16} className="sm:w-4.5 sm:h-4.5" />
            {t('col_download_png')}
          </button>
          <button onClick={handleDownloadPDF}
            className="flex items-center justify-center gap-2 sm:gap-3 w-full sm:w-auto border-2 border-sage-300 hover:border-sage-400 hover:bg-sage-50 text-sage-700 py-2.5 sm:py-3 px-5 sm:px-8 rounded-full font-bold transition-all text-xs sm:text-sm active:scale-95">
            <FileDown size={16} className="sm:w-4.5 sm:h-4.5" />
            {t('col_download_pdf')}
          </button>
        </div>

        {/* Share palette */}
        <div className="mt-2">
          <ShareButtons 
            lang={lang} 
            t={t} 
            variant="compact" 
            text={`${lang === 'ar' ? 'اختار لوحة ألواني' : lang === 'fr' ? 'Ma palette de couleurs' : 'My color palette'}: ${activePalette.name} — ${activePalette.colors.join(' ')} — ArtNew8 Studio`}
          />
        </div>
      </div>

      {/* All palettes grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-4">
        {PALETTES.map(palette => (
          <button
            key={palette.name}
            onClick={() => setActivePalette(palette)}
            className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl border transition-all hover:shadow-md active:scale-95 ${activePalette.name === palette.name ? 'border-brand-300 shadow-md ring-1 ring-brand-200' : 'border-slate-200'}`}
          >
            <p className="text-[10px] sm:text-xs font-bold text-slate-600 mb-1.5 sm:mb-2 text-left truncate">{palette.name}</p>
            <div className="flex h-6 sm:h-8 rounded-lg overflow-hidden">
              {palette.colors.map(c => (
                <div key={c} style={{ backgroundColor: c }} className="flex-1" />
              ))}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
