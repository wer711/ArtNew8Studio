'use client';

import { Heart, Rocket, ExternalLink, Facebook, PenTool, Users, Lightbulb, Store } from 'lucide-react';

interface VisionPanelProps {
  lang: 'en' | 'ar' | 'fr';
  t: (key: string) => string;
}

export function VisionPanel({ lang, t }: VisionPanelProps) {
  const steps = [
    { icon: <PenTool size={22} />, title: t('step1_title'), desc: t('step1_desc'), active: true, color: 'brand' },
    { icon: <Users size={22} />, title: t('step2_title'), desc: t('step2_desc'), active: false, color: 'brand' },
    { icon: <Lightbulb size={22} />, title: t('step3_title'), desc: t('step3_desc'), active: false, color: 'amber' },
    { icon: <Store size={22} />, title: t('step4_title'), desc: t('step4_desc'), active: false, color: 'green' },
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center space-y-3 sm:space-y-4">
        <div className="inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-brand-50 text-brand-600 mb-2 sm:mb-4 shadow-sm">
          <Rocket size={32} className="sm:w-10 sm:h-10 text-brand-500" />
        </div>
        <h2 className="text-2xl sm:text-4xl font-display font-black text-sage-800 tracking-tight">{t('vision_title')}</h2>
        <p className="text-sm sm:text-lg text-sage-600 leading-relaxed px-2">
          {t('vision_desc')}
        </p>
      </div>

      <div className="glass-card p-5 sm:p-8 md:p-10 rounded-2xl sm:rounded-3xl shadow-sm border border-sage-100">
        <h3 className="text-lg sm:text-xl font-display font-bold text-sage-800 mb-3 sm:mb-4">{t('why_building')}</h3>
        <p className="text-sage-600 leading-relaxed mb-5 sm:mb-8 text-xs sm:text-sm">{t('why_desc')}</p>
        <ul className="space-y-2.5 sm:space-y-4 text-sage-700 mb-6 sm:mb-10">
          <li className="flex items-center gap-3 sm:gap-4 bg-sage-50 p-3 sm:p-4 rounded-full">
            <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-brand-500 shadow-sm shrink-0" />
            <span className="font-medium text-xs sm:text-sm">{t('feature_storefront')}</span>
          </li>
          <li className="flex items-center gap-3 sm:gap-4 bg-sage-50 p-3 sm:p-4 rounded-full">
            <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-brand-500 shadow-sm shrink-0" />
            <span className="font-medium text-xs sm:text-sm">{t('feature_inventory')}</span>
          </li>
          <li className="flex items-center gap-3 sm:gap-4 bg-sage-50 p-3 sm:p-4 rounded-full">
            <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-brand-500 shadow-sm shrink-0" />
            <span className="font-medium text-xs sm:text-sm">{t('feature_community')}</span>
          </li>
        </ul>

        {/* Roadmap */}
        <div className="mb-6 sm:mb-10">
          <h3 className="text-lg sm:text-xl font-display font-bold text-sage-800 mb-4 sm:mb-6">{t('roadmap_title')}</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6 relative">
            <div className="hidden md:block absolute top-[28%] left-[12%] right-[12%] h-1 bg-slate-200 -z-10 rounded-full"></div>
            <div className="hidden md:block absolute top-[28%] left-[12%] w-[15%] h-1 bg-brand-500 -z-10 rounded-full"></div>
            {steps.map((step, i) => (
              <div key={i} className={`p-3 sm:p-6 md:p-8 rounded-xl sm:rounded-[2rem] border-2 relative group transition-all ${
                step.active
                  ? 'border-brand-500 shadow-[0_10px_30px_-15px_rgba(201,123,110,0.3)] -translate-y-1 sm:-translate-y-2'
                  : 'border-slate-200 shadow-sm opacity-70 hover:opacity-100 hover:-translate-y-1'
              } ${!step.active ? 'bg-slate-50' : 'bg-white'}`}>
                {step.active && (
                  <div className="absolute -top-2 sm:-top-3 right-3 sm:right-6 bg-brand-500 text-white text-[8px] sm:text-[10px] font-bold uppercase tracking-widest px-2 sm:px-3 py-0.5 sm:py-1 rounded-full shadow-md animate-pulse">
                    {t('you_are_here')}
                  </div>
                )}
                <div className={`w-10 h-10 sm:w-16 sm:h-16 rounded-lg sm:rounded-2xl flex items-center justify-center mb-3 sm:mb-6 shadow-sm ${
                  step.active ? 'bg-brand-100 text-brand-600' : 'bg-white border border-slate-200 text-slate-400'
                }`}>
                  {step.icon}
                </div>
                <h4 className="font-display font-bold text-sm sm:text-lg text-slate-800 mb-1.5 sm:mb-3 tracking-tight">{step.title}</h4>
                <p className="text-[10px] sm:text-sm text-slate-600 leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-brand-900 to-sage-900 p-5 sm:p-8 md:p-10 rounded-2xl sm:rounded-[2.5rem] shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-brand-500/30 rounded-full blur-xl opacity-50"></div>
          <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 bg-purple-500/30 rounded-full blur-xl opacity-50"></div>
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-5 sm:gap-8 text-center md:text-left">
            <div>
              <h4 className="text-lg sm:text-2xl font-display font-bold text-white mb-2 sm:mb-3 flex items-center justify-center md:justify-start gap-2 sm:gap-3">
                <Heart size={20} className="text-brand-400 fill-brand-400 animate-pulse sm:w-6 sm:h-6" /> {t('support_mission')}
              </h4>
              <p className="text-sage-300 text-xs sm:text-sm max-w-lg leading-relaxed">{t('support_desc')}</p>
            </div>
            <a href="https://www.paypal.com/ncp/payment/7TUYHE9XTU6AG" target="_blank" rel="noopener noreferrer"
              className="shrink-0 flex items-center justify-center gap-2 bg-brand-500 hover:bg-brand-400 text-white font-bold py-3 sm:py-4 px-6 sm:px-8 rounded-full shadow-[0_4px_20px_-5px_rgba(201,123,110,0.6)] transform hover:-translate-y-1 transition-all text-xs sm:text-sm active:scale-95">
              {t('donate_paypal')} <ExternalLink size={16} className="sm:w-[18px] sm:h-[18px]" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
