'use client';

import React, { useState, useCallback, useRef } from 'react';
import { generateTemplateSvg, generatePrintReadySvg, getTemplateInfo, TemplateType } from '@/lib/boxMath';
import { Download, Settings, Package, Coffee, FileDown, Cuboid, Eye, Move3d, Mail, Printer, Ruler, FileText, Gift, Box, Triangle, Hexagon, Layers, Calculator, Leaf, Circle, Monitor, ArrowRight, ArrowDown, ArrowUp, Camera, Heart, PartyPopper, Pizza, ShoppingBag, Archive, DoorOpen, ScanEye } from 'lucide-react';
import { CSS3DPreview, CSS3DPreviewHandle } from './CSS3DPreview';
import { ShareButtons } from './ShareButtons';

type PaperMaterial = 'cardstock' | 'corrugated' | 'kraft' | 'chipboard';

const PAPER_MATERIALS: Record<PaperMaterial, { thickness: number; kerf: number; labelKey: string }> = {
  cardstock: { thickness: 0.3, kerf: 0.1, labelKey: 'paper_cardstock' },
  corrugated: { thickness: 0.8, kerf: 0.3, labelKey: 'paper_corrugated' },
  kraft: { thickness: 0.2, kerf: 0.05, labelKey: 'paper_kraft' },
  chipboard: { thickness: 1.2, kerf: 0.5, labelKey: 'paper_chipboard' },
};

interface TemplateMakerProps {
  lang: 'en' | 'ar' | 'fr';
  t: (key: string) => string;
  canUse: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => boolean;
  consumeAttempt: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => boolean;
  getRemaining: (tool: 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download') => number;
}

export function TemplateMaker({ lang, t, canUse, consumeAttempt, getRemaining }: TemplateMakerProps) {
  const [templateType, setTemplateType] = useState<TemplateType>('box');
  const [viewMode, setViewMode] = useState<'2d' | '3d'>('2d');
  const [width, setWidth] = useState(50);
  const [length, setLength] = useState(80);
  const [height, setHeight] = useState(30);
  const [flapSize, setFlapSize] = useState(15);
  const [glueTab, setGlueTab] = useState(10);
  const [kerf, setKerf] = useState(0);
  const [machine, setMachine] = useState<'standard' | 'cricut' | 'silhouette' | 'laser'>('standard');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState('');
  const preview3dRef = useRef<CSS3DPreviewHandle>(null);
  const [paperMaterial, setPaperMaterial] = useState<PaperMaterial>('cardstock');
  const [showBleed, setShowBleed] = useState(false);
  const [showSafe, setShowSafe] = useState(false);
  const [volumeInput, setVolumeInput] = useState('');
  const [activePreset, setActivePreset] = useState<string>('custom');

  const remainingDownloads = getRemaining('template_download');
  const isDownloadLimited = !canUse('template_download');

  const materialThickness = PAPER_MATERIALS[paperMaterial].thickness;
  const options = { width, length, height, flapSize, glueTab, cornerRadius: 0, materialThickness, kerf, machine, showBleed, showSafe };
  const svgContent = React.useMemo(() => generateTemplateSvg(templateType, options), [templateType, width, length, height, flapSize, glueTab, kerf, machine, showBleed, showSafe]);
  const templateInfo = React.useMemo(() => getTemplateInfo(templateType, options), [templateType, width, length, height, flapSize, glueTab]);

  const showDownloadFeedback = (format: string) => {
    setDownloadSuccess(format);
    setTimeout(() => setDownloadSuccess(''), 2000);
  };

  // Apply preset sizes
  const applyPreset = useCallback((preset: string) => {
    setActivePreset(preset);
    switch (preset) {
      case 'small':
        setWidth(40); setLength(40); setHeight(40);
        break;
      case 'medium':
        setWidth(80); setLength(60); setHeight(40);
        break;
      case 'large':
        setWidth(200); setLength(150); setHeight(50);
        break;
      case 'a2':
        setWidth(111); setLength(146); setHeight(0);
        setTemplateType('envelope');
        break;
      default:
        break;
    }
    if (preset !== 'a2' && preset !== 'custom') {
      setTemplateType('box');
    }
  }, []);

  // Volume calculator - golden ratio distribution
  const calculateFromVolume = useCallback(() => {
    const vol = parseFloat(volumeInput);
    if (isNaN(vol) || vol <= 0) return;
    // Golden ratio φ ≈ 1.618
    const phi = 1.618;
    // V = w * l * h (in cm³), w = h * phi, l = h * phi * phi
    // V = h³ * phi³ → h = (V / phi³)^(1/3)
    const hCm = Math.cbrt(vol / (phi * phi * phi));
    const wCm = hCm * phi;
    const lCm = hCm * phi * phi;
    setHeight(Math.round(hCm * 10));
    setWidth(Math.round(wCm * 10));
    setLength(Math.round(lCm * 10));
    setActivePreset('custom');
  }, [volumeInput]);

  // Handle paper material change
  const handleMaterialChange = useCallback((material: PaperMaterial) => {
    setPaperMaterial(material);
    setKerf(PAPER_MATERIALS[material].kerf);
  }, []);

  // Download print-ready SVG with real mm dimensions
  const handleDownloadSVG = () => {
    if (!consumeAttempt('template_download')) return;
    const printSvg = generatePrintReadySvg(templateType, options);
    const blob = new Blob([printSvg], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ArtNew8_${templateInfo.templateName}_${templateInfo.dimensions}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showDownloadFeedback('SVG');
  };

  // Helper: convert SVG string to a canvas-renderable version with pixel dimensions
  const svgToCanvasReady = (svgStr: string, svgWidthMm: number, svgHeightMm: number): string => {
    // Replace mm-based width/height with pixel values for canvas rendering
    // Use 3.7795 px/mm (96 DPI) as the conversion factor
    const pxPerMm = 3.7795;
    const widthPx = Math.round(svgWidthMm * pxPerMm);
    const heightPx = Math.round(svgHeightMm * pxPerMm);
    return svgStr
      .replace(
        /width="[^"]*mm"\s*height="[^"]*mm"/,
        `width="${widthPx}" height="${heightPx}"`
      );
  };

  // Helper: render SVG to canvas using base64 data URL (avoids CORS issues)
  const renderSvgToCanvas = async (printSvg: string, svgWidthMm: number, svgHeightMm: number, scale: number): Promise<HTMLCanvasElement> => {
    const canvasReadySvg = svgToCanvasReady(printSvg, svgWidthMm, svgHeightMm);
    const svgBase64 = btoa(unescape(encodeURIComponent(canvasReadySvg)));
    const dataUrl = `data:image/svg+xml;base64,${svgBase64}`;

    const pxPerMm = 3.7795;
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(svgWidthMm * pxPerMm * scale);
    canvas.height = Math.round(svgHeightMm * pxPerMm * scale);
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('No canvas context');

    // White background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const img = new Image();
    await new Promise<void>((resolve, reject) => {
      img.onload = () => {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve();
      };
      img.onerror = () => {
        reject(new Error('Failed to render SVG to canvas'));
      };
      img.src = dataUrl;
    });

    return canvas;
  };

  // Download PNG (render SVG to canvas)
  const handleDownloadPNG = useCallback(async () => {
    if (!consumeAttempt('template_download')) return;
    try {
      const printSvg = generatePrintReadySvg(templateType, options);
      const margin = 15;
      const svgWidth = templateInfo.totalWidth + margin * 2;
      const svgHeight = templateInfo.totalLength + margin * 2;
      const scale = 3; // 3x for high resolution

      const canvas = await renderSvgToCanvas(printSvg, svgWidth, svgHeight, scale);

      canvas.toBlob((blob) => {
        if (!blob) return;
        const pngUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = pngUrl;
        link.download = `ArtNew8_${templateInfo.templateName}_${templateInfo.dimensions}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(pngUrl);
        showDownloadFeedback('PNG');
      }, 'image/png');
    } catch {
      // Fallback - just export SVG
      handleDownloadSVG();
    }
  }, [templateType, width, length, height, flapSize, glueTab, kerf, machine]);

  // Download print-ready PDF
  const handleDownloadPDF = () => {
    if (!consumeAttempt('template_download')) return;
    import('jspdf').then(async ({ jsPDF }) => {
      const printSvg = generatePrintReadySvg(templateType, options);
      const margin = 15;
      const svgWidth = templateInfo.totalWidth + margin * 2;
      const svgHeight = templateInfo.totalLength + margin * 2;

      const isLandscape = svgWidth > svgHeight;
      const doc = new jsPDF({
        orientation: isLandscape ? 'landscape' : 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();

      doc.setFontSize(8);
      doc.setTextColor(156, 163, 175);
      doc.text('ArtNew8 Studio', 10, 8);
      doc.text(`${templateInfo.templateName.replace(/_/g, ' ')} — ${templateInfo.dimensions}`, pageWidth - 10, 8, { align: 'right' });

      doc.setDrawColor(226, 232, 240);
      doc.setFillColor(250, 250, 248);
      doc.roundedRect(10, 12, pageWidth - 20, 14, 2, 2, 'FD');
      doc.setFontSize(9);
      doc.setTextColor(66, 77, 61);
      doc.text(`Template: ${templateInfo.templateName.replace(/_/g, ' ')}`, 15, 19);
      doc.text(`Dimensions: ${templateInfo.dimensions}`, 15, 24);
      doc.text(`Machine: ${machine} | Kerf: ${kerf}mm | Glue Tab: ${glueTab}mm`, pageWidth - 15, 19, { align: 'right' });

      try {
        // Render SVG to canvas using base64 data URL, then add as PNG to PDF
        const canvas = await renderSvgToCanvas(printSvg, svgWidth, svgHeight, 2);
        const maxW = pageWidth - 20;
        const maxH = pageHeight - 40;
        const scaleX = maxW / svgWidth;
        const scaleY = maxH / svgHeight;
        const scale = Math.min(scaleX, scaleY, 1);
        const imgW = svgWidth * scale;
        const imgH = svgHeight * scale;
        const offsetX = 10 + (maxW - imgW) / 2;
        const offsetY = 30 + (maxH - imgH) / 2;

        doc.addImage(canvas.toDataURL('image/png'), 'PNG', offsetX, offsetY, imgW, imgH);
        doc.save(`ArtNew8_${templateInfo.templateName}_${templateInfo.dimensions}.pdf`);
        showDownloadFeedback('PDF');
      } catch {
        doc.setFontSize(12);
        doc.text('Template could not be rendered. Use SVG export for cutting.', 20, 50);
        doc.save(`ArtNew8_${templateInfo.templateName}_${templateInfo.dimensions}.pdf`);
      }
    });
  };

  const handleDownloadDXF = () => {
    if (!consumeAttempt('template_download')) return;
    const parser = new DOMParser();
    const svgDoc = parser.parseFromString(svgContent, 'image/svg+xml');
    // Get ALL path elements (not just the first one)
    const cutPathElements = svgDoc.querySelectorAll('#cut-paths path');
    const foldPathElements = svgDoc.querySelectorAll('#score-paths path');

    let dxf = '0\nSECTION\n2\nHEADER\n0\nENDSEC\n0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLAYER\n0\nLAYER\n2\nCUT\n62\n1\n0\nLAYER\n2\nSCORE\n62\n5\n0\nENDTAB\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n';

    cutPathElements.forEach((pathEl) => {
      const d = pathEl.getAttribute('d') || '';
      dxf += parseSvgPathToDxf(d, 'CUT');
    });

    foldPathElements.forEach((pathEl) => {
      const d = pathEl.getAttribute('d') || '';
      dxf += parseSvgPathToDxf(d, 'SCORE');
    });

    dxf += '0\nENDSEC\n0\nEOF\n';

    const blob = new Blob([dxf], { type: 'application/dxf' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ArtNew8_${templateInfo.templateName}_${templateInfo.dimensions}.dxf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showDownloadFeedback('DXF');
  };

  // Generate geometry data (vertices and faces) for OBJ/STL based on template type
  const generateGeometry = useCallback(() => {
    const w = width / 10; // mm → cm
    const l = length / 10;
    const h = height / 10;
    const vertices: number[][] = [];
    const faces: number[][] = []; // 1-indexed vertex indices for OBJ

    const boxTypes = ['box', 'mailer', 'tray', 'gable_box', 'sleeve_box', 'tuck_end', 'display_box', 'reverse_tuck', 'auto_lock', 'window_box', 'drawer_box', 'heart_box', 'favor_box', 'french_fry', 'pizza_box', 'takeout'];

    if (boxTypes.includes(templateType)) {
      // Standard box geometry (8 vertices, 6 quad faces)
      vertices.push(
        [0, 0, 0], [w, 0, 0], [w, 0, l], [0, 0, l],   // 1-4: bottom
        [0, h, 0], [w, h, 0], [w, h, l], [0, h, l],     // 5-8: top
      );
      faces.push(
        [1, 2, 3, 4],   // bottom
        [8, 7, 6, 5],   // top
        [1, 5, 6, 2],   // front (z=0)
        [2, 6, 7, 3],   // right (x=w)
        [3, 7, 8, 4],   // back (z=l)
        [4, 8, 5, 1],   // left (x=0)
      );
    } else if (templateType === 'envelope') {
      // Flat rectangular shape
      vertices.push(
        [0, 0, 0], [w, 0, 0], [w, 0, l], [0, 0, l],
      );
      faces.push([1, 2, 3, 4]);
    } else if (templateType === 'pillow') {
      // Box with curved top/bottom (approximated with segments)
      const segs = 6;
      // Bottom curved face
      for (let i = 0; i <= segs; i++) {
        const t = i / segs;
        const curve = Math.sin(t * Math.PI) * h * 0.3;
        vertices.push([0, -curve, t * l]);
        vertices.push([w, -curve, t * l]);
      }
      for (let i = 0; i < segs; i++) {
        faces.push([i * 2 + 1, i * 2 + 2, (i + 1) * 2 + 2, (i + 1) * 2 + 1]);
      }
      // Top curved face
      const tb = vertices.length;
      for (let i = 0; i <= segs; i++) {
        const t = i / segs;
        const curve = Math.sin(t * Math.PI) * h * 0.3;
        vertices.push([0, h + curve, t * l]);
        vertices.push([w, h + curve, t * l]);
      }
      for (let i = 0; i < segs; i++) {
        faces.push([tb + i * 2 + 1, tb + (i + 1) * 2 + 1, tb + (i + 1) * 2 + 2, tb + i * 2 + 2]);
      }
      // Front face (z=0)
      const fb = vertices.length;
      vertices.push([0, 0, 0], [w, 0, 0], [w, h, 0], [0, h, 0]);
      faces.push([fb + 1, fb + 2, fb + 3, fb + 4]);
      // Back face (z=l)
      const bb = vertices.length;
      vertices.push([0, 0, l], [w, 0, l], [w, h, l], [0, h, l]);
      faces.push([bb + 1, bb + 4, bb + 3, bb + 2]);
      // Left face (x=0)
      const lb = vertices.length;
      vertices.push([0, 0, 0], [0, 0, l], [0, h, l], [0, h, 0]);
      faces.push([lb + 1, lb + 2, lb + 3, lb + 4]);
      // Right face (x=w)
      const rb = vertices.length;
      vertices.push([w, 0, 0], [w, 0, l], [w, h, l], [w, h, 0]);
      faces.push([rb + 1, rb + 4, rb + 3, rb + 2]);
    } else if (templateType === 'pyramid') {
      // Pyramid: square base + 4 triangular faces + apex
      vertices.push(
        [0, 0, 0], [w, 0, 0], [w, 0, w], [0, 0, w], // 1-4: base (square)
        [w / 2, h, w / 2],                              // 5: apex
      );
      faces.push(
        [4, 3, 2, 1],  // base (winding reversed for downward normal)
        [1, 2, 5],      // front
        [2, 3, 5],      // right
        [3, 4, 5],      // back
        [4, 1, 5],      // left
      );
    } else if (templateType === 'hex_box') {
      // Hexagonal prism: 6-sided
      const r = w / 2;
      const cx = w / 2;
      const cy = l / 2;
      // Bottom hexagon (vertices 1-6)
      for (let i = 0; i < 6; i++) {
        const angle = (Math.PI / 3) * i - Math.PI / 6;
        vertices.push([cx + r * Math.cos(angle), 0, cy + r * Math.sin(angle)]);
      }
      // Top hexagon (vertices 7-12)
      for (let i = 0; i < 6; i++) {
        const angle = (Math.PI / 3) * i - Math.PI / 6;
        vertices.push([cx + r * Math.cos(angle), h, cy + r * Math.sin(angle)]);
      }
      // Bottom face (fan triangulation)
      faces.push([1, 3, 2], [1, 4, 3], [1, 5, 4], [1, 6, 5]);
      // Top face (reversed winding)
      faces.push([7, 8, 9], [7, 9, 10], [7, 10, 11], [7, 11, 12]);
      // Side faces
      for (let i = 0; i < 6; i++) {
        const next = (i + 1) % 6;
        faces.push([i + 1, i + 7, next + 7, next + 1]);
      }
    } else if (templateType === 'milk_carton') {
      // Tall box body + gable top
      const gableH = h * 0.35;
      // Body: 8 vertices (1-8)
      vertices.push(
        [0, 0, 0], [w, 0, 0], [w, 0, l], [0, 0, l],       // 1-4: bottom
        [0, h, 0], [w, h, 0], [w, h, l], [0, h, l],         // 5-8: top of box
        [0, h + gableH, l / 2], [w, h + gableH, l / 2],     // 9-10: gable peaks
      );
      faces.push(
        [1, 2, 3, 4],       // bottom
        [5, 6, 7, 8],       // top of box body
        [1, 5, 6, 2],       // front (z=0) lower
        [5, 6, 10, 9],      // front (z=0) gable
        [4, 8, 7, 3],       // back (z=l) lower
        [8, 9, 10, 7],      // back (z=l) gable (note: 9 is at x=0, 10 is at x=w)
        [1, 4, 8, 5],       // left (x=0) lower
        [5, 8, 9],          // left gable triangle
        [2, 6, 7, 3],       // right (x=w) lower
        [6, 10, 7],         // right gable triangle
      );
    } else if (templateType === 'cylinder') {
      // 12-sided polygon approximation
      const sides = 12;
      const r = w / 2;
      const cx = w / 2;
      const cy = l / 2;
      // Bottom circle (vertices 1-12)
      for (let i = 0; i < sides; i++) {
        const angle = (2 * Math.PI * i) / sides;
        vertices.push([cx + r * Math.cos(angle), 0, cy + r * Math.sin(angle)]);
      }
      // Top circle (vertices 13-24)
      for (let i = 0; i < sides; i++) {
        const angle = (2 * Math.PI * i) / sides;
        vertices.push([cx + r * Math.cos(angle), h, cy + r * Math.sin(angle)]);
      }
      // Bottom face (fan from vertex 1)
      for (let i = 1; i < sides - 1; i++) {
        faces.push([1, i + 2, i + 1]);
      }
      // Top face (fan from vertex sides+1)
      const topStart = sides + 1;
      for (let i = 1; i < sides - 1; i++) {
        faces.push([topStart, topStart + i, topStart + i + 1]);
      }
      // Side faces
      for (let i = 0; i < sides; i++) {
        const next = (i + 1) % sides;
        faces.push([i + 1, i + 1 + sides, next + 1 + sides, next + 1]);
      }
    } else {
      // Fallback: basic box
      vertices.push(
        [0, 0, 0], [w, 0, 0], [w, 0, l], [0, 0, l],
        [0, h, 0], [w, h, 0], [w, h, l], [0, h, l],
      );
      faces.push(
        [1, 2, 3, 4], [8, 7, 6, 5],
        [1, 5, 6, 2], [2, 6, 7, 3],
        [3, 7, 8, 4], [4, 8, 5, 1],
      );
    }

    return { vertices, faces };
  }, [templateType, width, length, height]);

  // Convert faces to triangulated form for STL
  const triangulateFaces = useCallback((faces: number[][]) => {
    const triangles: number[][] = [];
    for (const face of faces) {
      if (face.length === 3) {
        triangles.push(face);
      } else if (face.length >= 4) {
        // Fan triangulation from first vertex
        for (let i = 1; i < face.length - 1; i++) {
          triangles.push([face[0], face[i], face[i + 1]]);
        }
      }
    }
    return triangles;
  }, []);

  // Compute normal for a triangle (given 3 vertices)
  const computeNormal = useCallback((v0: number[], v1: number[], v2: number[]) => {
    const ax = v1[0] - v0[0], ay = v1[1] - v0[1], az = v1[2] - v0[2];
    const bx = v2[0] - v0[0], by = v2[1] - v0[1], bz = v2[2] - v0[2];
    const nx = ay * bz - az * by;
    const ny = az * bx - ax * bz;
    const nz = ax * by - ay * bx;
    const len = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
    return [nx / len, ny / len, nz / len];
  }, []);

  const handleDownloadOBJ = () => {
    if (!consumeAttempt('template_download')) return;
    const { vertices, faces } = generateGeometry();

    let objData = `# ArtNew8 3D Template\n# ${templateInfo.templateName} ${templateInfo.dimensions}\no ${templateInfo.templateName}\n`;
    for (const v of vertices) {
      objData += `v ${v[0].toFixed(4)} ${v[1].toFixed(4)} ${v[2].toFixed(4)}\n`;
    }
    for (const f of faces) {
      objData += `f ${f.join(' ')}\n`;
    }

    const blob = new Blob([objData], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ArtNew8_${templateInfo.templateName}_${templateInfo.dimensions}.obj`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showDownloadFeedback('OBJ');
  };

  const handleDownloadSTL = () => {
    if (!consumeAttempt('template_download')) return;

    const { vertices, faces } = generateGeometry();
    const triangles = triangulateFaces(faces);

    // Compute normals and write binary STL
    const numTriangles = triangles.length;
    const bufferSize = 84 + numTriangles * 50;
    const buffer = new ArrayBuffer(bufferSize);
    const dv = new DataView(buffer);

    // Header (80 bytes)
    const header = `ArtNew8 STL - ${templateInfo.templateName} ${templateInfo.dimensions}`;
    for (let i = 0; i < 80; i++) {
      dv.setUint8(i, i < header.length ? header.charCodeAt(i) : 0);
    }

    // Number of triangles
    dv.setUint32(80, numTriangles, true);

    let offset = 84;

    for (const tri of triangles) {
      const v0 = vertices[tri[0] - 1]; // Convert 1-indexed to 0-indexed
      const v1 = vertices[tri[1] - 1];
      const v2 = vertices[tri[2] - 1];
      if (!v0 || !v1 || !v2) continue;

      const normal = computeNormal(v0, v1, v2);

      // Normal
      dv.setFloat32(offset, normal[0], true); offset += 4;
      dv.setFloat32(offset, normal[1], true); offset += 4;
      dv.setFloat32(offset, normal[2], true); offset += 4;
      // Vertex 1
      dv.setFloat32(offset, v0[0], true); offset += 4;
      dv.setFloat32(offset, v0[1], true); offset += 4;
      dv.setFloat32(offset, v0[2], true); offset += 4;
      // Vertex 2
      dv.setFloat32(offset, v1[0], true); offset += 4;
      dv.setFloat32(offset, v1[1], true); offset += 4;
      dv.setFloat32(offset, v1[2], true); offset += 4;
      // Vertex 3
      dv.setFloat32(offset, v2[0], true); offset += 4;
      dv.setFloat32(offset, v2[1], true); offset += 4;
      dv.setFloat32(offset, v2[2], true); offset += 4;
      // Attribute byte count
      dv.setUint16(offset, 0, true); offset += 2;
    }

    const blob = new Blob([buffer], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ArtNew8_${templateInfo.templateName}_${templateInfo.dimensions}.stl`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showDownloadFeedback('STL');
  };

  // Parse SVG path commands to DXF LINE entities
  // Supports: M, L, H, V, Z (and lowercase relative variants)
  function parseSvgPathToDxf(d: string, layer: string): string {
    let dxf = '';
    let curX = 0, curY = 0;
    let startX = 0, startY = 0; // for Z command
    let prevCmd = '';

    // Tokenize: split on command letters while keeping them
    const tokens = d.match(/[MmLlHhVvZz]|[-+]?[\d.]+/g) || [];
    let idx = 0;

    function readNum(): number {
      if (idx >= tokens.length) return 0;
      const val = parseFloat(tokens[idx]);
      idx++;
      return isNaN(val) ? 0 : val;
    }

    function emitLine(x1: number, y1: number, x2: number, y2: number) {
      dxf += `0\nLINE\n8\n${layer}\n10\n${x1.toFixed(4)}\n20\n${y1.toFixed(4)}\n30\n0\n11\n${x2.toFixed(4)}\n21\n${y2.toFixed(4)}\n31\n0\n`;
    }

    while (idx < tokens.length) {
      const token = tokens[idx];
      // Check if this token is a command letter
      if (/^[MmLlHhVvZz]$/.test(token)) {
        const cmd = token;
        idx++;

        switch (cmd) {
          case 'M': { // absolute moveto
            const x = readNum();
            const y = readNum();
            curX = x; curY = y;
            startX = x; startY = y;
            break;
          }
          case 'm': { // relative moveto
            const dx = readNum();
            const dy = readNum();
            curX += dx; curY += dy;
            startX = curX; startY = curY;
            break;
          }
          case 'L': { // absolute lineto
            const x = readNum();
            const y = readNum();
            emitLine(curX, curY, x, y);
            curX = x; curY = y;
            break;
          }
          case 'l': { // relative lineto
            const dx = readNum();
            const dy = readNum();
            const newX = curX + dx;
            const newY = curY + dy;
            emitLine(curX, curY, newX, newY);
            curX = newX; curY = newY;
            break;
          }
          case 'H': { // absolute horizontal lineto
            const x = readNum();
            emitLine(curX, curY, x, curY);
            curX = x;
            break;
          }
          case 'h': { // relative horizontal lineto
            const dx = readNum();
            const newX = curX + dx;
            emitLine(curX, curY, newX, curY);
            curX = newX;
            break;
          }
          case 'V': { // absolute vertical lineto
            const y = readNum();
            emitLine(curX, curY, curX, y);
            curY = y;
            break;
          }
          case 'v': { // relative vertical lineto
            const dy = readNum();
            const newY = curY + dy;
            emitLine(curX, curY, curX, newY);
            curY = newY;
            break;
          }
          case 'Z':
          case 'z': { // close path
            if (curX !== startX || curY !== startY) {
              emitLine(curX, curY, startX, startY);
            }
            curX = startX; curY = startY;
            break;
          }
          default:
            break;
        }
        prevCmd = cmd;
      } else {
        // Implicit repeat of previous command (L or M after first)
        // SVG spec: if a number follows M, subsequent pairs are treated as L
        if (prevCmd === 'M' || prevCmd === 'm') {
          // Treat as L (absolute) or l (relative)
          if (prevCmd === 'M') {
            const x = readNum();
            const y = readNum();
            emitLine(curX, curY, x, y);
            curX = x; curY = y;
          } else {
            const dx = readNum();
            const dy = readNum();
            const newX = curX + dx;
            const newY = curY + dy;
            emitLine(curX, curY, newX, newY);
            curX = newX; curY = newY;
          }
        } else if (prevCmd === 'L' || prevCmd === 'l') {
          if (prevCmd === 'L') {
            const x = readNum();
            const y = readNum();
            emitLine(curX, curY, x, y);
            curX = x; curY = y;
          } else {
            const dx = readNum();
            const dy = readNum();
            const newX = curX + dx;
            const newY = curY + dy;
            emitLine(curX, curY, newX, newY);
            curX = newX; curY = newY;
          }
        } else if (prevCmd === 'H' || prevCmd === 'h') {
          if (prevCmd === 'H') {
            const x = readNum();
            emitLine(curX, curY, x, curY);
            curX = x;
          } else {
            const dx = readNum();
            const newX = curX + dx;
            emitLine(curX, curY, newX, curY);
            curX = newX;
          }
        } else if (prevCmd === 'V' || prevCmd === 'v') {
          if (prevCmd === 'V') {
            const y = readNum();
            emitLine(curX, curY, curX, y);
            curY = y;
          } else {
            const dy = readNum();
            const newY = curY + dy;
            emitLine(curX, curY, curX, newY);
            curY = newY;
          }
        } else {
          // Unknown state, skip this token
          idx++;
        }
      }
    }
    return dxf;
  }

  // Estimate file sizes for display
  const estimateFileSize = (format: string): string => {
    const baseSize = (templateInfo.totalWidth * templateInfo.totalLength) / 100;
    switch (format) {
      case 'SVG': return `~${Math.round(baseSize * 0.8)}KB`;
      case 'PDF': return `~${Math.round(baseSize * 1.5)}KB`;
      case 'DXF': return `~${Math.round(baseSize * 0.6)}KB`;
      case 'OBJ': return `~${Math.round(baseSize * 0.4)}KB`;
      case 'STL': return `~${Math.round(baseSize * 0.5)}KB`;
      case 'PNG': return `~${Math.round(baseSize * 5)}KB`;
      default: return '';
    }
  };

  const templateTypes = [
    // ─── Classic Boxes ───
    { type: 'box' as TemplateType, icon: <Cuboid size={14} />, label: t('template_tray') },
    { type: 'mailer' as TemplateType, icon: <Package size={14} />, label: t('template_mailer') },
    { type: 'tuck_end' as TemplateType, icon: <Box size={14} />, label: t('template_tuck_end') },
    { type: 'reverse_tuck' as TemplateType, icon: <Archive size={14} />, label: t('template_reverse_tuck') },
    { type: 'auto_lock' as TemplateType, icon: <DoorOpen size={14} />, label: t('template_auto_lock') },
    // ─── Specialty Boxes ───
    { type: 'pillow' as TemplateType, icon: <Package size={14} />, label: t('template_pillow') },
    { type: 'gable_box' as TemplateType, icon: <Gift size={14} />, label: t('template_gable') },
    { type: 'sleeve_box' as TemplateType, icon: <Layers size={14} />, label: t('template_sleeve') },
    { type: 'drawer_box' as TemplateType, icon: <Archive size={14} />, label: t('template_drawer_box') },
    { type: 'window_box' as TemplateType, icon: <ScanEye size={14} />, label: t('template_window_box') },
    { type: 'display_box' as TemplateType, icon: <Monitor size={14} />, label: t('template_display') },
    // ─── Food & Beverage ───
    { type: 'milk_carton' as TemplateType, icon: <Coffee size={14} />, label: t('template_milk') },
    { type: 'french_fry' as TemplateType, icon: <Package size={14} />, label: t('template_french_fry') },
    { type: 'pizza_box' as TemplateType, icon: <Pizza size={14} />, label: t('template_pizza_box') },
    { type: 'takeout' as TemplateType, icon: <ShoppingBag size={14} />, label: t('template_takeout') },
    { type: 'favor_box' as TemplateType, icon: <Gift size={14} />, label: t('template_favor_box') },
    // ─── Unique Shapes ───
    { type: 'envelope' as TemplateType, icon: <Mail size={14} />, label: t('template_envelope') },
    { type: 'pyramid' as TemplateType, icon: <Triangle size={14} />, label: t('template_pyramid') },
    { type: 'hex_box' as TemplateType, icon: <Hexagon size={14} />, label: t('template_hex') },
    { type: 'cylinder' as TemplateType, icon: <Circle size={14} />, label: t('template_cylinder') },
    { type: 'cone' as TemplateType, icon: <PartyPopper size={14} />, label: t('template_cone') },
    { type: 'heart_box' as TemplateType, icon: <Heart size={14} />, label: t('template_heart_box') },
  ];

  const presets = [
    { id: 'small', label: t('preset_small'), dims: '40×40×40mm' },
    { id: 'medium', label: t('preset_medium'), dims: '80×60×40mm' },
    { id: 'large', label: t('preset_large'), dims: '200×150×50mm' },
    { id: 'a2', label: t('preset_a2'), dims: '111×146mm' },
    { id: 'custom', label: t('preset_custom'), dims: '' },
  ];

  return (
    <div className="space-y-4 sm:space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100/50 text-brand-700 text-[10px] sm:text-xs font-bold tracking-widest uppercase mb-3 shadow-sm border border-brand-200/50">
          <Settings size={12} /> {t('advanced_engine')}
        </div>
        <h2 className="text-2xl sm:text-3xl font-display font-bold text-brand-950 tracking-tight">{t('pro_template_gen')}</h2>
        <p className="text-brand-800 mt-2 max-w-3xl text-xs sm:text-sm leading-relaxed">
          {t('pro_template_desc')}
        </p>
      </div>

      {/* Template Type Selector - scrollable on mobile */}
      <div className="flex gap-2 sm:gap-3 overflow-x-auto scrollbar-hide pb-1 -mx-3 px-3 sm:mx-0 sm:px-0 sm:flex-wrap">
        {templateTypes.map(({ type, icon, label }) => (
          <button
            key={type}
            onClick={() => { setTemplateType(type); setActivePreset('custom'); }}
            className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-5 py-2 sm:py-3 rounded-full font-bold text-xs sm:text-sm transition-all shadow-sm border whitespace-nowrap shrink-0 active:scale-95 ${
              templateType === type
                ? 'bg-brand-500 text-white border-brand-500'
                : 'bg-white text-brand-700 border-brand-200 hover:bg-brand-50'
            }`}
          >
            {icon} {label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-8">
        {/* Controls */}
        <div className="lg:col-span-5 glass-panel p-4 sm:p-6 md:p-8 rounded-2xl sm:rounded-[2rem] shadow-sm border border-brand-200/60 flex flex-col gap-4 sm:gap-6 bg-white/60">
          
          {/* Quick Presets */}
          <div className="space-y-2">
            <h3 className="font-bold text-brand-900 text-xs sm:text-sm flex items-center gap-1.5">
              <Box size={14} className="text-brand-500" /> {t('preset_sizes')}
            </h3>
            <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
              {presets.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => applyPreset(preset.id)}
                  className={`flex flex-col items-center gap-0.5 px-1.5 sm:px-2 py-1.5 sm:py-2 rounded-lg sm:rounded-xl font-bold text-[9px] sm:text-[10px] transition-all border active:scale-95 ${
                    activePreset === preset.id
                      ? 'bg-sage-700 text-white border-sage-700'
                      : 'bg-white text-brand-700 border-brand-200 hover:bg-brand-50'
                  }`}
                >
                  <span>{preset.label}</span>
                  {preset.dims && <span className="text-[7px] sm:text-[8px] opacity-70">{preset.dims}</span>}
                </button>
              ))}
            </div>
          </div>

          {/* Base Dimensions */}
          <div className="space-y-4 sm:space-y-5">
            <h3 className="font-bold text-brand-900 border-b border-brand-100 pb-2 text-sm sm:text-base">{t('base_dimensions')}</h3>

            {/* Width Control */}
            <div className="p-3 sm:p-4 rounded-xl bg-amber-50/60 border border-amber-200/50">
              <label className="flex items-center gap-1.5 text-[10px] sm:text-xs font-bold text-amber-700 mb-2.5 uppercase tracking-wide">
                <ArrowRight size={14} className="text-amber-500" /> {t('width')}
              </label>
              <div className="flex items-center gap-2 mb-2.5">
                <button
                  onClick={() => { setWidth(Math.max(10, width - 5)); setActivePreset('custom'); }}
                  className="w-11 h-11 sm:w-12 sm:h-12 flex items-center justify-center bg-amber-100 hover:bg-amber-200 text-amber-800 rounded-xl font-bold text-xl transition-colors active:scale-90 shadow-sm border border-amber-200/60"
                  aria-label={t('dim_decrement')}
                >
                  −
                </button>
                <div className="flex-1 flex items-center justify-center">
                  <input
                    type="number"
                    min="10" max="300"
                    value={width}
                    onChange={(e) => { const v = Math.min(300, Math.max(10, parseInt(e.target.value) || 10)); setWidth(v); setActivePreset('custom'); }}
                    className="w-20 sm:w-24 text-center text-xl sm:text-2xl font-black text-amber-800 bg-white border-2 border-amber-300 rounded-lg py-1 outline-none focus:ring-2 focus:ring-amber-400 focus:border-amber-400 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  />
                  <span className="text-xs text-amber-500 ms-1.5 font-bold">mm</span>
                </div>
                <button
                  onClick={() => { setWidth(Math.min(300, width + 5)); setActivePreset('custom'); }}
                  className="w-11 h-11 sm:w-12 sm:h-12 flex items-center justify-center bg-amber-100 hover:bg-amber-200 text-amber-800 rounded-xl font-bold text-xl transition-colors active:scale-90 shadow-sm border border-amber-200/60"
                  aria-label={t('dim_increment')}
                >
                  +
                </button>
              </div>
              <input
                type="range" min="10" max="300" value={width}
                onChange={(e) => { setWidth(Number(e.target.value)); setActivePreset('custom'); }}
                className="w-full h-3 bg-amber-200 rounded-full appearance-none cursor-pointer accent-amber-500 touch-manipulation mb-2"
              />
              <div className="flex gap-1.5">
                {[1, 5, 10].map((step) => (
                  <button
                    key={step}
                    onClick={() => { setWidth(Math.min(300, Math.max(10, width + step))); setActivePreset('custom'); }}
                    className="flex-1 py-1 bg-amber-100 hover:bg-amber-200 text-amber-700 border border-amber-200/60 rounded-lg text-[9px] sm:text-[10px] font-bold transition-colors active:scale-95"
                  >
                    +{step}mm
                  </button>
                ))}
              </div>
            </div>

            {/* Length Control */}
            <div className="p-3 sm:p-4 rounded-xl bg-emerald-50/60 border border-emerald-200/50">
              <label className="flex items-center gap-1.5 text-[10px] sm:text-xs font-bold text-emerald-700 mb-2.5 uppercase tracking-wide">
                <ArrowDown size={14} className="text-emerald-500" /> {t('length')}
              </label>
              <div className="flex items-center gap-2 mb-2.5">
                <button
                  onClick={() => { setLength(Math.max(10, length - 5)); setActivePreset('custom'); }}
                  className="w-11 h-11 sm:w-12 sm:h-12 flex items-center justify-center bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl font-bold text-xl transition-colors active:scale-90 shadow-sm border border-emerald-200/60"
                  aria-label={t('dim_decrement')}
                >
                  −
                </button>
                <div className="flex-1 flex items-center justify-center">
                  <input
                    type="number"
                    min="10" max="300"
                    value={length}
                    onChange={(e) => { const v = Math.min(300, Math.max(10, parseInt(e.target.value) || 10)); setLength(v); setActivePreset('custom'); }}
                    className="w-20 sm:w-24 text-center text-xl sm:text-2xl font-black text-emerald-800 bg-white border-2 border-emerald-300 rounded-lg py-1 outline-none focus:ring-2 focus:ring-emerald-400 focus:border-emerald-400 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  />
                  <span className="text-xs text-emerald-500 ms-1.5 font-bold">mm</span>
                </div>
                <button
                  onClick={() => { setLength(Math.min(300, length + 5)); setActivePreset('custom'); }}
                  className="w-11 h-11 sm:w-12 sm:h-12 flex items-center justify-center bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl font-bold text-xl transition-colors active:scale-90 shadow-sm border border-emerald-200/60"
                  aria-label={t('dim_increment')}
                >
                  +
                </button>
              </div>
              <input
                type="range" min="10" max="300" value={length}
                onChange={(e) => { setLength(Number(e.target.value)); setActivePreset('custom'); }}
                className="w-full h-3 bg-emerald-200 rounded-full appearance-none cursor-pointer accent-emerald-500 touch-manipulation mb-2"
              />
              <div className="flex gap-1.5">
                {[1, 5, 10].map((step) => (
                  <button
                    key={step}
                    onClick={() => { setLength(Math.min(300, Math.max(10, length + step))); setActivePreset('custom'); }}
                    className="flex-1 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-700 border border-emerald-200/60 rounded-lg text-[9px] sm:text-[10px] font-bold transition-colors active:scale-95"
                  >
                    +{step}mm
                  </button>
                ))}
              </div>
            </div>

            {/* Height Control */}
            {templateType !== 'envelope' && (
              <div className="p-3 sm:p-4 rounded-xl bg-violet-50/60 border border-violet-200/50">
                <label className="flex items-center gap-1.5 text-[10px] sm:text-xs font-bold text-violet-700 mb-2.5 uppercase tracking-wide">
                  <ArrowUp size={14} className="text-violet-500" /> {t('height')}
                </label>
                <div className="flex items-center gap-2 mb-2.5">
                  <button
                    onClick={() => { setHeight(Math.max(5, height - 5)); setActivePreset('custom'); }}
                    className="w-11 h-11 sm:w-12 sm:h-12 flex items-center justify-center bg-violet-100 hover:bg-violet-200 text-violet-800 rounded-xl font-bold text-xl transition-colors active:scale-90 shadow-sm border border-violet-200/60"
                    aria-label={t('dim_decrement')}
                  >
                    −
                  </button>
                  <div className="flex-1 flex items-center justify-center">
                    <input
                      type="number"
                      min="5" max="200"
                      value={height}
                      onChange={(e) => { const v = Math.min(200, Math.max(5, parseInt(e.target.value) || 5)); setHeight(v); setActivePreset('custom'); }}
                      className="w-20 sm:w-24 text-center text-xl sm:text-2xl font-black text-violet-800 bg-white border-2 border-violet-300 rounded-lg py-1 outline-none focus:ring-2 focus:ring-violet-400 focus:border-violet-400 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                    />
                    <span className="text-xs text-violet-500 ms-1.5 font-bold">mm</span>
                  </div>
                  <button
                    onClick={() => { setHeight(Math.min(200, height + 5)); setActivePreset('custom'); }}
                    className="w-11 h-11 sm:w-12 sm:h-12 flex items-center justify-center bg-violet-100 hover:bg-violet-200 text-violet-800 rounded-xl font-bold text-xl transition-colors active:scale-90 shadow-sm border border-violet-200/60"
                    aria-label={t('dim_increment')}
                  >
                    +
                  </button>
                </div>
                <input
                  type="range" min="5" max="200" value={height}
                  onChange={(e) => { setHeight(Number(e.target.value)); setActivePreset('custom'); }}
                  className="w-full h-3 bg-violet-200 rounded-full appearance-none cursor-pointer accent-violet-500 touch-manipulation mb-2"
                />
                <div className="flex gap-1.5">
                  {[1, 5, 10].map((step) => (
                    <button
                      key={step}
                      onClick={() => { setHeight(Math.min(200, Math.max(5, height + step))); setActivePreset('custom'); }}
                      className="flex-1 py-1 bg-violet-100 hover:bg-violet-200 text-violet-700 border border-violet-200/60 rounded-lg text-[9px] sm:text-[10px] font-bold transition-colors active:scale-95"
                    >
                      +{step}mm
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Volume Calculator */}
          <div className="space-y-2 p-3 sm:p-4 bg-sage-50/60 rounded-xl border border-sage-200/60">
            <h3 className="font-bold text-brand-900 text-xs sm:text-sm flex items-center gap-1.5">
              <Calculator size={14} className="text-sage-600" /> {t('volume_calc')}
            </h3>
            <div className="flex gap-2">
              <input
                type="number"
                min="1"
                placeholder={t('volume_label')}
                value={volumeInput}
                onChange={(e) => setVolumeInput(e.target.value)}
                className="flex-1 bg-white border border-sage-200 text-brand-800 text-xs sm:text-sm rounded-lg focus:ring-sage-500 focus:border-sage-500 p-2 font-medium outline-none min-w-0"
              />
              <button
                onClick={calculateFromVolume}
                className="bg-sage-600 hover:bg-sage-700 text-white px-3 sm:px-4 py-2 rounded-lg text-[10px] sm:text-xs font-bold transition-colors active:scale-95 shrink-0"
              >
                {t('calc_from_volume')}
              </button>
            </div>
            <p className="text-[8px] sm:text-[9px] text-sage-500">φ Golden ratio: W:L:H ≈ 1.618:2.618:1</p>
          </div>

          {/* Paper Material Selector */}
          <div className="space-y-2">
            <h3 className="font-bold text-brand-900 text-xs sm:text-sm flex items-center gap-1.5">
              <Leaf size={14} className="text-brand-500" /> {t('paper_material')}
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {(Object.entries(PAPER_MATERIALS) as [PaperMaterial, typeof PAPER_MATERIALS[PaperMaterial]][]).map(([key, mat]) => (
                <button
                  key={key}
                  onClick={() => handleMaterialChange(key)}
                  className={`flex flex-col items-start gap-0.5 px-2.5 sm:px-3 py-2 sm:py-2.5 rounded-lg sm:rounded-xl font-bold text-[9px] sm:text-[10px] transition-all border active:scale-95 ${
                    paperMaterial === key
                      ? 'bg-brand-500 text-white border-brand-500'
                      : 'bg-white text-brand-700 border-brand-200 hover:bg-brand-50'
                  }`}
                >
                  <span>{t(mat.labelKey)}</span>
                  <span className={`text-[7px] sm:text-[8px] ${paperMaterial === key ? 'text-white/70' : 'text-brand-400'}`}>
                    Kerf: {mat.kerf}mm
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-1">
            <button onClick={() => setShowAdvanced(!showAdvanced)} className="text-brand-600 font-bold text-xs sm:text-sm flex items-center gap-1 hover:text-brand-800 active:scale-95">
              <Settings size={14} />
              {showAdvanced ? t('hide_advanced') : t('show_advanced')}
            </button>
          </div>

          {showAdvanced && (
            <div className="space-y-3 sm:space-y-4 p-3 sm:p-4 bg-white rounded-xl border border-brand-100 shadow-inner animate-in fade-in zoom-in-95 duration-200">
              <div>
                <label className="block text-[10px] sm:text-xs font-bold text-brand-700 mb-2 uppercase tracking-wide">{t('machine_format')}</label>
                <select value={machine} onChange={(e) => setMachine(e.target.value as any)} className="w-full bg-brand-50 border border-brand-200 text-brand-800 text-xs sm:text-sm rounded-lg focus:ring-brand-500 focus:border-brand-500 block p-2.5 font-medium outline-none">
                  <option value="standard">{t('machine_standard')}</option>
                  <option value="cricut">{t('machine_cricut')}</option>
                  <option value="silhouette">{t('machine_silhouette')}</option>
                  <option value="laser">{t('machine_laser')}</option>
                </select>
              </div>
              <div>
                <label className="flex justify-between text-[10px] sm:text-xs font-bold text-brand-700 mb-1 uppercase tracking-wide">
                  <span>{t('kerf_comp')}</span>
                  <span className="text-brand-600">{kerf}</span>
                </label>
                <p className="text-[9px] sm:text-[10px] text-brand-500 mb-2">{t('kerf_desc')}</p>
                <input type="range" min="0" max="2" step="0.1" value={kerf} onChange={(e) => setKerf(Number(e.target.value))} className="w-full h-2 sm:h-1.5 bg-brand-100 rounded-lg appearance-none cursor-pointer accent-brand-500 touch-manipulation" />
              </div>
              <div>
                <label className="flex justify-between text-[10px] sm:text-xs font-bold text-brand-700 mb-2 uppercase tracking-wide">
                  <span>{t('glue_tab')}</span>
                  <span className="text-brand-600">{glueTab}</span>
                </label>
                <input type="range" min="5" max="30" value={glueTab} onChange={(e) => setGlueTab(Number(e.target.value))} className="w-full h-2 sm:h-1.5 bg-brand-100 rounded-lg appearance-none cursor-pointer accent-brand-500 touch-manipulation" />
              </div>
              <div>
                <label className="flex justify-between text-[10px] sm:text-xs font-bold text-brand-700 mb-2 uppercase tracking-wide">
                  <span>{t('material_thickness')}</span>
                  <span className="text-brand-600">{materialThickness}mm</span>
                </label>
                <input type="range" min="0.1" max="2" step="0.1" value={materialThickness} readOnly className="w-full h-2 sm:h-1.5 bg-brand-100 rounded-lg appearance-none cursor-pointer accent-brand-500 opacity-60" />
              </div>
              {/* Bleed & Safe Zone Toggles */}
              <div className="flex gap-4 pt-2">
                <label className="flex items-center gap-2 text-[10px] sm:text-xs font-bold text-brand-700 cursor-pointer">
                  <input type="checkbox" checked={showBleed} onChange={(e) => setShowBleed(e.target.checked)} className="accent-brand-500 w-3.5 h-3.5" />
                  {t('show_bleed')}
                </label>
                <label className="flex items-center gap-2 text-[10px] sm:text-xs font-bold text-brand-700 cursor-pointer">
                  <input type="checkbox" checked={showSafe} onChange={(e) => setShowSafe(e.target.checked)} className="accent-sage-600 w-3.5 h-3.5" />
                  {t('show_safe')}
                </label>
              </div>
            </div>
          )}

          {/* Primary Download - Flat Template */}
          <div className="space-y-2 sm:space-y-3 pt-1">
            <button onClick={handleDownloadSVG} disabled={isDownloadLimited}
              className="w-full flex items-center justify-center gap-2 sm:gap-3 bg-brand-600 hover:bg-brand-500 text-white py-3 sm:py-4 px-4 sm:px-6 rounded-xl sm:rounded-2xl font-bold transition-all shadow-[0_4px_20px_-5px_rgba(201,123,110,0.5)] text-xs sm:text-sm cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed">
              <Download size={18} />
              <span>{isDownloadLimited ? (lang === 'ar' ? 'تم الوصول للحد اليومي' : lang === 'fr' ? 'Limite Atteinte' : 'Daily Limit Reached') : t('download_flat_template')}</span>
              {!isDownloadLimited && <span className="text-[10px] sm:text-xs bg-white/20 px-2 py-0.5 rounded-md">SVG · {remainingDownloads}/8</span>}
            </button>
            {downloadSuccess && (
              <div className="text-center text-xs font-bold text-green-600 animate-in fade-in slide-in-from-top-2">
                ✓ {t('download_success')} {downloadSuccess}
              </div>
            )}
          </div>

          {/* Secondary Downloads */}
          <div className="mt-auto pt-3 sm:pt-4 border-t border-brand-100 space-y-2.5">
            {/* Flat Downloads — 2D dieline formats */}
            <div>
              <h4 className="font-bold text-brand-600 text-[9px] sm:text-[10px] uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <Ruler size={11} className="text-brand-400" /> {t('flat_downloads') || 'Flat Downloads'}
              </h4>
              <div className="grid grid-cols-4 gap-1.5 sm:gap-2">
                <button onClick={handleDownloadSVG} disabled={isDownloadLimited} className="flex flex-col items-center justify-center gap-1 sm:gap-1.5 bg-white hover:bg-brand-50 text-brand-900 border border-brand-200 py-2.5 sm:py-3 px-1 sm:px-3 rounded-lg sm:rounded-xl font-bold transition-colors shadow-sm text-[10px] sm:text-xs cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed">
                  <Download size={16} className="sm:w-[18px] sm:h-[18px]" />
                  SVG
                  <span className="text-[7px] text-brand-400 hidden sm:block">{estimateFileSize('SVG')}</span>
                </button>
                <button onClick={handleDownloadPNG} disabled={isDownloadLimited} className="flex flex-col items-center justify-center gap-1 sm:gap-1.5 bg-white hover:bg-brand-50 text-brand-900 border border-brand-200 py-2.5 sm:py-3 px-1 sm:px-3 rounded-lg sm:rounded-xl font-bold transition-colors shadow-sm text-[10px] sm:text-xs cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed">
                  <Eye size={16} className="sm:w-[18px] sm:h-[18px]" />
                  {t('btn_png') || 'PNG'}
                  <span className="text-[7px] text-brand-400 hidden sm:block">{estimateFileSize('PNG')}</span>
                </button>
                <button onClick={handleDownloadPDF} disabled={isDownloadLimited} className="flex flex-col items-center justify-center gap-1 sm:gap-1.5 bg-white hover:bg-brand-50 text-brand-900 border border-brand-200 py-2.5 sm:py-3 px-1 sm:px-3 rounded-lg sm:rounded-xl font-bold transition-colors shadow-sm text-[10px] sm:text-xs cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed">
                  <Printer size={16} className="sm:w-[18px] sm:h-[18px]" />
                  {t('btn_pdf') || 'PDF'}
                  <span className="text-[7px] text-brand-400 hidden sm:block">{estimateFileSize('PDF')}</span>
                </button>
                <button onClick={handleDownloadDXF} disabled={isDownloadLimited} className="flex flex-col items-center justify-center gap-1 sm:gap-1.5 bg-white hover:bg-brand-50 text-brand-900 border border-brand-200 py-2.5 sm:py-3 px-1 sm:px-3 rounded-lg sm:rounded-xl font-bold transition-colors shadow-sm text-[10px] sm:text-xs cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed">
                  <FileText size={16} className="sm:w-[18px] sm:h-[18px]" />
                  {t('btn_dxf') || 'DXF'}
                  <span className="text-[7px] text-brand-400 hidden sm:block">{estimateFileSize('DXF')}</span>
                </button>
              </div>
            </div>
            {/* 3D Downloads — 3D model formats + screenshot */}
            <div>
              <h4 className="font-bold text-brand-600 text-[9px] sm:text-[10px] uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <Cuboid size={11} className="text-brand-400" /> {t('3d_downloads') || '3D Downloads'}
              </h4>
              <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                <button onClick={handleDownloadOBJ} disabled={isDownloadLimited} className="flex flex-col items-center justify-center gap-1 sm:gap-1.5 bg-violet-50 hover:bg-violet-100 text-violet-700 border border-violet-200 py-2.5 sm:py-3 px-1 sm:px-2 rounded-lg sm:rounded-xl font-bold transition-colors shadow-sm text-[10px] sm:text-xs cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed">
                  <Cuboid size={16} className="sm:w-[18px] sm:h-[18px]" />
                  {t('btn_obj') || 'OBJ'}
                  <span className="text-[7px] text-violet-400 hidden sm:block">{estimateFileSize('OBJ')}</span>
                </button>
                <button onClick={handleDownloadSTL} disabled={isDownloadLimited} className="flex flex-col items-center justify-center gap-1 sm:gap-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 py-2.5 sm:py-3 px-1 sm:px-2 rounded-lg sm:rounded-xl font-bold transition-colors shadow-sm text-[10px] sm:text-xs cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed">
                  <Cuboid size={16} className="sm:w-[18px] sm:h-[18px]" />
                  STL
                  <span className="text-[7px] text-emerald-400 hidden sm:block">{estimateFileSize('STL')}</span>
                </button>
                <button
                  onClick={() => {
                    if (!consumeAttempt('template_download')) return;
                    if (preview3dRef.current) {
                      preview3dRef.current.captureScreenshot();
                      showDownloadFeedback('📷');
                    }
                  }}
                  disabled={isDownloadLimited}
                  className="flex flex-col items-center justify-center gap-1 sm:gap-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 py-2.5 sm:py-3 px-1 sm:px-2 rounded-lg sm:rounded-xl font-bold transition-colors shadow-sm text-[10px] sm:text-xs cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                  title={t('screenshot_png') || '3D Screenshot as PNG'}
                >
                  <Camera size={16} className="sm:w-[18px] sm:h-[18px]" />
                  {t('screenshot_png') || '📷'}
                  <span className="text-[7px] text-amber-400 hidden sm:block">3D</span>
                </button>
              </div>
            </div>
            {/* Remaining downloads indicator */}
            <div className="text-center">
              <span className="text-[8px] sm:text-[9px] font-bold text-brand-400">
                {t('remaining') || 'Remaining'}: {remainingDownloads}/8
              </span>
            </div>
          </div>
        </div>

        {/* 2D/3D Preview */}
        <div className={`flex flex-col gap-3 sm:gap-4 relative ${viewMode === '3d' ? 'lg:col-span-7' : 'lg:col-span-7'}`}>
          {/* Toolbar for 3D mode — simplified: just view toggle + info */}
          {viewMode === '3d' && (
            <div className="flex items-center gap-2 sm:gap-3 p-2 sm:p-3 bg-white rounded-xl border border-brand-200/60 shadow-sm animate-in fade-in slide-in-from-top-2 duration-300">
              {/* View mode toggle */}
              <div className="flex gap-0.5 bg-brand-50 p-0.5 rounded-lg border border-brand-100 shrink-0">
                <button onClick={() => setViewMode('2d')} className="px-2.5 sm:px-3 py-1.5 rounded-md text-[10px] sm:text-xs font-bold transition-all flex items-center gap-1 text-brand-600 hover:bg-white">
                  <Ruler size={12} /> <span className="hidden sm:inline">{t('sim_2d')}</span>
                </button>
                <button className="px-2.5 sm:px-3 py-1.5 rounded-md text-[10px] sm:text-xs font-bold bg-brand-500 text-white shadow-sm flex items-center gap-1">
                  <Move3d size={12} /> <span className="hidden sm:inline">{t('sim_3d')}</span>
                </button>
              </div>

              {/* Download success feedback */}
              {downloadSuccess && (
                <span className="text-[10px] sm:text-xs font-bold text-green-600 animate-in fade-in slide-in-from-top-1 whitespace-nowrap">
                  ✓ {downloadSuccess}
                </span>
              )}

              {/* Share buttons (compact) */}
              <div className="hidden sm:flex">
                <ShareButtons
                  lang={lang}
                  t={t}
                  variant="compact"
                  text={`${lang === 'ar' ? 'صنعت قالب' : lang === 'fr' ? "J'ai créé un modèle" : 'I made a template'}: ${templateInfo.templateName.replace(/_/g, ' ')} ${templateInfo.dimensions} — ArtNew8 Studio`}
                />
              </div>

              {/* Template info badge */}
              <div className="hidden sm:flex items-center gap-1 px-2 py-1 rounded-md bg-brand-50 border border-brand-100 text-[9px] font-bold text-brand-600 ms-auto whitespace-nowrap">
                <Box size={10} />
                <span>{templateInfo.templateName.replace(/_/g, ' ')}</span>
                <span className="text-brand-300">|</span>
                <span>{templateInfo.dimensions}</span>
              </div>
            </div>
          )}

          <div className={`glass-panel border-2 border-brand-200 bg-white/80 rounded-2xl sm:rounded-[2rem] shadow-inner p-3 sm:p-4 md:p-8 flex items-center justify-center relative flex-1 ${viewMode === '3d' ? 'min-h-[400px]' : 'min-h-[300px] sm:min-h-[400px]'}`}>
            {/* View mode toggle for 2D mode only */}
            {viewMode === '2d' && (
              <div className={`absolute top-3 z-20 flex gap-1.5 sm:gap-2 bg-white p-1 sm:p-1.5 rounded-lg sm:rounded-xl shadow-sm border border-brand-100 ${lang === 'ar' ? 'left-3' : 'right-3'} sm:${lang === 'ar' ? 'left-4' : 'right-4'}`}>
                <button className="px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-bold bg-brand-500 text-white shadow-md flex items-center gap-1 sm:gap-1.5">
                  <Ruler size={12} className="sm:w-[14px] sm:h-[14px]" /> {t('sim_2d')}
                </button>
                <button onClick={() => setViewMode('3d')} className="px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-bold transition-all flex items-center gap-1 sm:gap-1.5 text-brand-600 hover:bg-brand-50">
                  <Move3d size={12} className="sm:w-[14px] sm:h-[14px]" /> {t('sim_3d')}
                </button>
              </div>
            )}

            {/* Download button overlay for 2D view */}
            {viewMode === '2d' && (
              <button onClick={handleDownloadSVG} disabled={isDownloadLimited} className="absolute bottom-3 left-3 z-20 flex items-center gap-1.5 sm:gap-2 bg-brand-600 hover:bg-brand-500 text-white px-3 sm:px-5 py-2 sm:py-2.5 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm shadow-lg transition-all cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed">
                <Download size={14} className="sm:w-4 sm:h-4" /> {isDownloadLimited ? (lang === 'ar' ? 'تم الوصول للحد' : 'Limit') : t('download_flat')}
              </button>
            )}

            {viewMode === '2d' ? (
              <div className="w-full h-full max-h-[300px] sm:max-h-[600px] overflow-auto mt-10 sm:mt-8" dangerouslySetInnerHTML={{ __html: svgContent }} />
            ) : (
              <div className="flex items-center justify-center w-full h-full min-h-[350px] sm:min-h-[400px]">
                <CSS3DPreview ref={preview3dRef} width={width} length={length} height={height} templateType={templateType} flapSize={flapSize} glueTab={glueTab} t={t} />
              </div>
            )}
          </div>

          {/* Info panel - only show in 2D mode */}
          {viewMode === '2d' && (
            <div className="glass-panel p-3 sm:p-4 rounded-xl sm:rounded-2xl border border-brand-100 bg-white/40 flex items-start gap-3 sm:gap-4">
              <div className="p-2 sm:p-3 bg-white rounded-xl text-brand-600 shadow-sm border border-brand-200/50 shrink-0">
                <Ruler size={20} className="sm:w-6 sm:h-6" />
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="font-bold text-brand-900 text-xs sm:text-sm">
                  {t('blueprint_view')}
                </h4>
                <p className="text-[10px] sm:text-xs text-brand-700 leading-relaxed mt-0.5">
                  {t('blueprint_desc')}
                </p>
                <div className="mt-2">
                  <ShareButtons
                    lang={lang}
                    t={t}
                    variant="compact"
                    text={`${lang === 'ar' ? 'صنعت قالب' : lang === 'fr' ? 'J\'ai créé un modèle' : 'I made a template'}: ${templateInfo.templateName.replace(/_/g, ' ')} ${templateInfo.dimensions} — ArtNew8 Studio`}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
