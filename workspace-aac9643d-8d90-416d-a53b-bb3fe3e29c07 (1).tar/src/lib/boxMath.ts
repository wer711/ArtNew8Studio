export type TemplateType = 'box' | 'envelope' | 'pillow' | 'mailer' | 'milk_carton' | 'gable_box' | 'sleeve_box' | 'pyramid' | 'hex_box' | 'tuck_end' | 'cylinder' | 'display_box' | 'reverse_tuck' | 'auto_lock' | 'window_box' | 'drawer_box' | 'heart_box' | 'cone' | 'favor_box' | 'french_fry' | 'pizza_box' | 'takeout';

export interface TemplateOptions {
  width: number;
  length: number;
  height: number;
  flapSize: number;
  glueTab: number;
  cornerRadius: number;
  materialThickness: number;
  kerf: number;
  machine: 'cricut' | 'silhouette' | 'laser' | 'standard';
  showBleed?: boolean;
  showSafe?: boolean;
}

export interface TemplateInfo {
  totalWidth: number;
  totalLength: number;
  templateName: string;
  dimensions: string;
}

// ─── Color Palette ───────────────────────────────────────────────────
const C = {
  base:     '#f8f4f0',  // warm off-white for base panels
  side:     '#f0ebe5',  // slightly darker for side panels
  flap:     '#e8e2da',  // even darker for flaps
  glue:     '#e0d8ce',  // darkest for glue tabs
  gable:    '#ece6de',  // for gable/pyramid peaks
  cutStd:   '#db2777',  // pink-red cut line (standard)
  cutLaser: '#ff0000',  // red cut line (laser)
  cutCricut:'#000000',  // black cut line (cricut)
  cutSilh:  '#000000',  // black cut line (silhouette)
  foldStd:  '#64748b',  // slate gray fold line (standard)
  foldLaser:'#0000ff',  // blue fold line (laser)
  foldCricut:'#ff00ff', // magenta fold line (cricut)
  foldSilh: '#0000ff',  // blue fold line (silhouette)
  dimLine:  '#a3b29c',  // olive dimension line
  dimText:  '#6f8266',  // green/olive dimension text
  labelMain:'#4a433d',  // dark warm label text
  labelDim: '#6f8266',  // green dimension label text
  grid:     '#e8e2da',  // background grid color
  regMark:  '#b0a89e',  // registration mark color
};

// ─── Helper: Filled Rectangle ────────────────────────────────────────
function rectFill(x: number, y: number, w: number, h: number, fill: string): string {
  return `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" stroke="none" />`;
}

// ─── Helper: Filled Polygon ──────────────────────────────────────────
function polyFill(points: [number, number][], fill: string): string {
  const pts = points.map(p => `${p[0]},${p[1]}`).join(' ');
  return `<polygon points="${pts}" fill="${fill}" stroke="none" />`;
}

// ─── Helper: Filled SVG Path ─────────────────────────────────────────
function pathFill(d: string, fill: string): string {
  return `<path d="${d}" fill="${fill}" stroke="none" />`;
}

// ─── Helper: Glue Tab Fill (hatch + solid overlay) ───────────────────
function glueTabFill(points: [number, number][]): string {
  const pts = points.map(p => `${p[0]},${p[1]}`).join(' ');
  return `<polygon points="${pts}" fill="url(#hatchPattern)" stroke="none" />` +
         `<polygon points="${pts}" fill="${C.glue}" fill-opacity="0.55" stroke="none" />`;
}

// ─── Helper: Glue Tab Label ──────────────────────────────────────────
function glueTabLabel(cx: number, cy: number, rotation = 0): string {
  const rot = rotation ? ` transform="rotate(${rotation},${cx},${cy})"` : '';
  return `<text x="${cx}" y="${cy + 1}" font-size="2.5" font-family="'Segoe UI',system-ui,sans-serif" font-weight="700" text-anchor="middle" fill="#9e8e7e" letter-spacing="1"${rot}>GLUE</text>`;
}

// ─── Helper: Panel Label ─────────────────────────────────────────────
function panelLabel(x: number, y: number, name: string, dims?: string, rotation = 0): string {
  const rot = rotation ? ` transform="rotate(${rotation},${x},${y})"` : '';
  let svg = `<text x="${x}" y="${y - 2}" font-size="5" font-family="'Segoe UI',system-ui,sans-serif" font-weight="700" text-anchor="middle" fill="${C.labelMain}" letter-spacing="0.8"${rot}>${name}</text>`;
  if (dims) {
    svg += `\n      <text x="${x}" y="${y + 4}" font-size="3" font-family="'Segoe UI',system-ui,sans-serif" text-anchor="middle" fill="${C.labelDim}"${rot}>${dims}</text>`;
  }
  return svg;
}

// ─── Helper: Dimension Line with Arrows ──────────────────────────────
function dimLine(x1: number, y1: number, x2: number, y2: number, label: string, offset = 0): string {
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  const isVertical = Math.abs(x2 - x1) < 0.1;
  let svg = '';

  if (isVertical) {
    const x = x1 + offset;
    // Extension lines
    svg += `<line x1="${x1}" y1="${y1}" x2="${x + (offset > 0 ? 2 : -2)}" y2="${y1}" stroke="${C.dimLine}" stroke-width="0.3" />`;
    svg += `<line x1="${x2}" y1="${y2}" x2="${x + (offset > 0 ? 2 : -2)}" y2="${y2}" stroke="${C.dimLine}" stroke-width="0.3" />`;
    // Dimension line
    svg += `<line x1="${x}" y1="${y1}" x2="${x}" y2="${y2}" stroke="${C.dimLine}" stroke-width="0.4" marker-start="url(#dimArrow)" marker-end="url(#dimArrow)" />`;
    // Label
    svg += `<text x="${x + (offset > 0 ? 3 : -3)}" y="${my}" font-size="2.5" font-family="'Segoe UI',system-ui,sans-serif" text-anchor="${offset > 0 ? 'start' : 'end'}" fill="${C.dimText}" dominant-baseline="central" transform="rotate(-90,${x + (offset > 0 ? 3 : -3)},${my})">${label}</text>`;
  } else {
    const y = y1 + offset;
    // Extension lines
    svg += `<line x1="${x1}" y1="${y1}" x2="${x1}" y2="${y + (offset > 0 ? 2 : -2)}" stroke="${C.dimLine}" stroke-width="0.3" />`;
    svg += `<line x1="${x2}" y1="${y2}" x2="${x2}" y2="${y + (offset > 0 ? 2 : -2)}" stroke="${C.dimLine}" stroke-width="0.3" />`;
    // Dimension line
    svg += `<line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}" stroke="${C.dimLine}" stroke-width="0.4" marker-start="url(#dimArrow)" marker-end="url(#dimArrow)" />`;
    // Label
    svg += `<text x="${mx}" y="${y + (offset > 0 ? -1.5 : 2.5)}" font-size="2.5" font-family="'Segoe UI',system-ui,sans-serif" text-anchor="middle" fill="${C.dimText}">${label}</text>`;
  }
  return svg;
}

// ─── Helper: Background Grid ─────────────────────────────────────────
function generateBackgroundGrid(totalWidth: number, totalLength: number, margin: number): string {
  const step = 10;
  const x0 = -margin;
  const y0 = -margin;
  const x1 = totalWidth + margin;
  const y1 = totalLength + margin;
  let lines = '';
  for (let x = Math.ceil(x0 / step) * step; x <= x1; x += step) {
    lines += `<line x1="${x}" y1="${y0}" x2="${x}" y2="${y1}" stroke="${C.grid}" stroke-width="0.2" stroke-opacity="0.35" />`;
  }
  for (let y = Math.ceil(y0 / step) * step; y <= y1; y += step) {
    lines += `<line x1="${x0}" y1="${y}" x2="${x1}" y2="${y}" stroke="${C.grid}" stroke-width="0.2" stroke-opacity="0.35" />`;
  }
  return `<g id="background-grid">\n    ${lines}\n    </g>`;
}

// ─── Helper: Registration Marks ──────────────────────────────────────
function generateRegistrationMarks(totalWidth: number, totalLength: number, margin: number): string {
  const rl = 6;
  const ro = 5;
  const rc = 2;
  const s = C.regMark;
  return `
    <g id="registration-marks">
      <line x1="${-margin + ro}" y1="${-margin + ro}" x2="${-margin + ro + rl}" y2="${-margin + ro}" stroke="${s}" stroke-width="0.5" />
      <line x1="${-margin + ro}" y1="${-margin + ro}" x2="${-margin + ro}" y2="${-margin + ro + rl}" stroke="${s}" stroke-width="0.5" />
      <circle cx="${-margin + ro}" cy="${-margin + ro}" r="${rc}" fill="none" stroke="${s}" stroke-width="0.3" />
      <line x1="${totalWidth + margin - ro}" y1="${-margin + ro}" x2="${totalWidth + margin - ro - rl}" y2="${-margin + ro}" stroke="${s}" stroke-width="0.5" />
      <line x1="${totalWidth + margin - ro}" y1="${-margin + ro}" x2="${totalWidth + margin - ro}" y2="${-margin + ro + rl}" stroke="${s}" stroke-width="0.5" />
      <circle cx="${totalWidth + margin - ro}" cy="${-margin + ro}" r="${rc}" fill="none" stroke="${s}" stroke-width="0.3" />
      <line x1="${-margin + ro}" y1="${totalLength + margin - ro}" x2="${-margin + ro + rl}" y2="${totalLength + margin - ro}" stroke="${s}" stroke-width="0.5" />
      <line x1="${-margin + ro}" y1="${totalLength + margin - ro}" x2="${-margin + ro}" y2="${totalLength + margin - ro - rl}" stroke="${s}" stroke-width="0.5" />
      <circle cx="${-margin + ro}" cy="${totalLength + margin - ro}" r="${rc}" fill="none" stroke="${s}" stroke-width="0.3" />
      <line x1="${totalWidth + margin - ro}" y1="${totalLength + margin - ro}" x2="${totalWidth + margin - ro - rl}" y2="${totalLength + margin - ro}" stroke="${s}" stroke-width="0.5" />
      <line x1="${totalWidth + margin - ro}" y1="${totalLength + margin - ro}" x2="${totalWidth + margin - ro}" y2="${totalLength + margin - ro - rl}" stroke="${s}" stroke-width="0.5" />
      <circle cx="${totalWidth + margin - ro}" cy="${totalLength + margin - ro}" r="${rc}" fill="none" stroke="${s}" stroke-width="0.3" />
    </g>`;
}

// ─── Helper: Bleed Zone ──────────────────────────────────────────────
function generateBleedZone(cutLines: string, totalWidth: number, totalLength: number): string {
  return `
    <g id="bleed-zone" opacity="0.15">
      <rect x="-3" y="-3" width="${totalWidth + 6}" height="${totalLength + 6}" fill="#ff9999" stroke="#ff6666" stroke-width="0.5" stroke-dasharray="2,2" rx="1" />
    </g>`;
}

// ─── Helper: Safe Zone ───────────────────────────────────────────────
function generateSafeZone(foldLines: string, totalWidth: number, totalLength: number): string {
  const inset = 3;
  return `
    <g id="safe-zone" opacity="0.2">
      <rect x="${inset}" y="${inset}" width="${totalWidth - inset * 2}" height="${totalLength - inset * 2}" fill="none" stroke="#66aa66" stroke-width="0.5" stroke-dasharray="1,3" rx="1" />
    </g>`;
}

// ─── SVG Defs (markers, patterns) ────────────────────────────────────
function generateDefs(isStandard: boolean): string {
  return `<defs>
      <marker id="dimArrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="2.5" markerHeight="2.5" orient="auto-start-reverse">
        <path d="M 0 1 L 10 5 L 0 9 z" fill="${C.dimText}" />
      </marker>
      <pattern id="hatchPattern" width="4" height="4" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
        <line x1="0" y1="0" x2="0" y2="4" stroke="#c4b8a8" stroke-width="0.5" />
      </pattern>
      <pattern id="gridPattern" width="10" height="10" patternUnits="userSpaceOnUse">
        <path d="M 10 0 L 0 0 0 10" fill="none" stroke="${C.grid}" stroke-width="0.15" stroke-opacity="0.4" />
      </pattern>
      ${isStandard ? `<marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="3" markerHeight="3" orient="auto-start-reverse">
        <path d="M 0 0 L 10 5 L 0 10 z" fill="#7a6460" />
      </marker>` : ''}
    </defs>`;
}

// ═════════════════════════════════════════════════════════════════════
// MAIN: generateTemplateSvg
// ═════════════════════════════════════════════════════════════════════
export function generateTemplateSvg(type: TemplateType, options: TemplateOptions): string {
  const { width: w, length: l, height: h, flapSize, glueTab, kerf, machine, showBleed, showSafe } = options;
  const k = kerf / 2;

  let cutLines = '';
  let foldLines = '';
  let panelFills = '';
  let labels = '';
  let dimAnnotations = '';
  let totalWidth = 0;
  let totalLength = 0;
  let templateName = '';
  let dimText = '';
  const isStandard = machine === 'standard';

  // ─── BOX (Tray Box) ──────────────────────────────────────────────
  if (type === 'box') {
    const gt = glueTab;
    templateName = 'Tray Box';
    dimText = `${w} × ${l} × ${h} mm`;
    totalWidth = h + w + h + gt;
    totalLength = gt + l + gt;

    // Panel fills
    panelFills = `
      ${rectFill(h, gt, w, l, C.base)}
      ${rectFill(0, gt, h, l, C.side)}
      ${rectFill(h + w, gt, h, l, C.side)}
      ${rectFill(h, 0, w, gt, C.flap)}
      ${rectFill(h, gt + l, w, gt, C.flap)}
      ${glueTabFill([[0, gt + l * 0.2], [-gt, gt + l * 0.3], [-gt, gt + l * 0.7], [0, gt + l * 0.8]])}
      ${glueTabFill([[h + w + h, gt + l * 0.2], [h + w + h + gt, gt + l * 0.3], [h + w + h + gt, gt + l * 0.7], [h + w + h, gt + l * 0.8]])}`;

    // Cut lines
    cutLines = `
      M ${h},${gt} L ${h + w},${gt}
      L ${h + w},${gt - k} L ${h + w + h},${gt - k}
      L ${h + w + h},${gt + l + k} L ${h + w},${gt + l + k}
      L ${h + w},${gt + l} L ${h},${gt + l}
      L ${h},${gt + l + k} L 0,${gt + l + k}
      L 0,${gt - k} L ${h},${gt - k} Z`;
    cutLines += `
      M 0,${gt + l * 0.2} L ${-gt},${gt + l * 0.3} L ${-gt},${gt + l * 0.7} L 0,${gt + l * 0.8}
      M ${h + w + h},${gt + l * 0.2} L ${h + w + h + gt},${gt + l * 0.3} L ${h + w + h + gt},${gt + l * 0.7} L ${h + w + h},${gt + l * 0.8}`;

    // Fold lines
    foldLines = `
      M ${h},${gt} L ${h + w},${gt}
      M ${h + w},${gt} L ${h + w},${gt + l}
      M ${h + w},${gt + l} L ${h},${gt + l}
      M ${h},${gt + l} L ${h},${gt}`;

    // Labels
    if (isStandard) {
      labels = `
      ${panelLabel(h + w / 2, gt + l / 2, 'BASE', `${w} × ${l} mm`)}
      ${panelLabel(h / 2, gt + l / 2, 'SIDE', `${h} mm`, -90)}
      ${panelLabel(h + w + h / 2, gt + l / 2, 'SIDE', `${h} mm`, 90)}
      ${panelLabel(h + w / 2, gt / 2, 'FLAP', `${w} mm`)}
      ${panelLabel(h + w / 2, gt + l + gt / 2, 'FLAP', `${w} mm`)}
      ${glueTabLabel(-gt / 2, gt + l / 2)}
      ${glueTabLabel(h + w + h + gt / 2, gt + l / 2)}`;

      const d = 10;
      dimAnnotations = `
      ${dimLine(h, gt, h + w, gt, `${w}mm`, -d)}
      ${dimLine(h + w, gt, h + w, gt + l, `${l}mm`, d + 2)}
      ${dimLine(0, gt, h, gt, `${h}mm`, -d)}
      ${dimLine(h, 0, h, gt, `${gt}mm`, -d - 6)}`;
    }

  // ─── ENVELOPE ─────────────────────────────────────────────────────
  } else if (type === 'envelope') {
    const topFlap = l * 0.55;
    const bottomFlap = l * 0.4;
    const sideFlap = w * 0.4;
    templateName = 'Envelope';
    dimText = `${w} × ${l} mm`;
    totalWidth = sideFlap + w + sideFlap;
    totalLength = topFlap + l + bottomFlap;

    // Panel fills
    panelFills = `
      ${rectFill(sideFlap, topFlap, w, l, C.base)}
      ${pathFill(`M ${sideFlap},0 L ${sideFlap + w},0 L ${sideFlap + w},${topFlap * 0.7} L ${sideFlap},${topFlap} Z`, C.flap)}
      ${pathFill(`M ${sideFlap},${topFlap + l} L ${sideFlap + w},${topFlap + l} L ${sideFlap + w},${topFlap + l + bottomFlap} L ${sideFlap},${topFlap + l + bottomFlap} Z`, C.flap)}
      ${pathFill(`M 0,${topFlap - topFlap * 0.3} L ${sideFlap},${topFlap} L ${sideFlap},${topFlap + l} L 0,${topFlap + l} Z`, C.flap)}
      ${pathFill(`M ${sideFlap + w},${topFlap - topFlap * 0.3} L ${sideFlap + w + sideFlap},${topFlap - topFlap * 0.3} L ${sideFlap + w + sideFlap},${topFlap + l} L ${sideFlap + w},${topFlap + l} Z`, C.flap)}`;

    cutLines = `
      M ${sideFlap},0
      L ${sideFlap + w},0
      L ${sideFlap + w + sideFlap},${topFlap - topFlap * 0.3}
      L ${sideFlap + w + sideFlap},${topFlap + l}
      L ${sideFlap + w},${topFlap + l + bottomFlap}
      L ${sideFlap},${topFlap + l + bottomFlap}
      L 0,${topFlap + l}
      L 0,${topFlap - topFlap * 0.3} Z`;

    foldLines = `
      M ${sideFlap},${topFlap} L ${sideFlap + w},${topFlap}
      M ${sideFlap + w},${topFlap} L ${sideFlap + w},${topFlap + l}
      M ${sideFlap + w},${topFlap + l} L ${sideFlap},${topFlap + l}
      M ${sideFlap},${topFlap + l} L ${sideFlap},${topFlap}`;

    if (isStandard) {
      labels = `
      ${panelLabel(sideFlap + w / 2, topFlap + l / 2, 'FACE', `${w} × ${l} mm`)}
      ${panelLabel(sideFlap + w / 2, topFlap * 0.45, 'TOP FLAP')}
      ${panelLabel(sideFlap + w / 2, topFlap + l + bottomFlap * 0.55, 'BOTTOM FLAP')}
      ${panelLabel(sideFlap * 0.5, topFlap + l / 2, 'SIDE', '', -90)}
      ${panelLabel(sideFlap + w + sideFlap * 0.5, topFlap + l / 2, 'SIDE', '', 90)}`;

      const d = 8;
      dimAnnotations = `
      ${dimLine(sideFlap, topFlap, sideFlap + w, topFlap, `${w}mm`, -d)}
      ${dimLine(sideFlap + w, topFlap, sideFlap + w, topFlap + l, `${l}mm`, d)}`;
    }

  // ─── PILLOW BOX ───────────────────────────────────────────────────
  } else if (type === 'pillow') {
    const curveH = Math.min(h, w * 0.4);
    templateName = 'Pillow Box';
    dimText = `${w} × ${l} × ${h} mm`;
    totalWidth = w + w;
    totalLength = curveH + l + curveH;

    // Panel fills
    panelFills = `
      ${pathFill(`M 0,${curveH} L ${w},${curveH} L ${w},${curveH + l} L 0,${curveH + l} Z`, C.base)}
      ${pathFill(`M ${w},${curveH} L ${w + w},${curveH} L ${w + w},${curveH + l} L ${w},${curveH + l} Z`, C.side)}
      ${pathFill(`M 0,${curveH} Q ${w * 0.25},0 ${w * 0.5},0 Q ${w * 0.75},0 ${w},${curveH} L 0,${curveH} Z`, C.flap)}
      ${pathFill(`M ${w},${curveH} L ${w + w},${curveH} Q ${w + w * 0.75},0 ${w + w * 0.5},0 Q ${w + w * 0.25},0 ${w},${curveH} Z`, C.flap)}
      ${pathFill(`M 0,${curveH + l} L ${w},${curveH + l} Q ${w * 0.75},${curveH + l + curveH} ${w * 0.5},${curveH + l + curveH} Q ${w * 0.25},${curveH + l + curveH} 0,${curveH + l} Z`, C.flap)}
      ${pathFill(`M ${w},${curveH + l} L ${w + w},${curveH + l} L ${w + w},${curveH + l} Q ${w + w * 0.75},${curveH + l + curveH} ${w + w * 0.5},${curveH + l + curveH} Q ${w + w * 0.25},${curveH + l + curveH} ${w},${curveH + l} Z`, C.flap)}`;

    cutLines = `
      M 0,${curveH}
      Q ${w * 0.25},0 ${w * 0.5},0
      Q ${w * 0.75},0 ${w},${curveH}
      L ${w},${curveH + l}
      Q ${w * 0.75},${curveH + l + curveH} ${w * 0.5},${curveH + l + curveH}
      Q ${w * 0.25},${curveH + l + curveH} 0,${curveH + l}
      Z`;
    cutLines += `
      M ${w},${curveH}
      Q ${w + w * 0.25},0 ${w + w * 0.5},0
      Q ${w + w * 0.75},0 ${w + w},${curveH}
      L ${w + w},${curveH + l}
      Q ${w + w * 0.75},${curveH + l + curveH} ${w + w * 0.5},${curveH + l + curveH}
      Q ${w + w * 0.25},${curveH + l + curveH} ${w},${curveH + l}
      Z`;

    foldLines = `
      M 0,${curveH} L ${w + w},${curveH}
      M 0,${curveH + l} L ${w + w},${curveH + l}
      M ${w},0 L ${w},${curveH + l + curveH}`;

    if (isStandard) {
      labels = `
      ${panelLabel(w / 2, curveH + l / 2, 'BACK', `${w} × ${l} mm`)}
      ${panelLabel(w + w / 2, curveH + l / 2, 'FRONT', `${w} × ${l} mm`)}`;

      dimAnnotations = `
      ${dimLine(0, curveH, w + w, curveH, `${w * 2}mm`, -8)}
      ${dimLine(w + w, curveH, w + w, curveH + l, `${l}mm`, 8)}`;
    }

  // ─── MAILER BOX ───────────────────────────────────────────────────
  } else if (type === 'mailer') {
    const gt = glueTab;
    const shortFlap = h * 0.7;
    const longFlap = h * 0.95;
    templateName = 'Mailer Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + l;
    const x2 = gt + l + w;
    const x3 = gt + l + w + l;
    const y0 = shortFlap;
    const y1 = shortFlap + h;

    // Panel fills
    panelFills = `
      ${glueTabFill([[0, y0 + h * 0.15], [-gt * 0.3, y0 + h * 0.25], [-gt * 0.3, y0 + h * 0.75], [0, y0 + h * 0.85]])}
      ${rectFill(x0, y0, l, h, C.side)}
      ${rectFill(x1, y0, w, h, C.base)}
      ${rectFill(x2, y0, l, h, C.side)}
      ${rectFill(x3, y0, l, h, C.side)}
      ${pathFill(`M ${x0},${y0} L ${x0 + l * 0.1},${y0 - shortFlap} L ${x0 + l * 0.9},${y0 - shortFlap} L ${x0 + l},${y0} Z`, C.flap)}
      ${pathFill(`M ${x2},${y0} L ${x2 + l * 0.1},${y0 - shortFlap} L ${x2 + l * 0.9},${y0 - shortFlap} L ${x2 + l},${y0} Z`, C.flap)}
      ${pathFill(`M ${x1},${y0} L ${x1 + w * 0.05},${y0 - longFlap} L ${x1 + w * 0.95},${y0 - longFlap} L ${x1 + w},${y0} Z`, C.flap)}
      ${pathFill(`M ${x3},${y0} L ${x3 + l * 0.05},${y0 - longFlap} L ${x3 + l * 0.95},${y0 - longFlap} L ${x3 + l},${y0} Z`, C.flap)}
      ${pathFill(`M ${x0},${y1} L ${x0 + l * 0.1},${y1 + shortFlap} L ${x0 + l * 0.9},${y1 + shortFlap} L ${x0 + l},${y1} Z`, C.flap)}
      ${pathFill(`M ${x2},${y1} L ${x2 + l * 0.1},${y1 + shortFlap} L ${x2 + l * 0.9},${y1 + shortFlap} L ${x2 + l},${y1} Z`, C.flap)}
      ${pathFill(`M ${x1},${y1} L ${x1 + w * 0.05},${y1 + longFlap} L ${x1 + w * 0.95},${y1 + longFlap} L ${x1 + w},${y1} Z`, C.flap)}
      ${pathFill(`M ${x3},${y1} L ${x3 + l * 0.05},${y1 + longFlap} L ${x3 + l * 0.95},${y1 + longFlap} L ${x3 + l},${y1} Z`, C.flap)}`;

    cutLines = `M 0,${y0} L ${gt},${y0} `;
    cutLines += `M 0,${y0 + h * 0.15} L ${-gt * 0.3},${y0 + h * 0.25} L ${-gt * 0.3},${y0 + h * 0.75} L 0,${y0 + h * 0.85} `;
    cutLines += `M ${x0},${y0} L ${x0 + l * 0.1},${y0 - shortFlap} L ${x0 + l * 0.9},${y0 - shortFlap} L ${x0 + l},${y0} `;
    cutLines += `M ${x2},${y0} L ${x2 + l * 0.1},${y0 - shortFlap} L ${x2 + l * 0.9},${y0 - shortFlap} L ${x2 + l},${y0} `;
    cutLines += `M ${x1},${y0} L ${x1 + w * 0.05},${y0 - longFlap} L ${x1 + w * 0.95},${y0 - longFlap} L ${x1 + w},${y0} `;
    cutLines += `M ${x3},${y0} L ${x3 + l * 0.05},${y0 - longFlap} Q ${x3 + l / 2},${y0 - longFlap - 5} ${x3 + l * 0.95},${y0 - longFlap} L ${x3 + l},${y0} `;
    cutLines += `M ${x0},${y1} L ${x0 + l * 0.1},${y1 + shortFlap} L ${x0 + l * 0.9},${y1 + shortFlap} L ${x0 + l},${y1} `;
    cutLines += `M ${x2},${y1} L ${x2 + l * 0.1},${y1 + shortFlap} L ${x2 + l * 0.9},${y1 + shortFlap} L ${x2 + l},${y1} `;
    cutLines += `M ${x1},${y1} L ${x1 + w * 0.05},${y1 + longFlap} L ${x1 + w * 0.95},${y1 + longFlap} L ${x1 + w},${y1} `;
    cutLines += `M ${x3},${y1} L ${x3 + l * 0.05},${y1 + longFlap} L ${x3 + l * 0.95},${y1 + longFlap} L ${x3 + l},${y1} `;
    cutLines += `M ${x3 + l},${y0} L ${x3 + l},${y1} `;

    foldLines = `
      M ${x0},${y0} L ${x0 + l},${y0}
      M ${x1},${y0} L ${x1 + w},${y0}
      M ${x2},${y0} L ${x2 + l},${y0}
      M ${x3},${y0} L ${x3 + l},${y0}
      M ${x0},${y1} L ${x0 + l},${y1}
      M ${x1},${y1} L ${x1 + w},${y1}
      M ${x2},${y1} L ${x2 + l},${y1}
      M ${x3},${y1} L ${x3 + l},${y1}
      M ${x0},${y0} L ${x0},${y1}
      M ${x1},${y0} L ${x1},${y1}
      M ${x2},${y0} L ${x2},${y1}
      M ${x3},${y0} L ${x3},${y1}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x1 + w / 2, y0 + h / 2, 'BASE', `${w} × ${h} mm`)}
      ${panelLabel(x0 + l / 2, y0 + h / 2, 'SIDE A', `${l} mm`)}
      ${panelLabel(x2 + l / 2, y0 + h / 2, 'SIDE B', `${l} mm`)}
      ${panelLabel(x3 + l / 2, y0 + h / 2, 'SIDE C', `${l} mm`)}
      ${glueTabLabel(-gt * 0.15, y0 + h / 2)}`;

      dimAnnotations = `
      ${dimLine(x1, y0, x1 + w, y0, `${w}mm`, -8)}
      ${dimLine(x1 + w, y0, x1 + w, y1, `${h}mm`, 8)}
      ${dimLine(x0, y0, x1, y0, `${l}mm`, -8)}`;
    }

    totalWidth = gt + l + w + l + l + gt;
    totalLength = longFlap + shortFlap + h + shortFlap + h;

  // ─── MILK CARTON ──────────────────────────────────────────────────
  } else if (type === 'milk_carton') {
    const gt = glueTab;
    const gableH = w * 0.45;
    const bottomFlap = w * 0.3;
    templateName = 'Milk Carton';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + w;
    const x2 = gt + w + l;
    const x3 = gt + w + l + w;
    const x4 = gt + w + l + w + l;
    const yTop = gableH;
    const yBot = gableH + h;

    // Panel fills
    panelFills = `
      ${glueTabFill([[0, yTop + h * 0.15], [-gt * 0.3, yTop + h * 0.25], [-gt * 0.3, yTop + h * 0.75], [0, yTop + h * 0.85]])}
      ${rectFill(x0, yTop, w, h, C.side)}
      ${rectFill(x1, yTop, l, h, C.base)}
      ${rectFill(x2, yTop, w, h, C.side)}
      ${rectFill(x3, yTop, l, h, C.side)}
      ${pathFill(`M ${x0},${yTop} L ${x0 + w * 0.15},${yTop - gableH * 0.6} L ${x0 + w / 2},${yTop - gableH} L ${x0 + w * 0.85},${yTop - gableH * 0.6} L ${x1},${yTop} Z`, C.gable)}
      ${pathFill(`M ${x1},${yTop} L ${x1 + l * 0.2},${yTop - gableH * 0.3} L ${x1 + l / 2},${yTop - gableH * 0.7} L ${x1 + l * 0.8},${yTop - gableH * 0.3} L ${x2},${yTop} Z`, C.gable)}
      ${pathFill(`M ${x2},${yTop} L ${x2 + w * 0.15},${yTop - gableH * 0.6} L ${x2 + w / 2},${yTop - gableH} L ${x2 + w * 0.85},${yTop - gableH * 0.6} L ${x3},${yTop} Z`, C.gable)}
      ${pathFill(`M ${x3},${yTop} L ${x3 + l * 0.2},${yTop - gableH * 0.3} L ${x3 + l / 2},${yTop - gableH * 0.7} L ${x3 + l * 0.8},${yTop - gableH * 0.3} L ${x4},${yTop} Z`, C.gable)}
      ${pathFill(`M ${x0 + w * 0.1},${yBot} L ${x0 + w * 0.9},${yBot} L ${x0 + w * 0.9},${yBot + bottomFlap} L ${x0 + w * 0.1},${yBot + bottomFlap} Z`, C.flap)}
      ${pathFill(`M ${x1 + l * 0.1},${yBot} L ${x1 + l * 0.9},${yBot} L ${x1 + l * 0.9},${yBot + bottomFlap} L ${x1 + l * 0.1},${yBot + bottomFlap} Z`, C.flap)}
      ${pathFill(`M ${x2 + w * 0.1},${yBot} L ${x2 + w * 0.9},${yBot} L ${x2 + w * 0.9},${yBot + bottomFlap} L ${x2 + w * 0.1},${yBot + bottomFlap} Z`, C.flap)}
      ${pathFill(`M ${x3 + l * 0.1},${yBot} L ${x3 + l * 0.9},${yBot} L ${x3 + l * 0.9},${yBot + bottomFlap} L ${x3 + l * 0.1},${yBot + bottomFlap} Z`, C.flap)}`;

    cutLines = `M 0,${yTop + h * 0.15} L ${-gt * 0.3},${yTop + h * 0.25} L ${-gt * 0.3},${yTop + h * 0.75} L 0,${yTop + h * 0.85} `;
    cutLines += `M 0,${yTop} `;
    cutLines += `L ${x0},${yTop} L ${x0 + w * 0.15},${yTop - gableH * 0.6} L ${x0 + w / 2},${yTop - gableH} L ${x0 + w * 0.85},${yTop - gableH * 0.6} L ${x1},${yTop} `;
    cutLines += `L ${x1 + l * 0.2},${yTop - gableH * 0.3} L ${x1 + l / 2},${yTop - gableH * 0.7} L ${x1 + l * 0.8},${yTop - gableH * 0.3} L ${x2},${yTop} `;
    cutLines += `L ${x2 + w * 0.15},${yTop - gableH * 0.6} L ${x2 + w / 2},${yTop - gableH} L ${x2 + w * 0.85},${yTop - gableH * 0.6} L ${x3},${yTop} `;
    cutLines += `L ${x3 + l * 0.2},${yTop - gableH * 0.3} L ${x3 + l / 2},${yTop - gableH * 0.7} L ${x3 + l * 0.8},${yTop - gableH * 0.3} L ${x4},${yTop} `;
    cutLines += `L ${x4},${yBot} `;
    cutLines += `L ${x3 + l * 0.9},${yBot + bottomFlap} L ${x3 + l * 0.1},${yBot + bottomFlap} L ${x3},${yBot} `;
    cutLines += `L ${x2 + w * 0.1},${yBot + bottomFlap} L ${x2 + w * 0.9},${yBot + bottomFlap} L ${x2},${yBot} `;
    cutLines += `L ${x1 + l * 0.1},${yBot + bottomFlap} L ${x1 + l * 0.9},${yBot + bottomFlap} L ${x1},${yBot} `;
    cutLines += `L ${x0 + w * 0.1},${yBot + bottomFlap} L ${x0 + w * 0.9},${yBot + bottomFlap} L ${x0},${yBot} `;
    cutLines += `L 0,${yBot} Z`;

    foldLines = `
      M ${x0},${yTop} L ${x0},${yBot}
      M ${x1},${yTop} L ${x1},${yBot}
      M ${x2},${yTop} L ${x2},${yBot}
      M ${x3},${yTop} L ${x3},${yBot}
      M ${x0},${yBot} L ${x0 + w},${yBot}
      M ${x1},${yBot} L ${x1 + l},${yBot}
      M ${x2},${yBot} L ${x2 + w},${yBot}
      M ${x3},${yBot} L ${x3 + l},${yBot}
      M ${x0 + w * 0.15},${yTop} L ${x0 + w * 0.15},${yTop - gableH * 0.6}
      M ${x0 + w * 0.85},${yTop} L ${x0 + w * 0.85},${yTop - gableH * 0.6}
      M ${x2 + w * 0.15},${yTop} L ${x2 + w * 0.15},${yTop - gableH * 0.6}
      M ${x2 + w * 0.85},${yTop} L ${x2 + w * 0.85},${yTop - gableH * 0.6}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x1 + l / 2, yTop + h / 2, 'FRONT', `${w} × ${l} × ${h} mm`)}
      ${panelLabel(x0 + w / 2, yTop + h / 2, 'SIDE', `${w} mm`, -90)}
      ${panelLabel(x2 + w / 2, yTop + h / 2, 'BACK', `${w} mm`)}
      ${panelLabel(x3 + l / 2, yTop + h / 2, 'SIDE', `${l} mm`, 90)}
      ${glueTabLabel(-gt * 0.15, yTop + h / 2)}`;

      dimAnnotations = `
      ${dimLine(x0, yTop, x0 + w, yTop, `${w}mm`, 8)}
      ${dimLine(x0, yTop, x0, yBot, `${h}mm`, -8)}`;
    }

    totalWidth = gt + w + l + w + l + gt;
    totalLength = gableH + h + bottomFlap + gableH;

  // ─── GABLE BOX ────────────────────────────────────────────────────
  } else if (type === 'gable_box') {
    const gt = glueTab;
    const gableH = h * 0.55;
    const handleW = w * 0.15;
    const bottomFlap = w * 0.3;
    templateName = 'Gable Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + w;
    const x2 = gt + w + l;
    const x3 = gt + w + l + w;
    const x4 = gt + w + l + w + l;
    const yTop = gableH;
    const yBot = gableH + h;

    panelFills = `
      ${glueTabFill([[0, yTop + h * 0.15], [-gt * 0.3, yTop + h * 0.25], [-gt * 0.3, yTop + h * 0.75], [0, yTop + h * 0.85]])}
      ${rectFill(x0, yTop, w, h, C.side)}
      ${rectFill(x1, yTop, l, h, C.base)}
      ${rectFill(x2, yTop, w, h, C.side)}
      ${rectFill(x3, yTop, l, h, C.base)}
      ${pathFill(`M ${x0},${yTop} L ${x0 + w * 0.2},${yTop - gableH * 0.5} L ${x0 + w / 2 - handleW},${yTop - gableH} L ${x0 + w / 2 + handleW},${yTop - gableH} L ${x0 + w * 0.8},${yTop - gableH * 0.5} L ${x1},${yTop} Z`, C.gable)}
      ${pathFill(`M ${x1},${yTop} L ${x1 + l * 0.15},${yTop - gableH * 0.4} L ${x1 + l / 2},${yTop - gableH * 0.8} L ${x1 + l * 0.85},${yTop - gableH * 0.4} L ${x2},${yTop} Z`, C.gable)}
      ${pathFill(`M ${x2},${yTop} L ${x2 + w * 0.2},${yTop - gableH * 0.5} L ${x2 + w / 2 - handleW},${yTop - gableH} L ${x2 + w / 2 + handleW},${yTop - gableH} L ${x2 + w * 0.8},${yTop - gableH * 0.5} L ${x3},${yTop} Z`, C.gable)}
      ${pathFill(`M ${x3},${yTop} L ${x3 + l * 0.15},${yTop - gableH * 0.4} L ${x3 + l / 2},${yTop - gableH * 0.8} L ${x3 + l * 0.85},${yTop - gableH * 0.4} L ${x4},${yTop} Z`, C.gable)}
      ${pathFill(`M ${x0 + w * 0.1},${yBot} L ${x0 + w * 0.9},${yBot} L ${x0 + w * 0.9},${yBot + bottomFlap} L ${x0 + w * 0.1},${yBot + bottomFlap} Z`, C.flap)}
      ${pathFill(`M ${x1 + l * 0.1},${yBot} L ${x1 + l * 0.9},${yBot} L ${x1 + l * 0.9},${yBot + bottomFlap} L ${x1 + l * 0.1},${yBot + bottomFlap} Z`, C.flap)}
      ${pathFill(`M ${x2 + w * 0.1},${yBot} L ${x2 + w * 0.9},${yBot} L ${x2 + w * 0.9},${yBot + bottomFlap} L ${x2 + w * 0.1},${yBot + bottomFlap} Z`, C.flap)}
      ${pathFill(`M ${x3 + l * 0.1},${yBot} L ${x3 + l * 0.9},${yBot} L ${x3 + l * 0.9},${yBot + bottomFlap} L ${x3 + l * 0.1},${yBot + bottomFlap} Z`, C.flap)}`;

    cutLines = `M 0,${yTop + h * 0.15} L ${-gt * 0.3},${yTop + h * 0.25} L ${-gt * 0.3},${yTop + h * 0.75} L 0,${yTop + h * 0.85} `;
    cutLines += `M 0,${yTop} `;
    cutLines += `L ${x0},${yTop} L ${x0 + w * 0.2},${yTop - gableH * 0.5} L ${x0 + w * 0.5 - handleW},${yTop - gableH} `;
    cutLines += `L ${x0 + w * 0.5 - handleW * 0.3},${yTop - gableH * 0.85} `;
    cutLines += `Q ${x0 + w * 0.5},${yTop - gableH * 0.6} ${x0 + w * 0.5 + handleW * 0.3},${yTop - gableH * 0.85} `;
    cutLines += `L ${x0 + w * 0.5 + handleW},${yTop - gableH} `;
    cutLines += `L ${x0 + w * 0.8},${yTop - gableH * 0.5} L ${x1},${yTop} `;
    cutLines += `L ${x1 + l * 0.15},${yTop - gableH * 0.4} L ${x1 + l * 0.5},${yTop - gableH * 0.8} L ${x1 + l * 0.85},${yTop - gableH * 0.4} L ${x2},${yTop} `;
    cutLines += `L ${x2 + w * 0.2},${yTop - gableH * 0.5} L ${x2 + w * 0.5 - handleW},${yTop - gableH} `;
    cutLines += `L ${x2 + w * 0.5 - handleW * 0.3},${yTop - gableH * 0.85} `;
    cutLines += `Q ${x2 + w * 0.5},${yTop - gableH * 0.6} ${x2 + w * 0.5 + handleW * 0.3},${yTop - gableH * 0.85} `;
    cutLines += `L ${x2 + w * 0.5 + handleW},${yTop - gableH} `;
    cutLines += `L ${x2 + w * 0.8},${yTop - gableH * 0.5} L ${x3},${yTop} `;
    cutLines += `L ${x3 + l * 0.15},${yTop - gableH * 0.4} L ${x3 + l * 0.5},${yTop - gableH * 0.8} L ${x3 + l * 0.85},${yTop - gableH * 0.4} L ${x4},${yTop} `;
    cutLines += `L ${x4},${yBot} `;
    cutLines += `L ${x3 + l * 0.9},${yBot + bottomFlap} L ${x3 + l * 0.1},${yBot + bottomFlap} L ${x3},${yBot} `;
    cutLines += `L ${x2 + w * 0.1},${yBot + bottomFlap} L ${x2 + w * 0.9},${yBot + bottomFlap} L ${x2},${yBot} `;
    cutLines += `L ${x1 + l * 0.1},${yBot + bottomFlap} L ${x1 + l * 0.9},${yBot + bottomFlap} L ${x1},${yBot} `;
    cutLines += `L ${x0 + w * 0.1},${yBot + bottomFlap} L ${x0 + w * 0.9},${yBot + bottomFlap} L ${x0},${yBot} `;
    cutLines += `L 0,${yBot} Z`;

    foldLines = `
      M ${x0},${yTop} L ${x0},${yBot}
      M ${x1},${yTop} L ${x1},${yBot}
      M ${x2},${yTop} L ${x2},${yBot}
      M ${x3},${yTop} L ${x3},${yBot}
      M ${x0},${yBot} L ${x0 + w},${yBot}
      M ${x1},${yBot} L ${x1 + l},${yBot}
      M ${x2},${yBot} L ${x2 + w},${yBot}
      M ${x3},${yBot} L ${x3 + l},${yBot}
      M ${x0 + w * 0.2},${yTop} L ${x0 + w * 0.2},${yTop - gableH * 0.5}
      M ${x0 + w * 0.8},${yTop} L ${x0 + w * 0.8},${yTop - gableH * 0.5}
      M ${x2 + w * 0.2},${yTop} L ${x2 + w * 0.2},${yTop - gableH * 0.5}
      M ${x2 + w * 0.8},${yTop} L ${x2 + w * 0.8},${yTop - gableH * 0.5}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + w / 2, yTop + h / 2, 'FRONT', `${w} × ${h} mm`)}
      ${panelLabel(x2 + w / 2, yTop + h / 2, 'BACK', `${w} × ${h} mm`)}
      ${panelLabel(x1 + l / 2, yTop + h / 2, 'SIDE', `${l} mm`)}
      ${panelLabel(x3 + l / 2, yTop + h / 2, 'SIDE', `${l} mm`)}
      ${glueTabLabel(-gt * 0.15, yTop + h / 2)}`;

      dimAnnotations = `
      ${dimLine(x0, yTop, x0 + w, yTop, `${w}mm`, 8)}
      ${dimLine(x0, yTop, x0, yBot, `${h}mm`, -8)}`;
    }

    totalWidth = gt + w + l + w + l + gt;
    totalLength = gableH + h + bottomFlap + gableH;

  // ─── SLEEVE BOX ───────────────────────────────────────────────────
  } else if (type === 'sleeve_box') {
    const gt = glueTab;
    const sleeveH = h * 0.35;
    const trayH = h;
    const thumbNotch = w * 0.12;
    const gap = 8;
    templateName = 'Sleeve Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const sx0 = gt;
    const sx1 = gt + l;
    const sx2 = gt + l + w;
    const sx3 = gt + l + w + l;
    const sy0 = sleeveH;
    const sy1 = sleeveH + sleeveH;
    const sy2 = sleeveH + sleeveH + w;
    const sy3 = sleeveH + sleeveH + w + sleeveH;

    // === OUTER SLEEVE ===
    panelFills = `
      ${glueTabFill([[0, sy0 + sleeveH * 0.15], [-gt * 0.3, sy0 + sleeveH * 0.25], [-gt * 0.3, sy0 + sleeveH * 0.75], [0, sy0 + sleeveH * 0.85]])}
      ${rectFill(sx0, sy0, l, sleeveH, C.side)}
      ${rectFill(sx1, sy0, w, sleeveH, C.base)}
      ${rectFill(sx2, sy0, l, sleeveH, C.side)}
      ${rectFill(sx0, sy1, l, sleeveH, C.flap)}
      ${rectFill(sx1, sy1, w, sleeveH, C.flap)}
      ${rectFill(sx2, sy1, l, sleeveH, C.flap)}`;

    cutLines = `M ${-gt * 0.3},${sy0 + sleeveH * 0.25} L ${-gt * 0.3},${sy0 + sleeveH * 0.75} L 0,${sy0 + sleeveH * 0.85} `;
    cutLines += `M 0,${sy0 + sleeveH * 0.15} L ${-gt * 0.3},${sy0 + sleeveH * 0.25} `;
    cutLines += `M 0,${sy0} L ${sx0},${sy0} `;
    cutLines += `L ${sx0 + l * 0.3},${sy0 - sleeveH * 0.05} L ${sx0 + l * 0.5 - thumbNotch},${sy0} `;
    cutLines += `Q ${sx0 + l * 0.5},${sy0 - thumbNotch * 0.8} ${sx0 + l * 0.5 + thumbNotch},${sy0} `;
    cutLines += `L ${sx0 + l * 0.7},${sy0 - sleeveH * 0.05} L ${sx1},${sy0} `;
    cutLines += `L ${sx1 + w * 0.05},${sy0 - sleeveH * 0.05} L ${sx1 + w * 0.95},${sy0 - sleeveH * 0.05} L ${sx2},${sy0} `;
    cutLines += `L ${sx2 + l * 0.3},${sy0 - sleeveH * 0.05} L ${sx2 + l * 0.7},${sy0 - sleeveH * 0.05} L ${sx3},${sy0} `;
    cutLines += `L ${sx3},${sy1} `;
    cutLines += `L ${sx2},${sy1} L ${sx2 + l * 0.05},${sy1 + sleeveH * 0.05} L ${sx2 + l * 0.95},${sy1 + sleeveH * 0.05} L ${sx2},${sy1} `;
    cutLines += `L ${sx1},${sy1} L ${sx1 + w * 0.05},${sy1 + sleeveH * 0.05} L ${sx1 + w * 0.95},${sy1 + sleeveH * 0.05} L ${sx1},${sy1} `;
    cutLines += `L ${sx0},${sy1} `;
    cutLines += `L 0,${sy1} Z`;

    foldLines = `
      M ${sx0},${sy0} L ${sx0},${sy1}
      M ${sx1},${sy0} L ${sx1},${sy1}
      M ${sx2},${sy0} L ${sx2},${sy1}
      M 0,${sy0} L ${sx3},${sy0}
      M 0,${sy1} L ${sx3},${sy1}`;

    // === INNER TRAY ===
    const trayOffset = sy1 + gap;
    const tx0 = gt;
    const tx1 = gt + l;
    const tx2 = gt + l + w;
    const tx3 = gt + l + w + l;
    const ty0 = trayH * 0.4;
    const ty1 = trayH * 0.4 + trayH;

    panelFills += `
      ${glueTabFill([[0, trayOffset + ty0 + trayH * 0.15], [-gt * 0.3, trayOffset + ty0 + trayH * 0.25], [-gt * 0.3, trayOffset + ty0 + trayH * 0.75], [0, trayOffset + ty0 + trayH * 0.85]])}
      ${rectFill(tx0, trayOffset + ty0, l, trayH, C.side)}
      ${rectFill(tx1, trayOffset + ty0, w, trayH, C.base)}
      ${rectFill(tx2, trayOffset + ty0, l, trayH, C.side)}
      ${pathFill(`M ${tx0 + l * 0.1},${trayOffset + ty0 - trayH * 0.4} L ${tx0 + l * 0.9},${trayOffset + ty0 - trayH * 0.4} L ${tx0 + l},${trayOffset + ty0} L ${tx0},${trayOffset + ty0} Z`, C.flap)}
      ${pathFill(`M ${tx1 + w * 0.05},${trayOffset + ty0 - trayH * 0.4} L ${tx1 + w * 0.95},${trayOffset + ty0 - trayH * 0.4} L ${tx2},${trayOffset + ty0} L ${tx1},${trayOffset + ty0} Z`, C.flap)}
      ${pathFill(`M ${tx2 + l * 0.1},${trayOffset + ty0 - trayH * 0.4} L ${tx2 + l * 0.9},${trayOffset + ty0 - trayH * 0.4} L ${tx3},${trayOffset + ty0} L ${tx2},${trayOffset + ty0} Z`, C.flap)}
      ${pathFill(`M ${tx0 + l * 0.1},${trayOffset + ty1 + trayH * 0.4} L ${tx0 + l * 0.9},${trayOffset + ty1 + trayH * 0.4} L ${tx0 + l},${trayOffset + ty1} L ${tx0},${trayOffset + ty1} Z`, C.flap)}
      ${pathFill(`M ${tx1 + w * 0.05},${trayOffset + ty1 + trayH * 0.4} L ${tx1 + w * 0.95},${trayOffset + ty1 + trayH * 0.4} L ${tx2},${trayOffset + ty1} L ${tx1},${trayOffset + ty1} Z`, C.flap)}
      ${pathFill(`M ${tx2 + l * 0.1},${trayOffset + ty1 + trayH * 0.4} L ${tx2 + l * 0.9},${trayOffset + ty1 + trayH * 0.4} L ${tx3},${trayOffset + ty1} L ${tx2},${trayOffset + ty1} Z`, C.flap)}`;

    cutLines += `M 0,${trayOffset + ty0 + trayH * 0.15} L ${-gt * 0.3},${trayOffset + ty0 + trayH * 0.25} L ${-gt * 0.3},${trayOffset + ty0 + trayH * 0.75} L 0,${trayOffset + ty0 + trayH * 0.85} `;
    cutLines += `M 0,${trayOffset + ty0} L ${tx0},${trayOffset + ty0} `;
    cutLines += `L ${tx0 + l * 0.1},${trayOffset + ty0 - trayH * 0.4} L ${tx0 + l * 0.9},${trayOffset + ty0 - trayH * 0.4} L ${tx1},${trayOffset + ty0} `;
    cutLines += `L ${tx1 + w * 0.05},${trayOffset + ty0 - trayH * 0.4} L ${tx1 + w * 0.95},${trayOffset + ty0 - trayH * 0.4} L ${tx2},${trayOffset + ty0} `;
    cutLines += `L ${tx2 + l * 0.1},${trayOffset + ty0 - trayH * 0.4} L ${tx2 + l * 0.9},${trayOffset + ty0 - trayH * 0.4} L ${tx3},${trayOffset + ty0} `;
    cutLines += `L ${tx3},${trayOffset + ty1} `;
    cutLines += `L ${tx2 + l * 0.9},${trayOffset + ty1 + trayH * 0.4} L ${tx2 + l * 0.1},${trayOffset + ty1 + trayH * 0.4} L ${tx2},${trayOffset + ty1} `;
    cutLines += `L ${tx1 + w * 0.05},${trayOffset + ty1 + trayH * 0.4} L ${tx1 + w * 0.95},${trayOffset + ty1 + trayH * 0.4} L ${tx1},${trayOffset + ty1} `;
    cutLines += `L ${tx0 + l * 0.1},${trayOffset + ty1 + trayH * 0.4} L ${tx0 + l * 0.9},${trayOffset + ty1 + trayH * 0.4} L ${tx0},${trayOffset + ty1} `;
    cutLines += `L 0,${trayOffset + ty1} Z`;

    foldLines += `
      M ${tx0},${trayOffset + ty0} L ${tx0},${trayOffset + ty1}
      M ${tx1},${trayOffset + ty0} L ${tx1},${trayOffset + ty1}
      M ${tx2},${trayOffset + ty0} L ${tx2},${trayOffset + ty1}
      M 0,${trayOffset + ty0} L ${tx3},${trayOffset + ty0}
      M 0,${trayOffset + ty1} L ${tx3},${trayOffset + ty1}`;

    if (isStandard) {
      labels = `
      ${panelLabel(sx1 + w / 2, sy0 + sleeveH / 2, 'SLEEVE TOP', `${w} mm`)}
      ${panelLabel(sx0 + l / 2, sy0 + sleeveH / 2, 'SIDE', `${l} mm`)}
      ${panelLabel(sx2 + l / 2, sy0 + sleeveH / 2, 'SIDE', `${l} mm`)}
      ${panelLabel(sx1 + w / 2, sy1 + sleeveH / 2, 'SLEEVE BOT', `${w} mm`)}
      ${panelLabel(tx1 + w / 2, trayOffset + ty0 + trayH / 2, 'TRAY BASE', `${w} × ${h} mm`)}
      ${panelLabel(tx0 + l / 2, trayOffset + ty0 + trayH / 2, 'SIDE', `${l} mm`)}
      ${panelLabel(tx2 + l / 2, trayOffset + ty0 + trayH / 2, 'SIDE', `${l} mm`)}`;
    }

    totalWidth = gt + l + w + l + gt;
    totalLength = sy1 + gap + ty1 + trayH * 0.4;

  // ─── PYRAMID ──────────────────────────────────────────────────────
  } else if (type === 'pyramid') {
    const gt = glueTab;
    const baseW = w;
    const halfBase = baseW / 2;
    const faceH = Math.sqrt(h * h + halfBase * halfBase);
    templateName = 'Pyramid';
    dimText = `${baseW} × ${baseW} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + baseW;
    const x2 = gt + baseW * 2;
    const x3 = gt + baseW * 3;
    const x4 = gt + baseW * 4;

    panelFills = `
      ${glueTabFill([[0, faceH * 0.15], [-gt * 0.3, faceH * 0.25], [-gt * 0.3, faceH * 0.75], [0, faceH * 0.85]])}
      ${pathFill(`M ${x0},${faceH} L ${x0 + baseW / 2},0 L ${x0 + baseW},${faceH} Z`, C.base)}
      ${pathFill(`M ${x1},${faceH} L ${x1 + baseW / 2},0 L ${x1 + baseW},${faceH} Z`, C.side)}
      ${pathFill(`M ${x2},${faceH} L ${x2 + baseW / 2},0 L ${x2 + baseW},${faceH} Z`, C.base)}
      ${pathFill(`M ${x3},${faceH} L ${x3 + baseW / 2},0 L ${x3 + baseW},${faceH} Z`, C.side)}`;

    cutLines = `M 0,${faceH * 0.15} L ${-gt * 0.3},${faceH * 0.25} L ${-gt * 0.3},${faceH * 0.75} L 0,${faceH * 0.85} `;
    cutLines += `M 0,${faceH} L ${x0 + baseW / 2},0 L ${x0 + baseW},${faceH} `;
    cutLines += `L ${x1 + baseW / 2},0 L ${x1 + baseW},${faceH} `;
    cutLines += `L ${x2 + baseW / 2},0 L ${x2 + baseW},${faceH} `;
    cutLines += `L ${x3 + baseW / 2},0 L ${x3 + baseW},${faceH} `;
    cutLines += `L 0,${faceH} Z`;

    foldLines = `
      M ${x0},${faceH} L ${x0 + baseW / 2},0
      M ${x0 + baseW},${faceH} L ${x1 + baseW / 2},0
      M ${x1 + baseW},${faceH} L ${x2 + baseW / 2},0
      M ${x2 + baseW},${faceH} L ${x3 + baseW / 2},0
      M 0,${faceH} L ${x4},${faceH}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + baseW / 2, faceH * 0.55, 'FACE 1', `${baseW} mm`)}
      ${panelLabel(x1 + baseW / 2, faceH * 0.55, 'FACE 2', `${baseW} mm`)}
      ${panelLabel(x2 + baseW / 2, faceH * 0.55, 'FACE 3', `${baseW} mm`)}
      ${panelLabel(x3 + baseW / 2, faceH * 0.55, 'FACE 4', `${baseW} mm`)}
      ${glueTabLabel(-gt * 0.15, faceH / 2)}`;

      dimAnnotations = `
      ${dimLine(0, faceH, x0 + baseW, faceH, `${baseW}mm`, 8)}`;
    }

    totalWidth = gt + baseW * 4 + gt;
    totalLength = faceH;

  // ─── HEX BOX ─────────────────────────────────────────────────────
  } else if (type === 'hex_box') {
    const gt = glueTab;
    const sideLen = w / 2;
    const bottomFlap = sideLen * 0.5;
    const topFlap = sideLen * 0.5;
    templateName = 'Hexagonal Box';
    dimText = `${w} × ${h} mm`;

    const panels = 6;
    const panelWidth = sideLen;
    const yTop = topFlap;
    const yBot = topFlap + h;

    // Panel fills
    let fillsArr: string[] = [];
    fillsArr.push(glueTabFill([[0, yTop + h * 0.15], [-gt * 0.3, yTop + h * 0.25], [-gt * 0.3, yTop + h * 0.75], [0, yTop + h * 0.85]]));
    for (let i = 0; i < panels; i++) {
      const px = gt + i * panelWidth;
      fillsArr.push(rectFill(px, yTop, panelWidth, h, i % 2 === 0 ? C.base : C.side));
      fillsArr.push(pathFill(`M ${px},${yTop} L ${px + panelWidth * 0.1},${yTop - topFlap} L ${px + panelWidth * 0.9},${yTop - topFlap} L ${px + panelWidth},${yTop} Z`, C.flap));
      fillsArr.push(pathFill(`M ${px},${yBot} L ${px + panelWidth * 0.1},${yBot + bottomFlap} L ${px + panelWidth * 0.9},${yBot + bottomFlap} L ${px + panelWidth},${yBot} Z`, C.flap));
    }
    panelFills = fillsArr.join('\n      ');

    cutLines = `M 0,${yTop + h * 0.15} L ${-gt * 0.3},${yTop + h * 0.25} L ${-gt * 0.3},${yTop + h * 0.75} L 0,${yTop + h * 0.85} `;
    for (let i = 0; i < panels; i++) {
      const px = gt + i * panelWidth;
      cutLines += `M ${px},${yTop} L ${px + panelWidth * 0.1},${yTop - topFlap} L ${px + panelWidth * 0.9},${yTop - topFlap} L ${px + panelWidth},${yTop} `;
    }
    cutLines += `M 0,${yTop} L ${gt + panels * panelWidth},${yTop} `;
    cutLines += `M 0,${yBot} L ${gt + panels * panelWidth},${yBot} `;
    for (let i = 0; i < panels; i++) {
      const px = gt + i * panelWidth;
      cutLines += `M ${px},${yBot} L ${px + panelWidth * 0.1},${yBot + bottomFlap} L ${px + panelWidth * 0.9},${yBot + bottomFlap} L ${px + panelWidth},${yBot} `;
    }

    foldLines = '';
    for (let i = 0; i <= panels; i++) {
      const px = gt + i * panelWidth;
      foldLines += `M ${px},${yTop} L ${px},${yBot} `;
    }
    foldLines += `M 0,${yTop} L ${gt + panels * panelWidth},${yTop}
      M 0,${yBot} L ${gt + panels * panelWidth},${yBot}`;

    if (isStandard) {
      labels = '';
      const panelNames = ['P1','P2','P3','P4','P5','P6'];
      for (let i = 0; i < panels; i++) {
        const px = gt + i * panelWidth;
        labels += panelLabel(px + panelWidth / 2, yTop + h / 2, panelNames[i], `${panelWidth} mm`) + '\n      ';
      }
      labels += glueTabLabel(-gt * 0.15, yTop + h / 2);

      dimAnnotations = `
      ${dimLine(gt, yTop, gt + panels * panelWidth, yTop, `${(panels * panelWidth).toFixed(0)}mm`, -8)}
      ${dimLine(gt + panels * panelWidth, yTop, gt + panels * panelWidth, yBot, `${h}mm`, 8)}`;
    }

    totalWidth = gt + panels * panelWidth + gt;
    totalLength = topFlap + h + bottomFlap;

  // ─── TUCK-END BOX ────────────────────────────────────────────────
  } else if (type === 'tuck_end') {
    const gt = glueTab;
    const tuckFlap = h * 0.4;
    const dustFlap = h * 0.45;
    const autoLockH = h * 0.35;
    templateName = 'Tuck-End Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + l;
    const x2 = gt + l + w;
    const x3 = gt + l + w + l;
    const yTop = tuckFlap;
    const yBot = tuckFlap + h + autoLockH;

    panelFills = `
      ${glueTabFill([[0, tuckFlap + h * 0.15], [-gt * 0.3, tuckFlap + h * 0.25], [-gt * 0.3, tuckFlap + h * 0.75], [0, tuckFlap + h * 0.85]])}
      ${rectFill(x0, tuckFlap, l, h, C.side)}
      ${rectFill(x1, tuckFlap, w, h, C.base)}
      ${rectFill(x2, tuckFlap, l, h, C.side)}
      ${rectFill(x3, tuckFlap, l, h, C.base)}
      ${pathFill(`M ${x0},${tuckFlap} L ${x0 + l * 0.15},${tuckFlap - tuckFlap * 0.7} L ${x0 + l * 0.85},${tuckFlap - tuckFlap * 0.7} L ${x0 + l},${tuckFlap} Z`, C.flap)}
      ${pathFill(`M ${x1},${tuckFlap} L ${x1 + w * 0.1},${tuckFlap - dustFlap} L ${x1 + w * 0.9},${tuckFlap - dustFlap} L ${x1 + w},${tuckFlap} Z`, C.flap)}
      ${pathFill(`M ${x2},${tuckFlap} L ${x2 + l * 0.15},${tuckFlap - tuckFlap * 0.7} L ${x2 + l * 0.85},${tuckFlap - tuckFlap * 0.7} L ${x2 + l},${tuckFlap} Z`, C.flap)}
      ${pathFill(`M ${x3},${tuckFlap} L ${x3 + l * 0.1},${tuckFlap - dustFlap} L ${x3 + l * 0.9},${tuckFlap - dustFlap} L ${x3 + l},${tuckFlap} Z`, C.flap)}
      ${pathFill(`M ${x0 + l * 0.15},${tuckFlap + h} L ${x0 + l * 0.85},${tuckFlap + h} L ${x0 + l * 0.85},${tuckFlap + h + autoLockH} L ${x0 + l * 0.15},${tuckFlap + h + autoLockH} Z`, C.flap)}
      ${pathFill(`M ${x1 + w * 0.05},${tuckFlap + h} L ${x1 + w * 0.95},${tuckFlap + h} L ${x1 + w * 0.95},${tuckFlap + h + autoLockH} L ${x1 + w * 0.05},${tuckFlap + h + autoLockH} Z`, C.flap)}
      ${pathFill(`M ${x2 + l * 0.15},${tuckFlap + h} L ${x2 + l * 0.85},${tuckFlap + h} L ${x2 + l * 0.85},${tuckFlap + h + autoLockH} L ${x2 + l * 0.15},${tuckFlap + h + autoLockH} Z`, C.flap)}
      ${pathFill(`M ${x3 + l * 0.05},${tuckFlap + h} L ${x3 + l * 0.95},${tuckFlap + h} L ${x3 + l * 0.95},${tuckFlap + h + autoLockH} L ${x3 + l * 0.05},${tuckFlap + h + autoLockH} Z`, C.flap)}`;

    cutLines = `M 0,${tuckFlap + h * 0.15} L ${-gt * 0.3},${tuckFlap + h * 0.25} L ${-gt * 0.3},${tuckFlap + h * 0.75} L 0,${tuckFlap + h * 0.85} `;
    cutLines += `M 0,${tuckFlap} L ${x0},${tuckFlap} `;
    cutLines += `L ${x0 + l * 0.15},${tuckFlap - tuckFlap * 0.7} L ${x0 + l * 0.2},${tuckFlap - tuckFlap} L ${x0 + l * 0.35},${tuckFlap - tuckFlap * 1.1} `;
    cutLines += `Q ${x0 + l * 0.5},${tuckFlap - tuckFlap * 1.15} ${x0 + l * 0.65},${tuckFlap - tuckFlap * 1.1} `;
    cutLines += `L ${x0 + l * 0.8},${tuckFlap - tuckFlap} L ${x0 + l * 0.85},${tuckFlap - tuckFlap * 0.7} L ${x1},${tuckFlap} `;
    cutLines += `L ${x1 + w * 0.1},${tuckFlap - dustFlap} L ${x1 + w * 0.9},${tuckFlap - dustFlap} L ${x2},${tuckFlap} `;
    cutLines += `L ${x2 + l * 0.15},${tuckFlap - tuckFlap * 0.7} L ${x2 + l * 0.2},${tuckFlap - tuckFlap} L ${x2 + l * 0.35},${tuckFlap - tuckFlap * 1.1} `;
    cutLines += `Q ${x2 + l * 0.5},${tuckFlap - tuckFlap * 1.15} ${x2 + l * 0.65},${tuckFlap - tuckFlap * 1.1} `;
    cutLines += `L ${x2 + l * 0.8},${tuckFlap - tuckFlap} L ${x2 + l * 0.85},${tuckFlap - tuckFlap * 0.7} L ${x3},${tuckFlap} `;
    cutLines += `L ${x3 + l * 0.1},${tuckFlap - dustFlap} L ${x3 + l * 0.9},${tuckFlap - dustFlap} L ${x3 + l},${tuckFlap} `;
    cutLines += `L ${x3 + l},${yBot} `;
    cutLines += `L ${x3 + l * 0.85},${yBot} L ${x3 + l * 0.7},${yBot + autoLockH * 0.6} L ${x3 + l * 0.5},${yBot + autoLockH * 0.4} L ${x3 + l * 0.3},${yBot + autoLockH * 0.6} L ${x3 + l * 0.15},${yBot} `;
    cutLines += `L ${x2 + w * 0.05},${yBot} L ${x2 + w * 0.1},${yBot + autoLockH} L ${x2 + w * 0.5},${yBot + autoLockH * 0.85} L ${x2 + w * 0.9},${yBot + autoLockH} L ${x2 + w * 0.95},${yBot} `;
    cutLines += `L ${x1 + l * 0.85},${yBot} L ${x1 + l * 0.7},${yBot + autoLockH * 0.6} L ${x1 + l * 0.5},${yBot + autoLockH * 0.4} L ${x1 + l * 0.3},${yBot + autoLockH * 0.6} L ${x1 + l * 0.15},${yBot} `;
    cutLines += `L ${x0 + w * 0.05},${yBot} L ${x0 + w * 0.1},${yBot + autoLockH} L ${x0 + w * 0.5},${yBot + autoLockH * 0.85} L ${x0 + w * 0.9},${yBot + autoLockH} L ${x0 + w * 0.95},${yBot} `;
    cutLines += `L 0,${yBot} Z`;

    foldLines = `
      M ${x0},${tuckFlap} L ${x0},${yBot}
      M ${x1},${tuckFlap} L ${x1},${yBot}
      M ${x2},${tuckFlap} L ${x2},${yBot}
      M ${x3},${tuckFlap} L ${x3},${yBot}
      M ${x0},${tuckFlap + h} L ${x0 + l},${tuckFlap + h}
      M ${x1},${tuckFlap + h} L ${x1 + w},${tuckFlap + h}
      M ${x2},${tuckFlap + h} L ${x2 + l},${tuckFlap + h}
      M ${x3},${tuckFlap + h} L ${x3 + l},${tuckFlap + h}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + l / 2, tuckFlap + h / 2, 'FRONT', `${l} × ${h} mm`)}
      ${panelLabel(x2 + l / 2, tuckFlap + h / 2, 'BACK', `${l} × ${h} mm`)}
      ${panelLabel(x1 + w / 2, tuckFlap + h / 2, 'SIDE', `${w} mm`)}
      ${panelLabel(x3 + l / 2, tuckFlap + h / 2, 'SIDE', `${l} mm`)}
      ${glueTabLabel(-gt * 0.15, tuckFlap + h / 2)}`;

      dimAnnotations = `
      ${dimLine(x1, tuckFlap, x1 + w, tuckFlap, `${w}mm`, -8)}
      ${dimLine(x1 + w, tuckFlap, x1 + w, tuckFlap + h, `${h}mm`, 8)}`;
    }

    totalWidth = gt + l + w + l + l + gt;
    totalLength = tuckFlap * 1.15 + h + autoLockH;

  // ─── CYLINDER ─────────────────────────────────────────────────────
  } else if (type === 'cylinder') {
    const gt = glueTab;
    const circumference = Math.PI * w;
    const capR = w / 2;
    const capFlap = capR * 0.2;
    templateName = 'Cylinder Box';
    dimText = `∅${w} × ${h} mm`;

    const bodyX = gt;
    const bodyW = circumference;
    const bodyH = h;
    const capCY_top = -capR * 1.2;
    const capCY_bot = bodyH + capR * 1.2;
    const capCX = bodyX + bodyW / 2;

    panelFills = `
      ${glueTabFill([[0, bodyH * 0.15], [-gt * 0.3, bodyH * 0.25], [-gt * 0.3, bodyH * 0.75], [0, bodyH * 0.85]])}
      ${rectFill(bodyX, 0, bodyW, bodyH, C.base)}
      <circle cx="${capCX}" cy="${capCY_top}" r="${capR}" fill="${C.flap}" stroke="none" />
      <circle cx="${capCX}" cy="${capCY_bot}" r="${capR}" fill="${C.flap}" stroke="none" />`;

    cutLines = `M 0,${bodyH * 0.15} L ${-gt * 0.3},${bodyH * 0.25} L ${-gt * 0.3},${bodyH * 0.75} L 0,${bodyH * 0.85} `;
    cutLines += `M 0,0 L ${bodyX},0 L ${bodyX + bodyW},0 L ${bodyX + bodyW},${bodyH} L 0,${bodyH} Z `;
    cutLines += `M ${capCX + capR},${capCY_top} A ${capR} ${capR} 0 1 0 ${capCX - capR},${capCY_top} A ${capR} ${capR} 0 1 0 ${capCX + capR},${capCY_top} `;
    cutLines += `M ${capCX - capR * 0.15},${capCY_top - capR} A ${capR * 0.3} ${capR * 0.3} 0 0 1 ${capCX + capR * 0.15},${capCY_top - capR} `;
    cutLines += `M ${capCX + capR},${capCY_bot} A ${capR} ${capR} 0 1 0 ${capCX - capR},${capCY_bot} A ${capR} ${capR} 0 1 0 ${capCX + capR},${capCY_bot} `;

    for (let angle = 0; angle < 360; angle += 90) {
      const rad = (angle * Math.PI) / 180;
      const fx1 = capCX + Math.sin(rad) * capR;
      const fy1_top = capCY_top - Math.cos(rad) * capR;
      const fx2 = capCX + Math.sin(rad) * (capR + capFlap);
      const fy2_top = capCY_top - Math.cos(rad) * (capR + capFlap);
      cutLines += `M ${fx1 - capFlap * Math.cos(rad)},${fy1_top - capFlap * Math.sin(rad)} L ${fx2 - capFlap * 0.3 * Math.cos(rad)},${fy2_top - capFlap * 0.3 * Math.sin(rad)} L ${fx2 + capFlap * 0.3 * Math.cos(rad)},${fy2_top + capFlap * 0.3 * Math.sin(rad)} L ${fx1 + capFlap * Math.cos(rad)},${fy1_top + capFlap * Math.sin(rad)} `;
    }

    foldLines = `
      M ${bodyX},0 L ${bodyX + bodyW},0
      M ${bodyX},${bodyH} L ${bodyX + bodyW},${bodyH}`;

    if (isStandard) {
      labels = `
      ${panelLabel(bodyX + bodyW / 2, bodyH / 2, 'BODY', `∅${w} × ${h} mm`)}
      <text x="${capCX}" y="${capCY_top + 2}" font-size="3.5" font-family="'Segoe UI',system-ui,sans-serif" font-weight="700" text-anchor="middle" fill="${C.labelMain}" letter-spacing="0.5">TOP</text>
      <text x="${capCX}" y="${capCY_bot + 2}" font-size="3.5" font-family="'Segoe UI',system-ui,sans-serif" font-weight="700" text-anchor="middle" fill="${C.labelMain}" letter-spacing="0.5">BOTTOM</text>
      ${glueTabLabel(-gt * 0.15, bodyH / 2)}`;

      dimAnnotations = `
      ${dimLine(bodyX, 0, bodyX + bodyW, 0, `${bodyW.toFixed(0)}mm`, -8)}
      ${dimLine(bodyX + bodyW, 0, bodyX + bodyW, bodyH, `${h}mm`, 8)}`;
    }

    totalWidth = gt + bodyW + gt;
    totalLength = capR * 1.2 + capR + bodyH + capR * 1.2 + capR;

  // ─── DISPLAY BOX ──────────────────────────────────────────────────
  } else if (type === 'display_box') {
    const gt = glueTab;
    const frontAngle = 0.7;
    const frontH = h * frontAngle;
    const bottomFlap = w * 0.35;
    const topFlap = w * 0.3;
    templateName = 'Display Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + l;
    const x2 = gt + l + w;
    const x3 = gt + l + w + l;
    const x4 = gt + l + w + l + l;
    const yTop = topFlap;
    const yMid = topFlap + h;
    const yFrontTop = topFlap + (h - frontH);

    panelFills = `
      ${glueTabFill([[0, yTop + h * 0.15], [-gt * 0.3, yTop + h * 0.25], [-gt * 0.3, yTop + h * 0.75], [0, yTop + h * 0.85]])}
      ${rectFill(x0, yTop, l, h, C.base)}
      ${pathFill(`M ${x1},${yTop} L ${x1 + w},${yTop} L ${x2},${yFrontTop} L ${x2 + w * 0.05},${yFrontTop} L ${x1},${yTop} Z`, C.side)}
      ${rectFill(x2, yFrontTop, w, yMid - yFrontTop, C.side)}
      ${pathFill(`M ${x2},${yFrontTop} L ${x3},${yFrontTop} L ${x3 + l * 0.95},${yTop} L ${x3},${yTop} Z`, C.side)}
      ${rectFill(x3, yTop, l, h, C.base)}
      ${pathFill(`M ${x0 + l * 0.1},${yTop - topFlap * 0.5} L ${x0 + l * 0.9},${yTop - topFlap * 0.5} L ${x0 + l},${yTop} L ${x0},${yTop} Z`, C.flap)}
      ${pathFill(`M ${x0 + w * 0.1},${yMid} L ${x0 + w * 0.9},${yMid} L ${x0 + w * 0.9},${yMid + bottomFlap} L ${x0 + w * 0.1},${yMid + bottomFlap} Z`, C.flap)}
      ${pathFill(`M ${x1 + w * 0.1},${yMid} L ${x1 + w * 0.9},${yMid} L ${x1 + w * 0.9},${yMid + bottomFlap} L ${x1 + w * 0.1},${yMid + bottomFlap} Z`, C.flap)}
      ${pathFill(`M ${x2 + w * 0.1},${yMid} L ${x2 + w * 0.9},${yMid} L ${x2 + w * 0.9},${yMid + bottomFlap} L ${x2 + w * 0.1},${yMid + bottomFlap} Z`, C.flap)}
      ${pathFill(`M ${x3 + l * 0.1},${yMid} L ${x3 + l * 0.9},${yMid} L ${x3 + l * 0.9},${yMid + bottomFlap} L ${x3 + l * 0.1},${yMid + bottomFlap} Z`, C.flap)}`;

    cutLines = `M 0,${yTop + h * 0.15} L ${-gt * 0.3},${yTop + h * 0.25} L ${-gt * 0.3},${yTop + h * 0.75} L 0,${yTop + h * 0.85} `;
    cutLines += `M 0,${yTop} L ${x0},${yTop} `;
    cutLines += `L ${x0 + l * 0.1},${yTop - topFlap * 0.5} L ${x0 + l * 0.9},${yTop - topFlap * 0.5} L ${x1},${yTop} `;
    cutLines += `L ${x1 + w * 0.05},${yFrontTop} L ${x2},${yFrontTop} `;
    cutLines += `Q ${x2 + w * 0.25},${yFrontTop - 3} ${x2 + w * 0.5},${yFrontTop - 5} `;
    cutLines += `Q ${x2 + w * 0.75},${yFrontTop - 3} ${x3},${yFrontTop} `;
    cutLines += `L ${x3 + l * 0.95},${yTop} L ${x4},${yTop} `;
    cutLines += `L ${x4},${yMid + bottomFlap} `;
    cutLines += `L ${x3 + l * 0.9},${yMid + bottomFlap} L ${x3 + l * 0.1},${yMid + bottomFlap} L ${x3},${yMid} `;
    cutLines += `L ${x2 + w * 0.1},${yMid + bottomFlap} L ${x2 + w * 0.9},${yMid + bottomFlap} L ${x2},${yMid} `;
    cutLines += `L ${x1 + l * 0.1},${yMid + bottomFlap} L ${x1 + l * 0.9},${yMid + bottomFlap} L ${x1},${yMid} `;
    cutLines += `L ${x0 + w * 0.1},${yMid + bottomFlap} L ${x0 + w * 0.9},${yMid + bottomFlap} L ${x0},${yMid} `;
    cutLines += `L 0,${yMid} Z`;

    foldLines = `
      M ${x0},${yTop} L ${x0},${yMid}
      M ${x1},${yTop} L ${x1},${yMid}
      M ${x2},${yFrontTop} L ${x2},${yMid}
      M ${x3},${yTop} L ${x3},${yMid}
      M ${x0},${yMid} L ${x0 + l},${yMid}
      M ${x1},${yMid} L ${x1 + w},${yMid}
      M ${x2},${yMid} L ${x2 + l},${yMid}
      M ${x3},${yMid} L ${x3 + l},${yMid}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + l / 2, yTop + h / 2, 'BACK', `${l} × ${h} mm`)}
      ${panelLabel(x2 + w / 2, yFrontTop + (yMid - yFrontTop) / 2, 'FRONT', `${w} mm`)}
      ${panelLabel(x1 + l / 2, yTop + h / 2, 'SIDE', `${w} mm`)}
      ${panelLabel(x3 + l / 2, yTop + h / 2, 'SIDE', `${l} mm`)}
      ${glueTabLabel(-gt * 0.15, yTop + h / 2)}`;

      dimAnnotations = `
      ${dimLine(x0, yTop, x0 + l, yTop, `${l}mm`, 8)}
      ${dimLine(x0, yTop, x0, yMid, `${h}mm`, -8)}`;
    }

    totalWidth = gt + l + w + l + l + gt;
    totalLength = topFlap + h + bottomFlap + topFlap * 0.5;

  // ─── REVERSE TUCK END BOX ────────────────────────────────────────
  } else if (type === 'reverse_tuck') {
    const gt = glueTab;
    const tuckFlap = h * 0.4;
    const dustFlap = h * 0.45;
    const tuckH = h * 0.35;
    templateName = 'Reverse Tuck End Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + l;
    const x2 = gt + l + w;
    const x3 = gt + l + w + l;
    const yTop = tuckFlap;
    const yBot = tuckFlap + h;

    panelFills = `
      ${glueTabFill([[0, yTop + h * 0.15], [-gt * 0.3, yTop + h * 0.25], [-gt * 0.3, yTop + h * 0.75], [0, yTop + h * 0.85]])}
      ${rectFill(x0, yTop, l, h, C.side)}
      ${rectFill(x1, yTop, w, h, C.base)}
      ${rectFill(x2, yTop, l, h, C.side)}
      ${rectFill(x3, yTop, l, h, C.base)}
      ${pathFill(`M ${x0},${yTop} L ${x0 + l * 0.15},${yTop - tuckFlap * 0.7} L ${x0 + l * 0.85},${yTop - tuckFlap * 0.7} L ${x0 + l},${yTop} Z`, C.flap)}
      ${pathFill(`M ${x1},${yTop} L ${x1 + w * 0.1},${yTop - dustFlap} L ${x1 + w * 0.9},${yTop - dustFlap} L ${x1 + w},${yTop} Z`, C.flap)}
      ${pathFill(`M ${x2},${yTop} L ${x2 + l * 0.1},${yTop - dustFlap} L ${x2 + l * 0.9},${yTop - dustFlap} L ${x2 + l},${yTop} Z`, C.flap)}
      ${pathFill(`M ${x3},${yTop} L ${x3 + l * 0.15},${yTop - tuckFlap * 0.7} L ${x3 + l * 0.85},${yTop - tuckFlap * 0.7} L ${x3 + l},${yTop} Z`, C.flap)}
      ${pathFill(`M ${x0 + l * 0.15},${yBot} L ${x0 + l * 0.85},${yBot} L ${x0 + l * 0.85},${yBot + tuckH} L ${x0 + l * 0.15},${yBot + tuckH} Z`, C.flap)}
      ${pathFill(`M ${x1 + w * 0.05},${yBot} L ${x1 + w * 0.95},${yBot} L ${x1 + w * 0.95},${yBot + tuckH} L ${x1 + w * 0.05},${yBot + tuckH} Z`, C.flap)}
      ${pathFill(`M ${x2 + l * 0.15},${yBot} L ${x2 + l * 0.85},${yBot} L ${x2 + l * 0.85},${yBot + tuckH} L ${x2 + l * 0.15},${yBot + tuckH} Z`, C.flap)}
      ${pathFill(`M ${x3 + l * 0.05},${yBot} L ${x3 + l * 0.95},${yBot} L ${x3 + l * 0.95},${yBot + tuckH} L ${x3 + l * 0.05},${yBot + tuckH} Z`, C.flap)}`;

    // Front tuck goes inward (opposite direction from back tuck)
    cutLines = `M 0,${yTop + h * 0.15} L ${-gt * 0.3},${yTop + h * 0.25} L ${-gt * 0.3},${yTop + h * 0.75} L 0,${yTop + h * 0.85} `;
    cutLines += `M 0,${yTop} L ${x0},${yTop} `;
    cutLines += `L ${x0 + l * 0.15},${yTop - tuckFlap * 0.7} L ${x0 + l * 0.2},${yTop - tuckFlap} L ${x0 + l * 0.35},${yTop - tuckFlap * 1.1} `;
    cutLines += `Q ${x0 + l * 0.5},${yTop - tuckFlap * 1.15} ${x0 + l * 0.65},${yTop - tuckFlap * 1.1} `;
    cutLines += `L ${x0 + l * 0.8},${yTop - tuckFlap} L ${x0 + l * 0.85},${yTop - tuckFlap * 0.7} L ${x1},${yTop} `;
    cutLines += `L ${x1 + w * 0.1},${yTop - dustFlap} L ${x1 + w * 0.9},${yTop - dustFlap} L ${x2},${yTop} `;
    cutLines += `L ${x2 + l * 0.1},${yTop - dustFlap} L ${x2 + l * 0.9},${yTop - dustFlap} L ${x3},${yTop} `;
    // Reverse tuck on back panel: tuck goes the OTHER direction
    cutLines += `L ${x3 + l * 0.15},${yTop - tuckFlap * 0.7} L ${x3 + l * 0.85},${yTop - tuckFlap * 0.7} L ${x3 + l},${yTop} `;
    cutLines += `L ${x3 + l},${yBot} `;
    cutLines += `L ${x3 + l * 0.85},${yBot + tuckH} L ${x3 + l * 0.15},${yBot + tuckH} L ${x3},${yBot} `;
    cutLines += `L ${x2 + l * 0.85},${yBot + tuckH} L ${x2 + l * 0.15},${yBot + tuckH} L ${x2},${yBot} `;
    cutLines += `L ${x1 + w * 0.95},${yBot + tuckH} L ${x1 + w * 0.05},${yBot + tuckH} L ${x1},${yBot} `;
    cutLines += `L ${x0 + l * 0.85},${yBot + tuckH} L ${x0 + l * 0.15},${yBot + tuckH} L ${x0},${yBot} `;
    cutLines += `L 0,${yBot} Z`;

    foldLines = `
      M ${x0},${yTop} L ${x0},${yBot}
      M ${x1},${yTop} L ${x1},${yBot}
      M ${x2},${yTop} L ${x2},${yBot}
      M ${x3},${yTop} L ${x3},${yBot}
      M ${x0},${yBot} L ${x0 + l},${yBot}
      M ${x1},${yBot} L ${x1 + w},${yBot}
      M ${x2},${yBot} L ${x2 + l},${yBot}
      M ${x3},${yBot} L ${x3 + l},${yBot}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + l / 2, yTop + h / 2, 'FRONT', `${l} × ${h} mm`)}
      ${panelLabel(x2 + l / 2, yTop + h / 2, 'BACK', `${l} × ${h} mm`)}
      ${panelLabel(x1 + w / 2, yTop + h / 2, 'SIDE', `${w} mm`)}
      ${panelLabel(x3 + l / 2, yTop + h / 2, 'SIDE', `${l} mm`)}
      ${glueTabLabel(-gt * 0.15, yTop + h / 2)}`;

      dimAnnotations = `
      ${dimLine(x1, yTop, x1 + w, yTop, `${w}mm`, -8)}
      ${dimLine(x1 + w, yTop, x1 + w, yBot, `${h}mm`, 8)}`;
    }

    totalWidth = gt + l + w + l + l + gt;
    totalLength = tuckFlap * 1.15 + h + tuckH;

  // ─── AUTO LOCK BOTTOM BOX ────────────────────────────────────────
  } else if (type === 'auto_lock') {
    const gt = glueTab;
    const lockH = h * 0.45;
    templateName = 'Auto Lock Bottom Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + l;
    const x2 = gt + l + w;
    const x3 = gt + l + w + l;
    const yTop = h * 0.4;
    const yBot = yTop + h;

    panelFills = `
      ${glueTabFill([[0, yTop + h * 0.15], [-gt * 0.3, yTop + h * 0.25], [-gt * 0.3, yTop + h * 0.75], [0, yTop + h * 0.85]])}
      ${rectFill(x0, yTop, l, h, C.side)}
      ${rectFill(x1, yTop, w, h, C.base)}
      ${rectFill(x2, yTop, l, h, C.side)}
      ${rectFill(x3, yTop, l, h, C.base)}
      ${pathFill(`M ${x0 + l * 0.1},${yTop} L ${x0 + l * 0.9},${yTop} L ${x0 + l * 0.9},${yTop - h * 0.35} L ${x0 + l * 0.1},${yTop - h * 0.35} Z`, C.flap)}
      ${pathFill(`M ${x1 + w * 0.1},${yTop} L ${x1 + w * 0.9},${yTop} L ${x1 + w * 0.9},${yTop - h * 0.35} L ${x1 + w * 0.1},${yTop - h * 0.35} Z`, C.flap)}
      ${pathFill(`M ${x2 + l * 0.1},${yTop} L ${x2 + l * 0.9},${yTop} L ${x2 + l * 0.9},${yTop - h * 0.35} L ${x2 + l * 0.1},${yTop - h * 0.35} Z`, C.flap)}
      ${pathFill(`M ${x3 + l * 0.1},${yTop} L ${x3 + l * 0.9},${yTop} L ${x3 + l * 0.9},${yTop - h * 0.35} L ${x3 + l * 0.1},${yTop - h * 0.35} Z`, C.flap)}
      ${pathFill(`M ${x0 + l * 0.15},${yBot} L ${x0 + l * 0.85},${yBot} L ${x0 + l * 0.5},${yBot + lockH} Z`, C.flap)}
      ${pathFill(`M ${x1 + w * 0.05},${yBot} L ${x1 + w * 0.95},${yBot} L ${x1 + w * 0.5},${yBot + lockH} Z`, C.flap)}
      ${pathFill(`M ${x2 + l * 0.15},${yBot} L ${x2 + l * 0.85},${yBot} L ${x2 + l * 0.5},${yBot + lockH} Z`, C.flap)}
      ${pathFill(`M ${x3 + l * 0.05},${yBot} L ${x3 + l * 0.95},${yBot} L ${x3 + l * 0.5},${yBot + lockH} Z`, C.flap)}`;

    cutLines = `M 0,${yTop + h * 0.15} L ${-gt * 0.3},${yTop + h * 0.25} L ${-gt * 0.3},${yTop + h * 0.75} L 0,${yTop + h * 0.85} `;
    cutLines += `M 0,${yTop} L ${x0},${yTop} `;
    cutLines += `L ${x0 + l * 0.1},${yTop - h * 0.35} L ${x0 + l * 0.9},${yTop - h * 0.35} L ${x0 + l},${yTop} `;
    cutLines += `L ${x1 + w * 0.1},${yTop - h * 0.35} L ${x1 + w * 0.9},${yTop - h * 0.35} L ${x2},${yTop} `;
    cutLines += `L ${x2 + l * 0.1},${yTop - h * 0.35} L ${x2 + l * 0.9},${yTop - h * 0.35} L ${x3},${yTop} `;
    cutLines += `L ${x3 + l * 0.1},${yTop - h * 0.35} L ${x3 + l * 0.9},${yTop - h * 0.35} L ${x3 + l},${yTop} `;
    cutLines += `L ${x3 + l},${yBot} `;
    // Auto-lock bottom flaps (interlocking diagonal cuts)
    cutLines += `M ${x0 + l * 0.15},${yBot} L ${x0 + l * 0.85},${yBot} L ${x0 + l * 0.5},${yBot + lockH} Z `;
    cutLines += `M ${x1 + w * 0.05},${yBot} L ${x1 + w * 0.95},${yBot} L ${x1 + w * 0.5},${yBot + lockH} Z `;
    cutLines += `M ${x2 + l * 0.15},${yBot} L ${x2 + l * 0.85},${yBot} L ${x2 + l * 0.5},${yBot + lockH} Z `;
    cutLines += `M ${x3 + l * 0.05},${yBot} L ${x3 + l * 0.95},${yBot} L ${x3 + l * 0.5},${yBot + lockH} Z `;
    // Diagonal cuts for interlock
    cutLines += `M ${x0 + l * 0.3},${yBot + lockH * 0.3} L ${x0 + l * 0.7},${yBot + lockH * 0.3} `;
    cutLines += `M ${x2 + l * 0.3},${yBot + lockH * 0.3} L ${x2 + l * 0.7},${yBot + lockH * 0.3} `;
    cutLines += `L 0,${yBot} Z`;

    foldLines = `
      M ${x0},${yTop} L ${x0},${yBot}
      M ${x1},${yTop} L ${x1},${yBot}
      M ${x2},${yTop} L ${x2},${yBot}
      M ${x3},${yTop} L ${x3},${yBot}
      M ${x0},${yBot} L ${x0 + l},${yBot}
      M ${x1},${yBot} L ${x1 + w},${yBot}
      M ${x2},${yBot} L ${x2 + l},${yBot}
      M ${x3},${yBot} L ${x3 + l},${yBot}
      M ${x0 + l * 0.5},${yBot} L ${x0 + l * 0.5},${yBot + lockH}
      M ${x1 + w * 0.5},${yBot} L ${x1 + w * 0.5},${yBot + lockH}
      M ${x2 + l * 0.5},${yBot} L ${x2 + l * 0.5},${yBot + lockH}
      M ${x3 + l * 0.5},${yBot} L ${x3 + l * 0.5},${yBot + lockH}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + l / 2, yTop + h / 2, 'FRONT', `${l} × ${h} mm`)}
      ${panelLabel(x2 + l / 2, yTop + h / 2, 'BACK', `${l} mm`)}
      ${panelLabel(x1 + w / 2, yTop + h / 2, 'SIDE', `${w} mm`)}
      ${panelLabel(x3 + l / 2, yTop + h / 2, 'SIDE', `${l} mm`)}
      ${glueTabLabel(-gt * 0.15, yTop + h / 2)}`;

      dimAnnotations = `
      ${dimLine(x1, yTop, x1 + w, yTop, `${w}mm`, -8)}
      ${dimLine(x1 + w, yTop, x1 + w, yBot, `${h}mm`, 8)}`;
    }

    totalWidth = gt + l + w + l + l + gt;
    totalLength = h * 0.35 + h + lockH;

  // ─── WINDOW CUT BOX ──────────────────────────────────────────────
  } else if (type === 'window_box') {
    const gt = glueTab;
    const tuckH = h * 0.35;
    templateName = 'Window Cut Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + l;
    const x2 = gt + l + w;
    const x3 = gt + l + w + l;
    const yTop = tuckH;
    const yBot = yTop + h;
    const winW = w * 0.55;
    const winH = h * 0.4;
    const winCX = x1 + w / 2;
    const winCY = yTop + h / 2;

    panelFills = `
      ${glueTabFill([[0, yTop + h * 0.15], [-gt * 0.3, yTop + h * 0.25], [-gt * 0.3, yTop + h * 0.75], [0, yTop + h * 0.85]])}
      ${rectFill(x0, yTop, l, h, C.side)}
      ${rectFill(x1, yTop, w, h, C.base)}
      ${rectFill(x2, yTop, l, h, C.side)}
      ${rectFill(x3, yTop, l, h, C.base)}
      ${pathFill(`M ${x0 + l * 0.1},${yTop} L ${x0 + l * 0.9},${yTop} L ${x0 + l * 0.9},${yTop - tuckH} L ${x0 + l * 0.1},${yTop - tuckH} Z`, C.flap)}
      ${pathFill(`M ${x1 + w * 0.1},${yTop} L ${x1 + w * 0.9},${yTop} L ${x1 + w * 0.9},${yTop - tuckH} L ${x1 + w * 0.1},${yTop - tuckH} Z`, C.flap)}
      ${pathFill(`M ${x2 + l * 0.1},${yTop} L ${x2 + l * 0.9},${yTop} L ${x2 + l * 0.9},${yTop - tuckH} L ${x2 + l * 0.1},${yTop - tuckH} Z`, C.flap)}
      ${pathFill(`M ${x3 + l * 0.1},${yTop} L ${x3 + l * 0.9},${yTop} L ${x3 + l * 0.9},${yTop - tuckH} L ${x3 + l * 0.1},${yTop - tuckH} Z`, C.flap)}
      ${pathFill(`M ${x0 + l * 0.15},${yBot} L ${x0 + l * 0.85},${yBot} L ${x0 + l * 0.85},${yBot + tuckH} L ${x0 + l * 0.15},${yBot + tuckH} Z`, C.flap)}
      ${pathFill(`M ${x1 + w * 0.05},${yBot} L ${x1 + w * 0.95},${yBot} L ${x1 + w * 0.95},${yBot + tuckH} L ${x1 + w * 0.05},${yBot + tuckH} Z`, C.flap)}
      ${pathFill(`M ${x2 + l * 0.15},${yBot} L ${x2 + l * 0.85},${yBot} L ${x2 + l * 0.85},${yBot + tuckH} L ${x2 + l * 0.15},${yBot + tuckH} Z`, C.flap)}
      ${pathFill(`M ${x3 + l * 0.05},${yBot} L ${x3 + l * 0.95},${yBot} L ${x3 + l * 0.95},${yBot + tuckH} L ${x3 + l * 0.05},${yBot + tuckH} Z`, C.flap)}
      <rect x="${winCX - winW / 2}" y="${winCY - winH / 2}" width="${winW}" height="${winH}" rx="${Math.min(winW, winH) * 0.15}" fill="#d8d0c6" fill-opacity="0.5" stroke="none" />`;

    cutLines = `M 0,${yTop + h * 0.15} L ${-gt * 0.3},${yTop + h * 0.25} L ${-gt * 0.3},${yTop + h * 0.75} L 0,${yTop + h * 0.85} `;
    cutLines += `M 0,${yTop} L ${x0},${yTop} `;
    cutLines += `L ${x0 + l * 0.1},${yTop - tuckH} L ${x0 + l * 0.9},${yTop - tuckH} L ${x0 + l},${yTop} `;
    cutLines += `L ${x1 + w * 0.1},${yTop - tuckH} L ${x1 + w * 0.9},${yTop - tuckH} L ${x2},${yTop} `;
    cutLines += `L ${x2 + l * 0.1},${yTop - tuckH} L ${x2 + l * 0.9},${yTop - tuckH} L ${x3},${yTop} `;
    cutLines += `L ${x3 + l * 0.1},${yTop - tuckH} L ${x3 + l * 0.9},${yTop - tuckH} L ${x3 + l},${yTop} `;
    cutLines += `L ${x3 + l},${yBot} `;
    cutLines += `L ${x3 + l * 0.95},${yBot + tuckH} L ${x3 + l * 0.05},${yBot + tuckH} L ${x3},${yBot} `;
    cutLines += `L ${x2 + l * 0.85},${yBot + tuckH} L ${x2 + l * 0.15},${yBot + tuckH} L ${x2},${yBot} `;
    cutLines += `L ${x1 + w * 0.95},${yBot + tuckH} L ${x1 + w * 0.05},${yBot + tuckH} L ${x1},${yBot} `;
    cutLines += `L ${x0 + l * 0.85},${yBot + tuckH} L ${x0 + l * 0.15},${yBot + tuckH} L ${x0},${yBot} `;
    cutLines += `L 0,${yBot} Z `;
    // Window die-cut on front panel
    cutLines += `M ${winCX - winW / 2 + Math.min(winW, winH) * 0.15},${winCY - winH / 2} L ${winCX + winW / 2 - Math.min(winW, winH) * 0.15},${winCY - winH / 2} Q ${winCX + winW / 2},${winCY - winH / 2} ${winCX + winW / 2},${winCY - winH / 2 + Math.min(winW, winH) * 0.15} L ${winCX + winW / 2},${winCY + winH / 2 - Math.min(winW, winH) * 0.15} Q ${winCX + winW / 2},${winCY + winH / 2} ${winCX + winW / 2 - Math.min(winW, winH) * 0.15},${winCY + winH / 2} L ${winCX - winW / 2 + Math.min(winW, winH) * 0.15},${winCY + winH / 2} Q ${winCX - winW / 2},${winCY + winH / 2} ${winCX - winW / 2},${winCY + winH / 2 - Math.min(winW, winH) * 0.15} L ${winCX - winW / 2},${winCY - winH / 2 + Math.min(winW, winH) * 0.15} Q ${winCX - winW / 2},${winCY - winH / 2} ${winCX - winW / 2 + Math.min(winW, winH) * 0.15},${winCY - winH / 2} Z`;

    foldLines = `
      M ${x0},${yTop} L ${x0},${yBot}
      M ${x1},${yTop} L ${x1},${yBot}
      M ${x2},${yTop} L ${x2},${yBot}
      M ${x3},${yTop} L ${x3},${yBot}
      M ${x0},${yBot} L ${x0 + l},${yBot}
      M ${x1},${yBot} L ${x1 + w},${yBot}
      M ${x2},${yBot} L ${x2 + l},${yBot}
      M ${x3},${yBot} L ${x3 + l},${yBot}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + l / 2, yTop + h / 2, 'FRONT', `${l} × ${h} mm`)}
      ${panelLabel(x2 + l / 2, yTop + h / 2, 'BACK', `${l} mm`)}
      ${panelLabel(x1 + w / 2, yTop + h / 2 - 10, 'SIDE', `${w} mm`)}
      ${panelLabel(x3 + l / 2, yTop + h / 2, 'SIDE', `${l} mm`)}
      ${glueTabLabel(-gt * 0.15, yTop + h / 2)}
      <text x="${winCX}" y="${winCY + 1}" font-size="2.5" font-family="'Segoe UI',system-ui,sans-serif" font-weight="700" text-anchor="middle" fill="#9e8e7e" letter-spacing="0.8">WINDOW</text>`;

      dimAnnotations = `
      ${dimLine(x1, yTop, x1 + w, yTop, `${w}mm`, -8)}
      ${dimLine(x1 + w, yTop, x1 + w, yBot, `${h}mm`, 8)}`;
    }

    totalWidth = gt + l + w + l + l + gt;
    totalLength = tuckH + h + tuckH;

  // ─── DRAWER BOX ──────────────────────────────────────────────────
  } else if (type === 'drawer_box') {
    const gt = glueTab;
    const sleeveH = h * 0.45;
    const gap = 10;
    templateName = 'Drawer Box';
    dimText = `${w} × ${l} × ${h} mm`;

    // Outer sleeve (3-sided, open on one end)
    const sx0 = gt;
    const sx1 = gt + l;
    const sx2 = gt + l + w;
    const sx3 = gt + l + w + l;
    const syTop = sleeveH * 0.4;
    const syBot = syTop + sleeveH;

    panelFills = `
      ${glueTabFill([[0, syTop + sleeveH * 0.15], [-gt * 0.3, syTop + sleeveH * 0.25], [-gt * 0.3, syTop + sleeveH * 0.75], [0, syTop + sleeveH * 0.85]])}
      ${rectFill(sx0, syTop, l, sleeveH, C.side)}
      ${rectFill(sx1, syTop, w, sleeveH, C.base)}
      ${rectFill(sx2, syTop, l, sleeveH, C.side)}
      ${pathFill(`M ${sx0 + l * 0.1},${syTop} L ${sx0 + l * 0.9},${syTop} L ${sx0 + l * 0.9},${syTop - sleeveH * 0.35} L ${sx0 + l * 0.1},${syTop - sleeveH * 0.35} Z`, C.flap)}
      ${pathFill(`M ${sx2 + l * 0.1},${syTop} L ${sx2 + l * 0.9},${syTop} L ${sx2 + l * 0.9},${syTop - sleeveH * 0.35} L ${sx2 + l * 0.1},${syTop - sleeveH * 0.35} Z`, C.flap)}
      ${pathFill(`M ${sx0 + l * 0.1},${syBot} L ${sx0 + l * 0.9},${syBot} L ${sx0 + l * 0.9},${syBot + sleeveH * 0.35} L ${sx0 + l * 0.1},${syBot + sleeveH * 0.35} Z`, C.flap)}
      ${pathFill(`M ${sx1 + w * 0.05},${syBot} L ${sx1 + w * 0.95},${syBot} L ${sx1 + w * 0.95},${syBot + sleeveH * 0.35} L ${sx1 + w * 0.05},${syBot + sleeveH * 0.35} Z`, C.flap)}
      ${pathFill(`M ${sx2 + l * 0.1},${syBot} L ${sx2 + l * 0.9},${syBot} L ${sx2 + l * 0.9},${syBot + sleeveH * 0.35} L ${sx2 + l * 0.1},${syBot + sleeveH * 0.35} Z`, C.flap)}`;

    cutLines = `M 0,${syTop + sleeveH * 0.15} L ${-gt * 0.3},${syTop + sleeveH * 0.25} L ${-gt * 0.3},${syTop + sleeveH * 0.75} L 0,${syTop + sleeveH * 0.85} `;
    cutLines += `M 0,${syTop} L ${sx0},${syTop} `;
    cutLines += `L ${sx0 + l * 0.1},${syTop - sleeveH * 0.35} L ${sx0 + l * 0.9},${syTop - sleeveH * 0.35} L ${sx1},${syTop} `;
    cutLines += `L ${sx1 + w * 0.95},${syTop} L ${sx2},${syTop} `;
    cutLines += `L ${sx2 + l * 0.1},${syTop - sleeveH * 0.35} L ${sx2 + l * 0.9},${syTop - sleeveH * 0.35} L ${sx3},${syTop} `;
    cutLines += `L ${sx3},${syBot} `;
    cutLines += `L ${sx2 + l * 0.9},${syBot + sleeveH * 0.35} L ${sx2 + l * 0.1},${syBot + sleeveH * 0.35} L ${sx2},${syBot} `;
    cutLines += `L ${sx1 + w * 0.95},${syBot + sleeveH * 0.35} L ${sx1 + w * 0.05},${syBot + sleeveH * 0.35} L ${sx1},${syBot} `;
    cutLines += `L ${sx0 + l * 0.9},${syBot + sleeveH * 0.35} L ${sx0 + l * 0.1},${syBot + sleeveH * 0.35} L ${sx0},${syBot} `;
    cutLines += `L 0,${syBot} Z`;

    foldLines = `
      M ${sx0},${syTop} L ${sx0},${syBot}
      M ${sx1},${syTop} L ${sx1},${syBot}
      M ${sx2},${syTop} L ${sx2},${syBot}
      M ${sx0},${syBot} L ${sx0 + l},${syBot}
      M ${sx1},${syBot} L ${sx1 + w},${syBot}
      M ${sx2},${syBot} L ${sx2 + l},${syBot}`;

    // Inner tray
    const trayOffset = syBot + sleeveH * 0.35 + gap;
    const trayH = h * 0.75;
    const tx0 = gt;
    const tx1 = gt + l;
    const tx2 = gt + l + w;
    const tx3 = gt + l + w + l;
    const tyTop = trayH * 0.3;
    const tyBot = tyTop + trayH;

    panelFills += `
      ${glueTabFill([[0, trayOffset + tyTop + trayH * 0.15], [-gt * 0.3, trayOffset + tyTop + trayH * 0.25], [-gt * 0.3, trayOffset + tyTop + trayH * 0.75], [0, trayOffset + tyTop + trayH * 0.85]])}
      ${rectFill(tx0, trayOffset + tyTop, l, trayH, C.side)}
      ${rectFill(tx1, trayOffset + tyTop, w, trayH, C.base)}
      ${rectFill(tx2, trayOffset + tyTop, l, trayH, C.side)}
      ${pathFill(`M ${tx0 + l * 0.1},${trayOffset + tyTop} L ${tx0 + l * 0.9},${trayOffset + tyTop} L ${tx0 + l * 0.9},${trayOffset + tyTop - trayH * 0.3} L ${tx0 + l * 0.1},${trayOffset + tyTop - trayH * 0.3} Z`, C.flap)}
      ${pathFill(`M ${tx1 + w * 0.05},${trayOffset + tyTop} L ${tx1 + w * 0.95},${trayOffset + tyTop} L ${tx1 + w * 0.95},${trayOffset + tyTop - trayH * 0.3} L ${tx1 + w * 0.05},${trayOffset + tyTop - trayH * 0.3} Z`, C.flap)}
      ${pathFill(`M ${tx2 + l * 0.1},${trayOffset + tyTop} L ${tx2 + l * 0.9},${trayOffset + tyTop} L ${tx2 + l * 0.9},${trayOffset + tyTop - trayH * 0.3} L ${tx2 + l * 0.1},${trayOffset + tyTop - trayH * 0.3} Z`, C.flap)}
      ${pathFill(`M ${tx0 + l * 0.15},${trayOffset + tyBot} L ${tx0 + l * 0.85},${trayOffset + tyBot} L ${tx0 + l * 0.85},${trayOffset + tyBot + trayH * 0.3} L ${tx0 + l * 0.15},${trayOffset + tyBot + trayH * 0.3} Z`, C.flap)}
      ${pathFill(`M ${tx1 + w * 0.05},${trayOffset + tyBot} L ${tx1 + w * 0.95},${trayOffset + tyBot} L ${tx1 + w * 0.95},${trayOffset + tyBot + trayH * 0.3} L ${tx1 + w * 0.05},${trayOffset + tyBot + trayH * 0.3} Z`, C.flap)}
      ${pathFill(`M ${tx2 + l * 0.15},${trayOffset + tyBot} L ${tx2 + l * 0.85},${trayOffset + tyBot} L ${tx2 + l * 0.85},${trayOffset + tyBot + trayH * 0.3} L ${tx2 + l * 0.15},${trayOffset + tyBot + trayH * 0.3} Z`, C.flap)}`;

    cutLines += `M 0,${trayOffset + tyTop + trayH * 0.15} L ${-gt * 0.3},${trayOffset + tyTop + trayH * 0.25} L ${-gt * 0.3},${trayOffset + tyTop + trayH * 0.75} L 0,${trayOffset + tyTop + trayH * 0.85} `;
    cutLines += `M 0,${trayOffset + tyTop} L ${tx0},${trayOffset + tyTop} `;
    cutLines += `L ${tx0 + l * 0.1},${trayOffset + tyTop - trayH * 0.3} L ${tx0 + l * 0.9},${trayOffset + tyTop - trayH * 0.3} L ${tx1},${trayOffset + tyTop} `;
    cutLines += `L ${tx1 + w * 0.05},${trayOffset + tyTop - trayH * 0.3} L ${tx1 + w * 0.95},${trayOffset + tyTop - trayH * 0.3} L ${tx2},${trayOffset + tyTop} `;
    cutLines += `L ${tx2 + l * 0.1},${trayOffset + tyTop - trayH * 0.3} L ${tx2 + l * 0.9},${trayOffset + tyTop - trayH * 0.3} L ${tx3},${trayOffset + tyTop} `;
    cutLines += `L ${tx3},${trayOffset + tyBot} `;
    cutLines += `L ${tx2 + l * 0.85},${trayOffset + tyBot + trayH * 0.3} L ${tx2 + l * 0.15},${trayOffset + tyBot + trayH * 0.3} L ${tx2},${trayOffset + tyBot} `;
    cutLines += `L ${tx1 + w * 0.95},${trayOffset + tyBot + trayH * 0.3} L ${tx1 + w * 0.05},${trayOffset + tyBot + trayH * 0.3} L ${tx1},${trayOffset + tyBot} `;
    cutLines += `L ${tx0 + l * 0.85},${trayOffset + tyBot + trayH * 0.3} L ${tx0 + l * 0.15},${trayOffset + tyBot + trayH * 0.3} L ${tx0},${trayOffset + tyBot} `;
    cutLines += `L 0,${trayOffset + tyBot} Z`;

    foldLines += `
      M ${tx0},${trayOffset + tyTop} L ${tx0},${trayOffset + tyBot}
      M ${tx1},${trayOffset + tyTop} L ${tx1},${trayOffset + tyBot}
      M ${tx2},${trayOffset + tyTop} L ${tx2},${trayOffset + tyBot}
      M ${tx0},${trayOffset + tyBot} L ${tx0 + l},${trayOffset + tyBot}
      M ${tx1},${trayOffset + tyBot} L ${tx1 + w},${trayOffset + tyBot}
      M ${tx2},${trayOffset + tyBot} L ${tx2 + l},${trayOffset + tyBot}`;

    if (isStandard) {
      labels = `
      ${panelLabel(sx1 + w / 2, syTop + sleeveH / 2, 'SLEEVE', `${w} mm`)}
      ${panelLabel(sx0 + l / 2, syTop + sleeveH / 2, 'SIDE', `${l} mm`)}
      ${panelLabel(tx1 + w / 2, trayOffset + tyTop + trayH / 2, 'TRAY', `${w} × ${h} mm`)}
      ${panelLabel(tx0 + l / 2, trayOffset + tyTop + trayH / 2, 'SIDE', `${l} mm`)}
      ${panelLabel(tx2 + l / 2, trayOffset + tyTop + trayH / 2, 'SIDE', `${l} mm`)}
      ${glueTabLabel(-gt * 0.15, syTop + sleeveH / 2)}`;
    }

    totalWidth = gt + l + w + l + gt;
    totalLength = sleeveH * 0.35 + sleeveH + sleeveH * 0.35 + gap + trayH * 0.3 + trayH + trayH * 0.3;

  // ─── HEART SHAPED BOX ────────────────────────────────────────────
  } else if (type === 'heart_box') {
    const gt = glueTab;
    const halfW = w / 2;
    const heartH = h * 1.2;
    templateName = 'Heart Shaped Box';
    dimText = `${w} × ${w} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + w;
    const yMid = heartH * 0.45;

    // Heart shape: two cubic beziers for top curves, point at bottom
    panelFills = `
      ${glueTabFill([[0, yMid * 0.15], [-gt * 0.3, yMid * 0.25], [-gt * 0.3, yMid * 0.75], [0, yMid * 0.85]])}
      ${pathFill(`M ${x0 + halfW},${heartH} C ${x0},${heartH * 0.75} ${x0 - halfW * 0.2},${heartH * 0.35} ${x0 + halfW * 0.25},${heartH * 0.15} C ${x0 + halfW * 0.4},${heartH * 0.02} ${x0 + halfW},${heartH * 0.05} ${x0 + halfW},${heartH * 0.2} C ${x0 + halfW},${heartH * 0.05} ${x0 + halfW * 0.6},${heartH * 0.02} ${x0 + halfW * 0.75},${heartH * 0.15} C ${x0 + w + halfW * 0.2},${heartH * 0.35} ${x0 + w},${heartH * 0.75} ${x0 + halfW},${heartH} Z`, C.base)}
      ${pathFill(`M ${x1 + halfW},${heartH} C ${x1},${heartH * 0.75} ${x1 - halfW * 0.2},${heartH * 0.35} ${x1 + halfW * 0.25},${heartH * 0.15} C ${x1 + halfW * 0.4},${heartH * 0.02} ${x1 + halfW},${heartH * 0.05} ${x1 + halfW},${heartH * 0.2} C ${x1 + halfW},${heartH * 0.05} ${x1 + halfW * 0.6},${heartH * 0.02} ${x1 + halfW * 0.75},${heartH * 0.15} C ${x1 + w + halfW * 0.2},${heartH * 0.35} ${x1 + w},${heartH * 0.75} ${x1 + halfW},${heartH} Z`, C.side)}`;

    cutLines = `M ${x0 + halfW},${heartH} `;
    cutLines += `C ${x0},${heartH * 0.75} ${x0 - halfW * 0.2},${heartH * 0.35} ${x0 + halfW * 0.25},${heartH * 0.15} `;
    cutLines += `C ${x0 + halfW * 0.4},${heartH * 0.02} ${x0 + halfW},${heartH * 0.05} ${x0 + halfW},${heartH * 0.2} `;
    cutLines += `C ${x0 + halfW},${heartH * 0.05} ${x0 + halfW * 0.6},${heartH * 0.02} ${x0 + halfW * 0.75},${heartH * 0.15} `;
    cutLines += `C ${x0 + w + halfW * 0.2},${heartH * 0.35} ${x0 + w},${heartH * 0.75} ${x0 + halfW},${heartH} Z `;
    cutLines += `M ${x1 + halfW},${heartH} `;
    cutLines += `C ${x1},${heartH * 0.75} ${x1 - halfW * 0.2},${heartH * 0.35} ${x1 + halfW * 0.25},${heartH * 0.15} `;
    cutLines += `C ${x1 + halfW * 0.4},${heartH * 0.02} ${x1 + halfW},${heartH * 0.05} ${x1 + halfW},${heartH * 0.2} `;
    cutLines += `C ${x1 + halfW},${heartH * 0.05} ${x1 + halfW * 0.6},${heartH * 0.02} ${x1 + halfW * 0.75},${heartH * 0.15} `;
    cutLines += `C ${x1 + w + halfW * 0.2},${heartH * 0.35} ${x1 + w},${heartH * 0.75} ${x1 + halfW},${heartH} Z`;
    // Glue tab
    cutLines += ` M 0,${yMid * 0.15} L ${-gt * 0.3},${yMid * 0.25} L ${-gt * 0.3},${yMid * 0.75} L 0,${yMid * 0.85}`;

    foldLines = `M ${x0 + w},${0} L ${x0 + w},${heartH}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + halfW, heartH * 0.55, 'BOTTOM', `${w} mm`)}
      ${panelLabel(x1 + halfW, heartH * 0.55, 'TOP', `${w} mm`)}
      ${glueTabLabel(-gt * 0.15, yMid / 2)}`;

      dimAnnotations = `
      ${dimLine(x0, heartH * 0.75, x0 + w, heartH * 0.75, `${w}mm`, -8)}`;
    }

    totalWidth = gt + w + w + gt;
    totalLength = heartH;

  // ─── CONE / PARTY HAT ────────────────────────────────────────────
  } else if (type === 'cone') {
    const gt = glueTab;
    const slantH = Math.sqrt(h * h + (w / 2) * (w / 2));
    const circBase = Math.PI * w;
    const sectorAngle = (w / (2 * slantH)) * 360;
    templateName = 'Cone / Party Hat';
    dimText = `∅${w} × ${h} mm`;

    // Sector approximation: radius = slantH, arc = circBase
    const r = slantH;
    const arcLen = circBase;
    const halfAngle = (sectorAngle / 2) * Math.PI / 180;

    // Sector from top center
    const cx = r + gt;
    const cy = r * 0.1;

    panelFills = `
      ${glueTabFill([[cx - r * Math.sin(halfAngle) - gt * 0.3, cy + r * 0.3], [cx - r * Math.sin(halfAngle) - gt * 0.3, cy + r * 0.7], [cx - r * Math.sin(halfAngle), cy + r * 0.85], [cx - r * Math.sin(halfAngle), cy + r * 0.15]])}
      ${pathFill(`M ${cx},${cy} L ${cx - r * Math.sin(halfAngle)},${cy + r * Math.cos(halfAngle)} A ${r} ${r} 0 0 1 ${cx + r * Math.sin(halfAngle)},${cy + r * Math.cos(halfAngle)} Z`, C.base)}
      <circle cx="${cx + r + w * 0.6}" cy="${cy + r * 0.5}" r="${w / 2}" fill="${C.flap}" stroke="none" />`;

    cutLines = `M ${cx},${cy} L ${cx - r * Math.sin(halfAngle)},${cy + r * Math.cos(halfAngle)} `;
    cutLines += `A ${r} ${r} 0 0 1 ${cx + r * Math.sin(halfAngle)},${cy + r * Math.cos(halfAngle)} `;
    cutLines += `L ${cx},${cy} Z `;
    // Base circle
    cutLines += `M ${cx + r + w * 0.6 + w / 2},${cy + r * 0.5} A ${w / 2} ${w / 2} 0 1 0 ${cx + r + w * 0.6 - w / 2},${cy + r * 0.5} A ${w / 2} ${w / 2} 0 1 0 ${cx + r + w * 0.6 + w / 2},${cy + r * 0.5} `;
    // Glue tab
    cutLines += `M ${cx - r * Math.sin(halfAngle)},${cy + r * 0.15} L ${cx - r * Math.sin(halfAngle) - gt * 0.3},${cy + r * 0.3} L ${cx - r * Math.sin(halfAngle) - gt * 0.3},${cy + r * 0.7} L ${cx - r * Math.sin(halfAngle)},${cy + r * 0.85}`;

    foldLines = `M ${cx},${cy} L ${cx},${cy + r}`;

    if (isStandard) {
      labels = `
      ${panelLabel(cx, cy + r * 0.55, 'BODY', `∅${w} × ${h} mm`)}
      <text x="${cx + r + w * 0.6}" y="${cy + r * 0.5 + 2}" font-size="3.5" font-family="'Segoe UI',system-ui,sans-serif" font-weight="700" text-anchor="middle" fill="${C.labelMain}" letter-spacing="0.5">BASE</text>
      ${glueTabLabel(cx - r * Math.sin(halfAngle) - gt * 0.15, cy + r * 0.5)}`;

      dimAnnotations = `
      ${dimLine(cx - r * Math.sin(halfAngle), cy + r * Math.cos(halfAngle), cx + r * Math.sin(halfAngle), cy + r * Math.cos(halfAngle), `${arcLen.toFixed(0)}mm`, 8)}`;
    }

    totalWidth = gt + r * Math.sin(halfAngle) * 2 + gt + r + w;
    totalLength = cy + r + w / 2;

  // ─── FAVOR / TRUFFLE BOX ──────────────────────────────────────────
  } else if (type === 'favor_box') {
    const gt = glueTab;
    const taperW = w * 0.15;
    const ribbonSlot = w * 0.08;
    templateName = 'Favor / Truffle Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + l;
    const x2 = gt + l + w;
    const x3 = gt + l + w + l;
    const yTop = h * 0.3;
    const yBot = yTop + h;

    panelFills = `
      ${glueTabFill([[0, yTop + h * 0.15], [-gt * 0.3, yTop + h * 0.25], [-gt * 0.3, yTop + h * 0.75], [0, yTop + h * 0.85]])}
      ${polyFill([[x0, yTop], [x0 + taperW, yTop - h * 0.25], [x0 + l - taperW, yTop - h * 0.25], [x0 + l, yTop], [x0 + l, yBot], [x0, yBot]], C.side)}
      ${rectFill(x1, yTop, w, h, C.base)}
      ${polyFill([[x2, yTop], [x2 + taperW, yTop - h * 0.25], [x2 + l - taperW, yTop - h * 0.25], [x2 + l, yTop], [x2 + l, yBot], [x2, yBot]], C.side)}
      ${rectFill(x3, yTop, l, h, C.base)}
      ${pathFill(`M ${x1},${yTop} L ${x1 + taperW},${yTop - h * 0.25} L ${x1 + w - taperW},${yTop - h * 0.25} L ${x1 + w},${yTop} Z`, C.flap)}
      ${pathFill(`M ${x0 + l * 0.1},${yBot} L ${x0 + l * 0.9},${yBot} L ${x0 + l * 0.9},${yBot + h * 0.25} L ${x0 + l * 0.1},${yBot + h * 0.25} Z`, C.flap)}
      ${pathFill(`M ${x1 + w * 0.05},${yBot} L ${x1 + w * 0.95},${yBot} L ${x1 + w * 0.95},${yBot + h * 0.25} L ${x1 + w * 0.05},${yBot + h * 0.25} Z`, C.flap)}
      ${pathFill(`M ${x2 + l * 0.1},${yBot} L ${x2 + l * 0.9},${yBot} L ${x2 + l * 0.9},${yBot + h * 0.25} L ${x2 + l * 0.1},${yBot + h * 0.25} Z`, C.flap)}
      ${pathFill(`M ${x3 + l * 0.05},${yBot} L ${x3 + l * 0.95},${yBot} L ${x3 + l * 0.95},${yBot + h * 0.25} L ${x3 + l * 0.05},${yBot + h * 0.25} Z`, C.flap)}`;

    cutLines = `M 0,${yTop + h * 0.15} L ${-gt * 0.3},${yTop + h * 0.25} L ${-gt * 0.3},${yTop + h * 0.75} L 0,${yTop + h * 0.85} `;
    cutLines += `M 0,${yTop} L ${x0},${yTop} `;
    cutLines += `L ${x0 + taperW},${yTop - h * 0.25} L ${x0 + l - taperW},${yTop - h * 0.25} L ${x0 + l},${yTop} `;
    cutLines += `L ${x1 + taperW},${yTop - h * 0.25} L ${x1 + w - taperW},${yTop - h * 0.25} L ${x2},${yTop} `;
    cutLines += `L ${x2 + taperW},${yTop - h * 0.25} L ${x2 + l - taperW},${yTop - h * 0.25} L ${x3},${yTop} `;
    cutLines += `L ${x3 + l},${yTop} `;
    cutLines += `L ${x3 + l},${yBot} `;
    cutLines += `L ${x3 + l * 0.95},${yBot + h * 0.25} L ${x3 + l * 0.05},${yBot + h * 0.25} L ${x3},${yBot} `;
    cutLines += `L ${x2 + l * 0.9},${yBot + h * 0.25} L ${x2 + l * 0.1},${yBot + h * 0.25} L ${x2},${yBot} `;
    cutLines += `L ${x1 + w * 0.95},${yBot + h * 0.25} L ${x1 + w * 0.05},${yBot + h * 0.25} L ${x1},${yBot} `;
    cutLines += `L ${x0 + l * 0.9},${yBot + h * 0.25} L ${x0 + l * 0.1},${yBot + h * 0.25} L ${x0},${yBot} `;
    cutLines += `L 0,${yBot} Z `;
    // Ribbon slot cut-out on top front panel
    cutLines += `M ${x1 + w / 2 - ribbonSlot},${yTop - h * 0.15} L ${x1 + w / 2 + ribbonSlot},${yTop - h * 0.15} L ${x1 + w / 2 + ribbonSlot},${yTop - h * 0.08} L ${x1 + w / 2 - ribbonSlot},${yTop - h * 0.08} Z`;

    foldLines = `
      M ${x0},${yTop} L ${x0},${yBot}
      M ${x1},${yTop} L ${x1},${yBot}
      M ${x2},${yTop} L ${x2},${yBot}
      M ${x3},${yTop} L ${x3},${yBot}
      M ${x0},${yBot} L ${x0 + l},${yBot}
      M ${x1},${yBot} L ${x1 + w},${yBot}
      M ${x2},${yBot} L ${x2 + l},${yBot}
      M ${x3},${yBot} L ${x3 + l},${yBot}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + l / 2, yTop + h / 2, 'FRONT', `${l} mm`)}
      ${panelLabel(x1 + w / 2, yTop + h / 2, 'TOP', `${w} mm`)}
      ${panelLabel(x2 + l / 2, yTop + h / 2, 'BACK', `${l} mm`)}
      ${panelLabel(x3 + l / 2, yTop + h / 2, 'SIDE', `${l} mm`)}
      ${glueTabLabel(-gt * 0.15, yTop + h / 2)}`;

      dimAnnotations = `
      ${dimLine(x1, yTop, x1 + w, yTop, `${w}mm`, -8)}
      ${dimLine(x1 + w, yTop, x1 + w, yBot, `${h}mm`, 8)}`;
    }

    totalWidth = gt + l + w + l + l + gt;
    totalLength = h * 0.25 + h + h * 0.25;

  // ─── FRENCH FRY BOX ──────────────────────────────────────────────
  } else if (type === 'french_fry') {
    const gt = glueTab;
    const taperTop = l * 0.2;
    const frontExtra = h * 0.3;
    templateName = 'French Fry Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + w;
    const yBase = frontExtra;

    panelFills = `
      ${glueTabFill([[0, yBase + l * 0.15], [-gt * 0.3, yBase + l * 0.25], [-gt * 0.3, yBase + l * 0.75], [0, yBase + l * 0.85]])}
      ${polyFill([[x0, yBase], [x0 + taperTop, 0], [x1 - taperTop, 0], [x1, yBase], [x1, yBase + l], [x0, yBase + l]], C.base)}
      ${polyFill([[x1, yBase], [x1 + taperTop, 0], [x1 + w - taperTop, 0], [x1 + w, yBase], [x1 + w, yBase + l], [x1, yBase + l]], C.side)}
      ${pathFill(`M ${x0},${yBase + l} L ${x0 + w * 0.1},${yBase + l + h * 0.25} L ${x0 + w * 0.9},${yBase + l + h * 0.25} L ${x1},${yBase + l} Z`, C.flap)}
      ${pathFill(`M ${x1},${yBase + l} L ${x1 + w * 0.1},${yBase + l + h * 0.25} L ${x1 + w * 0.9},${yBase + l + h * 0.25} L ${x1 + w},${yBase + l} Z`, C.flap)}`;

    cutLines = `M 0,${yBase + l * 0.15} L ${-gt * 0.3},${yBase + l * 0.25} L ${-gt * 0.3},${yBase + l * 0.75} L 0,${yBase + l * 0.85} `;
    cutLines += `M 0,${yBase} L ${x0},${yBase} `;
    cutLines += `L ${x0 + taperTop},0 L ${x1 - taperTop},0 `;
    cutLines += `L ${x1 + taperTop},0 L ${x1 + w - taperTop},0 `;
    cutLines += `L ${x1 + w},${yBase} `;
    cutLines += `L ${x1 + w},${yBase + l} `;
    cutLines += `L ${x1 + w * 0.9},${yBase + l + h * 0.25} L ${x1 + w * 0.1},${yBase + l + h * 0.25} L ${x1},${yBase + l} `;
    cutLines += `L ${x0 + w * 0.9},${yBase + l + h * 0.25} L ${x0 + w * 0.1},${yBase + l + h * 0.25} L ${x0},${yBase + l} `;
    cutLines += `L 0,${yBase + l} Z`;

    foldLines = `
      M ${x0},${yBase} L ${x0},${yBase + l}
      M ${x1},${yBase} L ${x1},${yBase + l}
      M ${x0},${yBase + l} L ${x1},${yBase + l}
      M ${x1},${yBase + l} L ${x1 + w},${yBase + l}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + w / 2, yBase + l / 2, 'FRONT', `${w} mm`)}
      ${panelLabel(x1 + w / 2, yBase + l / 2, 'BACK', `${w} mm`)}
      ${glueTabLabel(-gt * 0.15, yBase + l / 2)}`;

      dimAnnotations = `
      ${dimLine(x0, yBase, x1, yBase, `${w}mm`, 8)}
      ${dimLine(x0, yBase, x0, yBase + l, `${l}mm`, -8)}`;
    }

    totalWidth = gt + w + w + gt;
    totalLength = frontExtra + l + h * 0.25;

  // ─── PIZZA BOX ────────────────────────────────────────────────────
  } else if (type === 'pizza_box') {
    const gt = glueTab;
    const cornerCut = l * 0.3;
    templateName = 'Pizza Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + l;
    const x2 = gt + l + w;
    const x3 = gt + l + w + l;
    const yTop = h;
    const yBot = h + h;

    panelFills = `
      ${glueTabFill([[0, yTop + h * 0.15], [-gt * 0.3, yTop + h * 0.25], [-gt * 0.3, yTop + h * 0.75], [0, yTop + h * 0.85]])}
      ${rectFill(x0, yTop, l, h, C.side)}
      ${rectFill(x1, yTop, w, h, C.base)}
      ${rectFill(x2, yTop, l, h, C.side)}
      ${rectFill(x3, yTop, l, h, C.base)}
      ${rectFill(x0, yBot, l, h, C.flap)}
      ${rectFill(x1, yBot, w, h, C.flap)}
      ${rectFill(x2, yBot, l, h, C.flap)}
      ${rectFill(x3, yBot, l, h, C.flap)}`;

    // V-shaped corner cuts for folding
    cutLines = `M 0,${yTop + h * 0.15} L ${-gt * 0.3},${yTop + h * 0.25} L ${-gt * 0.3},${yTop + h * 0.75} L 0,${yTop + h * 0.85} `;
    cutLines += `M 0,${yTop} L ${x0},${yTop} `;
    // Top edge with corner cuts for lid
    cutLines += `L ${x1},${yTop} L ${x2},${yTop} L ${x3},${yTop} L ${x3 + l},${yTop} `;
    cutLines += `L ${x3 + l},${yBot} `;
    cutLines += `L ${x3 + l},${yBot} L ${x3},${yBot} L ${x2},${yBot} L ${x1},${yBot} L ${x0},${yBot} `;
    cutLines += `L 0,${yBot} Z `;
    // V-shaped corner cuts (diagonal half-slits) at each corner of the lid
    cutLines += `M ${x1},${yTop} L ${x1 + cornerCut},${yTop - cornerCut * 0.5} L ${x1},${yBot} `;
    cutLines += `M ${x2},${yTop} L ${x2 - cornerCut},${yTop - cornerCut * 0.5} L ${x2},${yBot} `;
    cutLines += `M ${x3},${yTop} L ${x3 + cornerCut},${yTop - cornerCut * 0.5} L ${x3},${yBot} `;
    // Bottom corner cuts
    cutLines += `M ${x1},${yBot} L ${x1 + cornerCut},${yBot + cornerCut * 0.5} `;
    cutLines += `M ${x2},${yBot} L ${x2 - cornerCut},${yBot + cornerCut * 0.5} `;
    cutLines += `M ${x3},${yBot} L ${x3 + cornerCut},${yBot + cornerCut * 0.5} `;

    foldLines = `
      M ${x0},${yTop} L ${x0},${yBot}
      M ${x1},${yTop} L ${x1},${yBot}
      M ${x2},${yTop} L ${x2},${yBot}
      M ${x3},${yTop} L ${x3},${yBot}
      M ${x0},${yTop} L ${x0 + l},${yTop}
      M ${x1},${yTop} L ${x1 + w},${yTop}
      M ${x2},${yTop} L ${x2 + l},${yTop}
      M ${x3},${yTop} L ${x3 + l},${yTop}
      M ${x0},${yBot} L ${x0 + l},${yBot}
      M ${x1},${yBot} L ${x1 + w},${yBot}
      M ${x2},${yBot} L ${x2 + l},${yBot}
      M ${x3},${yBot} L ${x3 + l},${yBot}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x1 + w / 2, yTop + h / 2, 'LID', `${w} × ${l} mm`)}
      ${panelLabel(x0 + l / 2, yTop + h / 2, 'SIDE', `${l} mm`)}
      ${panelLabel(x2 + l / 2, yTop + h / 2, 'SIDE', `${l} mm`)}
      ${panelLabel(x1 + w / 2, yBot + h / 2, 'BASE', `${w} × ${l} mm`)}
      ${glueTabLabel(-gt * 0.15, yTop + h / 2)}`;

      dimAnnotations = `
      ${dimLine(x1, yTop, x1 + w, yTop, `${w}mm`, -8)}
      ${dimLine(x1 + w, yTop, x1 + w, yBot, `${h}mm`, 8)}`;
    }

    totalWidth = gt + l + w + l + l + gt;
    totalLength = h + h + cornerCut * 0.5;

  // ─── TAKEOUT / BURGER BOX ────────────────────────────────────────
  } else if (type === 'takeout') {
    const gt = glueTab;
    const curveR = w * 0.15;
    const tabW = w * 0.12;
    templateName = 'Takeout / Burger Box';
    dimText = `${w} × ${l} × ${h} mm`;

    const x0 = gt;
    const x1 = gt + w;
    const yMid = h * 0.5;
    const yTop = 0;
    const yBot = yMid + l;

    panelFills = `
      ${glueTabFill([[0, yMid * 0.2], [-gt * 0.3, yMid * 0.3], [-gt * 0.3, yMid * 0.7], [0, yMid * 0.8]])}
      ${pathFill(`M ${x0},${yMid} Q ${x0 + w * 0.3},${yTop - curveR} ${x0 + w / 2},${yTop - curveR} Q ${x0 + w * 0.7},${yTop - curveR} ${x1},${yMid} L ${x1},${yMid + l} Q ${x1 + w * 0.1},${yMid + l + h * 0.1} ${x1 + w * 0.5},${yMid + l} L ${x0},${yMid + l} Z`, C.base)}
      ${pathFill(`M ${x1},${yMid} Q ${x1 + w * 0.3},${yTop - curveR} ${x1 + w / 2},${yTop - curveR} Q ${x1 + w * 0.7},${yTop - curveR} ${x1 + w},${yMid} L ${x1 + w},${yMid + l} L ${x1},${yMid + l} Q ${x1 + w * 0.1},${yMid + l + h * 0.1} ${x1 + w * 0.5},${yMid + l} Z`, C.side)}
      ${pathFill(`M ${x0 + w / 2 - tabW},${yMid + l} L ${x0 + w / 2},${yMid + l + h * 0.3} L ${x0 + w / 2 + tabW},${yMid + l} Z`, C.flap)}`;

    cutLines = `M 0,${yMid * 0.2} L ${-gt * 0.3},${yMid * 0.3} L ${-gt * 0.3},${yMid * 0.7} L 0,${yMid * 0.8} `;
    cutLines += `M ${x0},${yMid} `;
    cutLines += `Q ${x0 + w * 0.3},${yTop - curveR} ${x0 + w / 2},${yTop - curveR} `;
    cutLines += `Q ${x0 + w * 0.7},${yTop - curveR} ${x1},${yMid} `;
    cutLines += `Q ${x1 + w * 0.3},${yTop - curveR} ${x1 + w / 2},${yTop - curveR} `;
    cutLines += `Q ${x1 + w * 0.7},${yTop - curveR} ${x1 + w},${yMid} `;
    cutLines += `L ${x1 + w},${yMid + l} `;
    cutLines += `L ${x1 + w / 2 + tabW},${yMid + l} L ${x1 + w / 2},${yMid + l + h * 0.3} L ${x1 + w / 2 - tabW},${yMid + l} `;
    cutLines += `L ${x1},${yMid + l} `;
    cutLines += `L ${x0},${yMid + l} Z`;

    foldLines = `
      M ${x0},${yMid} L ${x1},${yMid}
      M ${x0 + w / 2},${yTop - curveR} L ${x0 + w / 2},${yMid}
      M ${x0},${yMid + l} L ${x1 + w},${yMid + l}`;

    if (isStandard) {
      labels = `
      ${panelLabel(x0 + w / 2, yMid * 0.5 + (yTop - curveR) * 0.5, 'FRONT', `${w} mm`)}
      ${panelLabel(x1 + w / 2, yMid * 0.5 + (yTop - curveR) * 0.5, 'BACK', `${w} mm`)}
      ${glueTabLabel(-gt * 0.15, yMid / 2)}`;

      dimAnnotations = `
      ${dimLine(x0, yMid, x1, yMid, `${w}mm`, 8)}
      ${dimLine(x0, yMid, x0, yMid + l, `${l}mm`, -8)}`;
    }

    totalWidth = gt + w + w + gt;
    totalLength = curveR + l + h * 0.3;
  }

  // ─── Machine-specific colors ──────────────────────────────────────
  let cutColor = C.cutStd;
  let foldColor = C.foldStd;
  let foldDash = 'stroke-dasharray="6,3"';

  if (machine === 'laser') {
    cutColor = C.cutLaser;
    foldColor = C.foldLaser;
    foldDash = '';
  } else if (machine === 'cricut') {
    cutColor = C.cutCricut;
    foldColor = C.foldCricut;
    foldDash = 'stroke-dasharray="6,3"';
  } else if (machine === 'silhouette') {
    cutColor = C.cutSilh;
    foldColor = C.foldSilh;
    foldDash = 'stroke-dasharray="6,3"';
  }

  const margin = 15;
  const defs = generateDefs(isStandard);
  const bgGrid = generateBackgroundGrid(totalWidth, totalLength, margin);
  const regMarks = generateRegistrationMarks(totalWidth, totalLength, margin);
  const bleedZone = showBleed ? generateBleedZone(cutLines, totalWidth, totalLength) : '';
  const safeZone = showSafe ? generateSafeZone(foldLines, totalWidth, totalLength) : '';

  // Title block
  const titleBlock = isStandard ? `
    <g id="title-block">
      <rect x="${totalWidth - 38}" y="${totalLength + margin - 13}" width="55" height="14" fill="white" fill-opacity="0.9" stroke="#d4ccc2" stroke-width="0.4" rx="1.5" />
      <text x="${totalWidth - 35}" y="${totalLength + margin - 5}" font-size="3" font-family="'Segoe UI',system-ui,sans-serif" font-weight="700" fill="#4a433d" letter-spacing="0.3">ArtNew8 Studio</text>
      <text x="${totalWidth - 35}" y="${totalLength + margin - 1.5}" font-size="2.2" font-family="'Segoe UI',system-ui,sans-serif" fill="${C.labelDim}">${templateName} · ${dimText}</text>
    </g>` : '';

  // Legend (for standard mode)
  const legend = isStandard ? `
    <g id="legend" transform="translate(${-margin + 2}, ${totalLength + margin - 13})">
      <line x1="0" y1="3" x2="8" y2="3" stroke="${C.cutStd}" stroke-width="1.5" stroke-linecap="round" />
      <text x="9" y="4.5" font-size="2" font-family="'Segoe UI',system-ui,sans-serif" fill="${C.labelMain}">CUT</text>
      <line x1="0" y1="8" x2="8" y2="8" stroke="${C.foldStd}" stroke-width="1" stroke-dasharray="3,1.5" stroke-linecap="round" />
      <text x="9" y="9.5" font-size="2" font-family="'Segoe UI',system-ui,sans-serif" fill="${C.labelMain}">FOLD</text>
      <rect x="20" y="1" width="5" height="4" fill="${C.glue}" stroke="none" />
      <text x="26" y="4.5" font-size="2" font-family="'Segoe UI',system-ui,sans-serif" fill="${C.labelMain}">GLUE</text>
    </g>` : '';

  return `
    <svg viewBox="${-margin} ${-margin} ${totalWidth + margin * 2} ${totalLength + margin * 2}" xmlns="http://www.w3.org/2000/svg" class="w-full h-full" id="svg-template-export">
      ${defs}
      ${bgGrid}
      <g id="panel-fills">
      ${panelFills}
      </g>
      ${bleedZone}
      ${safeZone}
      <g id="cut-paths">
        <path d="${cutLines}" fill="none" stroke="${cutColor}" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round" />
      </g>
      <g id="score-paths">
        <path d="${foldLines}" fill="none" stroke="${foldColor}" stroke-width="1.0" ${foldDash} stroke-linejoin="round" stroke-linecap="round" />
      </g>
      ${isStandard ? `<g id="dimensions">${dimAnnotations}</g>` : ''}
      ${isStandard ? `<g id="labels">${labels}</g>` : ''}
      ${regMarks}
      ${titleBlock}
      ${legend}
    </svg>`;
}

/**
 * Generate a print-ready SVG with real mm dimensions for direct download
 */
export function generatePrintReadySvg(type: TemplateType, options: TemplateOptions): string {
  const regularSvg = generateTemplateSvg(type, options);
  const margin = 15;

  let totalWidth = 0;
  let totalLength = 0;
  const { width: w, length: l, height: h, glueTab } = options;

  if (type === 'box') {
    totalWidth = h + w + h + glueTab;
    totalLength = glueTab + l + glueTab;
  } else if (type === 'envelope') {
    const sideFlap = w * 0.4;
    const topFlap = l * 0.55;
    const bottomFlap = l * 0.4;
    totalWidth = sideFlap + w + sideFlap;
    totalLength = topFlap + l + bottomFlap;
  } else if (type === 'pillow') {
    const curveH = Math.min(h, w * 0.4);
    totalWidth = w + w;
    totalLength = curveH + l + curveH;
  } else if (type === 'mailer') {
    const gt = glueTab;
    const shortFlap = h * 0.7;
    const longFlap = h * 0.95;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = longFlap + shortFlap + h + shortFlap + h;
  } else if (type === 'milk_carton') {
    const gt = glueTab;
    const gableH = w * 0.45;
    const bottomFlap = w * 0.3;
    totalWidth = gt + w + l + w + l + gt;
    totalLength = gableH + h + bottomFlap + gableH;
  } else if (type === 'gable_box') {
    const gt = glueTab;
    const gableH = h * 0.55;
    const bottomFlap = w * 0.3;
    totalWidth = gt + w + l + w + l + gt;
    totalLength = gableH + h + bottomFlap + gableH;
  } else if (type === 'sleeve_box') {
    const gt = glueTab;
    const sleeveH = h * 0.35;
    const gap = 8;
    totalWidth = gt + l + w + l + gt;
    totalLength = sleeveH * 2 + w + sleeveH + gap + h * 0.4 + h + h * 0.4;
  } else if (type === 'pyramid') {
    const gt = glueTab;
    const halfBase = w / 2;
    const faceH = Math.sqrt(h * h + halfBase * halfBase);
    totalWidth = gt + w * 4 + gt;
    totalLength = faceH;
  } else if (type === 'hex_box') {
    const gt = glueTab;
    const sideLen = w / 2;
    const bottomFlap = sideLen * 0.5;
    const topFlap = sideLen * 0.5;
    totalWidth = gt + 6 * sideLen + gt;
    totalLength = topFlap + h + bottomFlap;
  } else if (type === 'tuck_end') {
    const gt = glueTab;
    const tuckFlap = h * 0.4;
    const autoLockH = h * 0.35;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = tuckFlap * 1.15 + h + autoLockH;
  } else if (type === 'cylinder') {
    const gt = glueTab;
    const circumference = Math.PI * w;
    const capR = w / 2;
    totalWidth = gt + circumference + gt;
    totalLength = capR * 1.2 + capR + h + capR * 1.2 + capR;
  } else if (type === 'display_box') {
    const gt = glueTab;
    const bottomFlap = w * 0.35;
    const topFlap = w * 0.3;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = topFlap + h + bottomFlap + topFlap * 0.5;
  } else if (type === 'reverse_tuck') {
    const gt = glueTab;
    const tuckFlap = h * 0.4;
    const tuckH = h * 0.35;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = tuckFlap * 1.15 + h + tuckH;
  } else if (type === 'auto_lock') {
    const gt = glueTab;
    const lockH = h * 0.45;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = h * 0.35 + h + lockH;
  } else if (type === 'window_box') {
    const gt = glueTab;
    const tuckH = h * 0.35;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = tuckH + h + tuckH;
  } else if (type === 'drawer_box') {
    const gt = glueTab;
    const sleeveH = h * 0.45;
    const gap = 10;
    const trayH = h * 0.75;
    totalWidth = gt + l + w + l + gt;
    totalLength = sleeveH * 0.35 + sleeveH + sleeveH * 0.35 + gap + trayH * 0.3 + trayH + trayH * 0.3;
  } else if (type === 'heart_box') {
    const gt = glueTab;
    const heartH = h * 1.2;
    totalWidth = gt + w + w + gt;
    totalLength = heartH;
  } else if (type === 'cone') {
    const gt = glueTab;
    const slantH = Math.sqrt(h * h + (w / 2) * (w / 2));
    const sectorAngle = (w / (2 * slantH)) * 360;
    const r = slantH;
    const halfAngle = (sectorAngle / 2) * Math.PI / 180;
    const cx = r + gt;
    const cy = r * 0.1;
    totalWidth = gt + r * Math.sin(halfAngle) * 2 + gt + r + w;
    totalLength = cy + r + w / 2;
  } else if (type === 'favor_box') {
    const gt = glueTab;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = h * 0.25 + h + h * 0.25;
  } else if (type === 'french_fry') {
    const gt = glueTab;
    const frontExtra = h * 0.3;
    totalWidth = gt + w + w + gt;
    totalLength = frontExtra + l + h * 0.25;
  } else if (type === 'pizza_box') {
    const gt = glueTab;
    const cornerCut = l * 0.3;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = h + h + cornerCut * 0.5;
  } else if (type === 'takeout') {
    const gt = glueTab;
    const curveR = w * 0.15;
    totalWidth = gt + w + w + gt;
    totalLength = curveR + l + h * 0.3;
  }

  const svgWidth = totalWidth + margin * 2;
  const svgHeight = totalLength + margin * 2;

  return regularSvg
    .replace(
      '<svg viewBox',
      `<svg width="${svgWidth}mm" height="${svgHeight}mm" viewBox`
    );
}

/**
 * Get template info for filename and display
 */
export function getTemplateInfo(type: TemplateType, options: TemplateOptions): TemplateInfo {
  const { width: w, length: l, height: h, glueTab } = options;

  let totalWidth = 0;
  let totalLength = 0;
  let templateName = '';
  let dimensions = '';

  if (type === 'box') {
    totalWidth = h + w + h + glueTab;
    totalLength = glueTab + l + glueTab;
    templateName = 'Tray_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'envelope') {
    const sideFlap = w * 0.4;
    const topFlap = l * 0.55;
    const bottomFlap = l * 0.4;
    totalWidth = sideFlap + w + sideFlap;
    totalLength = topFlap + l + bottomFlap;
    templateName = 'Envelope';
    dimensions = `${w}x${l}mm`;
  } else if (type === 'pillow') {
    const curveH = Math.min(h, w * 0.4);
    totalWidth = w + w;
    totalLength = curveH + l + curveH;
    templateName = 'Pillow_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'mailer') {
    const gt = glueTab;
    const shortFlap = h * 0.7;
    const longFlap = h * 0.95;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = longFlap + shortFlap + h + shortFlap + h;
    templateName = 'Mailer_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'milk_carton') {
    const gt = glueTab;
    const gableH = w * 0.45;
    const bottomFlap = w * 0.3;
    totalWidth = gt + w + l + w + l + gt;
    totalLength = gableH + h + bottomFlap + gableH;
    templateName = 'Milk_Carton';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'gable_box') {
    const gt = glueTab;
    const gableH = h * 0.55;
    const bottomFlap = w * 0.3;
    totalWidth = gt + w + l + w + l + gt;
    totalLength = gableH + h + bottomFlap + gableH;
    templateName = 'Gable_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'sleeve_box') {
    const gt = glueTab;
    const sleeveH = h * 0.35;
    const gap = 8;
    totalWidth = gt + l + w + l + gt;
    totalLength = sleeveH * 2 + w + sleeveH + gap + h * 0.4 + h + h * 0.4;
    templateName = 'Sleeve_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'pyramid') {
    const gt = glueTab;
    const halfBase = w / 2;
    const faceH = Math.sqrt(h * h + halfBase * halfBase);
    totalWidth = gt + w * 4 + gt;
    totalLength = faceH;
    templateName = 'Pyramid';
    dimensions = `${w}x${w}x${h}mm`;
  } else if (type === 'hex_box') {
    const gt = glueTab;
    const sideLen = w / 2;
    const bottomFlap = sideLen * 0.5;
    const topFlap = sideLen * 0.5;
    totalWidth = gt + 6 * sideLen + gt;
    totalLength = topFlap + h + bottomFlap;
    templateName = 'Hex_Box';
    dimensions = `${w}x${h}mm`;
  } else if (type === 'tuck_end') {
    const gt = glueTab;
    const tuckFlap = h * 0.4;
    const autoLockH = h * 0.35;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = tuckFlap * 1.15 + h + autoLockH;
    templateName = 'Tuck_End_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'cylinder') {
    const gt = glueTab;
    const circumference = Math.PI * w;
    const capR = w / 2;
    totalWidth = gt + circumference + gt;
    totalLength = capR * 1.2 + capR + h + capR * 1.2 + capR;
    templateName = 'Cylinder_Box';
    dimensions = `d${w}x${h}mm`;
  } else if (type === 'display_box') {
    const gt = glueTab;
    const bottomFlap = w * 0.35;
    const topFlap = w * 0.3;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = topFlap + h + bottomFlap + topFlap * 0.5;
    templateName = 'Display_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'reverse_tuck') {
    const gt = glueTab;
    const tuckFlap = h * 0.4;
    const tuckH = h * 0.35;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = tuckFlap * 1.15 + h + tuckH;
    templateName = 'Reverse_Tuck_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'auto_lock') {
    const gt = glueTab;
    const lockH = h * 0.45;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = h * 0.35 + h + lockH;
    templateName = 'Auto_Lock_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'window_box') {
    const gt = glueTab;
    const tuckH = h * 0.35;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = tuckH + h + tuckH;
    templateName = 'Window_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'drawer_box') {
    const gt = glueTab;
    const sleeveH = h * 0.45;
    const gap = 10;
    const trayH = h * 0.75;
    totalWidth = gt + l + w + l + gt;
    totalLength = sleeveH * 0.35 + sleeveH + sleeveH * 0.35 + gap + trayH * 0.3 + trayH + trayH * 0.3;
    templateName = 'Drawer_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'heart_box') {
    const gt = glueTab;
    const heartH = h * 1.2;
    totalWidth = gt + w + w + gt;
    totalLength = heartH;
    templateName = 'Heart_Box';
    dimensions = `${w}x${w}x${h}mm`;
  } else if (type === 'cone') {
    const gt = glueTab;
    const slantH = Math.sqrt(h * h + (w / 2) * (w / 2));
    const sectorAngle = (w / (2 * slantH)) * 360;
    const r = slantH;
    const halfAngle = (sectorAngle / 2) * Math.PI / 180;
    const cx = r + gt;
    const cy = r * 0.1;
    totalWidth = gt + r * Math.sin(halfAngle) * 2 + gt + r + w;
    totalLength = cy + r + w / 2;
    templateName = 'Cone';
    dimensions = `d${w}x${h}mm`;
  } else if (type === 'favor_box') {
    const gt = glueTab;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = h * 0.25 + h + h * 0.25;
    templateName = 'Favor_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'french_fry') {
    const gt = glueTab;
    const frontExtra = h * 0.3;
    totalWidth = gt + w + w + gt;
    totalLength = frontExtra + l + h * 0.25;
    templateName = 'French_Fry_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'pizza_box') {
    const gt = glueTab;
    const cornerCut = l * 0.3;
    totalWidth = gt + l + w + l + l + gt;
    totalLength = h + h + cornerCut * 0.5;
    templateName = 'Pizza_Box';
    dimensions = `${w}x${l}x${h}mm`;
  } else if (type === 'takeout') {
    const gt = glueTab;
    const curveR = w * 0.15;
    totalWidth = gt + w + w + gt;
    totalLength = curveR + l + h * 0.3;
    templateName = 'Takeout_Box';
    dimensions = `${w}x${l}x${h}mm`;
  }

  return { totalWidth, totalLength, templateName, dimensions };
}
