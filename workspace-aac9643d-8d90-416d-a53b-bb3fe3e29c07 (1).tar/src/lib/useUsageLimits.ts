'use client';

import { useState, useCallback } from 'react';

// Tool types that consume daily attempts
export type ToolType = 'ai_message' | 'ai_palette' | 'template_download' | 'pricing_download';

// Base daily limits per tool (total = 10)
const BASE_DAILY_LIMITS: Record<ToolType, number> = {
  ai_message: 3,           // AI message generation (expensive API call)
  ai_palette: 1,           // AI palette generation (API call)
  template_download: 5,    // Template file downloads (SVG/PDF/DXF/OBJ/PNG)
  pricing_download: 1,     // Pricing PDF downloads
};

// Donor gets 2x limits
const DONOR_MULTIPLIER = 2;

// Sharing incentive
const MAX_SHARES_PER_DAY = 5;
const BONUS_PER_SHARE = 2;

// Tool display names for UI
export const TOOL_LABELS: Record<ToolType, { en: string; ar: string; fr: string }> = {
  ai_message: { en: 'AI Message', ar: 'رسالة الذكاء الاصطناعي', fr: 'Message IA' },
  ai_palette: { en: 'AI Palette', ar: 'لوحة الذكاء الاصطناعي', fr: 'Palette IA' },
  template_download: { en: 'Template Download', ar: 'تنزيل القالب', fr: 'Téléchargement' },
  pricing_download: { en: 'Pricing Export', ar: 'تصدير الأسعار', fr: 'Export Prix' },
};

const STORAGE_KEY = 'artnew8_usage';
const DONOR_KEY = 'artnew8_donor';

interface UsageData {
  date: string;       // YYYY-MM-DD format
  usage: Record<ToolType, number>;
  sharesToday: number;  // number of shares recorded today
  bonusPool: number;    // accumulated bonus attempts
}

function getTodayStr(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

function createDefaultUsage(): UsageData {
  return {
    date: getTodayStr(),
    usage: { ai_message: 0, ai_palette: 0, template_download: 0, pricing_download: 0 },
    sharesToday: 0,
    bonusPool: 0,
  };
}

function loadUsage(): UsageData {
  if (typeof window === 'undefined') {
    return createDefaultUsage();
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createDefaultUsage();
    const data: UsageData = JSON.parse(raw);
    // Reset if different day
    if (data.date !== getTodayStr()) {
      return createDefaultUsage();
    }
    // Ensure sharesToday and bonusPool exist (migration from old format)
    if (data.sharesToday === undefined) data.sharesToday = 0;
    if (data.bonusPool === undefined) data.bonusPool = 0;
    return data;
  } catch {
    return createDefaultUsage();
  }
}

function saveUsage(data: UsageData) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function loadDonorStatus(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return localStorage.getItem(DONOR_KEY) === 'true';
  } catch {
    return false;
  }
}

function saveDonorStatus(isDonor: boolean) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(DONOR_KEY, isDonor ? 'true' : '');
  if (!isDonor) localStorage.removeItem(DONOR_KEY);
}

export function useUsageLimits() {
  // Use lazy initializer to read from localStorage on client, defaults on server
  const [usageData, setUsageData] = useState<UsageData>(loadUsage);
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [limitedTool, setLimitedTool] = useState<ToolType | null>(null);
  const [donorStatus, setDonorStatus] = useState<boolean>(loadDonorStatus);

  // Check and reset on date change
  const todayDate = getTodayStr();
  const isStale = usageData.date !== todayDate;

  // Recompute if stale (different day)
  const effectiveData = isStale
    ? { date: todayDate, usage: { ai_message: 0, ai_palette: 0, template_download: 0, pricing_download: 0 } as Record<ToolType, number>, sharesToday: 0, bonusPool: 0 }
    : usageData;

  // Reset stale data (different day)
  if (isStale && typeof window !== 'undefined') {
    const resetData = { date: todayDate, usage: { ai_message: 0, ai_palette: 0, template_download: 0, pricing_download: 0 } as Record<ToolType, number>, sharesToday: 0, bonusPool: 0 };
    setUsageData(resetData);
    saveUsage(resetData);
  }

  // Get effective limit for a tool (accounting for donor status)
  const getEffectiveLimit = useCallback((tool: ToolType): number => {
    const base = BASE_DAILY_LIMITS[tool];
    return donorStatus ? base * DONOR_MULTIPLIER : base;
  }, [donorStatus]);

  // Get remaining attempts for a tool (regular only)
  const getRemaining = useCallback((tool: ToolType): number => {
    const limit = getEffectiveLimit(tool);
    const used = effectiveData.usage[tool] || 0;
    return Math.max(0, limit - used);
  }, [effectiveData, getEffectiveLimit]);

  // Check if user can use a tool (considering regular + bonus pool)
  const canUse = useCallback((tool: ToolType): boolean => {
    return getRemaining(tool) > 0 || effectiveData.bonusPool > 0;
  }, [getRemaining, effectiveData]);

  // Consume an attempt for a tool
  const consumeAttempt = useCallback((tool: ToolType): boolean => {
    const remaining = getRemaining(tool);

    if (remaining > 0) {
      // Use regular limit first
      const newUsage = { ...effectiveData.usage, [tool]: (effectiveData.usage[tool] || 0) + 1 };
      const newData = { ...effectiveData, usage: newUsage };
      setUsageData(newData);
      saveUsage(newData);
      return true;
    }

    if (effectiveData.bonusPool > 0) {
      // Use bonus pool
      const newUsage = { ...effectiveData.usage, [tool]: (effectiveData.usage[tool] || 0) + 1 };
      const newData = { ...effectiveData, usage: newUsage, bonusPool: effectiveData.bonusPool - 1 };
      setUsageData(newData);
      saveUsage(newData);
      return true;
    }

    // No regular or bonus attempts left
    setLimitedTool(tool);
    setShowLimitModal(true);
    return false;
  }, [effectiveData, getRemaining]);

  // Get total AI remaining (for banner display)
  const getTotalAIRemaining = useCallback((): number => {
    return getRemaining('ai_message') + getRemaining('ai_palette');
  }, [getRemaining]);

  // Get total remaining (all tools combined, regular only)
  const getTotalRemaining = useCallback((): number => {
    return (Object.keys(BASE_DAILY_LIMITS) as ToolType[]).reduce(
      (total, tool) => total + getRemaining(tool), 0
    );
  }, [getRemaining]);

  // Get bonus attempts
  const getBonusAttempts = useCallback((): number => {
    return effectiveData.bonusPool;
  }, [effectiveData]);

  // Get total remaining including bonus
  const getTotalWithBonus = useCallback((): number => {
    return getTotalRemaining() + effectiveData.bonusPool;
  }, [getTotalRemaining, effectiveData]);

  // Share for bonus attempts
  const shareForBonus = useCallback((): boolean => {
    if (effectiveData.sharesToday >= MAX_SHARES_PER_DAY) {
      return false;
    }
    const newData = {
      ...effectiveData,
      sharesToday: effectiveData.sharesToday + 1,
      bonusPool: effectiveData.bonusPool + BONUS_PER_SHARE,
    };
    setUsageData(newData);
    saveUsage(newData);
    return true;
  }, [effectiveData]);

  // Mark as donor
  const markAsDonor = useCallback(() => {
    setDonorStatus(true);
    saveDonorStatus(true);
  }, []);

  // Is donor getter
  const isDonor = useCallback((): boolean => {
    return donorStatus;
  }, [donorStatus]);

  // Close limit modal
  const closeLimitModal = useCallback(() => {
    setShowLimitModal(false);
    setLimitedTool(null);
  }, []);

  return {
    usageData,
    canUse,
    consumeAttempt,
    getRemaining,
    getTotalAIRemaining,
    getTotalRemaining,
    getBonusAttempts,
    getTotalWithBonus,
    shareForBonus,
    markAsDonor,
    isDonor,
    showLimitModal,
    limitedTool,
    closeLimitModal,
    dailyLimits: BASE_DAILY_LIMITS,
    getEffectiveLimit,
  };
}
