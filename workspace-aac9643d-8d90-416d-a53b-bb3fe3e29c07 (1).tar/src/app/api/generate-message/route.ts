import { NextRequest, NextResponse } from 'next/server';

// System prompts in different languages for better quality output
const SYSTEM_PROMPTS: Record<string, string> = {
  Arabic: 'أنت كاتب إبداعي متخصص في كتابة رسائل بطاقات المعايدة. اكتب رسائل جميلة ومؤثرة وملهمة لبطاقات المصنوعة يدوياً. يجب أن تكون الرسالة باللغة العربية الفصحى، بأسلوب أدبي راقٍ ومشاعر صادقة. أخرج نص الرسالة فقط بدون أي شرح أو مقدمات أو علامات تنصيص.',
  French: 'Vous êtes un écrivain créatif spécialisé dans les messages de cartes de vœux. Écrivez de beaux messages sincères et inspirants pour des cartes faites main. Produisez uniquement le texte du message, sans explication ni introduction ni guillemets.',
  Spanish: 'Eres un escritor creativo especializado en mensajes de tarjetas de felicitación. Escribe mensajes hermosos, sinceros e inspiradores para tarjetas hechas a mano. Produce solo el texto del mensaje, sin explicaciones ni introducciones ni comillas.',
  German: 'Sie sind ein kreativer Schriftsteller, der auf Grußkartenbotschaften spezialisiert ist. Schreiben Sie schöne, herzliche und inspirierende Botschaften für handgefertigte Karten. Geben Sie nur den Nachrichtentext aus, ohne Erklärungen, Einleitungen oder Anführungszeichen.',
  Italian: 'Sei uno scrittore creativo specializzato in messaggi di biglietti d\'auguri. Scrivi messaggi belli, sentiti e ispiratori per biglietti fatti a mano. Produci solo il testo del messaggio, senza spiegazioni, introduzioni o virgolette.',
  English: 'You are a creative greeting card writer. Write beautiful, heartfelt messages for handmade cards. Output only the message text, nothing else.',
};

// Prompt templates in different languages for more natural instructions
const PROMPT_TEMPLATES: Record<string, string> = {
  Arabic: 'اكتب رسالة بطاقة معايدة جميلة واحترافية لمناسبة {occasion}. المستلم هو {recipient}، والنبرة يجب أن تكون {tone}. طول الرسالة المطلوب: {length}.{context} حافظ على الرسالة إبداعية ودافئة ومناسبة لبطاقة ورقية مصنوعة يدوياً. أخرج نص الرسالة فقط.',
  French: 'Écrivez un beau message de carte de vœux professionnel pour {occasion}. Le destinataire est {recipient}, et le ton doit être {tone}. La longueur souhaitée est {length}.{context} Gardez-le créatif, chaleureux et adapté à une carte en papier fait main. Produisez uniquement le texte du message.',
  Spanish: 'Escribe un hermoso mensaje profesional de tarjeta de felicitación para {occasion}. El destinatario es {recipient}, y el tono debe ser {tone}. La longitud deseada es {length}.{context} Mantenlo creativo, cálido y adecuado para una tarjeta de papel hecha a mano. Produce solo el texto del mensaje.',
  German: 'Schreiben Sie eine schöne, professionelle Grußkartenbotschaft für {occasion}. Der Empfänger ist {recipient}, und der Ton soll {tone} sein. Die gewünschte Länge ist {length}.{context} Halten Sie es kreativ, herzlich und passend für eine handgefertigte Papierkarte. Geben Sie nur den Nachrichtentext aus.',
  Italian: 'Scrivi un bellissimo messaggio professionale per un biglietto d\'auguri per {occasion}. Il destinatario è {recipient}, e il tono deve essere {tone}. La lunghezza desiderata è {length}.{context} Mantienilo creativo, caloroso e adatto a un biglietto di carta fatto a mano. Produci solo il testo del messaggio.',
  English: 'Write a beautiful, professional greeting card message for {occasion}. The recipient is {recipient}, and the tone should be {tone}. The desired length is {length}.{context} Keep it creative, warm, and suitable for a handmade paper craft card. Provide only the message text, no quotes or intro or explanation.',
};

export async function POST(request: NextRequest) {
  try {
    const { occasion, recipient, tone, language, length, context } = await request.json();

    if (!occasion || !recipient || !tone) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const langKey = language || 'English';

    const ZAI = await import('z-ai-web-dev-sdk').then(m => m.default);
    const zai = await ZAI.create();

    // Use language-appropriate system prompt and user prompt
    const systemPrompt = SYSTEM_PROMPTS[langKey] || SYSTEM_PROMPTS['English'];
    const promptTemplate = PROMPT_TEMPLATES[langKey] || PROMPT_TEMPLATES['English'];

    const contextStr = context ? ` ${langKey === 'Arabic' ? `أضف هذه التفاصيل المحددة: ${context}.` : langKey === 'French' ? `Incluez ces détails spécifiques: ${context}.` : langKey === 'Spanish' ? `Incluya estos detalles específicos: ${context}.` : langKey === 'German' ? `Schließen Sie diese spezifischen Details ein: ${context}.` : langKey === 'Italian' ? `Includi questi dettagli specifici: ${context}.` : `Include these specific details: ${context}.`}` : '';

    const prompt = promptTemplate
      .replace('{occasion}', occasion)
      .replace('{recipient}', recipient)
      .replace('{tone}', tone)
      .replace('{length}', length || 'Medium')
      .replace('{context}', contextStr);

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: prompt }
      ],
      thinking: { type: 'disabled' }
    });

    const message = completion.choices?.[0]?.message?.content || (langKey === 'Arabic' ? 'تعذر توليد الرسالة. يرجى المحاولة مرة أخرى.' : 'Could not generate message. Please try again.');

    return NextResponse.json({ message });
  } catch (error: any) {
    console.error('AI Message Error:', error);
    return NextResponse.json(
      { error: 'Failed to generate message. Please try again.', message: 'Failed to generate message. Please try again later.' },
      { status: 500 }
    );
  }
}
