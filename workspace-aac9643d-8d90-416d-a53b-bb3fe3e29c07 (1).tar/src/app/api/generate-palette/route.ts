import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { style } = await request.json();

    const ZAI = await import('z-ai-web-dev-sdk').then(m => m.default);
    const zai = await ZAI.create();

    const prompt = `Generate a beautiful color palette of 5 hex colors suitable for paper crafting and cardstock pairing. ${style ? `The style should be inspired by: ${style}.` : ''} Return ONLY a JSON object with "name" (a creative palette name) and "colors" (array of 5 hex color strings). No markdown, no explanation, just the JSON. Example: {"name": "Sunset Glow", "colors": ["#ff6b6b", "#ffa07a", "#ffd700", "#98d8c8", "#6c5ce7"]}`;

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: 'You are a color palette designer for paper crafts. Always respond with valid JSON only, no markdown formatting.' },
        { role: 'user', content: prompt }
      ],
      thinking: { type: 'disabled' }
    });

    let responseText = completion.choices?.[0]?.message?.content || '';

    // Clean up response - remove markdown code blocks if present
    responseText = responseText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();

    try {
      const parsed = JSON.parse(responseText);
      if (parsed.colors && Array.isArray(parsed.colors)) {
        return NextResponse.json({ name: parsed.name || 'AI Generated', colors: parsed.colors.slice(0, 5) });
      }
    } catch {
      // If parsing fails, generate a random palette
    }

    // Fallback: generate a random harmonious palette
    const hue = Math.floor(Math.random() * 360);
    const colors = [
      hslToHex(hue, 70, 60),
      hslToHex(hue + 30, 60, 70),
      hslToHex(hue + 60, 50, 80),
      hslToHex(hue + 180, 40, 50),
      hslToHex(hue + 210, 60, 40),
    ];
    return NextResponse.json({ name: 'AI Generated', colors });
  } catch (error) {
    console.error('AI Palette Error:', error);
    // Return a fallback palette
    return NextResponse.json({
      name: 'AI Generated',
      colors: ['#e07a5f', '#3d405b', '#81b29a', '#f2cc8f', '#f4f1de']
    });
  }
}

function hslToHex(h: number, s: number, l: number): string {
  h = ((h % 360) + 360) % 360;
  s /= 100;
  l /= 100;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color).toString(16).padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}
