'use client';

import React, { useState, useEffect } from 'react';
import { TemplateMaker } from '@/components/tools/TemplateMaker';
import { PricingCalculator } from '@/components/tools/PricingCalculator';
import { MessageGenerator } from '@/components/tools/MessageGenerator';
import { ColorPalette } from '@/components/tools/ColorPalette';
import { VisionPanel } from '@/components/tools/VisionPanel';
import { Language, t as translate, isRTL } from '@/lib/i18n';
import { useUsageLimits, ToolType, TOOL_LABELS } from '@/lib/useUsageLimits';
import { ShareButtons } from '@/components/tools/ShareButtons';
import {
  BoxSelect,
  Calculator,
  HeartHandshake,
  Scissors,
  MessageSquareHeart,
  Palette,
  Store,
  Globe,
  Heart,
  X,
  Menu,
  AlertTriangle,
  ExternalLink,
  Zap,
  RefreshCw,
  Share2,
  Clock,
  MessageCircle,
  Mail,
  Info,
  Gift,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

type ActiveTab = 'template' | 'pricing' | 'messages' | 'colors' | 'vision';

export default function Home() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('template');
  const [language, setLanguage] = useState<Language>('en');
  const [mounted, setMounted] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Real usage limits system
  const {
    canUse,
    consumeAttempt,
    getRemaining,
    getTotalRemaining,
    getTotalWithBonus,
    getBonusAttempts,
    shareForBonus,
    markAsDonor,
    isDonor,
    showLimitModal,
    limitedTool,
    closeLimitModal,
    dailyLimits,
    getEffectiveLimit,
  } = useUsageLimits();

  // Share feedback state
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  // Countdown to midnight for limit reset
  const [countdown, setCountdown] = useState('');

  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      const midnight = new Date(now);
      midnight.setHours(24, 0, 0, 0);
      const diff = midnight.getTime() - now.getTime();
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const hStr = language === 'ar' ? 'س' : language === 'fr' ? 'h' : 'h';
      const mStr = language === 'ar' ? 'د' : 'm';
      setCountdown(`${hours}${hStr} ${minutes}${mStr}`);
    };
    updateCountdown();
    const interval = setInterval(updateCountdown, 60000);
    return () => clearInterval(interval);
  }, [language]);

  // Load language from localStorage on mount (avoids hydration mismatch)
  useEffect(() => {
    try {
      const savedLang = localStorage.getItem('artnew8_lang') as Language | null;
      if (savedLang && ['en', 'ar', 'fr'].includes(savedLang)) {
        // eslint-disable-next-line react-hooks/set-state-in-effect -- Necessary to sync locale from localStorage after hydration
        setLanguage(savedLang);
      }
    } catch {}
    setMounted(true);
  }, []);

  // Save language to localStorage and update HTML attributes
  useEffect(() => {
    if (!mounted) return;
    localStorage.setItem('artnew8_lang', language);
    const htmlEl = document.documentElement;
    htmlEl.lang = language;
    htmlEl.dir = isRTL(language) ? 'rtl' : 'ltr';
  }, [language, mounted]);

  const t = (key: string) => translate(language, key);
  const rtl = isRTL(language);

  const totalRemaining = getTotalWithBonus();

  const navItems = [
    { id: 'template' as ActiveTab, icon: <BoxSelect size={20} />, label: t('nav_template'), shortLabel: t('mob_template') },
    { id: 'pricing' as ActiveTab, icon: <Calculator size={20} />, label: t('nav_pricing'), shortLabel: t('mob_pricing') },
    { id: 'messages' as ActiveTab, icon: <MessageSquareHeart size={20} />, label: t('nav_messages'), shortLabel: t('mob_messages') },
    { id: 'colors' as ActiveTab, icon: <Palette size={20} />, label: t('nav_colors'), shortLabel: t('mob_colors') },
  ];

  // Get the tool name for the limit modal
  const getToolName = (tool: ToolType | null): string => {
    if (!tool) return '';
    return TOOL_LABELS[tool][language] || TOOL_LABELS[tool].en;
  };

  // Get tool limit key for i18n
  const getToolLimitKey = (tool: ToolType | null): string => {
    if (!tool) return '';
    const map: Record<ToolType, string> = {
      ai_message: 'limit_ai_message',
      ai_palette: 'limit_ai_palette',
      template_download: 'limit_template_download',
      pricing_download: 'limit_pricing_download',
    };
    return t(map[tool]);
  };

  return (
    <div className={`min-h-screen flex flex-col bg-background font-sans selection:bg-brand-200 ${mounted && rtl ? 'rtl' : 'ltr'}`} dir={mounted && rtl ? 'rtl' : 'ltr'} suppressHydrationWarning>
      {/* Donation Banner with Real Usage Counter */}
      <div className="bg-sage-900 text-white px-3 py-2 sm:px-6 lg:px-8 text-center text-xs sm:text-sm font-medium flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-6 shadow-md z-20 relative">
        <span className="flex items-center gap-2 flex-wrap justify-center">
          <Heart size={14} className="text-brand-400 animate-pulse" />
          <span className="text-sage-100">{t('donation_text')}<strong className="text-white px-1 font-bold bg-white/10 rounded-md py-0.5 mx-1">{mounted ? totalRemaining : '–'}</strong>{getBonusAttempts() > 0 && mounted ? <span className="text-emerald-300 text-[10px] ms-1">(+{getBonusAttempts()} {t('bonus_attempts').toLowerCase()})</span> : null}{t('generations_left')}</span>
        </span>
        <a href="https://www.paypal.com/ncp/payment/7TUYHE9XTU6AG" target="_blank" rel="noopener noreferrer"
          className="inline-flex py-1 px-4 sm:py-1.5 sm:px-5 bg-brand-500 hover:bg-brand-600 rounded-full text-white text-[10px] sm:text-xs font-bold transition-colors shadow-sm">
          {t('donation_btn')}
        </a>
      </div>

      {/* Header */}
      <header className="glass-panel sticky top-0 z-30 w-full px-3 sm:px-6 lg:px-8 shadow-sm">
        <div className="max-w-[90rem] mx-auto flex items-center justify-between h-14 sm:h-20 transition-all">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <div className="w-9 h-9 sm:w-12 sm:h-12 bg-sage-800 rounded-xl flex items-center justify-center text-white shadow-md transform transition hover:scale-105 shrink-0">
              <Scissors size={18} className="text-brand-300 sm:w-5 sm:h-5" />
            </div>
            <h1 className="text-xl sm:text-3xl font-display font-black tracking-tight text-brand-600 truncate">
              {t('app_title')}
              <span className="font-sans font-medium text-sage-500 hidden sm:inline ms-2 text-lg">{t('app_subtitle')}</span>
            </h1>
          </div>

          <nav className="flex items-center gap-2 sm:gap-4 rtl:gap-2 shrink-0">
            <div className="relative group flex items-center">
              <Globe size={16} className={`text-sage-500 absolute pointer-events-none group-hover:text-brand-500 transition-colors ${rtl ? 'right-2.5' : 'left-2.5'}`} />
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className={`${rtl ? 'pr-7 pl-6' : 'pl-7 pr-6'} py-1.5 sm:py-2 appearance-none bg-white/50 hover:bg-white border border-sage-200 text-sage-600 font-bold rounded-full text-[10px] sm:text-xs outline-none cursor-pointer focus:ring-2 focus:ring-brand-200 transition-all text-center`}
              >
                <option value="en">EN</option>
                <option value="ar">عربي</option>
                <option value="fr">FR</option>
              </select>
            </div>

            <button
              onClick={() => setActiveTab('vision')}
              className={`hidden sm:flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-2.5 rounded-full bg-brand-50 text-brand-600 font-bold hover:bg-brand-100 transition-all border border-brand-200/50 hover:shadow-sm text-sm`}
            >
              <Store size={18} />
              <span className="hidden md:inline">{t('nav_marketplace')}</span>
            </button>

            {/* Mobile menu toggle */}
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden p-2 text-sage-600 hover:text-brand-500">
              <Menu size={22} />
            </button>
          </nav>
        </div>
      </header>

      <div className="flex-1 flex max-w-[90rem] w-full mx-auto relative">
        {/* Sidebar Nav - Desktop */}
        <aside className={`w-72 hidden md:flex flex-col border-sage-200/60 bg-white/30 backdrop-blur-md min-h-[calc(100vh-5rem)] py-8 px-5 relative shrink-0 ${rtl ? 'border-l' : 'border-r'}`}>
          <nav className="space-y-3 sticky top-28">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl font-bold transition-all duration-300 ${
                  activeTab === item.id
                    ? 'bg-sage-800 text-white shadow-lg scale-105 origin-left rtl:origin-right'
                    : 'text-sage-600 hover:bg-white hover:text-sage-900 border border-transparent hover:border-sage-200/50 shadow-sm'
                }`}
              >
                <span className={activeTab === item.id ? 'text-brand-300' : 'text-sage-400'}>{item.icon}</span>
                {item.label}
              </button>
            ))}

            {/* Usage Stats in Sidebar */}
            <div className={`pt-6 mt-4 border-t border-sage-200/60 space-y-2`}>
              <h4 className="text-[10px] font-bold text-sage-400 uppercase tracking-widest px-5 flex items-center gap-1.5">
                <Zap size={10} /> {language === 'ar' ? 'المحاولات المتبقية' : language === 'fr' ? 'Tentatives Restantes' : 'Attempts Left'}
              </h4>
              {([
                { tool: 'ai_message' as ToolType, icon: <MessageSquareHeart size={12} />, labelKey: 'limit_ai_message' },
                { tool: 'ai_palette' as ToolType, icon: <Palette size={12} />, labelKey: 'limit_ai_palette' },
                { tool: 'template_download' as ToolType, icon: <BoxSelect size={12} />, labelKey: 'limit_template_download' },
                { tool: 'pricing_download' as ToolType, icon: <Calculator size={12} />, labelKey: 'limit_pricing_download' },
              ]).map(({ tool, icon, labelKey }) => {
                const remaining = getRemaining(tool);
                const limit = getEffectiveLimit(tool);
                const pct = (remaining / limit) * 100;
                const isLow = remaining <= 1;
                return (
                  <div key={tool} className="px-5 py-2">
                    <div className="flex items-center justify-between text-[10px] mb-1">
                      <span className={`flex items-center gap-1 font-medium ${isLow ? 'text-amber-600' : 'text-sage-500'}`}>
                        {icon} {t(labelKey)}
                      </span>
                      <span className={`font-bold ${isLow ? 'text-amber-600' : 'text-sage-700'}`}>
                        {remaining}/{limit}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-sage-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${isLow ? 'bg-amber-500' : remaining === 0 ? 'bg-red-400' : 'bg-brand-400'}`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
              {/* Bonus attempts indicator */}
              {getBonusAttempts() > 0 && (
                <div className="px-5 py-2">
                  <div className="flex items-center gap-1.5 text-[10px] font-medium text-emerald-600">
                    <Sparkles size={12} /> {t('bonus_attempts')}: +{getBonusAttempts()}
                  </div>
                </div>
              )}
            </div>

            <div className={`pt-4 mt-4 border-t border-sage-200/60 space-y-2`}>
              <button
                onClick={() => setActiveTab('vision')}
                className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl font-bold transition-all duration-300 ${
                  activeTab === 'vision'
                    ? 'bg-gradient-to-r from-brand-400 to-brand-500 text-white shadow-lg scale-105 origin-left rtl:origin-right'
                    : 'bg-brand-50/50 text-brand-600 hover:bg-brand-50 border border-brand-100 hover:shadow-sm'
                }`}
              >
                <HeartHandshake size={22} className={activeTab === 'vision' ? 'text-white' : 'text-brand-500'} />
                {t('nav_vision')}
              </button>
            </div>
          </nav>
        </aside>

        {/* Mobile Nav Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-50 bg-black/50" onClick={() => setMobileMenuOpen(false)}>
            <div className={`absolute ${rtl ? 'left-0' : 'right-0'} top-0 h-full w-64 bg-white shadow-xl p-6 space-y-3`} onClick={(e) => e.stopPropagation()}>
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-sage-800">{language === 'ar' ? 'القائمة' : 'Menu'}</h3>
                <button onClick={() => setMobileMenuOpen(false)} className="p-2 hover:bg-sage-100 rounded-lg">
                  <X size={20} />
                </button>
              </div>
              {navItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl font-bold transition-all ${
                    activeTab === item.id ? 'bg-sage-800 text-white' : 'text-sage-600 hover:bg-sage-50'
                  }`}
                >
                  {item.icon} {item.label}
                </button>
              ))}
              <div className="border-t border-sage-200 pt-3 mt-3">
                <button
                  onClick={() => { setActiveTab('vision'); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl font-bold transition-all ${
                    activeTab === 'vision' ? 'bg-brand-500 text-white' : 'text-brand-600 hover:bg-brand-50'
                  }`}
                >
                  <HeartHandshake size={20} /> {t('nav_vision')}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 p-3 sm:p-6 lg:p-12 w-full mx-auto min-w-0 flex flex-col items-center pb-20 md:pb-0">
          {/* View Rendering */}
          <div className="w-full max-w-7xl">
            {activeTab === 'template' && <TemplateMaker lang={language} t={t} canUse={canUse} consumeAttempt={consumeAttempt} getRemaining={getRemaining} />}
            {activeTab === 'pricing' && <PricingCalculator lang={language} t={t} canUse={canUse} consumeAttempt={consumeAttempt} getRemaining={getRemaining} />}
            {activeTab === 'messages' && <MessageGenerator lang={language} t={t} canUse={canUse} consumeAttempt={consumeAttempt} getRemaining={getRemaining} />}
            {activeTab === 'colors' && <ColorPalette lang={language} t={t} canUse={canUse} consumeAttempt={consumeAttempt} getRemaining={getRemaining} />}
            {activeTab === 'vision' && <VisionPanel lang={language} t={t} />}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation - Sticky */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-sage-200/60 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] safe-area-bottom">
        <div className="flex items-center justify-around px-1 py-1">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center gap-0.5 py-2 px-2.5 rounded-xl min-w-[56px] transition-all ${
                activeTab === item.id
                  ? 'text-brand-600'
                  : 'text-sage-400 active:text-sage-600'
              }`}
            >
              <span className={activeTab === item.id ? 'text-brand-600' : ''}>{item.icon}</span>
              <span className={`text-[9px] font-bold leading-tight ${activeTab === item.id ? 'text-brand-600' : ''}`}>
                {item.shortLabel}
              </span>
            </button>
          ))}
          <button
            onClick={() => setActiveTab('vision')}
            className={`flex flex-col items-center justify-center gap-0.5 py-2 px-2.5 rounded-xl min-w-[56px] transition-all ${
              activeTab === 'vision'
                ? 'text-brand-600'
                : 'text-sage-400 active:text-sage-600'
            }`}
          >
            <HeartHandshake size={20} />
            <span className={`text-[9px] font-bold leading-tight ${activeTab === 'vision' ? 'text-brand-600' : ''}`}>
              {t('mob_vision')}
            </span>
          </button>
        </div>
      </nav>

      {/* Footer - Desktop only */}
      <footer className="hidden md:block mt-auto bg-sage-900 text-sage-300 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[90rem] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Scissors size={16} className="text-brand-400" />
            <span className="font-display font-bold text-white">{t('app_title')}</span>
            <span>{t('app_subtitle')}</span>
          </div>
          <p className="text-sage-400 text-xs">{t('support_desc')}</p>
        </div>
      </footer>

      {/* Limit Reached Modal */}
      {showLimitModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={closeLimitModal}>
          <div
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden animate-in zoom-in-95 duration-300"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header with gradient */}
            <div className="bg-gradient-to-br from-amber-500 to-orange-600 p-6 text-white text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-xl" />
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2 blur-xl" />
              <div className="relative z-10">
                <div className="inline-flex p-3 bg-white/20 rounded-full mb-3">
                  <AlertTriangle size={28} />
                </div>
                <h3 className="text-xl font-display font-bold">{t('limit_reached')}</h3>
                <p className="text-white/80 text-sm mt-1">
                  {t('limit_reached_desc').replace('{tool}', getToolLimitKey(limitedTool))}
                </p>
              </div>
            </div>

            {/* Body */}
            <div className="p-6 space-y-4">
              {/* Usage breakdown */}
              <div className="bg-slate-50 rounded-2xl p-4 space-y-2">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
                  <Zap size={12} /> {t('limit_all_tools')}
                </h4>
                {([
                  { tool: 'ai_message' as ToolType, labelKey: 'limit_ai_message' },
                  { tool: 'ai_palette' as ToolType, labelKey: 'limit_ai_palette' },
                  { tool: 'template_download' as ToolType, labelKey: 'limit_template_download' },
                  { tool: 'pricing_download' as ToolType, labelKey: 'limit_pricing_download' },
                ]).map(({ tool, labelKey }) => {
                  const remaining = getRemaining(tool);
                  const limit = getEffectiveLimit(tool);
                  const isCurrentTool = tool === limitedTool;
                  return (
                    <div key={tool} className={`flex items-center justify-between py-1.5 px-3 rounded-lg ${isCurrentTool ? 'bg-amber-50 ring-1 ring-amber-200' : ''}`}>
                      <span className={`text-xs font-medium ${isCurrentTool ? 'text-amber-700' : 'text-slate-500'}`}>
                        {t(labelKey)}
                      </span>
                      <span className={`text-xs font-bold ${remaining === 0 ? 'text-red-500' : remaining <= 1 ? 'text-amber-500' : 'text-slate-700'}`}>
                        {remaining}/{limit}
                      </span>
                    </div>
                  );
                })}
              {/* Bonus attempts in modal */}
              {getBonusAttempts() > 0 && (
                <div className="flex items-center justify-between py-1.5 px-3 rounded-lg bg-emerald-50">
                  <span className="text-xs font-medium text-emerald-700 flex items-center gap-1.5">
                    <Sparkles size={12} /> {t('bonus_attempts')}
                  </span>
                  <span className="text-xs font-bold text-emerald-600">+{getBonusAttempts()}</span>
                </div>
              )}
              </div>

              {/* Countdown to reset */}
              <div className="flex items-center justify-center gap-2 bg-slate-100 rounded-xl py-2.5 px-4">
                <Clock size={14} className="text-brand-500" />
                <span className="text-sm font-bold text-slate-700">
                  {t('limit_countdown').replace('{time}', countdown)}
                </span>
              </div>

              {/* Why donate section */}
              <div className="bg-amber-50 rounded-xl p-3.5 border border-amber-200/60">
                <h4 className="font-bold text-amber-800 text-xs flex items-center gap-1.5 mb-1.5">
                  <Info size={13} className="text-amber-600" /> {t('limit_why_donate')}
                </h4>
                <p className="text-amber-700 text-[11px] leading-relaxed">{t('limit_why_desc')}</p>
              </div>

              {/* Donate CTA - Primary action - BIGGER and pulsing */}
              <div className="bg-gradient-to-br from-brand-500 to-brand-600 rounded-2xl p-6 text-white text-center relative overflow-hidden">
                <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-lg" />
                <div className="absolute bottom-0 left-0 w-16 h-16 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2 blur-lg" />
                <div className="relative z-10">
                  <Heart size={28} className="mx-auto mb-2 text-white/90 animate-pulse" />
                  <h4 className="font-bold text-xl mb-1.5">{t('limit_donate_cta')}</h4>
                  <p className="text-white/80 text-xs leading-relaxed mb-5">{t('limit_donate_desc')}</p>
                  <a
                    href="https://www.paypal.com/ncp/payment/7TUYHE9XTU6AG"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2.5 bg-white text-brand-600 py-4 px-10 rounded-full font-extrabold text-base transition-all shadow-lg hover:shadow-xl hover:scale-110 active:scale-95 animate-pulse"
                    style={{ animationDuration: '2s' }}
                  >
                    {t('limit_pay_now')} <ExternalLink size={18} />
                  </a>
                </div>
              </div>

              {/* Share for Bonus Section */}
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-4 border border-emerald-100">
                <h4 className="font-bold text-slate-700 text-sm mb-1 flex items-center gap-1.5">
                  <Gift size={14} className="text-emerald-500" /> {t('share_for_attempts')}
                </h4>
                <p className="text-slate-500 text-xs leading-relaxed mb-3">{t('limit_share_desc')}</p>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      const success = shareForBonus();
                      if (success) {
                        setShareFeedback('success');
                        setTimeout(() => setShareFeedback(null), 3000);
                      } else {
                        setShareFeedback('limit');
                        setTimeout(() => setShareFeedback(null), 3000);
                      }
                    }}
                    className="flex-1 inline-flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white py-2.5 px-4 rounded-xl font-bold text-sm transition-colors shadow-sm"
                  >
                    {shareFeedback === 'success' ? (
                      <><CheckCircle2 size={16} /> {t('share_success')}</>
                    ) : shareFeedback === 'limit' ? (
                      <><AlertTriangle size={16} /> {t('share_limit_reached')}</>
                    ) : (
                      <><Share2 size={16} /> {t('share_for_attempts')}</>
                    )}
                  </button>
                  <ShareButtons lang={language} t={t} variant="default" />
                </div>
              </div>

              {/* Donor Status Section */}
              {!isDonor() ? (
                <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-4 border border-amber-100">
                  <h4 className="font-bold text-slate-700 text-sm mb-1 flex items-center gap-1.5">
                    <Heart size={14} className="text-amber-500" /> {t('donor_status')}
                  </h4>
                  <p className="text-slate-500 text-xs leading-relaxed mb-3">{t('donor_benefits')}</p>
                  <button
                    onClick={() => {
                      markAsDonor();
                    }}
                    className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-white py-2.5 px-5 rounded-xl font-bold text-sm transition-colors shadow-sm"
                  >
                    <Heart size={16} /> {t('mark_donor')}
                  </button>
                </div>
              ) : (
                <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-4 border border-amber-200">
                  <div className="flex items-center gap-2 text-amber-700">
                    <CheckCircle2 size={16} />
                    <span className="font-bold text-sm">{t('donor_status')}</span>
                    <span className="text-xs bg-amber-200 text-amber-800 px-2 py-0.5 rounded-full font-bold">2x</span>
                  </div>
                  <p className="text-amber-600 text-xs mt-1">{t('donor_benefits')}</p>
                </div>
              )}

              {/* Contact - Facebook + Email */}
              <div className="flex flex-wrap items-center justify-center gap-4">
                <a
                  href="https://www.facebook.com/groups/artnew8"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-brand-500 hover:text-brand-600 text-xs font-bold transition-colors"
                >
                  <MessageCircle size={14} /> {t('limit_contact_us')}
                </a>
                <a
                  href="mailto:artnew8studio@gmail.com"
                  className="inline-flex items-center gap-1.5 text-brand-500 hover:text-brand-600 text-xs font-bold transition-colors"
                >
                  <Mail size={14} /> Email
                </a>
              </div>

              {/* Action buttons */}
              <div className="flex gap-3">
                <button
                  onClick={closeLimitModal}
                  className="flex-1 flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 py-3 rounded-xl font-bold text-sm transition-colors"
                >
                  <Clock size={16} /> {t('limit_wait_tomorrow')}
                </button>
                <button
                  onClick={closeLimitModal}
                  className="flex-1 bg-brand-100 hover:bg-brand-200 text-brand-700 py-3 rounded-xl font-bold text-sm transition-colors"
                >
                  {t('limit_close')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
