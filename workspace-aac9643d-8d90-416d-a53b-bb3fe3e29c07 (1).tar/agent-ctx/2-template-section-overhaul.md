---
Task ID: 2
Agent: Template Section Overhaul
Task: Significantly improve Template/Cutting section to surpass competitors

Work Log:
- Read existing TemplateMaker.tsx, CSS3DPreview.tsx, boxMath.ts, i18n.ts
- Enhanced CSS3DPreview with gradients (top-to-bottom per panel), inner shadows for depth, ground shadow ellipses, new 3D models for gable_box/sleeve_box/pyramid/hex_box
- Added auto-rotate feature with requestAnimationFrame loop
- Added camera preset buttons (Front, Top, Isometric)
- Added dimension overlay toggle (W/L/H labels on 3D faces)
- Added 4 new template types to boxMath.ts: gable_box, sleeve_box, pyramid, hex_box
- Added registration marks (with circle targets) to ALL templates via shared helper
- Added bleed zone toggle (3mm outside cut line, red dashed)
- Added safe zone toggle (3mm inside fold line, green dotted)
- Added template presets (Small Gift, Medium Box, Large Mailer, A2 Envelope, Custom)
- Added volume calculator with golden ratio distribution (φ ≈ 1.618)
- Added paper material selector (Cardstock 0.3mm, Corrugated 0.8mm, Kraft 0.2mm, Chipboard 1.2mm) that auto-adjusts kerf
- Added PNG export (renders SVG to canvas at 3x resolution)
- Added file size estimates for each download format
- Updated download grid to 4 columns (PDF, DXF, OBJ, PNG)
- Updated i18n translations for all new features (EN/AR/FR)
- Fixed duplicate key error in i18n.ts (drag_rotate was defined twice)
- All TypeScript errors resolved, all lint checks pass

Stage Summary:
- 3D preview now has professional-quality rendering with gradients and shadows on all panels
- 4 new template types added (9 total): Gable Box, Sleeve Box, Pyramid, Hexagonal Box
- Template presets and volume calculator for quick dimension setup
- Paper material selector affects kerf automatically
- Auto-rotate and camera presets (Front/Top/Isometric) in 3D preview
- Dimension overlay (W/L/H) toggleable on 3D model
- Bleed zone and safe zone indicators in 2D view
- PNG export added alongside SVG/PDF/DXF/OBJ
- All features fully translated in EN/AR/FR
