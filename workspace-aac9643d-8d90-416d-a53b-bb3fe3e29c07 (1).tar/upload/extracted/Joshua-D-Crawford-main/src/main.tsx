import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { LanguageProvider } from './context/LanguageContext';

// Prevent errors from older polyfills attempting to override window.fetch
// in browsers where window.fetch is a getter-only property.
const fetchDescriptor = Object.getOwnPropertyDescriptor(window, 'fetch');
if (fetchDescriptor && !fetchDescriptor.set) {
  const originalFetch = window.fetch;
  Object.defineProperty(window, 'fetch', {
    get: () => originalFetch,
    set: () => {}, // Silently ignore attempts to overwrite fetch
    configurable: true
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <LanguageProvider>
      <App />
    </LanguageProvider>
  </StrictMode>,
);
