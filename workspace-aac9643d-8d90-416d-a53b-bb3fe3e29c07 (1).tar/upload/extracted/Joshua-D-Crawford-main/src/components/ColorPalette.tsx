import { useState } from 'react';
import { useDailyLimit } from '../context/DailyLimitContext';
import { useLanguage } from '../context/LanguageContext';
import { Palette, Copy, CheckCircle2 } from 'lucide-react';

const PALETTES = [
  { name: 'Warm Spring', colors: ['#f4a261', '#e76f51', '#2a9d8f', '#e9c46a', '#264653'] },
  { name: 'Soft Pastel', colors: ['#ffb5a7', '#fcd5ce', '#f8edeb', '#f1faee', '#a8dadc'] },
  { name: 'Royal Elegance', colors: ['#1d3557', '#457b9d', '#e63946', '#f1faee', '#a8dadc'] },
  { name: 'Forest Nature', colors: ['#386641', '#6a994e', '#a7c957', '#f2e8cf', '#bc4749'] },
  { name: 'Japanese Vintage', colors: ['#9c6644', '#b08968', '#ddb892', '#e6ccb2', '#ede0d4'] },
  { name: 'Summer Nights', colors: ['#03045e', '#0077b6', '#00b4d8', '#90e0ef', '#caf0f8'] },
  { name: 'Romantic Sunset', colors: ['#ff7b00', '#ff9500', '#ffea00', '#ff006e', '#8338ec'] },
  { name: 'Greyscale Chic', colors: ['#d5bdaf', '#e3d5ca', '#f5ebe0', '#edede9', '#d6ccc2'] },
];

export function ColorPalette() {
  const { consumeAttempt } = useDailyLimit();
  const { t } = useLanguage();
  const [activePalette, setActivePalette] = useState(PALETTES[0]);
  const [copiedColor, setCopiedColor] = useState('');

  const generateRandom = () => {
    consumeAttempt(() => {
      let idx;
      do {
        idx = Math.floor(Math.random() * PALETTES.length);
      } while (PALETTES[idx].name === activePalette.name && PALETTES.length > 1);
      setActivePalette(PALETTES[idx]);
    });
  };

  const copyColor = (color: string) => {
    navigator.clipboard.writeText(color);
    setCopiedColor(color);
    setTimeout(() => setCopiedColor(''), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-3xl font-display font-bold text-sage-800 tracking-tight">Paper Color Matcher</h2>
        <p className="text-sage-500 mt-2 leading-relaxed">
          Harmony is key in layered paper crafts. Explore our curated palettes explicitly designed for cardstock pairing and layer aesthetics.
        </p>
      </div>

      <div className="glass-card p-6 sm:p-10 rounded-3xl shadow-sm border border-sage-100 flex flex-col items-center text-center">
        
        <div className="inline-flex items-center justify-center p-3.5 rounded-full bg-brand-50 text-brand-600 mb-6 shadow-sm">
           <Palette size={28} />
        </div>
        <h3 className="text-2xl font-display font-bold text-sage-800 mb-8 tracking-tight">{activePalette.name}</h3>
        
        <div className="flex flex-col sm:flex-row w-full h-[400px] sm:h-64 rounded-3xl overflow-hidden shadow-inner mb-10 ring-1 ring-sage-900/5">
          {activePalette.colors.map(color => (
            <div 
              key={color} 
              style={{ backgroundColor: color }}
              className="flex-1 flex items-center justify-center relative group cursor-pointer hover:flex-[1.5] transition-all duration-500 ease-out"
              onClick={() => copyColor(color)}
            >
              <div className="opacity-0 group-hover:opacity-100 bg-black/60 text-white text-sm font-mono px-4 py-2 rounded-full flex items-center gap-2 backdrop-blur-md transition-opacity shadow-lg">
                {copiedColor === color ? <CheckCircle2 size={16} className="text-green-400" /> : <Copy size={16} />}
                {color}
              </div>
            </div>
          ))}
        </div>

        <button 
          onClick={generateRandom}
          className="flex items-center justify-center gap-3 w-full sm:w-auto bg-gradient-to-r from-sage-700 to-sage-800 hover:from-sage-600 hover:to-sage-700 text-white shadow-xl hover:shadow-2xl hover:-translate-y-1 py-4 px-10 rounded-full font-bold transition-all transform hover:-transtone-y-0.5 shadow-md"
        >
          <Palette size={20} />
          Discover New Palette
        </button>

      </div>
    </div>
  );
}
