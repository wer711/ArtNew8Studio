import { useState } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { useDailyLimit } from '../context/DailyLimitContext';
import { useLanguage } from '../context/LanguageContext';
import { Material, Project } from '../types';
import { Plus, Trash2, Calculator, Save, Briefcase, Scissors, Clock, DollarSign, Activity, Percent, Truck, Download } from 'lucide-react';
import { jsPDF } from 'jspdf';

export function PricingCalculator() {
  const [projects, setProjects] = useLocalStorage<Project[]>('artnew8_projects_en', []);
  const { consumeAttempt } = useDailyLimit();
  const { t } = useLanguage();
  
  const [name, setName] = useState('');
  const [materials, setMaterials] = useState<Material[]>([{ id: '1', name: '', cost: 0, quantityUsed: 1 }]);
  const [hourlyRate, setHourlyRate] = useState(20); 
  const [hoursSpent, setHoursSpent] = useState(1.5);
  const [packagingCost, setPackagingCost] = useState(1.50);
  const [overheadPercentage, setOverheadPercentage] = useState(10);
  const [profitMargin, setProfitMargin] = useState(40);
  const [platformFeeType, setPlatformFeeType] = useState<Project['platformFeeType']>('etsy');

  const [customFeePercent, setCustomFeePercent] = useState(5);
  const [customFeeFixed, setCustomFeeFixed] = useState(0);
  const [freeShippingCost, setFreeShippingCost] = useState(0);
  const [discountPercentage, setDiscountPercentage] = useState(0);
  const [taxPercentage, setTaxPercentage] = useState(0);

  const addMaterial = () => {
    setMaterials([...materials, { id: Math.random().toString(), name: '', cost: 0, quantityUsed: 1 }]);
  };

  const updateMaterial = (id: string, field: keyof Material, value: string | number) => {
    setMaterials(materials.map(m => m.id === id ? { ...m, [field]: value } : m));
  };

  const removeMaterial = (id: string) => {
    setMaterials(materials.filter(m => m.id !== id));
  };

  const calculateTotalCost = () => {
    const rawMaterialCost = materials.reduce((acc, m) => acc + (m.cost * m.quantityUsed), 0);
    const laborCost = hourlyRate * hoursSpent;
    const directCost = rawMaterialCost + laborCost + packagingCost;
    
    const overheadCost = directCost * (overheadPercentage / 100);
    const baseCost = directCost + overheadCost + freeShippingCost;
    
    const wholesalePrice = baseCost * (1 + (profitMargin / 100));
    
    let feePercent = 0;
    let feeFixed = 0;

    if (platformFeeType === 'etsy') {
      feePercent = 0.095;
      feeFixed = 0.25;
    } else if (platformFeeType === 'shopify') {
      feePercent = 0.029;
      feeFixed = 0.30;
    } else if (platformFeeType === 'amazon') {
      feePercent = 0.15;
      feeFixed = 0;
    } else if (platformFeeType === 'custom') {
      feePercent = customFeePercent / 100;
      feeFixed = customFeeFixed;
    }

    const priceAfterDiscount = (wholesalePrice + feeFixed) / (1 - feePercent);
    const retailPricePreTax = priceAfterDiscount / (1 - (discountPercentage / 100));
    const taxAmount = retailPricePreTax * (taxPercentage / 100);
    
    const retailPrice = retailPricePreTax + taxAmount;
    const platformFeeAmount = priceAfterDiscount - wholesalePrice;
    const discountAmount = retailPricePreTax - priceAfterDiscount;

    return { rawMaterialCost, laborCost, overheadCost, baseCost, wholesalePrice, platformFeeAmount, discountAmount, taxAmount, retailPrice };
  };

  const { rawMaterialCost, laborCost, overheadCost, baseCost, wholesalePrice, platformFeeAmount, discountAmount, taxAmount, retailPrice } = calculateTotalCost();

  const downloadSummary = () => {
    consumeAttempt(() => {
      const doc = new jsPDF();
      
      doc.setFontSize(20);
      doc.text('Pricing Summary', 20, 20);
      
      doc.setFontSize(14);
      doc.text(`Project: ${name || 'Unnamed Project'}`, 20, 30);
      
      doc.setFontSize(12);
      doc.text('--- Cost Breakdown ---', 20, 45);
      doc.text(`Materials: $${rawMaterialCost.toFixed(2)}`, 20, 55);
      doc.text(`Labor & Overhead: $${(laborCost + overheadCost + packagingCost + freeShippingCost).toFixed(2)}`, 20, 65);
      doc.text(`Platform Fees: $${platformFeeAmount.toFixed(2)}`, 20, 75);
      
      if (discountAmount > 0) {
        doc.text(`Discount Absorbed: -$${discountAmount.toFixed(2)}`, 20, 85);
      }
      if (taxAmount > 0) {
        doc.text(`Tax: $${taxAmount.toFixed(2)}`, 20, 95);
      }
      
      let y = taxAmount > 0 || discountAmount > 0 ? 105 : 85;
      doc.text('--- Final Pricing ---', 20, y + 10);
      doc.text(`Wholesale Price: $${wholesalePrice.toFixed(2)}`, 20, y + 20);
      doc.setFontSize(16);
      doc.text(`Retail Price: $${retailPrice.toFixed(2)}`, 20, y + 35);
      doc.setFontSize(12);
      doc.text(`Net Profit: $${(wholesalePrice - baseCost).toFixed(2)}`, 20, y + 45);
      
      doc.save(`Pricing_Summary_${name.replace(/\\s+/g, '_') || 'Project'}.pdf`);
    });
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-800 tracking-tight flex items-center gap-3">
             <div className="p-2.5 bg-brand-100 rounded-xl">
               <Calculator className="w-6 h-6 text-brand-600" />
             </div>
             Pricing Calculator
          </h2>
          <p className="text-slate-500 mt-2 max-w-2xl leading-relaxed">
            Stop guessing and secure your profits. Calculate true production costs and marketplace fees.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Input Form */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-6">
          <div className="bg-white p-6 md:p-8 rounded-[2rem] shadow-[0_10px_40px_-15px_rgba(0,0,0,0.05)] border border-slate-100/60 ring-1 ring-slate-100 space-y-8 relative overflow-hidden">
             {/* Decorative Background Element */}
            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-brand-50 rounded-full blur-xl opacity-50 opacity-50 opacity-50 pointer-events-none"></div>

            <div className="relative z-10">
              <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                <Briefcase size={16} className="text-brand-500" /> Project Name
              </label>
              <input 
                type="text" value={name} onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Luxury Petal Box Set"
                className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 rounded-2xl px-5 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium"
              />
            </div>

            <div className="relative z-10 space-y-4">
              <h4 className="text-sm font-bold tracking-widest text-slate-400 uppercase flex items-center gap-2">
                <Scissors size={16} className="text-brand-500" /> Materials List
              </h4>
              <div className="space-y-3">
                {materials.map((mat) => (
                  <div key={mat.id} className="flex flex-wrap sm:flex-nowrap gap-3 items-center bg-slate-50 p-3 rounded-2xl border border-slate-100 hover:border-brand-200 transition-colors">
                     <div className="w-full sm:w-[50%] relative">
                       <label className="sm:hidden block text-xs font-bold text-slate-500 mb-1">Material Name</label>
                       <input type="text" placeholder="Cardstock..." value={mat.name} onChange={(e) => updateMaterial(mat.id, 'name', e.target.value)} className="w-full bg-white border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-sm rounded-xl px-4 py-2.5 transition-all" />
                     </div>
                     <div className="w-[calc(50%-0.5rem)] sm:w-[20%] relative">
                       <label className="sm:hidden block text-xs font-bold text-slate-500 mb-1">Cost ($)</label>
                       <input type="number" placeholder="Cost" value={mat.cost || ''} onChange={(e) => updateMaterial(mat.id, 'cost', Number(e.target.value))} className="w-full bg-white border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-sm rounded-xl px-4 py-2.5 transition-all" />
                     </div>
                     <div className="w-[calc(50%-2rem)] sm:w-[20%] relative">
                       <label className="sm:hidden block text-xs font-bold text-slate-500 mb-1">Qty</label>
                       <input type="number" placeholder="Qty" value={mat.quantityUsed || ''} onChange={(e) => updateMaterial(mat.id, 'quantityUsed', Number(e.target.value))} className="w-full bg-white border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-sm rounded-xl px-4 py-2.5 transition-all" />
                     </div>
                     <button onClick={() => removeMaterial(mat.id)} className="w-10 h-10 ml-auto sm:w-auto text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl flex items-center justify-center transition-all bg-white ring-1 ring-slate-200 sm:px-3 sm:mt-0 mt-6 shrink-0">
                       <Trash2 size={18} />
                     </button>
                  </div>
                ))}
              </div>
              <button onClick={addMaterial} className="text-sm bg-brand-50 hover:bg-brand-100 text-brand-700 font-bold flex items-center justify-center gap-2 w-full py-3.5 rounded-2xl transition-colors border border-brand-100/50">
                 <Plus size={18} strokeWidth={2.5} /> Add Material
              </button>
            </div>

            <div className="border-t border-slate-100 pt-8 relative z-10 space-y-6">
               <h4 className="text-sm font-bold tracking-widest text-slate-400 uppercase flex items-center gap-2">
                 <Clock size={16} className="text-brand-500" /> Labor & Overheads
               </h4>
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-50 p-1.5 rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-xs font-bold text-slate-500 px-3 pt-2">Hourly Rate ($)</label>
                  <input type="number" value={hourlyRate} onChange={(e) => setHourlyRate(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium px-3 py-2" />
                </div>
                <div className="bg-slate-50 p-1.5 rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-xs font-bold text-slate-500 px-3 pt-2">Time Spent (Hours)</label>
                  <input type="number" value={hoursSpent} onChange={(e) => setHoursSpent(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium px-3 py-2" />
                </div>
                <div className="bg-slate-50 p-1.5 rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-xs font-bold text-slate-500 px-3 pt-2">Packaging Cost ($)</label>
                  <input type="number" value={packagingCost} onChange={(e) => setPackagingCost(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium px-3 py-2" />
                </div>
                <div className="bg-slate-50 p-1.5 rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-xs font-bold text-slate-500 px-3 pt-2">Studio Overhead (%)</label>
                  <input type="number" value={overheadPercentage} onChange={(e) => setOverheadPercentage(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium px-3 py-2" />
                </div>
                <div className="bg-slate-50 p-1.5 rounded-2xl ring-1 ring-slate-200">
                  <label className="block text-xs font-bold text-slate-500 px-3 pt-2 flex items-center gap-1">Shipped Free (Cost) <Truck size={12}/></label>
                  <input type="number" value={freeShippingCost} onChange={(e) => setFreeShippingCost(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium px-3 py-2" />
                </div>
               </div>
            </div>

            <div className="border-t border-slate-100 pt-8 relative z-10 space-y-6">
               <h4 className="text-sm font-bold tracking-widest text-slate-400 uppercase flex items-center gap-2">
                 <Activity size={16} className="text-brand-500" /> Marketplace & Margin
               </h4>
               <div className="flex flex-wrap gap-2 bg-slate-100 p-1.5 rounded-[1.25rem]">
                 {(['none', 'etsy', 'shopify', 'amazon', 'custom'] as const).map(type => (
                   <button 
                    key={type}
                    onClick={() => setPlatformFeeType(type)}
                    className={`flex-1 py-2 px-3 rounded-xl text-xs sm:text-sm font-bold capitalize transition-all ${
                      platformFeeType === type 
                        ? 'bg-white text-brand-700 shadow-sm ring-1 ring-black/5' 
                        : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'
                    }`}
                   >
                     {type}
                   </button>
                 ))}
               </div>

               {platformFeeType === 'custom' && (
                 <div className="grid grid-cols-2 gap-4 animate-in fade-in slide-in-from-top-2">
                    <div className="bg-slate-50 p-1.5 rounded-2xl ring-1 ring-slate-200">
                      <label className="block text-xs font-bold text-slate-500 px-3 pt-2">Custom Fee (%)</label>
                      <input type="number" value={customFeePercent} onChange={(e) => setCustomFeePercent(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium px-3 py-2" />
                    </div>
                    <div className="bg-slate-50 p-1.5 rounded-2xl ring-1 ring-slate-200">
                      <label className="block text-xs font-bold text-slate-500 px-3 pt-2">Custom Fixed Fee ($)</label>
                      <input type="number" value={customFeeFixed} onChange={(e) => setCustomFeeFixed(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium px-3 py-2" />
                    </div>
                 </div>
               )}
               
               <div className="bg-slate-50 p-5 rounded-2xl ring-1 ring-slate-200 mt-4">
                  <div className="flex justify-between items-end mb-4">
                    <label className="block text-sm font-bold text-slate-600">Target Profit Margin</label>
                    <span className="text-2xl font-black font-display text-brand-600">{profitMargin}%</span>
                  </div>
                  <input 
                    type="range" min="10" max="150" value={profitMargin} step="5"
                    onChange={(e) => setProfitMargin(Number(e.target.value))}
                    className="w-full h-2 bg-slate-200 rounded-full appearance-none cursor-pointer accent-brand-500"
                  />
               </div>
            </div>

            <div className="border-t border-slate-100 pt-8 relative z-10 space-y-6">
               <h4 className="text-sm font-bold tracking-widest text-slate-400 uppercase flex items-center gap-2">
                 <Percent size={16} className="text-brand-500" /> Advanced Strategy
               </h4>
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                 <div className="bg-slate-50 p-1.5 rounded-2xl ring-1 ring-slate-200">
                    <label className="block text-xs font-bold text-slate-500 px-3 pt-2">Simulate Discount (%)</label>
                    <input type="number" min="0" max="90" value={discountPercentage} onChange={(e) => setDiscountPercentage(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium px-3 py-2" />
                 </div>
                 <div className="bg-slate-50 p-1.5 rounded-2xl ring-1 ring-slate-200">
                    <label className="block text-xs font-bold text-slate-500 px-3 pt-2">Tax / VAT (%)</label>
                    <input type="number" min="0" max="50" value={taxPercentage} onChange={(e) => setTaxPercentage(Number(e.target.value))} className="w-full bg-transparent border-0 focus:ring-0 text-slate-700 font-medium px-3 py-2" />
                 </div>
               </div>
            </div>

          </div>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-5 xl:col-span-4 flex flex-col gap-6">
          <div className="bg-slate-900 border border-slate-800 text-white p-8 rounded-[2rem] shadow-xl relative overflow-hidden flex-1 shrink-0 flex flex-col items-center">
            {/* Visual Flair */}
            <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-brand-500/20 blur-[100px] rounded-full pointer-events-none translate-x-1/2 -translate-y-1/2"></div>
            
            <div className="w-full text-center space-y-6 relative z-10 flex-1 flex flex-col justify-center">
               <div className="inline-flex items-center justify-center p-3 sm:p-4 bg-brand-500/20 rounded-3xl mx-auto mb-2 text-brand-400">
                  <DollarSign size={40} className="sm:w-12 sm:h-12" />
               </div>
               
               <div className="space-y-1">
                 <p className="text-sm font-bold tracking-widest text-slate-400 uppercase">Recommended Retail</p>
                 <div className="text-6xl sm:text-7xl font-black font-display tracking-tighter text-white">
                   ${retailPrice.toFixed(2)}
                 </div>
               </div>

               <div className="bg-slate-800/50 rounded-[1.5rem] p-5 w-full space-y-4 border border-slate-700/50 backdrop-blur-xl mt-8">
                 <div className="flex justify-between items-center pb-3 border-b border-white/5">
                   <span className="text-slate-400 text-sm font-medium">{t('p_wholesale')}</span>
                   <span className="font-bold text-slate-200 text-lg">${wholesalePrice.toFixed(2)}</span>
                 </div>
                 
                 <div className="space-y-2 text-sm text-slate-400">
                    <div className="flex justify-between items-center">
                      <span>Materials</span>
                      <span>${rawMaterialCost.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Labor & Overhead {freeShippingCost > 0 ? '+ Ship' : ''}</span>
                      <span>${(laborCost + overheadCost + packagingCost + freeShippingCost).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center text-amber-400/80">
                      <span>Platform Fees</span>
                      <span>${platformFeeAmount.toFixed(2)}</span>
                    </div>
                    {discountAmount > 0 && (
                      <div className="flex justify-between items-center text-red-400/80">
                        <span>Discount Absorbed</span>
                        <span>-${discountAmount.toFixed(2)}</span>
                      </div>
                    )}
                    {taxAmount > 0 && (
                      <div className="flex justify-between items-center text-indigo-300">
                        <span>Tax</span>
                        <span>${taxAmount.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="border-t border-white/10 pt-2 mt-2 flex justify-between items-center text-brand-300 font-bold">
                      <span>{t('p_profit')}</span>
                      <span>${(wholesalePrice - baseCost).toFixed(2)}</span>
                    </div>
                 </div>
               </div>
            </div>
            
            <div className="w-full mt-6 relative z-10">
               <button 
                 onClick={downloadSummary}
                 disabled={!name.trim()}
                 className="w-full bg-brand-600 hover:bg-brand-500 text-white py-4 px-6 rounded-2xl font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_4px_20px_-5px_rgba(79,70,229,0.5)] flex items-center justify-center gap-2 text-sm sm:text-base"
               >
                 <Download size={20} /> {t('btn_save')}
               </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

