import React, { useState, useEffect } from 'react';
import { Move3d, Info, ZoomIn, ZoomOut, RefreshCw } from 'lucide-react';

interface Props {
  width: number;
  length: number;
  height: number;
  flapSize: number;
  glueTab: number;
  templateType: string;
}

export function CSS3DPreview({ width, length, height, flapSize, glueTab, templateType }: Props) {
  const [rotX, setRotX] = useState(60);
  const [rotZ, setRotZ] = useState(45);
  const [zoom, setZoom] = useState(1);
  const [isDragging, setIsDragging] = useState(false);
  const [lastTouch, setLastTouch] = useState<{x: number, y: number} | null>(null);
  const [foldAngle, setFoldAngle] = useState(0);

  useEffect(() => {
    setFoldAngle(0);
    const timer = setTimeout(() => setFoldAngle(90), 500);
    return () => clearTimeout(timer);
  }, [width, length, height, templateType]);

  const handleZoomIn = (e: React.MouseEvent) => { e.stopPropagation(); setZoom(z => Math.min(5, z + 0.2)); };
  const handleZoomOut = (e: React.MouseEvent) => { e.stopPropagation(); setZoom(z => Math.max(0.2, z - 0.2)); };
  const resetView = (e: React.MouseEvent) => { e.stopPropagation(); setRotX(60); setRotZ(45); setZoom(1); };
  const toggleFold = (e: React.MouseEvent) => { e.stopPropagation(); setFoldAngle(old => old === 90 ? 0 : 90); };

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true);
    setLastTouch({ x: e.touches[0].clientX, y: e.touches[0].clientY });
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || !lastTouch) return;
    const touch = e.touches[0];
    const dx = touch.clientX - lastTouch.x;
    const dy = touch.clientY - lastTouch.y;
    setRotZ(prev => prev + dx * 0.5);
    setRotX(prev => prev - dy * 0.5);
    setLastTouch({ x: touch.clientX, y: touch.clientY });
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    setLastTouch(null);
  };

  const maxDim = Math.max(width + height * 2.5, length + height * 2.5);
  const factor = Math.min(300 / maxDim, 1.2) * zoom;

  const renderModel = () => {
    const ts = 'transform 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)';
    const bgBase = 'rgba(253, 248, 242, 0.96)';
    const bgWall = 'rgba(253, 248, 242, 0.90)';
    const bgSide = 'rgba(240, 230, 222, 0.92)';
    const stroke = '#c97b6e';
    const txtColor = '#9e4f44';

    if (templateType === 'box') {
      const fAngle = foldAngle;
      const tH = width * 0.5;
      const sH = length * 0.5;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: `rotateX(${rotX}deg) rotateZ(${rotZ}deg) scale(${factor})`, position: 'relative', width, height: length, transition: isDragging ? 'none' : 'transform 0.1s ease-out' }}>
          <div style={{ position: 'absolute', width, height: length, backgroundColor: bgBase, border: `1.5px solid ${stroke}`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: txtColor, fontWeight: 'bold' }}>BASE</div>
          
          <div style={{ position: 'absolute', width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fAngle}deg)`, backgroundColor: bgWall, border: `1px solid ${stroke}`, transition: ts }}>
             <div style={{ position: 'absolute', width, height: tH, top: -tH, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fAngle * 0.98}deg)`, backgroundColor: bgBase, border: `1px solid ${stroke}`, transition: ts }} />
          </div>
          
          <div style={{ position: 'absolute', width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fAngle}deg)`, backgroundColor: bgWall, border: `1px solid ${stroke}`, transition: ts }}>
             <div style={{ position: 'absolute', width, height: tH, top: height, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fAngle * 0.95}deg)`, backgroundColor: bgBase, border: `1px solid ${stroke}`, transition: ts }} />
          </div>
          
          <div style={{ position: 'absolute', width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-fAngle}deg)`, backgroundColor: bgSide, border: `1px solid ${stroke}`, transition: ts }}>
             <div style={{ position: 'absolute', width: sH, height: length, top: 0, left: -sH, transformOrigin: 'right center', transform: `rotateY(${-fAngle * 0.9}deg)`, backgroundColor: bgSide, border: `1px solid ${stroke}`, transition: ts }} />
          </div>
          
          <div style={{ position: 'absolute', width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${fAngle}deg)`, backgroundColor: bgSide, border: `1px solid ${stroke}`, transition: ts }}>
             <div style={{ position: 'absolute', width: sH, height: length, top: 0, left: height, transformOrigin: 'left center', transform: `rotateY(${fAngle * 0.85}deg)`, backgroundColor: bgSide, border: `1px solid ${stroke}`, transition: ts }} />
          </div>
        </div>
      );
    }

    if (templateType === 'mailer') {
      const fA = foldAngle;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: `rotateX(${rotX}deg) rotateZ(${rotZ}deg) scale(${factor})`, position: 'relative', width, height: length, transition: isDragging ? 'none' : 'transform 0.1s ease-out' }}>
          <div style={{ position: 'absolute', width, height: length, backgroundColor: bgBase, border: `1.5px solid ${stroke}`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: txtColor, fontWeight: 'bold' }}>BASE</div>
          
          <div style={{ position: 'absolute', width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA}deg)`, backgroundColor: bgWall, border: `1px solid ${stroke}`, transition: ts }}>
              <div style={{ position: 'absolute', width, height: height * 0.9, top: -height * 0.9, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA * 0.98}deg)`, backgroundColor: bgBase, border: `1px dashed ${stroke}`, transition: ts }} />
          </div>
          
          <div style={{ position: 'absolute', width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-fA}deg)`, backgroundColor: bgSide, border: `1px solid ${stroke}`, transition: ts }}>
              <div style={{ position: 'absolute', width: height, height: height * 0.8, top: -height * 0.8, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${-fA * 0.9}deg)`, backgroundColor: bgSide, border: `1px dashed ${stroke}`, transition: ts }} />
              <div style={{ position: 'absolute', width: height, height: height * 0.8, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${fA * 0.9}deg)`, backgroundColor: bgSide, border: `1px dashed ${stroke}`, transition: ts }} />
          </div>
          
          <div style={{ position: 'absolute', width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${fA}deg)`, backgroundColor: bgSide, border: `1px solid ${stroke}`, transition: ts }}>
              <div style={{ position: 'absolute', width: height, height: height * 0.8, top: -height * 0.8, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${-fA * 0.9}deg)`, backgroundColor: bgSide, border: `1px dashed ${stroke}`, transition: ts }} />
              <div style={{ position: 'absolute', width: height, height: height * 0.8, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${fA * 0.9}deg)`, backgroundColor: bgSide, border: `1px dashed ${stroke}`, transition: ts }} />
          </div>

          <div style={{ position: 'absolute', width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, backgroundColor: bgWall, border: `1px solid ${stroke}`, transition: ts }}>
             <div style={{ position: 'absolute', width, height: length, top: height, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, backgroundColor: bgBase, border: `1px dashed ${stroke}`, transition: ts }}>
                <div style={{ position: 'absolute', width, height: height * 0.9, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA * 0.95}deg)`, backgroundColor: bgWall, border: `1px solid ${stroke}`, transition: ts }} />
                <div style={{ position: 'absolute', width: Math.max(15, flapSize), height: length * 0.5, top: length * 0.3, left: -Math.max(15, flapSize), transformOrigin: 'right center', transform: `rotateY(${-fA * 0.9}deg)`, backgroundColor: bgBase, border: `1px dashed ${stroke}`, transition: ts, borderRadius: '15px 0 0 15px' }} />
                <div style={{ position: 'absolute', width: Math.max(15, flapSize), height: length * 0.5, top: length * 0.3, left: width, transformOrigin: 'left center', transform: `rotateY(${fA * 0.9}deg)`, backgroundColor: bgBase, border: `1px dashed ${stroke}`, transition: ts, borderRadius: '0 15px 15px 0' }} />
             </div>
          </div>
        </div>
      );
    }

    if (templateType === 'envelope') {
      const flapTop = length * 0.55;
      const flapBottom = length * 0.6;
      const flapSide = width * 0.45;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: `rotateX(${rotX}deg) rotateZ(${rotZ}deg) scale(${factor})`, position: 'relative', width, height: length, transition: isDragging ? 'none' : 'transform 0.1s ease-out' }}>
          <div style={{ position: 'absolute', width, height: length, backgroundColor: bgBase, border: `1px solid ${stroke}` }} />
          <div style={{ position: 'absolute', width: flapSide, height: length, top: 0, left: -flapSide, clipPath: 'polygon(100% 0%, 0% 50%, 100% 100%)', transformOrigin: 'right center', transform: `rotateY(${-foldAngle * 1.99}deg) translateZ(${foldAngle/90 * 1}px)`, backgroundColor: bgSide, transition: ts }} />
          <div style={{ position: 'absolute', width: flapSide, height: length, top: 0, left: width, clipPath: 'polygon(0% 0%, 100% 50%, 0% 100%)', transformOrigin: 'left center', transform: `rotateY(${foldAngle * 1.99}deg) translateZ(${foldAngle/90 * 2}px)`, backgroundColor: bgSide, transition: ts }} />
          <div style={{ position: 'absolute', width, height: flapBottom, top: length, clipPath: 'polygon(0% 0%, 50% 100%, 100% 0%)', transformOrigin: 'top center', transform: `rotateX(${-foldAngle * 1.99}deg) translateZ(${foldAngle/90 * 3}px)`, backgroundColor: bgWall, transition: ts }} />
          <div style={{ position: 'absolute', width, height: flapTop, top: -flapTop, clipPath: 'polygon(0% 100%, 50% 0%, 100% 100%)', transformOrigin: 'bottom center', transform: `rotateX(${foldAngle * 1.99}deg) translateZ(${foldAngle/90 * 4}px)`, backgroundColor: bgWall, transition: ts }} />
        </div>
      );
    }

    if (templateType === 'pillow') {
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: `rotateX(${rotX}deg) rotateZ(${rotZ}deg) scale(${factor})`, position: 'relative', width, height: length, transition: isDragging ? 'none' : 'transform 0.1s ease-out' }}>
          <div style={{ position: 'absolute', width, height: length, backgroundColor: bgBase, border: `1px solid ${stroke}`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: txtColor, fontWeight: 'bold' }}>BASE</div>
          <div style={{ position: 'absolute', width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-foldAngle}deg)`, backgroundColor: bgSide, border: `1px solid ${stroke}`, transition: ts }} />
          <div style={{ position: 'absolute', width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${foldAngle}deg)`, backgroundColor: bgSide, border: `1px solid ${stroke}`, transition: ts }}>
             <div style={{ position: 'absolute', width, height: length, top: 0, left: height, transformOrigin: 'left center', transform: `rotateY(${foldAngle}deg)`, backgroundColor: bgWall, border: `1px solid ${stroke}`, transition: ts }}>
                 <div style={{ position: 'absolute', width, height, top: -height, left: 0, borderRadius: '100% 100% 0 0', backgroundColor: bgSide, transformOrigin: 'bottom center', transform: `rotateX(${foldAngle * 0.95}deg)`, border: `1px dashed ${stroke}`, transition: ts, opacity: 0.8 }} />
                 <div style={{ position: 'absolute', width, height, top: length, left: 0, borderRadius: '0 0 100% 100%', backgroundColor: bgSide, transformOrigin: 'top center', transform: `rotateX(${-foldAngle * 0.95}deg)`, border: `1px dashed ${stroke}`, transition: ts, opacity: 0.8 }} />
             </div>
          </div>
          <div style={{ position: 'absolute', width, height, top: -height, left: 0, borderRadius: '100% 100% 0 0', backgroundColor: bgWall, transformOrigin: 'bottom center', transform: `rotateX(${foldAngle * 0.85}deg)`, border: `1px solid ${stroke}`, transition: ts }} />
          <div style={{ position: 'absolute', width, height, top: length, left: 0, borderRadius: '0 0 100% 100%', backgroundColor: bgWall, transformOrigin: 'top center', transform: `rotateX(${-foldAngle * 0.85}deg)`, border: `1px solid ${stroke}`, transition: ts }} />
        </div>
      );
    }

    if (templateType === 'milk_carton') {
      const topH = width * 0.5;
      const fA = foldAngle;
      return (
        <div style={{ transformStyle: 'preserve-3d', transform: `rotateX(${rotX}deg) rotateZ(${rotZ}deg) scale(${factor})`, position: 'relative', width, height: length, transition: isDragging ? 'none' : 'transform 0.1s ease-out' }}>
          <div style={{ position: 'absolute', width, height: length, backgroundColor: bgBase, border: `1.5px solid ${stroke}`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: txtColor, fontWeight: 'bold' }}>BASE</div>
          
          <div style={{ position: 'absolute', width, height, top: -height, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA}deg)`, backgroundColor: bgWall, border: `1px solid ${stroke}`, transition: ts }}>
            <div style={{ position: 'absolute', width, height: topH, top: -topH, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA * 0.5}deg)`, backgroundColor: 'rgba(253, 248, 242, 0.85)', border: `1px dashed ${stroke}`, transition: ts }}>
                 <div style={{ position: 'absolute', width, height: 15, top: -15, left: 0, transformOrigin: 'bottom center', transform: `rotateX(${fA * 0.6}deg)`, backgroundColor: bgBase, border: `1px solid ${stroke}`, transition: ts }} />
            </div>
          </div>
          
          <div style={{ position: 'absolute', width, height, top: length, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA}deg)`, backgroundColor: bgWall, border: `1px solid ${stroke}`, transition: ts }}>
             <div style={{ position: 'absolute', width, height: topH, top: height, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA * 0.5}deg)`, backgroundColor: 'rgba(253, 248, 242, 0.85)', border: `1px dashed ${stroke}`, transition: ts }}>
                 <div style={{ position: 'absolute', width, height: 15, top: topH, left: 0, transformOrigin: 'top center', transform: `rotateX(${-fA * 0.6}deg)`, backgroundColor: bgBase, border: `1px solid ${stroke}`, transition: ts }} />
             </div>
          </div>
          
          <div style={{ position: 'absolute', width: height, height: length, top: 0, left: -height, transformOrigin: 'right center', transform: `rotateY(${-fA}deg)`, backgroundColor: bgSide, border: `1px solid ${stroke}`, transition: ts }}>
             <div style={{ position: 'absolute', width: topH, height: length, top: 0, left: -topH, transformOrigin: 'right center', transform: `rotateY(${-fA * 0.5}deg)`, backgroundColor: 'rgba(240, 230, 222, 0.85)', clipPath: 'polygon(0% 50%, 100% 0%, 100% 100%)', transition: ts, opacity: 0.9 }} />
          </div>
          
          <div style={{ position: 'absolute', width: height, height: length, top: 0, left: width, transformOrigin: 'left center', transform: `rotateY(${fA}deg)`, backgroundColor: bgSide, border: `1px solid ${stroke}`, transition: ts }}>
             <div style={{ position: 'absolute', width: topH, height: length, top: 0, left: height, transformOrigin: 'left center', transform: `rotateY(${fA * 0.5}deg)`, backgroundColor: 'rgba(240, 230, 222, 0.85)', clipPath: 'polygon(100% 50%, 0% 0%, 0% 100%)', transition: ts, opacity: 0.9 }} />
          </div>
        </div>
      );
    }
  };

  return (
    <div 
      className="relative w-full h-full min-h-[400px] md:min-h-[500px] flex flex-col items-center justify-center overflow-hidden rounded-[2rem] cursor-move mt-12 md:mt-0 lg:mt-12 bg-[#fdf8f2] border border-brand-200/50 touch-none"
      onMouseDown={() => setIsDragging(true)}
      onMouseUp={() => setIsDragging(false)}
      onMouseLeave={() => setIsDragging(false)}
      onMouseMove={(e) => {
        if (!isDragging) return;
        setRotZ(prev => prev + e.movementX * 0.5);
        setRotX(prev => prev - e.movementY * 0.5);
      }}
      onWheel={(e) => {
        setZoom(prev => Math.max(0.2, Math.min(5, prev - e.deltaY * 0.002)));
      }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchEnd}
    >
      <div className="absolute top-4 left-4 z-10 flex gap-2">
        <button onClick={toggleFold} className="bg-brand-900 hover:bg-brand-800 text-white px-4 py-2.5 rounded-xl text-[11px] uppercase tracking-wider font-bold shadow-md flex items-center gap-2 transition-all">
          <Move3d size={14} /> {foldAngle === 90 ? 'Unfold Flat' : 'Fold 3D'}
        </button>
      </div>

      <div className="absolute bottom-16 right-4 md:top-4 md:bottom-auto md:right-4 z-10 flex flex-col gap-2">
         <button onClick={handleZoomIn} className="bg-white hover:bg-brand-50 text-brand-700 p-2.5 rounded-xl shadow-md border border-brand-100 transition-colors" aria-label="Zoom In">
           <ZoomIn size={18} />
         </button>
         <button onClick={handleZoomOut} className="bg-white hover:bg-brand-50 text-brand-700 p-2.5 rounded-xl shadow-md border border-brand-100 transition-colors" aria-label="Zoom Out">
           <ZoomOut size={18} />
         </button>
         <button onClick={resetView} className="bg-white hover:bg-brand-50 text-brand-700 p-2.5 rounded-xl shadow-md border border-brand-100 transition-colors mt-1" aria-label="Reset View">
           <RefreshCw size={18} />
         </button>
      </div>

      <div style={{ perspective: '2500px', width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
         {renderModel()}
      </div>
      
      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-[10px] md:text-[11px] text-brand-600 font-bold bg-white/90 px-4 py-2.5 rounded-xl backdrop-blur-md border border-brand-200/60 shadow-sm pointer-events-none">
         <span className="uppercase tracking-wider">Interactive 3D Engine ({templateType})</span>
         <span className="flex items-center gap-1.5"><Info size={14}/> Drag canvas to rotate</span>
      </div>
    </div>
  );
}
