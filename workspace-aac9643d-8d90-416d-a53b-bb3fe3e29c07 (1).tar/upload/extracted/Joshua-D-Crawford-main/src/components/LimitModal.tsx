import { Heart, X, Facebook, ExternalLink } from 'lucide-react';

export function LimitModal({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-sage-800/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white rounded-3xl p-6 sm:p-10 max-w-md w-full shadow-2xl relative animate-in zoom-in-95 duration-300">
        <button onClick={onClose} className="absolute top-4 right-4 p-2 text-sage-400 hover:text-sage-600 rounded-full hover:bg-sage-100 transition-colors">
          <X size={20} />
        </button>
        
        <div className="text-center space-y-5">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-brand-50 text-brand-500 mb-2">
            <Heart size={32} fill="currentColor" />
          </div>
          <h3 className="text-2xl font-display font-bold text-sage-800">Daily Limit Reached!</h3>
          <p className="text-sage-600 text-sm leading-relaxed">
            You've used all your free tool generations for today. We love seeing you craft!
            <br/><br/>
            We provide these professional tools at <span className="font-bold text-brand-600">ArtNew8</span> for free to support the maker community. If you find them valuable for your business, consider supporting our server costs to help us build the global Artisan Marketplace.
          </p>
          
          <div className="pt-6 space-y-3">
            <a 
              href="https://www.paypal.com/ncp/payment/7TUYHE9XTU6AG" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center justify-center w-full gap-2 bg-[#0070ba] hover:bg-[#003087] text-white py-3.5 px-6 rounded-full font-bold transition-all shadow-md transform hover:-transtone-y-0.5"
            >
              Support via PayPal
            </a>
            
            <a 
              href="https://www.facebook.com/share/g/1HLBeMbAVJ/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center justify-center w-full gap-2 bg-[#1877F2] hover:bg-[#166fe5] text-white py-3.5 px-6 rounded-full font-bold transition-all shadow-md transform hover:-transtone-y-0.5"
            >
              <Facebook size={20} />
              Join Our Facebook Group
            </a>

            <button 
              onClick={onClose}
              className="w-full py-3.5 px-6 rounded-full font-medium text-sage-500 hover:bg-sage-50 transition-colors mt-2"
            >
              I'll wait until tomorrow
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
