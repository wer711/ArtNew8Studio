import { Heart, Rocket, ExternalLink, Facebook } from 'lucide-react';

export function VisionPanel() {
  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-brand-50 text-brand-600 mb-4 shadow-sm">
          <Rocket size={40} className="text-brand-500" />
        </div>
        <h2 className="text-4xl font-display font-black text-sage-800 tracking-tight">The Future: Artisan Marketplace</h2>
        <p className="text-lg text-sage-600 leading-relaxed">
          These free tools are just the beginning. Our vision at <span className="font-bold text-brand-600">ArtNew8</span> is to build a unified digital marketplace connecting talented crafters directly with buyers who value handmade art.
        </p>
      </div>

      <div className="glass-card p-8 md:p-10 rounded-3xl shadow-sm border border-sage-100">
        <h3 className="text-xl font-display font-bold text-sage-800 mb-4">Why are we building this?</h3>
        <p className="text-sage-600 leading-relaxed mb-8">
          We know that as a paper crafter, you face steep challenges competing on platforms that don't value "handmade" and take massive cuts of your profit. Our upcoming project will provide:
        </p>
        <ul className="space-y-4 text-sage-700 mb-10">
          <li className="flex items-center gap-4 bg-sage-50 p-4 rounded-full">
             <div className="w-3 h-3 rounded-full bg-brand-500 shadow-sm" /> 
             <span className="font-medium">Your own branded digital storefront without listing fees.</span>
          </li>
          <li className="flex items-center gap-4 bg-sage-50 p-4 rounded-full">
             <div className="w-3 h-3 rounded-full bg-brand-500 shadow-sm" /> 
             <span className="font-medium">Advanced tools for inventory management and client commissions.</span>
          </li>
          <li className="flex items-center gap-4 bg-sage-50 p-4 rounded-full">
             <div className="w-3 h-3 rounded-full bg-brand-500 shadow-sm" /> 
             <span className="font-medium">A supportive, vetted community sharing resources and supplies.</span>
          </li>
        </ul>

        <div className="bg-sage-800 text-white p-8 rounded-3xl text-center shadow-lg relative overflow-hidden">
           <div className="absolute top-0 right-0 w-64 h-64 bg-brand-500 rounded-full mix-blend-multiply filter blur-xl opacity-50 opacity-50 opacity-20 transtone-x-1/2 -transtone-y-1/2"></div>
           <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-50 opacity-50 opacity-20 -transtone-x-1/2 transtone-y-1/2"></div>
           
           <Heart className="mx-auto text-brand-400 mb-6 relative z-10" size={40} fill="currentColor" />
           <h4 className="text-2xl font-display font-bold text-white mb-3 relative z-10">Join the Story</h4>
           <p className="text-stone-300 mb-8 max-w-lg mx-auto relative z-10 leading-relaxed">
             We are bootstrapping this entirely to keep it aimed at helping you, not investors. If you want to accelerate the launch of the marketplace and request new tools, please support our server costs.
           </p>
           
           <div className="flex flex-col sm:flex-row gap-4 justify-center relative z-10">
             <a 
               href="https://www.paypal.com/ncp/payment/7TUYHE9XTU6AG" 
               target="_blank" 
               rel="noopener noreferrer"
               className="inline-flex items-center justify-center gap-2 bg-[#0070ba] hover:bg-[#003087] text-white py-4 px-8 rounded-full font-bold transition-all shadow-md hover:shadow-lg transform hover:-transtone-y-0.5"
             >
               Donate via PayPal <ExternalLink size={18} />
             </a>
             <a 
               href="https://www.facebook.com/share/g/1HLBeMbAVJ/" 
               target="_blank" 
               rel="noopener noreferrer"
               className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white py-4 px-6 sm:px-8 rounded-full font-bold transition-all border border-white/10 backdrop-blur-sm"
             >
               <Facebook size={18} /> Join Facebook Group
             </a>
           </div>
        </div>
      </div>

    </div>
  );
}
