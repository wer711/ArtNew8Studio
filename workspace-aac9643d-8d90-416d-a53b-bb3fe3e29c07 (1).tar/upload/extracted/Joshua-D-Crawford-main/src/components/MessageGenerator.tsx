import { useState } from 'react';
import { useDailyLimit } from '../context/DailyLimitContext';
import { useLanguage } from '../context/LanguageContext';
import { Sparkles, Copy, CheckCircle2, Loader2, PenTool, Type, Globe, AlignLeft, User, Heart, MessageSquare } from 'lucide-react';

const OCCASIONS = ['Wedding', 'Birthday', 'Mother\'s Day', 'Father\'s Day', 'Anniversary', 'Thank You', 'Sympathy', 'Graduation', 'New Baby', 'Get Well Soon'];
const RECIPIENTS = ['Friend', 'Mother', 'Father', 'Partner', 'Colleague', 'Sibling', 'Client', 'Teacher', 'Child'];
const TONES = ['Heartfelt', 'Funny', 'Formal', 'Poetic', 'Short & Sweet', 'Inspirational'];
const LANGUAGES = ['English', 'Arabic', 'French', 'Spanish', 'German', 'Italian'];
const LENGTHS = ['Short (1-2 sentences)', 'Medium (3-4 sentences)', 'Long (Paragraph)'];

export function MessageGenerator() {
  const [occasion, setOccasion] = useState(OCCASIONS[1]);
  const [recipient, setRecipient] = useState(RECIPIENTS[0]);
  const [tone, setTone] = useState(TONES[0]);
  const [language, set] = useState(LANGUAGES[0]);
  const [length, setLength] = useState(LENGTHS[1]);
  const [context, setContext] = useState('');
  
  const [generatedMessage, setGeneratedMessage] = useState('');
  const [copied, setCopied] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { consumeAttempt } = useDailyLimit();
  const { t } = useLanguage();

  const handleGenerate = () => {
    consumeAttempt(async () => {
      setIsLoading(true);
      setGeneratedMessage('');
      try {
        const res = await fetch('/api/generate-message', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ occasion, recipient, tone, language, length, context })
        });
        const data = await res.json();
        setGeneratedMessage(data.message || 'Failed to generate message.');
      } catch (err) {
        setGeneratedMessage('An error occurred connecting to the AI service. Please try again.');
      } finally {
        setIsLoading(false);
      }
    });
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-800 tracking-tight flex items-center gap-3">
             <div className="p-2.5 bg-brand-100 rounded-xl">
               <Sparkles className="w-6 h-6 text-brand-600" />
             </div>
             AI Message Studio
          </h2>
          <p className="text-slate-500 mt-2 max-w-2xl leading-relaxed">
            Craft the perfect words for your handmade cards. Personalize occasion, tone, and specific details.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Input Form */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-6">
          <div className="bg-white p-6 md:p-8 rounded-[2rem] shadow-[0_10px_40px_-15px_rgba(0,0,0,0.05)] border border-slate-100/60 ring-1 ring-slate-100 space-y-6 md:space-y-8 relative overflow-hidden">
             {/* Decorative Background Element */}
            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-brand-50 rounded-full blur-xl opacity-50 opacity-50 opacity-60 pointer-events-none"></div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 flex items-center gap-2">
                  <Heart size={16} className="text-brand-500" /> Occasion
                </label>
                <div className="relative">
                  <select 
                    value={occasion} onChange={(e) => setOccasion(e.target.value)}
                    className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-slate-700 rounded-xl px-4 py-3 outline-none appearance-none font-medium transition-all"
                  >
                    {OCCASIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 flex items-center gap-2">
                  <User size={16} className="text-brand-500" /> Recipient
                </label>
                <select 
                  value={recipient} onChange={(e) => setRecipient(e.target.value)}
                  className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-slate-700 rounded-xl px-4 py-3 outline-none appearance-none font-medium transition-all"
                >
                  {RECIPIENTS.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 flex items-center gap-2">
                  <Type size={16} className="text-brand-500" /> Tone
                </label>
                <select 
                  value={tone} onChange={(e) => setTone(e.target.value)}
                  className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-slate-700 rounded-xl px-4 py-3 outline-none appearance-none font-medium transition-all"
                >
                  {TONES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 flex items-center gap-2">
                  <Globe size={16} className="text-brand-500" /> 
                </label>
                <select 
                  value={language} onChange={(e) => set(e.target.value)}
                  className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-slate-700 rounded-xl px-4 py-3 outline-none appearance-none font-medium transition-all"
                >
                  {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
            </div>

            <div className="space-y-2 relative z-10">
              <label className="text-sm font-bold text-slate-700 flex items-center gap-2">
                <AlignLeft size={16} className="text-brand-500" /> Message Length
              </label>
              <div className="flex flex-wrap sm:flex-nowrap gap-2 bg-slate-100 p-1.5 rounded-2xl">
                 {LENGTHS.map(l => (
                   <button 
                    key={l}
                    onClick={() => setLength(l)}
                    className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                      length === l 
                        ? 'bg-white text-brand-700 shadow-sm ring-1 ring-black/5' 
                        : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'
                    }`}
                   >
                     {l.split(' (')[0]}
                   </button>
                 ))}
               </div>
            </div>

            <div className="space-y-2 relative z-10">
              <label className="text-sm font-bold text-slate-700 flex items-center gap-2 flex-wrap">
                <MessageSquare size={16} className="text-brand-500" /> 
                Specific Details 
                <span className="text-slate-400 font-normal text-xs ml-auto">(Names, inside jokes, hobbies)</span>
              </label>
              <textarea 
                value={context} onChange={(e) => setContext(e.target.value)}
                placeholder="e.g. Include that we've been friends for 10 years, and mention her dog Max."
                className="w-full bg-slate-50 border-0 ring-1 ring-slate-200 focus:bg-white focus:ring-2 focus:ring-brand-500 text-slate-700 rounded-xl px-5 py-4 outline-none font-medium transition-all resize-none h-24"
              />
            </div>

            <button 
              onClick={handleGenerate}
              disabled={isLoading}
              className="w-full bg-brand-600 hover:bg-brand-500 text-white shadow-[0_4px_20px_-5px_rgba(79,70,229,0.5)] py-4 rounded-xl font-bold transition-all disabled:opacity-70 disabled:transform-none disabled:cursor-not-allowed flex items-center justify-center gap-3 relative z-10 text-sm sm:text-base cursor-pointer"
            >
              {isLoading ? <Loader2 size={20} className="animate-spin" /> : <Sparkles size={20} />}
              {isLoading ? 'Drafting masterpiece...' : 'Generate AI Message'}
            </button>
          </div>
        </div>

        {/* Output Panel */}
        <div className="lg:col-span-5 xl:col-span-4 flex flex-col gap-6">
          <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2rem] shadow-xl relative overflow-hidden flex-1 flex flex-col items-center justify-center min-h-[400px]">
             {/* Visual Flair */}
             <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-400 via-purple-500 to-brand-600"></div>
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-brand-500/10 blur-[100px] rounded-full pointer-events-none"></div>

             {isLoading ? (
                <div className="flex flex-col items-center text-brand-400 gap-4 relative z-10">
                  <div className="p-4 bg-brand-900/50 rounded-full border border-brand-500/30">
                     <PenTool size={36} className="animate-bounce" />
                  </div>
                  <span className="text-sm font-bold tracking-widest uppercase animate-pulse">Writing thoughts...</span>
                </div>
             ) : generatedMessage ? (
               <div className="w-full h-full flex flex-col justify-between relative z-10 animate-in zoom-in-95 duration-500 fade-in">
                 <div className="flex-1 flex flex-col justify-center items-center text-center">
                    <p className="text-xl md:text-2xl font-display font-medium text-white leading-relaxed text-balance" style={{ direction: language === 'Arabic' ? 'rtl' : 'ltr' }}>
                      "{generatedMessage}"
                    </p>
                 </div>
                 
                 <div className="mt-8 flex justify-center">
                   <button 
                     onClick={handleCopy}
                     className="bg-white/10 hover:bg-white/20 text-white rounded-full px-6 py-3 font-bold flex items-center gap-2 border border-white/10 transition-all font-display text-sm tracking-wide"
                   >
                     {copied ? <CheckCircle2 size={18} className="text-green-400" /> : <Copy size={18} />}
                     {copied ? 'COPIED!' : 'COPY TO CLIPBOARD'}
                   </button>
                 </div>
               </div>
             ) : (
               <div className="text-center relative z-10 space-y-4">
                 <div className="inline-flex items-center justify-center p-4 bg-slate-800 rounded-full text-slate-500 mb-2">
                   <MessageSquare size={32} />
                 </div>
                 <p className="text-slate-400 max-w-[200px] mx-auto text-sm leading-relaxed">
                   Set your preferences and click generate to create a beautifully written custom greeting.
                 </p>
               </div>
             )}
          </div>
        </div>

      </div>
    </div>
  );
}
