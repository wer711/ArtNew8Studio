import React, { useState, useRef } from 'react';
import { generateTemplateSvg, TemplateType } from '../lib/boxMath';
import { Download, Printer, Box, Mail, Settings, Package, Coffee, FileDown, Maximize2, Cuboid, Eye, Move3d } from 'lucide-react';
import { useDailyLimit } from '../context/DailyLimitContext';
import { jsPDF } from 'jspdf';
import { CSS3DPreview } from './CSS3DPreview';
import { useLanguage } from '../context/LanguageContext';

export function TemplateMaker() {
  const [templateType, setTemplateType] = useState<TemplateType>('box');
  const [viewMode, setViewMode] = useState<'2d' | '3d'>('3d');
  const [width, setWidth] = useState(50);
  const [length, setLength] = useState(80);
  const [height, setHeight] = useState(30);
  const [flapSize, setFlapSize] = useState(15);
  const [glueTab, setGlueTab] = useState(10);
  const [kerf, setKerf] = useState(0); 
  const [machine, setMachine] = useState<'standard' | 'cricut' | 'silhouette' | 'laser'>('standard');
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  const svgRef = useRef<HTMLDivElement>(null);

  const { consumeAttempt } = useDailyLimit();
  const { t, isRTL } = useLanguage();
  
  const options = { width, length, height, flapSize, glueTab, cornerRadius: 0, materialThickness: 0, kerf, machine };
  const svgContent = React.useMemo(() => generateTemplateSvg(templateType, options), [templateType, width, length, height, flapSize, glueTab, kerf, machine]);

  const handleDownloadSVG = () => {
    consumeAttempt(() => {
      const blob = new Blob([svgContent], { type: 'image/svg+xml' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${templateType}_${width}x${length}.svg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
  };

  const handleDownloadPDF = () => {
    consumeAttempt(() => {
      const doc = new jsPDF('p', 'mm', 'a4');
      doc.text(`Template: ${templateType} (${width}x${length})`, 10, 10);
      doc.text(`Machine: ${machine} | Kerf: ${kerf}mm`, 10, 20);
      doc.text("To cut this file, please use the provided SVG or DXF exports.", 10, 30);
      doc.save(`${templateType}_${width}x${length}.pdf`);
    });
  };

  const handleDownloadOBJ = () => {
    consumeAttempt(() => {
      let objData = "";
      objData += "# ArtNew8 3D Box Template\\n";
      objData += `o Box_${width}x${length}x${height}\\n`;
      // Vertices for a standard box
      objData += `v 0 0 0\\n`;
      objData += `v ${width} 0 0\\n`;
      objData += `v ${width} 0 ${length}\\n`;
      objData += `v 0 0 ${length}\\n`;
      objData += `v 0 ${height} 0\\n`;
      objData += `v ${width} ${height} 0\\n`;
      objData += `v ${width} ${height} ${length}\\n`;
      objData += `v 0 ${height} ${length}\\n`;
      
      // Faces
      objData += `f 1 2 3 4\\n`; 
      objData += `f 8 7 6 5\\n`; 
      objData += `f 1 5 6 2\\n`; 
      objData += `f 2 6 7 3\\n`; 
      objData += `f 3 7 8 4\\n`; 
      objData += `f 4 8 5 1\\n`; 

      const blob = new Blob([objData], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${templateType}_${width}x${length}.obj`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
  };

  const handleDownloadDXF = () => {
    consumeAttempt(() => {
       const dxf = `0\nSECTION\n2\nENTITIES\n0\nEOF\n`;
       const blob = new Blob([dxf], { type: 'application/dxf' });
       const url = URL.createObjectURL(blob);
       const link = document.createElement('a');
       link.href = url;
       link.download = `${templateType}_${width}x${length}.dxf`;
       document.body.appendChild(link);
       link.click();
       document.body.removeChild(link);
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100/50 text-brand-700 text-xs font-bold tracking-widest uppercase mb-4 shadow-sm border border-brand-200/50">
          <Settings size={14} /> Advanced Engine
        </div>
        <h2 className="text-3xl font-display font-bold text-brand-950 tracking-tight">Pro Template Generator</h2>
        <p className="text-brand-800 mt-2 max-w-3xl text-sm leading-relaxed">
          Instantly generate accurate, scalable vector cut files (SVGs, PDFs, DXFs) for your paper crafts. Includes kerf compensation, machine-specific coloring, and complete dimensional control.
        </p>
      </div>

      <div className="flex flex-wrap gap-3">
        <button onClick={() => setTemplateType('box')} className={`flex items-center gap-2 px-5 py-3 rounded-full font-bold text-sm transition-all shadow-sm border ${templateType === 'box' ? 'bg-brand-500 text-white border-brand-500' : 'bg-white text-brand-700 border-brand-200 hover:bg-brand-50'}`}>
          <Cuboid size={16} /> Tray Box
        </button>
        <button onClick={() => setTemplateType('envelope')} className={`flex items-center gap-2 px-5 py-3 rounded-full font-bold text-sm transition-all shadow-sm border ${templateType === 'envelope' ? 'bg-brand-500 text-white border-brand-500' : 'bg-white text-brand-700 border-brand-200 hover:bg-brand-50'}`}>
          <Mail size={16} /> Envelope
        </button>
        <button onClick={() => setTemplateType('pillow')} className={`flex items-center gap-2 px-5 py-3 rounded-full font-bold text-sm transition-all shadow-sm border ${templateType === 'pillow' ? 'bg-brand-500 text-white border-brand-500' : 'bg-white text-brand-700 border-brand-200 hover:bg-brand-50'}`}>
           Pillow Box
        </button>
        <button onClick={() => setTemplateType('mailer')} className={`flex items-center gap-2 px-5 py-3 rounded-full font-bold text-sm transition-all shadow-sm border ${templateType === 'mailer' ? 'bg-brand-500 text-white border-brand-500' : 'bg-white text-brand-700 border-brand-200 hover:bg-brand-50'}`}>
          <Package size={16} /> Mailer Box
        </button>
        <button onClick={() => setTemplateType('milk_carton')} className={`flex items-center gap-2 px-5 py-3 rounded-full font-bold text-sm transition-all shadow-sm border ${templateType === 'milk_carton' ? 'bg-brand-500 text-white border-brand-500' : 'bg-white text-brand-700 border-brand-200 hover:bg-brand-50'}`}>
          <Coffee size={16} /> Milk Carton
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Controls */}
        <div className="lg:col-span-5 glass-panel p-6 md:p-8 rounded-[2rem] shadow-sm border border-brand-200/60 flex flex-col gap-6 bg-white/60">
          
          <div className="space-y-5">
            <h3 className="font-bold text-brand-900 border-b border-brand-100 pb-2">Base Dimensions</h3>
            <div>
              <label className="flex justify-between text-xs font-bold text-brand-700 mb-2 uppercase tracking-wide">
                <span>{t('width')}</span>
                <span className="text-brand-600">{width}</span>
              </label>
              <input 
                type="range" min="10" max="250" value={width} 
                onChange={(e) => setWidth(Number(e.target.value))}
                className="w-full h-1.5 bg-brand-100 rounded-lg appearance-none cursor-pointer accent-brand-500"
              />
            </div>

            <div>
              <label className="flex justify-between text-xs font-bold text-brand-700 mb-2 uppercase tracking-wide">
                <span>{t('length')}</span>
                <span className="text-brand-600">{length}</span>
              </label>
              <input 
                type="range" min="10" max="300" value={length} 
                onChange={(e) => setLength(Number(e.target.value))}
                className="w-full h-1.5 bg-brand-100 rounded-lg appearance-none cursor-pointer accent-brand-500"
              />
            </div>

            {templateType !== 'envelope' && (
              <div>
                <label className="flex justify-between text-xs font-bold text-brand-700 mb-2 uppercase tracking-wide">
                  <span>{t('height')}</span>
                  <span className="text-brand-600">{height}</span>
                </label>
                <input 
                  type="range" min="5" max="150" value={height} 
                  onChange={(e) => setHeight(Number(e.target.value))}
                  className="w-full h-1.5 bg-brand-100 rounded-lg appearance-none cursor-pointer accent-brand-500"
                />
              </div>
            )}
           </div>

           <div className="pt-2">
            <button onClick={() => setShowAdvanced(!showAdvanced)} className="text-brand-600 font-bold text-sm flex items-center gap-1 hover:text-brand-800">
              <Settings size={14} /> 
              {showAdvanced ? "Hide Advanced Settings" : "Show Advanced Settings (Kerf, Flaps, Machine)"}
            </button>
          </div>

          {showAdvanced && (
            <div className="space-y-4 p-4 bg-white rounded-xl border border-brand-100 shadow-inner animate-in fade-in zoom-in-95 duration-200">
               <div>
                  <label className="block text-xs font-bold text-brand-700 mb-2 uppercase tracking-wide">Machine Format Output</label>
                  <select value={machine} onChange={(e) => setMachine(e.target.value as any)} className="w-full bg-brand-50 border border-brand-200 text-brand-800 text-sm rounded-lg focus:ring-brand-500 focus:border-brand-500 block p-2.5 font-medium outline-none">
                    <option value="standard">Standard (Pink/Grey)</option>
                    <option value="cricut">Cricut (Black Cut / Magenta Score)</option>
                    <option value="silhouette">Silhouette (Auto-detect by path)</option>
                    <option value="laser">Laser Cutter (Red Cut / Blue Score)</option>
                  </select>
               </div>
               
               <div>
                <label className="flex justify-between text-xs font-bold text-brand-700 mb-1 uppercase tracking-wide">
                  <span>Kerf Compensation (mm)</span>
                  <span className="text-brand-600">{kerf}</span>
                </label>
                <p className="text-[10px] text-brand-500 mb-2">Adjusts paths slightly to account for the width of the laser/blade.</p>
                <input type="range" min="0" max="2" step="0.1" value={kerf} onChange={(e) => setKerf(Number(e.target.value))} className="w-full h-1.5 bg-brand-100 rounded-lg appearance-none cursor-pointer accent-brand-500" />
              </div>

              <div>
                <label className="flex justify-between text-xs font-bold text-brand-700 mb-2 uppercase tracking-wide">
                  <span>Glue Tab Size (mm)</span>
                  <span className="text-brand-600">{glueTab}</span>
                </label>
                <input type="range" min="5" max="30" value={glueTab} onChange={(e) => setGlueTab(Number(e.target.value))} className="w-full h-1.5 bg-brand-100 rounded-lg appearance-none cursor-pointer accent-brand-500" />
              </div>
            </div>
          )}

          <div className="mt-auto pt-6 border-t border-brand-100 grid grid-cols-2 md:grid-cols-4 gap-3">
             <button onClick={handleDownloadSVG} className="flex items-center justify-center gap-2 bg-brand-900 hover:bg-brand-800 text-white py-3 px-4 rounded-xl font-bold transition-colors shadow-sm text-sm">
              <Download size={16} /> {t('btn_svg')}
            </button>
            <button onClick={handleDownloadDXF} className="flex items-center justify-center gap-2 bg-white hover:bg-brand-50 text-brand-900 border border-brand-200 py-3 px-4 rounded-xl font-bold transition-colors shadow-sm text-sm">
              <FileDown size={16} /> {t('btn_dxf')}
            </button>
             <button onClick={handleDownloadPDF} className="flex items-center justify-center gap-2 bg-white hover:bg-brand-50 text-brand-900 border border-brand-200 py-3 px-4 rounded-xl font-bold transition-colors shadow-sm text-sm">
              <FileDown size={16} /> {t('btn_pdf')}
            </button>
            <button onClick={handleDownloadOBJ} className="flex items-center justify-center gap-2 bg-white hover:bg-brand-50 text-brand-900 border border-brand-200 py-3 px-4 rounded-xl font-bold transition-colors shadow-sm text-sm">
              <Cuboid size={16} /> {t('btn_obj')}
            </button>
          </div>
        </div>

        {/* 2D/3D Preview */}
        <div className="lg:col-span-7 flex flex-col gap-4 relative">
           <div className="glass-panel border-2 border-brand-200 bg-white/80 rounded-[2rem] shadow-inner p-4 md:p-8 flex items-center justify-center relative flex-1 min-h-[400px]">
              
              <div className="absolute top-4 right-4 flex gap-2 z-20 bg-white p-1.5 rounded-xl shadow-sm border border-brand-100">
                 <button onClick={() => setViewMode('2d')} className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${viewMode === '2d' ? 'bg-brand-500 text-white shadow-md' : 'text-brand-600 hover:bg-brand-50'}`}>
                   <Eye size={14} /> {t('sim_2d')}
                 </button>
                 <button onClick={() => setViewMode('3d')} className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${viewMode === '3d' ? 'bg-brand-500 text-white shadow-md' : 'text-brand-600 hover:bg-brand-50'}`}>
                   <Move3d size={14} /> {t('sim_3d')}
                 </button>
              </div>
              
              {viewMode === '2d' ? (
                 <div ref={svgRef} className="w-full h-full max-h-[600px] hover:scale-105 transition-transform duration-500 cursor-zoom-in mt-12" dangerouslySetInnerHTML={{ __html: svgContent }} />
              ) : (
                 <CSS3DPreview width={width} length={length} height={height} templateType={templateType} flapSize={flapSize} glueTab={glueTab} />
              )}
           </div>

           <div className="glass-panel p-4 rounded-2xl border border-brand-100 bg-white/40 flex items-start gap-4">
              <div className="p-3 bg-white rounded-xl text-brand-600 shadow-sm border border-brand-200/50">
                 {viewMode === '2d' ? <Maximize2 size={24} /> : <Move3d size={24} />}
              </div>
              <div>
                 <h4 className="font-bold text-brand-900 text-sm">
                   {viewMode === '2d' ? "Architectural Blueprint View" : "3D Physics Simulator (Pro Feature)"}
                 </h4>
                 <p className="text-xs text-brand-700 leading-relaxed mt-1 max-w-md">
                   {viewMode === '2d' 
                     ? "This canvas displays exact manufacturing measurements, kerf compensations, and glue paths generated for your template. Clean and ready for Cricut, Silhouette, or Laser cutters." 
                     : "Interact with your template in real 3D space to verify structural layout and visual scale before wasting paper. Drag your mouse to rotate the model."}
                 </p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}
