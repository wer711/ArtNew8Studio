import { Heart } from 'lucide-react';
import { useDailyLimit } from '../context/DailyLimitContext';

export function DonationBanner() {
  const { attemptsLeft, isAdmin } = useDailyLimit();
  
  if (attemptsLeft === 0 && !isAdmin) return null; 
  
  return (
    <div className="bg-sage-900 text-white px-4 py-3 sm:px-6 lg:px-8 text-center text-sm font-medium flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-6 shadow-md z-20 relative">
      <span className="flex items-center gap-2">
        <Heart size={16} fill="currentColor" className="text-brand-400 animate-pulse" />
        <span className="text-sage-100">
          These pro tools are free thanks to you! 
          {!isAdmin && <strong className="text-white px-1 font-bold bg-white/10 rounded-md py-0.5 mx-1">{attemptsLeft}</strong>}
          {!isAdmin && 'generations left today.'}
          {isAdmin && <span className="ml-2 font-bold text-brand-300">(Admin bypass active)</span>}
        </span>
      </span>
      <a 
        href="https://www.paypal.com/ncp/payment/7TUYHE9XTU6AG" 
        target="_blank" 
        rel="noopener noreferrer"
        className="inline-flex py-1.5 px-5 bg-brand-500 hover:bg-brand-600 rounded-full text-white text-xs font-bold transition-colors shadow-sm"
      >
        Support Us ☕
      </a>
    </div>
  );
}
