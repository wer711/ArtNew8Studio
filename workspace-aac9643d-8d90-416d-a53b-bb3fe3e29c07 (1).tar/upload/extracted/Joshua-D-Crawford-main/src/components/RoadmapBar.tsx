import { PenTool, Users, Lightbulb, Store, Heart, ExternalLink } from 'lucide-react';

export function RoadmapBar() {
  return (
    <div className="w-full mt-24 mb-24 animate-in fade-in slide-in-from-bottom-8 duration-700 relative">
      <div className="max-w-6xl mx-auto px-4 z-10 relative">
        <div className="text-center mb-16">
           <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-100 text-brand-700 text-xs font-bold tracking-widest uppercase mb-6 shadow-sm border border-brand-200">
            <Store size={14} />
            The Artisan Journey
          </div>
          <h3 className="text-4xl md:text-5xl font-display font-black text-slate-800 mb-6 tracking-tight">
            Our Roadmap to a Fair Marketplace
          </h3>
          <p className="text-slate-600 text-lg max-w-2xl mx-auto leading-relaxed">
            We are actively building the ultimate zero-fee digital marketplace. These free tools are just the beginning. Join us as we build a platform that truly connects crafters with buyers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
          {/* Decorative background line connecting cards */}
          <div className="hidden md:block absolute top-[28%] left-[12%] right-[12%] h-1 bg-slate-200 -z-10 rounded-full"></div>
          <div className="hidden md:block absolute top-[28%] left-[12%] w-[15%] h-1 bg-brand-500 -z-10 rounded-full"></div>

          {/* Phase 1 */}
          <div className="bg-white p-6 md:p-8 rounded-[2rem] border-2 border-brand-500 shadow-[0_10px_30px_-15px_rgba(79,70,229,0.3)] relative group transform -translate-y-2 transition-all">
            <div className="absolute -top-3 right-6 bg-brand-500 text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full shadow-md animate-pulse">
              You Are Here
            </div>
            <div className="w-16 h-16 rounded-2xl bg-brand-100 flex items-center justify-center text-brand-600 mb-6 shadow-sm">
              <PenTool size={28} />
            </div>
            <h4 className="font-display font-black text-xl text-slate-800 mb-3 tracking-tight">1. The Free Studio</h4>
            <p className="text-sm text-slate-600 leading-relaxed font-medium">
              Equipping makers with professional-grade crafting utilities—free of charge. Building trust and delivering immediate value.
            </p>
          </div>
          
          {/* Phase 2 */}
          <div className="bg-slate-50 p-6 md:p-8 rounded-[2rem] border border-slate-200 shadow-sm relative group hover:-translate-y-1 transition-all opacity-80 hover:opacity-100">
            <div className="w-16 h-16 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-400 mb-6 shadow-sm group-hover:text-brand-500 transition-colors">
              <Users size={28} />
            </div>
            <h4 className="font-display font-bold text-lg text-slate-800 mb-3 tracking-tight">2. Community Shaping</h4>
            <p className="text-sm text-slate-600 leading-relaxed">
              Launching exclusive beta access. Crafters will directly vote and shape the marketplace mechanics.
            </p>
          </div>

          {/* Phase 3 */}
          <div className="bg-slate-50 p-6 md:p-8 rounded-[2rem] border border-slate-200 shadow-sm relative group hover:-translate-y-1 transition-all opacity-70 hover:opacity-100">
            <div className="w-16 h-16 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-400 mb-6 shadow-sm group-hover:text-amber-500 transition-colors">
              <Lightbulb size={28} />
            </div>
            <h4 className="font-display font-bold text-lg text-slate-800 mb-3 tracking-tight">3. Platform Beta</h4>
            <p className="text-sm text-slate-600 leading-relaxed">
              Early access to the unified storefront. A fair ecosystem providing direct client commissions and inventory management.
            </p>
          </div>

          {/* Phase 4 */}
          <div className="bg-slate-50 p-6 md:p-8 rounded-[2rem] border border-slate-200 shadow-sm relative group hover:-translate-y-1 transition-all opacity-60 hover:opacity-100">
             <div className="w-16 h-16 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-400 mb-6 shadow-sm group-hover:text-green-500 transition-colors">
              <Store size={28} />
            </div>
            <h4 className="font-display font-bold text-lg text-slate-800 mb-3 tracking-tight">4. Grand Launch</h4>
            <p className="text-sm text-slate-600 leading-relaxed">
              The ultimate zero-fee digital marketplace opens to the public, connecting talented crafters directly with buyers globally.
            </p>
          </div>
        </div>

        {/* Integrated Donation Banner */}
        <div className="mt-16 max-w-3xl mx-auto bg-gradient-to-br from-brand-900 to-indigo-950 p-8 md:p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-brand-500/30 rounded-full blur-xl opacity-50 opacity-50 group-hover:bg-brand-500/40 transition-all duration-700"></div>
          <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 bg-purple-500/30 rounded-full blur-xl opacity-50 opacity-50 group-hover:bg-purple-500/40 transition-all duration-700"></div>
          
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
            <div>
              <h4 className="text-2xl font-display font-bold text-white mb-3 flex items-center justify-center md:justify-start gap-3">
                 <Heart className="text-brand-400 fill-brand-400 animate-pulse" /> 
                 Support Our Mission
              </h4>
              <p className="text-indigo-200 text-sm max-w-lg leading-relaxed">
                We provide these professional tools entirely for free to help artisans grow. If you find them valuable, consider supporting our server costs and the development of the upcoming marketplace. Every coffee helps!
              </p>
            </div>
            <a 
              href="https://www.paypal.com/ncp/payment/7TUYHE9XTU6AG" 
              target="_blank" 
              rel="noopener noreferrer"
              className="shrink-0 flex items-center justify-center gap-2 bg-brand-500 hover:bg-brand-400 text-white font-bold py-4 px-8 rounded-full shadow-[0_4px_20px_-5px_rgba(79,70,229,0.6)] transform hover:-translate-y-1 transition-all"
            >
              Donate via PayPal <ExternalLink size={18} />
            </a>
          </div>
        </div>

      </div>
    </div>
  );
}
