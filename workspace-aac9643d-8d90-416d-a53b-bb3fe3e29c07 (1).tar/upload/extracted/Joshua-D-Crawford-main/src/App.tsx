import React, { useState } from "react";
import { TemplateMaker } from "./components/TemplateMaker";
import { PricingCalculator } from "./components/PricingCalculator";
import { MessageGenerator } from "./components/MessageGenerator";
import { ColorPalette } from "./components/ColorPalette";
import { VisionPanel } from "./components/VisionPanel";
import { DonationBanner } from "./components/DonationBanner";
import { LimitModal } from "./components/LimitModal";
import { RoadmapBar } from "./components/RoadmapBar";
import { DailyLimitProvider, useDailyLimit } from "./context/DailyLimitContext";
import { useLanguage } from "./context/LanguageContext";
import {
  BoxSelect,
  Calculator,
  HeartHandshake,
  Scissors,
  MessageSquareHeart,
  Palette,
  Store,
  Globe,
} from "lucide-react";

function AdminTrigger({ children }: { children: React.ReactNode }) {
  const { enableAdmin } = useDailyLimit();
  const [clicks, setClicks] = useState(0);

  const handleClick = () => {
    const newClicks = clicks + 1;
    setClicks(newClicks);
    if (newClicks >= 5) {
      enableAdmin();
      setClicks(0);
    }
  };

  return (
    <div onClick={handleClick} className="cursor-pointer">
      {children}
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<
    "template" | "pricing" | "messages" | "colors" | "vision"
  >("template");
  const [isLimitModalOpen, setIsLimitModalOpen] = useState(false);
  const { language, setLanguage, t, isRTL } = useLanguage();

  return (
    <DailyLimitProvider onLimitReached={() => setIsLimitModalOpen(true)}>
      <div className={`min-h-screen flex flex-col bg-sage-50 font-sans selection:bg-brand-200 ${isRTL ? 'rtl' : 'ltr'}`}>
        <DonationBanner />

        {/* Header */}
        <header className="glass-panel sticky top-0 z-30 w-full px-4 sm:px-6 lg:px-8 shadow-sm">
          <div className="max-w-[90rem] mx-auto flex items-center justify-between h-16 sm:h-20 transition-all">
            <AdminTrigger>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-sage-800 rounded-xl flex items-center justify-center text-white shadow-md transform transition hover:scale-105">
                  <Scissors size={20} className="text-brand-300" />
                </div>
                <h1 className="text-2xl sm:text-3xl font-display font-black tracking-tight text-brand-600">
                  {t('app_title')}
                  <span className="font-sans font-medium text-sage-500 hidden sm:inline ml-2 text-lg">
                    {t('app_subtitle')}
                  </span>
                </h1>
              </div>
            </AdminTrigger>

            <nav className={`flex items-center space-x-2 sm:space-x-4 ${isRTL ? 'space-x-reverse' : ''}`}>
              <div className="relative group flex items-center">
                <Globe size={18} className="text-sage-500 absolute left-3 pointer-events-none group-hover:text-brand-500 transition-colors" />
                <select 
                  value={language}
                  onChange={(e) => setLanguage(e.target.value as any)}
                  className="pl-9 pr-8 py-2 appearance-none bg-white/50 hover:bg-white border border-sage-200 text-sage-600 font-bold rounded-full text-xs outline-none cursor-pointer focus:ring-2 focus:ring-brand-200 transition-all text-center"
                >
                  <option value="en">English</option>
                  <option value="ar">العربية</option>
                  <option value="fr">Français</option>
                </select>
              </div>

              <a
                href="https://www.artnew8.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 text-sage-500 hover:text-brand-500 transition-colors hidden sm:block font-medium text-sm"
              >
                {t('nav_blog')}
              </a>
              <button
                onClick={() => setActiveTab("vision")}
                className="flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-2.5 rounded-full bg-brand-50 text-brand-600 font-bold hover:bg-brand-100 transition-all border border-brand-200/50 hover:shadow-sm text-sm"
              >
                <Store size={18} />
                <span className="hidden sm:inline">{t('nav_marketplace')}</span>
              </button>
            </nav>
          </div>
        </header>

        <div className="flex-1 flex max-w-[90rem] w-full mx-auto relative">
          {/* Sidebar Nav */}
          <aside className="w-72 hidden md:flex flex-col border-r border-sage-200/60 bg-white/30 backdrop-blur-md min-h-[calc(100vh-5rem)] py-8 px-5 relative shrink-0">
            <nav className="space-y-3 sticky top-28">
              <button
                onClick={() => setActiveTab("template")}
                className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl font-bold transition-all duration-300 ${
                  activeTab === "template"
                    ? "bg-sage-800 text-white shadow-lg scale-105 origin-left"
                    : "text-sage-600 hover:bg-white hover:text-sage-900 border border-transparent hover:border-sage-200/50 shadow-sm"
                }`}
              >
                <BoxSelect
                  size={22}
                  className={
                    activeTab === "template"
                      ? "text-brand-300"
                      : "text-sage-400"
                  }
                />
                {t('nav_template')}
              </button>

              <button
                onClick={() => setActiveTab("pricing")}
                className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl font-bold transition-all duration-300 ${
                  activeTab === "pricing"
                    ? "bg-sage-800 text-white shadow-lg scale-105 origin-left"
                    : "text-sage-600 hover:bg-white hover:text-sage-900 border border-transparent hover:border-sage-200/50 shadow-sm"
                }`}
              >
                <Calculator
                  size={22}
                  className={
                    activeTab === "pricing" ? "text-brand-300" : "text-sage-400"
                  }
                />
                {t('nav_pricing')}
              </button>

              <button
                onClick={() => setActiveTab("messages")}
                className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl font-bold transition-all duration-300 ${
                  activeTab === "messages"
                    ? "bg-sage-800 text-white shadow-lg scale-105 origin-left"
                    : "text-sage-600 hover:bg-white hover:text-sage-900 border border-transparent hover:border-sage-200/50 shadow-sm"
                }`}
              >
                <MessageSquareHeart
                  size={22}
                  className={
                    activeTab === "messages"
                      ? "text-brand-300"
                      : "text-sage-400"
                  }
                />
                {t('nav_messages')}
              </button>

              <button
                onClick={() => setActiveTab("colors")}
                className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl font-bold transition-all duration-300 ${
                  activeTab === "colors"
                    ? "bg-sage-800 text-white shadow-lg scale-105 origin-left"
                    : "text-sage-600 hover:bg-white hover:text-sage-900 border border-transparent hover:border-sage-200/50 shadow-sm"
                }`}
              >
                <Palette
                  size={22}
                  className={
                    activeTab === "colors" ? "text-brand-300" : "text-sage-400"
                  }
                />
                {t('nav_colors')}
              </button>

              <div className="pt-8 mt-8 border-t border-sage-200/60 space-y-2">
                <button
                  onClick={() => setActiveTab("vision")}
                  className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl font-bold transition-all duration-300 ${
                    activeTab === "vision"
                      ? "bg-gradient-to-r from-brand-400 to-brand-500 text-white shadow-lg scale-105 origin-left"
                      : "bg-brand-50/50 text-brand-600 hover:bg-brand-50 border border-brand-100 hover:shadow-sm"
                  }`}
                >
                  <HeartHandshake
                    size={22}
                    className={
                      activeTab === "vision" ? "text-white" : "text-brand-500"
                    }
                  />
                  {t('nav_vision')}
                </button>
              </div>
            </nav>
          </aside>

          {/* Main Content Area */}
          <main className="flex-1 p-4 sm:p-8 lg:p-12 w-full mx-auto min-w-0 flex flex-col items-center">
            {/* Mobile Nav */}
            <div className={`md:hidden flex gap-2 mb-8 overflow-x-auto pb-4 scrollbar-hide -mx-4 px-4 sm:mx-0 sm:px-0 w-full scroll-smooth ${isRTL ? 'flex-row-reverse' : ''}`}>
              <button
                onClick={() => setActiveTab("template")}
                className={`flex-shrink-0 px-6 py-3 rounded-full text-sm font-bold transition-all shadow-sm ${activeTab === "template" ? "bg-sage-800 text-white" : "glass-panel text-sage-600 border-none"}`}
              >
                {t('mob_template')}
              </button>
              <button
                onClick={() => setActiveTab("pricing")}
                className={`flex-shrink-0 px-6 py-3 rounded-full text-sm font-bold transition-all shadow-sm ${activeTab === "pricing" ? "bg-sage-800 text-white" : "glass-panel text-sage-600 border-none"}`}
              >
                {t('mob_pricing')}
              </button>
              <button
                onClick={() => setActiveTab("messages")}
                className={`flex-shrink-0 px-6 py-3 rounded-full text-sm font-bold transition-all shadow-sm ${activeTab === "messages" ? "bg-sage-800 text-white" : "glass-panel text-sage-600 border-none"}`}
              >
                {t('mob_messages')}
              </button>
              <button
                onClick={() => setActiveTab("colors")}
                className={`flex-shrink-0 px-6 py-3 rounded-full text-sm font-bold transition-all shadow-sm ${activeTab === "colors" ? "bg-sage-800 text-white" : "glass-panel text-sage-600 border-none"}`}
              >
                {t('mob_colors')}
              </button>
              <button
                onClick={() => setActiveTab("vision")}
                className={`flex-shrink-0 px-6 py-3 rounded-full text-sm font-bold transition-all shadow-sm ${activeTab === "vision" ? "bg-brand-500 text-white" : "glass-panel text-sage-600 border-none"}`}
              >
                {t('mob_vision')}
              </button>
            </div>

            {/* View Rendering */}
            <div className="w-full max-w-7xl">
              {activeTab === "template" && <TemplateMaker />}
              {activeTab === "pricing" && <PricingCalculator />}
              {activeTab === "messages" && <MessageGenerator />}
              {activeTab === "colors" && <ColorPalette />}
              {activeTab === "vision" && <VisionPanel />}

              <RoadmapBar />
            </div>
          </main>
        </div>

        <LimitModal
          isOpen={isLimitModalOpen}
          onClose={() => setIsLimitModalOpen(false)}
        />
      </div>
    </DailyLimitProvider>
  );
}
