import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'en' | 'ar' | 'fr';

interface Translations {
  [key: string]: {
    [key: string]: string;
  };
}

const translations: Translations = {
  en: {
    app_title: "ArtNew8",
    app_subtitle: "Studio",
    nav_template: "Template Maker",
    nav_pricing: "Pricing Calculator",
    nav_messages: "Message Generator",
    nav_colors: "Color Palettes",
    nav_vision: "Artisan Marketplace",
    nav_marketplace: "Our Marketplace",
    nav_blog: "Blog",
    mob_template: "Templates",
    mob_pricing: "Pricing",
    mob_messages: "Messages",
    mob_colors: "Colors",
    mob_vision: "Vision",
    param_settings: "Parameters",
    width: "Width (mm)",
    length: "Length (mm)",
    height: "Height (mm)",
    material_thickness: "Material Thickness",
    template_type: "Template Structure",
    sim_2d: "Architectural Blueprint View",
    sim_3d: "3D Physics Simulator",
    flap: "Flap Size",
    glue_tab: "Glue Tab Edge",
    kerf: "Kerf (Laser cut)",
    box_standard: "Standard Cardboard Box",
    box_milk: "Milk Carton Style",
    btn_svg: "SVG",
    btn_dxf: "DXF",
    btn_pdf: "PDF",
    btn_obj: "OBJ (3D)",
    pricing_title: "Pricing Calculator",
    profit_margin: "Desired Profit Margin",
    calc_summary: "Cost Breakdown",
    p_materials: "Raw Materials",
    p_labor: "Labor & Time",
    p_overhead: "Overhead (Packaging, Shipping)",
    p_fees: "Marketplace Fees",
    p_base: "Base Cost (Breakeven)",
    p_wholesale: "Wholesale Price",
    p_retail: "Retail Price",
    p_profit: "Net Profit",
    btn_save: "Download Pricing Summary",
    msg_title: "Professional Message Generator",
    msg_subtitle: "Generate polite, structured client communications instantly.",
    msg_topic: "Message Topic",
    msg_recipient: "Recipient Name",
    msg_tone: "Message Tone",
    msg_tone_prof: "Professional",
    msg_tone_warm: "Warm & Friendly",
    msg_tone_firm: "Firm & Direct",
    msg_context: "Additional Context (Optional)",
    msg_btn_gen: "Generate Message",
    msg_btn_copy: "Copy to Clipboard",
    col_title: "Curated Color Palettes",
    col_subtitle: "Hand-picked aesthetic combinations for your brand.",
    col_copy: "Copy",
    col_copied: "Copied!"
  },
  ar: {
    app_title: "ArtNew8",
    app_subtitle: "إستوديو",
    nav_template: "صانع القوالب",
    nav_pricing: "حاسبة الأسعار",
    nav_messages: "مولد الرسائل",
    nav_colors: "لوحات الألوان",
    nav_vision: "سوق الحرفيين",
    nav_marketplace: "سوقنا",
    nav_blog: "المدونة",
    mob_template: "القوالب",
    mob_pricing: "الأسعار",
    mob_messages: "الرسائل",
    mob_colors: "الألوان",
    mob_vision: "رؤيتنا",
    param_settings: "الإعدادات والقياسات",
    width: "العرض (ملم)",
    length: "الطول (ملم)",
    height: "الارتفاع (ملم)",
    material_thickness: "سمك المادة",
    template_type: "نوع القالب",
    sim_2d: "عرض المخطط ثنائي الأبعاد",
    sim_3d: "محاكي ثلاثي الأبعاد",
    flap: "حجم الغطاء",
    glue_tab: "حافة اللصق",
    kerf: "حافة القطع (ليزر)",
    box_standard: "صندوق كرتون قياسي",
    box_milk: "صندوق حليب عتيق",
    btn_svg: "تحميل SVG",
    btn_dxf: "تحميل DXF",
    btn_pdf: "تحميل PDF",
    btn_obj: "تحميل ثلاثي الابعاد OBJ",
    pricing_title: "حاسبة الأسعار",
    profit_margin: "هامش الربح المطلوب",
    calc_summary: "تفاصيل التكلفة",
    p_materials: "المواد الخام",
    p_labor: "العمل والوقت",
    p_overhead: "المصاريف (التغليف، الشحن)",
    p_fees: "رسوم المنصة",
    p_base: "التكلفة الأساسية (نقطة التعادل)",
    p_wholesale: "سعر الجملة",
    p_retail: "سعر التجزئة",
    p_profit: "صافي الربح",
    btn_save: "تحميل ملخص التسعير",
    msg_title: "مولد الرسائل الاحترافية",
    msg_subtitle: "قم بإنشاء رسائل منظمة ومهذبة للعملاء فورًا.",
    msg_topic: "موضوع الرسالة",
    msg_recipient: "اسم المستلم",
    msg_tone: "نبرة الرسالة",
    msg_tone_prof: "احترافية",
    msg_tone_warm: "ودودة ودافئة",
    msg_tone_firm: "صارمة ومباشرة",
    msg_context: "تفاصيل إضافية (اختياري)",
    msg_btn_gen: "توليد الرسالة",
    msg_btn_copy: "نسخ إلى الحافظة",
    col_title: "لوحات ألوان منتقاة",
    col_subtitle: "تركيبات جمالية منتقاة بعناية لعلامتك التجارية.",
    col_copy: "نسخ",
    col_copied: "تم النسخ!"
  },
  fr: {
    app_title: "ArtNew8",
    app_subtitle: "Studio",
    nav_template: "Créateur de Modèles",
    nav_pricing: "Calculateur de Prix",
    nav_messages: "Générateur de Messages",
    nav_colors: "Palettes de Couleurs",
    nav_vision: "Marché Artisanal",
    nav_marketplace: "Notre Marché",
    nav_blog: "Le Blog",
    mob_template: "Modèles",
    mob_pricing: "Prix",
    mob_messages: "Messages",
    mob_colors: "Couleurs",
    mob_vision: "Vision",
    param_settings: "Paramètres",
    width: "Largeur (mm)",
    length: "Longueur (mm)",
    height: "Hauteur (mm)",
    material_thickness: "Épaisseur",
    template_type: "Type de Modèle",
    sim_2d: "Vue de Plan Architecturale",
    sim_3d: "Simulateur 3D",
    flap: "Taille du Rabat",
    glue_tab: "Onglet de Colle",
    kerf: "Trait de Scie (Laser)",
    box_standard: "Boîte en Carton",
    box_milk: "Boîte Lait",
    btn_svg: "SVG",
    btn_dxf: "DXF",
    btn_pdf: "PDF",
    btn_obj: "OBJ (3D)",
    pricing_title: "Calculateur de Prix",
    profit_margin: "Marge Bénéficiaire Souhaitée",
    calc_summary: "Répartition des Coûts",
    p_materials: "Matières Premières",
    p_labor: "Travail et Temps",
    p_overhead: "Frais Généraux (Emballage, Expédition)",
    p_fees: "Frais de Plateforme",
    p_base: "Coût de Base (Seuil de Rentabilité)",
    p_wholesale: "Prix de Gros",
    p_retail: "Prix de Détail",
    p_profit: "Bénéfice Net",
    btn_save: "Télécharger le Résumé",
    msg_title: "Générateur de Messages",
    msg_subtitle: "Générez instantanément des communications clients structurées.",
    msg_topic: "Sujet du Message",
    msg_recipient: "Nom du Destinataire",
    msg_tone: "Ton du Message",
    msg_tone_prof: "Professionnel",
    msg_tone_warm: "Chaleureux et Amical",
    msg_tone_firm: "Ferme et Direct",
    msg_context: "Contexte Supplémentaire (Optionnel)",
    msg_btn_gen: "Générer le Message",
    msg_btn_copy: "Copier",
    col_title: "Palettes de Couleurs",
    col_subtitle: "Combinaisons esthétiques pour votre marque.",
    col_copy: "Copier",
    col_copied: "Copié !"
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('artnew8_lang');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    localStorage.setItem('artnew8_lang', language);
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const t = (key: string) => {
    return translations[language]?.[key] || translations['en'][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL: language === 'ar' }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
