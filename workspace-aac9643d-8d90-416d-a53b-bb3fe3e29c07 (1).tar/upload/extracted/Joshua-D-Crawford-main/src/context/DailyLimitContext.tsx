import React, { createContext, useContext, useState, useEffect } from 'react';

const MAX_ATTEMPTS = 8;

interface DailyLimitContextType {
  attemptsLeft: number;
  isAdmin: boolean;
  consumeAttempt: (callback: () => void) => boolean;
  enableAdmin: () => void;
}

export const DailyLimitContext = createContext<DailyLimitContextType>({
  attemptsLeft: MAX_ATTEMPTS,
  isAdmin: false,
  consumeAttempt: () => false,
  enableAdmin: () => {},
});

export const DailyLimitProvider: React.FC<{ children: React.ReactNode; onLimitReached: () => void }> = ({ children, onLimitReached }) => {
  const [attemptsLeft, setAttemptsLeft] = useState(MAX_ATTEMPTS);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    // Hidden admin bypass registration
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('admin') === 'true') {
      localStorage.setItem('artnew8_admin_override', 'true');
      alert('Admin privileges activated. Daily limits bypassed.');
    }

    const adminStatus = localStorage.getItem('artnew8_admin_override') === 'true';
    setIsAdmin(adminStatus);

    if (adminStatus) {
      setAttemptsLeft(999);
      return;
    }

    const today = new Date().toDateString();
    const stored = localStorage.getItem('artnew8_usage_en');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (parsed.date === today) {
          setAttemptsLeft(Math.max(0, MAX_ATTEMPTS - parsed.count));
        } else {
          localStorage.setItem('artnew8_usage_en', JSON.stringify({ date: today, count: 0 }));
          setAttemptsLeft(MAX_ATTEMPTS);
        }
      } catch (e) {
        localStorage.setItem('artnew8_usage_en', JSON.stringify({ date: today, count: 0 }));
      }
    } else {
      localStorage.setItem('artnew8_usage_en', JSON.stringify({ date: today, count: 0 }));
    }
  }, []);

  const consumeAttempt = (callback: () => void) => {
    if (isAdmin) {
      callback();
      return true;
    }

    const today = new Date().toDateString();
    const stored = localStorage.getItem('artnew8_usage_en');
    let currentCount = 0;
    
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (parsed.date === today) {
          currentCount = parsed.count;
        }
      } catch (e) {}
    }

    if (currentCount >= MAX_ATTEMPTS) {
      onLimitReached();
      return false;
    }

    const newCount = currentCount + 1;
    localStorage.setItem('artnew8_usage_en', JSON.stringify({ date: today, count: newCount }));
    setAttemptsLeft(Math.max(0, MAX_ATTEMPTS - newCount));
    callback();
    return true;
  };

  const enableAdmin = () => {
    localStorage.setItem('artnew8_admin_override', 'true');
    setIsAdmin(true);
    setAttemptsLeft(999);
    alert('Admin privileges activated. Daily limits bypassed.');
  };

  return <DailyLimitContext.Provider value={{ attemptsLeft, isAdmin, consumeAttempt, enableAdmin }}>{children}</DailyLimitContext.Provider>;
};

export const useDailyLimit = () => useContext(DailyLimitContext);
