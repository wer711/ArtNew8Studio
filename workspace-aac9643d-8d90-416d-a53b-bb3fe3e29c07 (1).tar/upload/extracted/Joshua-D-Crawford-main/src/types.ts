export interface Material {
  id: string;
  name: string;
  cost: number;
  quantityUsed: number;
}

export interface Project {
  id: string;
  name: string;
  materials: Material[];
  hourlyRate: number;
  hoursSpent: number;
  packagingCost: number;
  overheadPercentage: number;
  profitMargin: number; // percentage
  platformFeeType: 'none' | 'etsy' | 'shopify' | 'amazon' | 'custom';
  customFeePercent?: number;
  customFeeFixed?: number;
  freeShippingCost?: number;
  discountPercentage?: number;
  taxPercentage?: number;
  createdAt: number;
}
