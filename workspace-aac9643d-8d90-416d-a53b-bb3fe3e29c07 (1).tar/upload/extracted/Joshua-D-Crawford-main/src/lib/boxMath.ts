export type TemplateType = 'box' | 'envelope' | 'pillow' | 'mailer' | 'milk_carton';

export interface TemplateOptions {
  width: number;
  length: number;
  height: number;
  flapSize: number;
  glueTab: number;
  cornerRadius: number;
  materialThickness: number;
  kerf: number;
  machine: 'cricut' | 'silhouette' | 'laser' | 'standard';
}

export function generateTemplateSvg(type: TemplateType, options: TemplateOptions): string {
  const { width: w, length: l, height: h, flapSize, glueTab, cornerRadius: r, materialThickness: t, kerf, machine } = options;

  let cutLines = '';
  let foldLines = '';
  let labels = '';

  let totalWidth = 0;
  let totalLength = 0;
  
  // Kerf adjusted coordinates
  const k = kerf / 2;
  const k1 = k;
  const k2 = -k;

  if (type === 'box') {
    // Standard Tray Box
    totalWidth = w + 2 * h;
    totalLength = l + 2 * h;

    cutLines = `
      M ${h},0 L ${h+w},0 L ${h+w},${h-k1} L ${totalWidth},${h-k1} L ${totalWidth},${h+l+k1} L ${h+w},${h+l+k1} L ${h+w},${totalLength} L ${h},${totalLength} L ${h},${h+l+k1} L 0,${h+l+k1} L 0,${h-k1} L ${h},${h-k1} Z
      M ${h},${h} l 0,-${h} M ${h+w},${h} l 0,-${h}
      M ${totalWidth},${h} l -${h},0 M ${totalWidth},${h+l} l -${h},0
      M ${h+w},${totalLength} l 0,-${h} M ${h},${totalLength} l 0,-${h}
      M 0,${h+l} l ${h},0 M 0,${h} l ${h},0
    `;

    foldLines = `
      M ${h},${h} L ${h+w},${h}
      M ${h+w},${h} L ${h+w},${h+l}
      M ${h+w},${h+l} L ${h},${h+l}
      M ${h},${h+l} L ${h},${h}
    `;
    
    labels = `
      <!-- Base -->
      <text x="${h + w/2}" y="${h + l/2}" font-size="5" font-family="sans-serif" font-weight="bold" text-anchor="middle" fill="#9e4f44">BASE BOARD</text>
      <text x="${h + w/2}" y="${h + l/2 + 6}" font-size="3.5" font-family="sans-serif" text-anchor="middle" fill="#7a6460">W:${w}mm × L:${l}mm</text>
      
      <!-- Top Wall -->
      <line x1="${h + 2}" y1="${h/2 + 3}" x2="${h + w - 2}" y2="${h/2 + 3}" stroke="#7a6460" stroke-width="0.3" marker-start="url(#arrow)" marker-end="url(#arrow)" />
      <text x="${h + w/2}" y="${h/2 + 1.5}" font-size="3" text-anchor="middle" fill="#7a6460">W:${w}mm</text>
      <text x="${h + w/2}" y="${h/2 + 7}" font-size="3" font-family="sans-serif" font-weight="bold" text-anchor="middle" fill="#9e4f44">H:${h}mm</text>
      
      <!-- Bottom Wall -->
      <line x1="${h + 2}" y1="${h + l + h/2 - 3}" x2="${h + w - 2}" y2="${h + l + h/2 - 3}" stroke="#7a6460" stroke-width="0.3" marker-start="url(#arrow)" marker-end="url(#arrow)" />
      <text x="${h + w/2}" y="${h + l + h/2 - 5}" font-size="3" font-weight="bold" text-anchor="middle" fill="#9e4f44">H:${h}mm</text>
      <text x="${h + w/2}" y="${h + l + h/2 + 1}" font-size="3" font-family="sans-serif" text-anchor="middle" fill="#7a6460">W:${w}mm</text>

      <!-- Left Wall -->
      <g transform="rotate(-90, ${h/2}, ${h + l/2})">
        <line x1="${h/2 - w/4}" y1="${h + l/2}" x2="${h/2 + w/4}" y2="${h + l/2}" stroke="#7a6460" stroke-width="0.3" marker-start="url(#arrow)" marker-end="url(#arrow)" />
        <text x="${h/2}" y="${h + l/2 - 1.5}" font-size="3" font-family="sans-serif" text-anchor="middle" fill="#7a6460">L:${l}mm</text>
        <text x="${h/2}" y="${h + l/2 + 4.5}" font-size="3" font-family="sans-serif" font-weight="bold" text-anchor="middle" fill="#9e4f44">H:${h}mm</text>
      </g>
      
      <!-- Right Wall -->
      <g transform="rotate(90, ${h + w + h/2}, ${h + l/2})">
        <line x1="${h + w + h/2 - w/4}" y1="${h + l/2}" x2="${h + w + h/2 + w/4}" y2="${h + l/2}" stroke="#7a6460" stroke-width="0.3" marker-start="url(#arrow)" marker-end="url(#arrow)" />
        <text x="${h + w + h/2}" y="${h + l/2 - 1.5}" font-size="3" font-family="sans-serif" text-anchor="middle" fill="#7a6460">L:${l}mm</text>
        <text x="${h + w + h/2}" y="${h + l/2 + 4.5}" font-size="3" font-family="sans-serif" font-weight="bold" text-anchor="middle" fill="#9e4f44">H:${h}mm</text>
      </g>
    `;
  } else if (type === 'envelope') {
    // Envelope
    const flap = flapSize;
    const sideFlap = glueTab * 2;
    
    totalWidth = l + (2 * sideFlap);
    totalLength = w + (2 * flap);

    cutLines = `
      M ${sideFlap},0 
      L ${sideFlap + l},0
      L ${totalWidth},${flap}
      L ${totalWidth},${flap + w}
      L ${sideFlap + l},${totalLength}
      L ${sideFlap},${totalLength}
      L 0,${flap + w}
      L 0,${flap} Z
    `;

    foldLines = `
      M ${sideFlap},${flap} L ${sideFlap + l},${flap}
      M ${sideFlap + l},${flap} L ${sideFlap + l},${flap + w}
      M ${sideFlap + l},${flap + w} L ${sideFlap},${flap + w}
      M ${sideFlap},${flap + w} L ${sideFlap},${flap}
    `;
  } else if (type === 'pillow') {
    // Pillow box (Approximation with arcs)
    totalWidth = w + l;
    totalLength = h * 2 + w; // Using h for flap length
    
    // Pillow boxes use arcs for folding. Just simulating basic shape.
    cutLines = `
      M 0,${h} Q ${w/2},0 ${w},${h} Q ${w*1.5},0 ${w*2},${h}
      L ${w*2},${h+l} Q ${w*1.5},${h*2+l} ${w},${h+l} Q ${w/2},${h*2+l} 0,${h+l} Z
    `;
    foldLines = `
      M 0,${h} Q ${w/2},${h*1.5} ${w},${h} Q ${w*1.5},${h*1.5} ${w*2},${h}
      M 0,${h+l} Q ${w/2},${h+l - h*0.5} ${w},${h+l} Q ${w*1.5},${h+l - h*0.5} ${w*2},${h+l}
      M ${w},${h} L ${w},${h+l}
    `;
  } else if (type === 'mailer') {
     const gt = glueTab;
     totalWidth = l + w + l + gt;
     totalLength = h + w + h + h;
     cutLines = `M 0,0 h ${totalWidth} v ${totalLength} h -${totalWidth} Z`; // placeholder simple box
     foldLines = `M ${l},0 v ${totalLength} M ${l+w},0 v ${totalLength} M ${l+w+l},0 v ${totalLength}`;
  } else {
    // Milk carton
     totalWidth = (w + l)*2 + glueTab;
     totalLength = h + w/2 + h;
     cutLines = `M 0,0 h ${totalWidth} v ${totalLength} h -${totalWidth} Z`; // placeholder
     foldLines = `M ${w},0 v ${totalLength} M ${w+l},0 v ${totalLength} M ${w*2+l},0 v ${totalLength}`;
  }

  // Machine Specific Coloring
  let cutColor = '#db2777';
  let foldColor = '#64748b';
  
  if (machine === 'laser') {
    cutColor = '#ff0000'; // Pure red for cut
    foldColor = '#0000ff'; // Pure blue for vector score
  } else if (machine === 'cricut') {
    cutColor = '#000000'; // Black cut
    foldColor = '#ff00ff'; // Magenta score
  }

  const defs = `
    <defs>
      <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="3" markerHeight="3" orient="auto-start-reverse">
        <path d="M 0 0 L 10 5 L 0 10 z" fill="#7a6460" />
      </marker>
    </defs>
  `;

  return `
    <svg viewBox="-10 -10 ${totalWidth + 20} ${totalLength + 20}" xmlns="http://www.w3.org/2000/svg" class="w-full h-full" id="svg-template-export">
      ${machine === 'standard' ? defs : ''}
      <g id="cut-paths">
        <path d="${cutLines}" fill="none" stroke="${cutColor}" stroke-width="1.5" stroke-linejoin="round" />
      </g>
      <g id="score-paths">
        <path d="${foldLines}" fill="none" stroke="${foldColor}" stroke-width="1.5" stroke-dasharray="${machine === 'laser' ? 'none' : '4,4'}" />
      </g>
      ${machine === 'standard' ? labels : ''}
    </svg>
  `;
}

