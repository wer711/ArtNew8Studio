import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

// Lazily initialize to prevent crash on boot if missing
let ai: GoogleGenAI | null = null;
function getAI() {
  if (!ai) {
    if (!process.env.GEMINI_API_KEY) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return ai;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for generating personalized messages
  app.post('/api/generate-message', async (req, res) => {
    try {
      const { occasion, recipient, tone, language, length, context } = req.body;
      
      if (!process.env.GEMINI_API_KEY) {
         return res.json({ message: "Gemini API key is missing. Please configure it in the secrets menu to generate real AI messages! (Fallback text provided.)" });
      }

      const client = getAI();
      const prompt = `Write a beautiful, professional greeting card message for a ${occasion}. The recipient is a ${recipient}, and the tone should be ${tone}. The language of the message must be ${language || 'English'}. The desired length is ${length || 'Medium'}. ${context ? `Include these specific details: ${context}.` : ''} Keep it creative, and suitable for a handmade paper craft card. Provide only the message text, no quotes or intro.`;

      const response = await client.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });

      res.json({ message: response.text });
    } catch (error: any) {
      console.error("AI Error:", error);
      
      let errorMsg = 'Failed to generate message. Please try again.';
      if (error?.status === 503 || error?.message?.includes('503') || error?.message?.includes('high demand') || error?.message?.includes('UNAVAILABLE') || error?.status === 'UNAVAILABLE') {
        errorMsg = 'The AI model is currently experiencing high demand. Please wait a few moments and try again.';
      } else if (error?.status === 429 || error?.message?.includes('429') || error?.message?.includes('Quota')) {
        errorMsg = 'AI rate limit reached. Please wait a moment and try again, or configure your own Gemini API key.';
      }
      
      res.status(500).json({ error: errorMsg, message: errorMsg });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production static serving
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
