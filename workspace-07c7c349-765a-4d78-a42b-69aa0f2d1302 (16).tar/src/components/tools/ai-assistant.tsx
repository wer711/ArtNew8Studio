'use client'

import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useUsageTracker } from '@/hooks/use-usage-tracker'
import { toast } from '@/hooks/use-toast'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sparkles,
  Wand2,
  PenLine,
  ImageIcon,
  Search,
  Loader2,
  Copy,
  Check,
  Download,
  RefreshCw,
  Lightbulb,
  TrendingUp,
  Tag,
  DollarSign,
  FileText,
  Palette,
  ArrowRight,
} from 'lucide-react'
import { LimitPopup } from '@/components/support/limit-popup'
import { ToolDonationPrompt } from '@/components/support/tool-donation-prompt'

// ─── Types ───────────────────────────────────────────────────────────────
interface PriceResearch {
  priceRange: { min: number; max: number; avg: number }
  sources: { name: string; url: string; price: string }[]
  advice: string
}

interface DescriptionResult {
  description: string
  style: string
  platform: string
}

// ─── Component ───────────────────────────────────────────────────────────
export function AIAssistant({ onSupportClick }: { onSupportClick: () => void }) {
  const { canUse, incrementUsage, getRemaining, isAdmin } = useUsageTracker()
  const [showLimitPopup, setShowLimitPopup] = useState(false)

  // Shared product info
  const [productName, setProductName] = useState('')
  const [category, setCategory] = useState('other')

  // ─── Smart Pricing ────────────────────────────────────────
  const [isResearchingPrice, setIsResearchingPrice] = useState(false)
  const [priceResearch, setPriceResearch] = useState<PriceResearch | null>(null)
  const [priceError, setPriceError] = useState<string | null>(null)

  const handlePriceResearch = useCallback(async () => {
    if (!productName?.trim()) {
      toast({ title: 'Enter a product name', description: 'Name your product to research market prices' })
      return
    }
    if (!canUse()) {
      setShowLimitPopup(true)
      return
    }
    setIsResearchingPrice(true)
    setPriceError(null)
    setPriceResearch(null)
    try {
      const sessionId = typeof window !== 'undefined' ? localStorage.getItem('artnew8-session-id') || '' : ''
      const res = await fetch('/api/ai/research-price', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ product: productName, category, sessionId }),
      })
      if (res.status === 429) {
        toast({ title: 'Please wait', description: 'Too many requests. Try again in a minute.' })
        return
      }
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Request failed' }))
        throw new Error(err.error || 'Request failed')
      }
      const data = await res.json()
      incrementUsage('ai-assistant', 'price-research')
      setPriceResearch({
        priceRange: data.priceRange || { min: 0, max: 0, avg: 0 },
        sources: data.sources || [],
        advice: data.advice || '',
      })
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong'
      setPriceError(message)
      toast({ title: 'Research failed', description: message, variant: 'destructive' })
    } finally {
      setIsResearchingPrice(false)
    }
  }, [productName, category, canUse, incrementUsage])

  // ─── Description Writer ───────────────────────────────────
  const [isWritingDesc, setIsWritingDesc] = useState(false)
  const [descriptionResult, setDescriptionResult] = useState<DescriptionResult | null>(null)
  const [descError, setDescError] = useState<string | null>(null)
  const [descStyle, setDescStyle] = useState<'professional' | 'casual' | 'storytelling' | 'seo-optimized'>('professional')
  const [descPlatform, setDescPlatform] = useState('etsy')
  const [descCopied, setDescCopied] = useState(false)

  const handleWriteDescription = useCallback(async () => {
    if (!productName?.trim()) {
      toast({ title: 'Enter a product name', description: 'Name your product to generate a description' })
      return
    }
    if (!canUse()) {
      setShowLimitPopup(true)
      return
    }
    setIsWritingDesc(true)
    setDescError(null)
    setDescriptionResult(null)
    try {
      const sessionId = typeof window !== 'undefined' ? localStorage.getItem('artnew8-session-id') || '' : ''
      const res = await fetch('/api/ai/write-description', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productName,
          category,
          platform: descPlatform,
          style: descStyle,
          sessionId,
        }),
      })
      if (res.status === 429) {
        toast({ title: 'Please wait', description: 'Too many requests. Try again in a minute.' })
        return
      }
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Request failed' }))
        throw new Error(err.error || 'Request failed')
      }
      const data = await res.json()
      incrementUsage('ai-assistant', 'write-description')
      setDescriptionResult({
        description: data.description,
        style: data.style,
        platform: data.platform,
      })
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong'
      setDescError(message)
      toast({ title: 'Generation failed', description: message, variant: 'destructive' })
    } finally {
      setIsWritingDesc(false)
    }
  }, [productName, category, descStyle, descPlatform, canUse, incrementUsage])

  // ─── Image Generator ──────────────────────────────────────
  const [isGeneratingImage, setIsGeneratingImage] = useState(false)
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null)
  const [imagePrompt, setImagePrompt] = useState('')
  const [imageError, setImageError] = useState<string | null>(null)

  const handleGenerateImage = useCallback(async () => {
    const prompt = imagePrompt?.trim() || productName?.trim()
    if (!prompt) {
      toast({ title: 'Enter a description', description: 'Describe what image you want to generate' })
      return
    }
    if (!canUse()) {
      setShowLimitPopup(true)
      return
    }
    setIsGeneratingImage(true)
    setImageError(null)
    setGeneratedImageUrl(null)
    try {
      const sessionId = typeof window !== 'undefined' ? localStorage.getItem('artnew8-session-id') || '' : ''
      const colors = [] // Could be integrated with color palette tool
      const res = await fetch('/api/ai/generate-mockup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          colors,
          productType: prompt,
          sessionId,
        }),
      })
      if (res.status === 429) {
        toast({ title: 'Please wait', description: 'Too many requests. Try again in a minute.' })
        return
      }
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Request failed' }))
        throw new Error(err.error || 'Request failed')
      }
      const data = await res.json()
      incrementUsage('ai-assistant', 'generate-image')
      setGeneratedImageUrl(data.imageUrl)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong'
      setImageError(message)
      toast({ title: 'Image generation failed', description: message, variant: 'destructive' })
    } finally {
      setIsGeneratingImage(false)
    }
  }, [imagePrompt, productName, canUse, incrementUsage])

  const handleDownloadImage = useCallback(() => {
    if (!generatedImageUrl) return
    const link = document.createElement('a')
    link.href = generatedImageUrl
    link.download = `ai-product-${Date.now()}.png`
    link.click()
  }, [generatedImageUrl])

  // ─── Smart Tags ───────────────────────────────────────────
  const [isSuggestingTags, setIsSuggestingTags] = useState(false)
  const [aiTags, setAiTags] = useState<string[]>([])
  const [tagError, setTagError] = useState<string | null>(null)
  const [tagsCopied, setTagsCopied] = useState(false)

  const handleSmartTags = useCallback(async () => {
    if (!productName?.trim()) {
      toast({ title: 'Enter a product name', description: 'Name your product to get AI tag suggestions' })
      return
    }
    if (!canUse()) {
      setShowLimitPopup(true)
      return
    }
    setIsSuggestingTags(true)
    setTagError(null)
    setAiTags([])
    try {
      const sessionId = typeof window !== 'undefined' ? localStorage.getItem('artnew8-session-id') || '' : ''
      const res = await fetch('/api/ai/suggest-tags', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          keyword: productName,
          platform: 'etsy',
          sessionId,
        }),
      })
      if (res.status === 429) {
        toast({ title: 'Please wait', description: 'Too many requests. Try again in a minute.' })
        return
      }
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Request failed' }))
        throw new Error(err.error || 'Request failed')
      }
      const data = await res.json()
      incrementUsage('ai-assistant', 'smart-tags')
      setAiTags(data.tags || [])
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong'
      setTagError(message)
      toast({ title: 'Tag generation failed', description: message, variant: 'destructive' })
    } finally {
      setIsSuggestingTags(false)
    }
  }, [productName, canUse, incrementUsage])

  const handleCopyTags = useCallback(() => {
    if (!aiTags.length) return
    navigator.clipboard.writeText(aiTags.join(', ')).then(() => {
      setTagsCopied(true)
      toast({ title: 'Tags copied!', description: `${aiTags.length} tags copied to clipboard` })
      setTimeout(() => setTagsCopied(false), 2000)
    })
  }, [aiTags])

  const handleCopyDescription = useCallback(() => {
    if (!descriptionResult?.description) return
    navigator.clipboard.writeText(descriptionResult.description).then(() => {
      setDescCopied(true)
      toast({ title: 'Description copied!', description: 'Product description copied to clipboard' })
      setTimeout(() => setDescCopied(false), 2000)
    })
  }, [descriptionResult])

  const remaining = getRemaining()

  const CATEGORIES = [
    { value: 'jewelry', label: 'Jewelry' },
    { value: 'clothing', label: 'Clothing & Accessories' },
    { value: 'home_decor', label: 'Home Decor' },
    { value: 'paper_crafts', label: 'Paper Crafts' },
    { value: 'bath_body', label: 'Bath & Body' },
    { value: 'toys', label: 'Toys & Games' },
    { value: 'art', label: 'Art & Prints' },
    { value: 'candles', label: 'Candles' },
    { value: 'pottery', label: 'Pottery & Ceramics' },
    { value: 'other', label: 'Other Crafts' },
  ]

  return (
    <div className="w-full max-w-4xl mx-auto px-2 sm:px-4 py-4 sm:py-8 space-y-4 sm:space-y-6 overflow-x-hidden">
      <LimitPopup open={showLimitPopup} onClose={() => setShowLimitPopup(false)} onSupportClick={onSupportClick} remaining={remaining} />

      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 text-primary">
          <Sparkles className="size-7" />
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">AI Assistant</h1>
        </div>
        <p className="text-muted-foreground text-sm sm:text-base max-w-xl mx-auto">
          Powered by OpenAI — smart pricing, descriptions, tags, and product images for your handmade business.
        </p>
      </div>

      {/* Shared Product Info */}
      <Card className="border-primary/20 overflow-hidden">
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-center gap-2 mb-4 min-w-0">
            <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Lightbulb className="size-4 text-primary" />
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-sm truncate">Product Info</h3>
              <p className="text-xs text-muted-foreground truncate">Describe your product once, use it across all AI tools</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="ai-product-name" className="text-sm font-medium">Product Name</Label>
              <Input
                id="ai-product-name"
                placeholder="e.g., Handmade Lavender Soy Candle"
                value={productName}
                onChange={e => setProductName(e.target.value)}
                className="h-10"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ai-category" className="text-sm font-medium">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger id="ai-category" className="h-10">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(c => (
                    <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* AI Tools Tabs */}
      <Tabs defaultValue="pricing" className="w-full">
        <TabsList className="w-full sm:w-auto mx-auto grid grid-cols-2 sm:inline-flex h-auto gap-1 p-1">
          <TabsTrigger value="pricing" className="gap-1.5 text-xs sm:text-sm">
            <DollarSign className="size-3.5" />
            Smart Pricing
          </TabsTrigger>
          <TabsTrigger value="description" className="gap-1.5 text-xs sm:text-sm">
            <PenLine className="size-3.5" />
            Description Writer
          </TabsTrigger>
          <TabsTrigger value="tags" className="gap-1.5 text-xs sm:text-sm">
            <Tag className="size-3.5" />
            Smart Tags
          </TabsTrigger>
          <TabsTrigger value="image" className="gap-1.5 text-xs sm:text-sm">
            <ImageIcon className="size-3.5" />
            Image Generator
          </TabsTrigger>
        </TabsList>

        {/* ─── Smart Pricing Tab ───────────────────────────── */}
        <TabsContent value="pricing" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="size-5 text-green-600" />
                Market Price Research
              </CardTitle>
              <CardDescription>Get AI-powered market price estimates for your handmade product</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={handlePriceResearch}
                disabled={isResearchingPrice || !productName.trim()}
                className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white gap-2"
              >
                {isResearchingPrice ? (
                  <><Loader2 className="size-4 animate-spin" /> Researching...</>
                ) : (
                  <><Search className="size-4" /> Research Market Prices</>
                )}
              </Button>

              <AnimatePresence mode="wait">
                {isResearchingPrice && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="flex items-center gap-3 p-4 rounded-xl bg-green-50 border border-green-200"
                  >
                    <Loader2 className="size-5 text-green-600 animate-spin" />
                    <div>
                      <p className="font-medium text-sm text-green-700">Analyzing market prices...</p>
                      <p className="text-xs text-green-600">Searching Etsy, Amazon Handmade, and Shopify data</p>
                    </div>
                  </motion.div>
                )}

                {priceError && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 rounded-xl bg-red-50 border border-red-200"
                  >
                    <p className="text-sm text-red-600 break-words">{priceError}</p>
                  </motion.div>
                )}

                {priceResearch && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-4"
                  >
                    {/* Price Range */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="text-center p-3 rounded-xl bg-green-50 border border-green-200 overflow-hidden">
                        <p className="text-xs text-muted-foreground font-medium">Min</p>
                        <p className="text-base sm:text-xl font-bold text-green-600">${priceResearch.priceRange.min.toFixed(2)}</p>
                      </div>
                      <div className="text-center p-3 rounded-xl bg-primary/5 border border-primary/20 overflow-hidden">
                        <p className="text-xs text-muted-foreground font-medium">Average</p>
                        <p className="text-base sm:text-xl font-bold text-primary">${priceResearch.priceRange.avg.toFixed(2)}</p>
                      </div>
                      <div className="text-center p-3 rounded-xl bg-orange-50 border border-orange-200 overflow-hidden">
                        <p className="text-xs text-muted-foreground font-medium">Max</p>
                        <p className="text-base sm:text-xl font-bold text-orange-600">${priceResearch.priceRange.max.toFixed(2)}</p>
                      </div>
                    </div>

                    {/* Advice */}
                    {priceResearch.advice && (
                      <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
                        <div className="flex items-start gap-2">
                          <Lightbulb className="size-4 text-amber-600 shrink-0 mt-0.5" />
                          <p className="text-sm text-amber-700 break-words">{priceResearch.advice}</p>
                        </div>
                      </div>
                    )}

                    {/* Sources */}
                    {priceResearch.sources.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="text-sm font-semibold text-muted-foreground">Market Sources</h4>
                        <div className="space-y-1.5">
                          {priceResearch.sources.map((source, i) => (
                            <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-muted/30 text-sm">
                              <span className="truncate mr-2">{source.name}</span>
                              <Badge variant="secondary" className="shrink-0 text-xs">{source.price}</Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── Description Writer Tab ──────────────────────── */}
        <TabsContent value="description" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <PenLine className="size-5 text-blue-600" />
                AI Description Writer
              </CardTitle>
              <CardDescription>Generate professional product descriptions for any platform</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Platform</Label>
                  <Select value={descPlatform} onValueChange={setDescPlatform}>
                    <SelectTrigger className="h-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="etsy">Etsy</SelectItem>
                      <SelectItem value="amazon">Amazon</SelectItem>
                      <SelectItem value="shopify">Shopify</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Writing Style</Label>
                  <Select value={descStyle} onValueChange={(v) => setDescStyle(v as typeof descStyle)}>
                    <SelectTrigger className="h-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="casual">Casual & Friendly</SelectItem>
                      <SelectItem value="storytelling">Storytelling</SelectItem>
                      <SelectItem value="seo-optimized">SEO-Optimized</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                onClick={handleWriteDescription}
                disabled={isWritingDesc || !productName.trim()}
                className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white gap-2"
              >
                {isWritingDesc ? (
                  <><Loader2 className="size-4 animate-spin" /> Writing...</>
                ) : (
                  <><Wand2 className="size-4" /> Generate Description</>
                )}
              </Button>

              <AnimatePresence mode="wait">
                {isWritingDesc && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="flex items-center gap-3 p-4 rounded-xl bg-blue-50 border border-blue-200"
                  >
                    <Loader2 className="size-5 text-blue-600 animate-spin" />
                    <div>
                      <p className="font-medium text-sm text-blue-700">Crafting your description...</p>
                      <p className="text-xs text-blue-600">Using {descStyle} style for {descPlatform}</p>
                    </div>
                  </motion.div>
                )}

                {descError && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 rounded-xl bg-red-50 border border-red-200"
                  >
                    <p className="text-sm text-red-600 break-words">{descError}</p>
                  </motion.div>
                )}

                {descriptionResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-2 min-w-0">
                        <Badge variant="secondary" className="text-xs shrink-0">{descriptionResult.platform}</Badge>
                        <Badge variant="outline" className="text-xs capitalize shrink-0">{descriptionResult.style}</Badge>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleCopyDescription}
                          className="gap-1.5 text-xs min-h-[44px]"
                        >
                          {descCopied ? <Check className="size-3.5 text-green-600" /> : <Copy className="size-3.5" />}
                          {descCopied ? 'Copied!' : 'Copy'}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleWriteDescription}
                          className="gap-1.5 text-xs min-h-[44px]"
                        >
                          <RefreshCw className="size-3.5" />
                          Regenerate
                        </Button>
                      </div>
                    </div>
                    <div className="p-4 rounded-xl bg-muted/30 border border-border/50 whitespace-pre-wrap text-sm leading-relaxed break-words">
                      {descriptionResult.description}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── Smart Tags Tab ──────────────────────────────── */}
        <TabsContent value="tags" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Tag className="size-5 text-rose-600" />
                AI Smart Tags
              </CardTitle>
              <CardDescription>Get AI-suggested tags optimized for search discovery</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={handleSmartTags}
                disabled={isSuggestingTags || !productName.trim()}
                className="w-full sm:w-auto bg-rose-600 hover:bg-rose-700 text-white gap-2"
              >
                {isSuggestingTags ? (
                  <><Loader2 className="size-4 animate-spin" /> Generating...</>
                ) : (
                  <><Sparkles className="size-4" /> Generate Smart Tags</>
                )}
              </Button>

              <AnimatePresence mode="wait">
                {isSuggestingTags && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="flex items-center gap-3 p-4 rounded-xl bg-rose-50 border border-rose-200"
                  >
                    <Loader2 className="size-5 text-rose-600 animate-spin" />
                    <div>
                      <p className="font-medium text-sm text-rose-700">Finding the best tags...</p>
                      <p className="text-xs text-rose-600">Analyzing search trends and buyer keywords</p>
                    </div>
                  </motion.div>
                )}

                {tagError && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 rounded-xl bg-red-50 border border-red-200"
                  >
                    <p className="text-sm text-red-600 break-words">{tagError}</p>
                  </motion.div>
                )}

                {aiTags.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="text-sm font-medium min-w-0 truncate">{aiTags.length} AI-suggested tags</p>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleCopyTags}
                          className="gap-1.5 text-xs min-h-[44px]"
                        >
                          {tagsCopied ? <Check className="size-3.5 text-green-600" /> : <Copy className="size-3.5" />}
                          {tagsCopied ? 'Copied!' : 'Copy All'}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleSmartTags}
                          className="gap-1.5 text-xs min-h-[44px]"
                        >
                          <RefreshCw className="size-3.5" />
                          Regenerate
                        </Button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {aiTags.map((tag, i) => (
                        <Badge
                          key={i}
                          variant="secondary"
                          className="px-3 py-1.5 text-sm font-medium bg-rose-50 text-rose-700 border border-rose-200"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── Image Generator Tab ─────────────────────────── */}
        <TabsContent value="image" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Palette className="size-5 text-purple-600" />
                AI Product Image
              </CardTitle>
              <CardDescription>Generate a product mockup image with AI (DALL-E 3)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Image Description (optional — uses product name if empty)</Label>
                <Textarea
                  placeholder="e.g., Handmade lavender soy candle in a glass jar with dried flowers on a white marble surface, soft natural lighting"
                  value={imagePrompt}
                  onChange={e => setImagePrompt(e.target.value)}
                  className="min-h-[80px] resize-none"
                />
              </div>

              <Button
                onClick={handleGenerateImage}
                disabled={isGeneratingImage || (!productName.trim() && !imagePrompt.trim())}
                className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 text-white gap-2"
              >
                {isGeneratingImage ? (
                  <><Loader2 className="size-4 animate-spin" /> Generating Image...</>
                ) : (
                  <><ImageIcon className="size-4" /> Generate Product Image</>
                )}
              </Button>

              <AnimatePresence mode="wait">
                {isGeneratingImage && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="flex items-center gap-3 p-4 rounded-xl bg-purple-50 border border-purple-200"
                  >
                    <Loader2 className="size-5 text-purple-600 animate-spin" />
                    <div>
                      <p className="font-medium text-sm text-purple-700">Creating your product image...</p>
                      <p className="text-xs text-purple-600">This may take 10-30 seconds with DALL-E 3</p>
                    </div>
                  </motion.div>
                )}

                {imageError && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 rounded-xl bg-red-50 border border-red-200"
                  >
                    <p className="text-sm text-red-600 break-words">{imageError}</p>
                  </motion.div>
                )}

                {generatedImageUrl && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-3"
                  >
                    <div className="relative rounded-xl overflow-hidden border border-border/50 bg-muted/10">
                      <img
                        src={generatedImageUrl}
                        alt={`AI-generated product image for ${productName}`}
                        className="w-full max-h-[500px] object-contain max-w-full"
                      />
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleDownloadImage}
                        className="gap-1.5 text-xs min-h-[44px]"
                      >
                        <Download className="size-3.5" />
                        Download Image
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleGenerateImage}
                        className="gap-1.5 text-xs min-h-[44px]"
                      >
                        <RefreshCw className="size-3.5" />
                        Generate New
                      </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Usage hint */}
      <div className="text-center">
        <p className="text-xs text-muted-foreground">
          AI features use OpenAI GPT-4o-mini & DALL-E 3 • {isAdmin ? 'Unlimited uses (Admin)' : `${remaining} uses remaining today`}
        </p>
      </div>

      {/* Donation prompt */}
      <ToolDonationPrompt onSupportClick={onSupportClick} />
    </div>
  )
}
