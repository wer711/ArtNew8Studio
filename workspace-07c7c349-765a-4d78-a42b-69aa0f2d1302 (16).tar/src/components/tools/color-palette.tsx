'use client'

import { useState, useCallback, useEffect, useRef, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Palette,
  Copy,
  Check,
  Sparkles,
  Save,
  Trash2,
  Download,
  RotateCcw,
  FileText,
  Eye,
  Code2,
  Accessibility,
  Upload,
  Search,
  Dice5,
  LayoutDashboard,
  Share2,
  ImageIcon,
  Shirt,
  Monitor,
  Camera,
} from 'lucide-react'
import { useUsageTracker } from '@/hooks/use-usage-tracker'
import { useSharedData } from '@/hooks/use-shared-data'
import { useMarketInsights } from '@/hooks/use-market-insights'
import { LimitPopup } from '@/components/support/limit-popup'
import { ToolDonationPrompt } from '@/components/support/tool-donation-prompt'
import { downloadAsImage, downloadAsPDF } from '@/lib/export-utils'
import { toast } from '@/hooks/use-toast'

// ═══════════════════════════════════════════════════════════════════════
// COLOR MATH UTILITIES
// ═══════════════════════════════════════════════════════════════════════

function hexToHSL(hex: string): { h: number; s: number; l: number } {
  hex = hex.replace('#', '')
  const r = parseInt(hex.substring(0, 2), 16) / 255
  const g = parseInt(hex.substring(2, 4), 16) / 255
  const b = parseInt(hex.substring(4, 6), 16) / 255
  const max = Math.max(r, g, b)
  const min = Math.min(r, g, b)
  const l = (max + min) / 2
  if (max === min) return { h: 0, s: 0, l: Math.round(l * 100) }
  const d = max - min
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
  let h = 0
  if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6
  else if (max === g) h = ((b - r) / d + 2) / 6
  else h = ((r - g) / d + 4) / 6
  return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) }
}

function hslToHex(h: number, s: number, l: number): string {
  s /= 100
  l /= 100
  const a = s * Math.min(l, 1 - l)
  const f = (n: number) => {
    const k = (n + h / 30) % 12
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1)
    return Math.round(255 * Math.max(0, Math.min(1, color)))
      .toString(16)
      .padStart(2, '0')
  }
  return `#${f(0)}${f(8)}${f(4)}`
}

function hexToRGB(hex: string): { r: number; g: number; b: number } {
  hex = hex.replace('#', '')
  return {
    r: parseInt(hex.substring(0, 2), 16),
    g: parseInt(hex.substring(2, 4), 16),
    b: parseInt(hex.substring(4, 6), 16),
  }
}

function getRelativeLuminance(hex: string): number {
  const { r, g, b } = hexToRGB(hex)
  const linearize = (c: number) => {
    const s = c / 255
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4)
  }
  return 0.2126 * linearize(r) + 0.7152 * linearize(g) + 0.0722 * linearize(b)
}

function getContrastRatio(hex1: string, hex2: string): number {
  const l1 = getRelativeLuminance(hex1)
  const l2 = getRelativeLuminance(hex2)
  const lighter = Math.max(l1, l2)
  const darker = Math.min(l1, l2)
  return (lighter + 0.05) / (darker + 0.05)
}

function simulateColorBlindness(hex: string, type: 'protanopia' | 'deuteranopia' | 'tritanopia'): string {
  const { r, g, b } = hexToRGB(hex)
  const rn = r / 255, gn = g / 255, bn = b / 255
  let sr: number, sg: number, sb: number
  if (type === 'protanopia') {
    sr = 0.567 * rn + 0.433 * gn; sg = 0.558 * rn + 0.442 * gn; sb = 0.000 * rn + 0.242 * gn + 0.758 * bn
  } else if (type === 'deuteranopia') {
    sr = 0.625 * rn + 0.375 * gn; sg = 0.700 * rn + 0.300 * gn; sb = 0.000 * rn + 0.300 * gn + 0.700 * bn
  } else {
    sr = 0.950 * rn + 0.050 * gn; sg = 0.000 * rn + 0.433 * gn + 0.567 * bn; sb = 0.000 * rn + 0.475 * gn + 0.525 * bn
  }
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v * 255)))
  const toHex = (v: number) => v.toString(16).padStart(2, '0')
  return `#${toHex(clamp(sr))}${toHex(clamp(sg))}${toHex(clamp(sb))}`
}

function getContrastColor(hex: string): string {
  const { l } = hexToHSL(hex)
  return l > 55 ? '#1a1a1a' : '#ffffff'
}

function generateTintsShadesTones(hex: string): { tints: string[]; shades: string[]; tones: string[] } {
  const { h, s } = hexToHSL(hex)
  const tints = [10, 20, 30, 40].map(l => hslToHex(h, Math.max(s - 15, 5), Math.min(l, 95)))
  const shades = [80, 65, 50, 35].map(l => hslToHex(h, s, l))
  const tones = [50, 40, 30, 20].map(sat => hslToHex(h, sat, 50))
  return { tints, shades, tones }
}

// ═══════════════════════════════════════════════════════════════════════
// COLOR NAME DETECTION
// ═══════════════════════════════════════════════════════════════════════

const COLOR_NAMES: [string, string][] = [
  ['#FF0000', 'Red'], ['#DC143C', 'Crimson'], ['#B22222', 'Firebrick'],
  ['#FF4500', 'Orange Red'], ['#FF6347', 'Tomato'], ['#FFA500', 'Orange'],
  ['#FF8C00', 'Dark Orange'], ['#FFD700', 'Gold'], ['#FFFF00', 'Yellow'],
  ['#FFFACD', 'Lemon Chiffon'], ['#F0E68C', 'Khaki'], ['#BDB76B', 'Dark Khaki'],
  ['#808000', 'Olive'], ['#6B8E23', 'Olive Drab'], ['#556B2F', 'Dark Olive Green'],
  ['#00FF00', 'Lime'], ['#32CD32', 'Lime Green'], ['#228B22', 'Forest Green'],
  ['#008000', 'Green'], ['#006400', 'Dark Green'], ['#2E8B57', 'Sea Green'],
  ['#3CB371', 'Medium Sea Green'], ['#90EE90', 'Light Green'], ['#98FB98', 'Pale Green'],
  ['#00FA9A', 'Medium Spring Green'], ['#00FF7F', 'Spring Green'], ['#20B2AA', 'Light Sea Green'],
  ['#008080', 'Teal'], ['#008B8B', 'Dark Cyan'], ['#00CED1', 'Dark Turquoise'],
  ['#40E0D0', 'Turquoise'], ['#48D1CC', 'Medium Turquoise'], ['#7FFFD4', 'Aquamarine'],
  ['#00FFFF', 'Cyan'], ['#E0FFFF', 'Light Cyan'], ['#87CEEB', 'Sky Blue'],
  ['#4682B4', 'Steel Blue'], ['#5F9EA0', 'Cadet Blue'], ['#00BFFF', 'Deep Sky Blue'],
  ['#1E90FF', 'Dodger Blue'], ['#4169E1', 'Royal Blue'], ['#0000FF', 'Blue'],
  ['#0000CD', 'Medium Blue'], ['#00008B', 'Dark Blue'], ['#000080', 'Navy'],
  ['#191970', 'Midnight Blue'], ['#6A5ACD', 'Slate Blue'], ['#7B68EE', 'Medium Slate Blue'],
  ['#8A2BE2', 'Blue Violet'], ['#9400D3', 'Dark Violet'], ['#9932CC', 'Dark Orchid'],
  ['#800080', 'Purple'], ['#8B008B', 'Dark Magenta'], ['#FF00FF', 'Magenta'],
  ['#FF1493', 'Deep Pink'], ['#FF69B4', 'Hot Pink'], ['#FFC0CB', 'Pink'],
  ['#FFB6C1', 'Light Pink'], ['#DB7093', 'Pale Violet Red'], ['#C71585', 'Medium Violet Red'],
  ['#A52A2A', 'Brown'], ['#8B4513', 'Saddle Brown'], ['#D2691E', 'Chocolate'],
  ['#CD853F', 'Peru'], ['#F4A460', 'Sandy Brown'], ['#DEB887', 'Burlywood'],
  ['#D2B48C', 'Tan'], ['#BC8F8F', 'Rosy Brown'], ['#C67B5C', 'Terracotta'],
  ['#D4A843', 'Antique Gold'], ['#C8B88A', 'Sage Sand'], ['#9CAF88', 'Sage Green'],
  ['#F5EFE0', 'Cream'], ['#FAF8F5', 'Ivory'], ['#F5F0E1', 'Eggshell'],
  ['#E8C4B8', 'Dusty Rose'], ['#F0D9D2', 'Blush'], ['#F4ACB7', 'Salmon Pink'],
  ['#A8DADC', 'Powder Blue'], ['#D6EADF', 'Mint Cream'], ['#2A9D8F', 'Teal Green'],
  ['#48BFE3', 'Sky Cyan'], ['#90E0EF', 'Light Cyan Blue'], ['#C41E3A', 'Cardinal'],
  ['#2E6B4F', 'Hunter Green'], ['#8B1A2B', 'Dark Burgundy'], ['#FFFFFF', 'White'],
  ['#F5F5F5', 'White Smoke'], ['#DCDCDC', 'Gainsboro'], ['#C0C0C0', 'Silver'],
  ['#A9A9A9', 'Dark Gray'], ['#808080', 'Gray'], ['#696969', 'Dim Gray'],
  ['#404040', 'Charcoal'], ['#333333', 'Dark Charcoal'], ['#1A1A1A', 'Near Black'],
  ['#000000', 'Black'], ['#E6B8A2', 'Peach'], ['#B5838D', 'Mauve'],
  ['#6D6875', 'Old Lavender'], ['#CB997E', 'Fawn'], ['#DDBEA9', 'Buff'],
  ['#A5A58D', 'Sage'], ['#B7B7A4', 'Moss'], ['#FFE8D6', 'Seashell'],
  ['#D5C6E0', 'Wisteria'], ['#E8DEF8', 'Lavender Mist'], ['#FFB4A2', 'Coral Pink'],
  ['#FFCDB2', 'Peach Puff'], ['#E5989B', 'Rose Dust'], ['#5C374C', 'Plum'],
]

function getClosestColorName(hex: string): string {
  const { r: tr, g: tg, b: tb } = hexToRGB(hex)
  let minDist = Infinity
  let closestName = 'Unknown'
  for (const [colorHex, name] of COLOR_NAMES) {
    const { r, g, b } = hexToRGB(colorHex)
    const dist = Math.sqrt((tr - r) ** 2 + (tg - g) ** 2 + (tb - b) ** 2)
    if (dist < minDist) { minDist = dist; closestName = name }
  }
  return closestName
}

// ═══════════════════════════════════════════════════════════════════════
// HARMONY GENERATION (9 types)
// ═══════════════════════════════════════════════════════════════════════

type HarmonyType =
  | 'complementary'
  | 'analogous'
  | 'triadic'
  | 'split-complementary'
  | 'tetradic'
  | 'monochromatic'
  | 'square'
  | 'compound'
  | 'shades'

interface HarmonyOption {
  value: HarmonyType
  label: string
  description: string
}

const HARMONY_OPTIONS: HarmonyOption[] = [
  { value: 'complementary', label: 'Complementary', description: 'Opposite on the color wheel' },
  { value: 'analogous', label: 'Analogous', description: 'Adjacent colors' },
  { value: 'triadic', label: 'Triadic', description: '3 equally spaced colors' },
  { value: 'split-complementary', label: 'Split-Comp', description: 'Complement neighbors' },
  { value: 'tetradic', label: 'Tetradic', description: '4 equally spaced colors' },
  { value: 'monochromatic', label: 'Monochromatic', description: 'Same hue, varied tone' },
  { value: 'square', label: 'Square', description: '4 colors, 90\u00B0 apart' },
  { value: 'compound', label: 'Compound', description: 'Both sides of complement' },
  { value: 'shades', label: 'Shades', description: 'Same hue, 5 lightness levels' },
]

function generatePalette(baseHex: string, harmony: HarmonyType): string[] {
  const { h, s, l } = hexToHSL(baseHex)
  const clampH = (val: number) => ((val % 360) + 360) % 360
  const clamp = (val: number, min: number, max: number) => Math.max(min, Math.min(max, val))

  switch (harmony) {
    case 'complementary':
      return [
        hslToHex(h, s, l),
        hslToHex(h, clamp(s - 10, 10, 100), clamp(l + 15, 15, 90)),
        hslToHex(clampH(h + 180), s, l),
        hslToHex(clampH(h + 180), clamp(s - 10, 10, 100), clamp(l + 15, 15, 90)),
        hslToHex(h, clamp(s - 20, 5, 80), clamp(l + 30, 25, 95)),
      ]
    case 'analogous':
      return [
        hslToHex(clampH(h - 30), s, l),
        hslToHex(clampH(h - 15), clamp(s - 5, 10, 100), clamp(l + 5, 15, 90)),
        hslToHex(h, s, l),
        hslToHex(clampH(h + 15), clamp(s - 5, 10, 100), clamp(l + 5, 15, 90)),
        hslToHex(clampH(h + 30), s, l),
      ]
    case 'triadic':
      return [
        hslToHex(h, s, l),
        hslToHex(h, clamp(s - 15, 10, 80), clamp(l + 20, 25, 90)),
        hslToHex(clampH(h + 120), s, l),
        hslToHex(clampH(h + 240), s, l),
        hslToHex(clampH(h + 240), clamp(s - 15, 10, 80), clamp(l + 20, 25, 90)),
      ]
    case 'split-complementary':
      return [
        hslToHex(h, s, l),
        hslToHex(h, clamp(s - 15, 10, 80), clamp(l + 20, 25, 90)),
        hslToHex(clampH(h + 150), s, l),
        hslToHex(clampH(h + 210), s, l),
        hslToHex(clampH(h + 180), clamp(s - 20, 10, 60), clamp(l + 25, 30, 90)),
      ]
    case 'tetradic':
      return [
        hslToHex(h, s, l),
        hslToHex(clampH(h + 90), s, l),
        hslToHex(clampH(h + 180), s, l),
        hslToHex(clampH(h + 270), s, l),
        hslToHex(h, clamp(s - 25, 10, 60), clamp(l + 30, 30, 95)),
      ]
    case 'monochromatic':
      return [
        hslToHex(h, s, clamp(l - 20, 10, 80)),
        hslToHex(h, s, clamp(l - 10, 10, 85)),
        hslToHex(h, s, l),
        hslToHex(h, clamp(s - 10, 10, 100), clamp(l + 15, 15, 90)),
        hslToHex(h, clamp(s - 20, 5, 80), clamp(l + 28, 20, 95)),
      ]
    case 'square':
      return [
        hslToHex(h, s, l),
        hslToHex(clampH(h + 90), s, clamp(l + 5, 15, 90)),
        hslToHex(clampH(h + 180), s, l),
        hslToHex(clampH(h + 270), s, clamp(l + 5, 15, 90)),
        hslToHex(h, clamp(s - 30, 5, 60), clamp(l + 25, 30, 95)),
      ]
    case 'compound':
      return [
        hslToHex(h, s, l),
        hslToHex(clampH(h + 150), s, clamp(l + 5, 15, 90)),
        hslToHex(clampH(h + 180), s, l),
        hslToHex(clampH(h + 210), s, clamp(l + 5, 15, 90)),
        hslToHex(h, clamp(s - 25, 5, 70), clamp(l + 25, 25, 95)),
      ]
    case 'shades':
      return [
        hslToHex(h, s, clamp(l - 30, 5, 60)),
        hslToHex(h, s, clamp(l - 15, 10, 75)),
        hslToHex(h, s, l),
        hslToHex(h, clamp(s - 10, 10, 100), clamp(l + 15, 15, 90)),
        hslToHex(h, clamp(s - 20, 5, 80), clamp(l + 30, 25, 95)),
      ]
  }
}

// ═══════════════════════════════════════════════════════════════════════
// IMAGE COLOR EXTRACTION
// ═══════════════════════════════════════════════════════════════════════

async function extractColorsFromImage(file: File): Promise<string[]> {
  return new Promise((resolve) => {
    const img = new Image()
    const reader = new FileReader()
    reader.onload = (e) => {
      img.onload = () => {
        const canvas = document.createElement('canvas')
        const ctx = canvas.getContext('2d')
        if (!ctx) { resolve(['#C67B5C', '#D4A843', '#9CAF88', '#F5EFE0', '#E8C4B8']); return }
        const maxDim = 100
        const scale = Math.min(maxDim / img.width, maxDim / img.height, 1)
        canvas.width = Math.max(1, Math.round(img.width * scale))
        canvas.height = Math.max(1, Math.round(img.height * scale))
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data
        // Sample pixels and cluster
        const pixelBuckets: Map<string, { r: number; g: number; b: number; count: number }> = new Map()
        for (let i = 0; i < data.length; i += 16) { // sample every 4th pixel
          const r = data[i], g = data[i + 1], b = data[i + 2]
          // Quantize to reduce colors
          const qr = Math.round(r / 32) * 32
          const qg = Math.round(g / 32) * 32
          const qb = Math.round(b / 32) * 32
          const key = `${qr},${qg},${qb}`
          const existing = pixelBuckets.get(key)
          if (existing) {
            existing.r += r; existing.g += g; existing.b += b; existing.count++
          } else {
            pixelBuckets.set(key, { r, g, b, count: 1 })
          }
        }
        // Sort by frequency and pick top colors that are distinct
        const sorted = [...pixelBuckets.values()]
          .map(b => ({ r: Math.round(b.r / b.count), g: Math.round(b.g / b.count), b: Math.round(b.b / b.count), count: b.count }))
          .sort((a, b) => b.count - a.count)
        const results: string[] = []
        const toHex = (v: number) => Math.max(0, Math.min(255, v)).toString(16).padStart(2, '0')
        for (const c of sorted) {
          if (results.length >= 5) break
          const hex = `#${toHex(c.r)}${toHex(c.g)}${toHex(c.b)}`
          // Check if distinct from existing picks
          const isDistinct = results.every(existing => {
            const e = hexToRGB(existing)
            return Math.sqrt((c.r - e.r) ** 2 + (c.g - e.g) ** 2 + (c.b - e.b) ** 2) > 40
          })
          if (isDistinct) results.push(hex)
        }
        // Pad if fewer than 5
        while (results.length < 5) results.push(hslToHex(Math.round(results.length * 72), 50, 50))
        resolve(results)
      }
      img.src = e.target?.result as string
    }
    reader.readAsDataURL(file)
  })
}

// ═══════════════════════════════════════════════════════════════════════
// EXPORT FORMAT GENERATORS
// ═══════════════════════════════════════════════════════════════════════

function generateCSSVariables(colors: string[]): string {
  const lines = colors.map((c, i) => `  --palette-${i + 1}: ${c};`)
  return `:root {\n${lines.join('\n')}\n}`
}

function generateTailwindConfig(colors: string[]): string {
  const entries = colors.map((c, i) => `      'palette-${i + 1}': '${c}',`)
  return `colors: {\n${entries.join('\n')}\n    }`
}

function generateSCSSVariables(colors: string[]): string {
  const entries = colors.map((c, i) => `$palette-${i + 1}: ${c};`)
  return entries.join('\n')
}

// ═══════════════════════════════════════════════════════════════════════
// CRAFT PRESETS (20+ palettes)
// ═══════════════════════════════════════════════════════════════════════

interface CraftPalette {
  name: string
  colors: string[]
}

const CRAFT_PALETTES: CraftPalette[] = [
  { name: 'Wedding Elegance', colors: ['#FAF8F5', '#F5EDE3', '#F0D9D2', '#E8C4B8', '#D4A99A'] },
  { name: 'Rustic Charm', colors: ['#8B7355', '#9CAF88', '#C8B88A', '#E8DCC8', '#F5EFE0'] },
  { name: 'Spring Garden', colors: ['#F4ACB7', '#FFDBE5', '#A8DADC', '#B8E0D2', '#D6EADF'] },
  { name: 'Holiday Cheer', colors: ['#C41E3A', '#2E6B4F', '#D4A843', '#F5F0E1', '#8B1A2B'] },
  { name: 'Boho Desert', colors: ['#C67B5C', '#D4A843', '#9CAF88', '#F5EFE0', '#E8C4B8'] },
  { name: 'Ocean Breeze', colors: ['#2A9D8F', '#48BFE3', '#90E0EF', '#E8DCC8', '#F8F7F4'] },
  { name: 'Autumn Harvest', colors: ['#8B4513', '#CD853F', '#DAA520', '#D2691E', '#F4A460'] },
  { name: 'Lavender Dreams', colors: ['#E6E6FA', '#D8BFD8', '#9370DB', '#7B68EE', '#4B0082'] },
  { name: 'Vintage Teal', colors: ['#2F4F4F', '#5F9EA0', '#7FFFD4', '#F0E68C', '#FAF0E6'] },
  { name: 'Cherry Blossom', colors: ['#FFB7C5', '#FF69B4', '#DB7093', '#FFF0F5', '#F8F8FF'] },
  { name: 'Forest Cabin', colors: ['#3B2F2F', '#556B2F', '#6B8E23', '#8FBC8F', '#F5F5DC'] },
  { name: 'Midnight Gala', colors: ['#191970', '#483D8B', '#C0C0C0', '#D4AF37', '#FFFAF0'] },
  { name: 'Tropical Paradise', colors: ['#FF6B35', '#00B4D8', '#90BE6D', '#F9C74F', '#F94144'] },
  { name: 'Baby Nursery', colors: ['#FFD6E0', '#C8E7ED', '#FFF1BA', '#D4EDDA', '#E8DAEF'] },
  { name: 'Mardi Gras', colors: ['#7B2D8E', '#F0C808', '#0D7B3F', '#E8175D', '#2C3E50'] },
  { name: 'Scandinavian', colors: ['#F5F5F0', '#E8E0D8', '#B0A898', '#5C524A', '#2D2926'] },
  { name: 'Mediterranean', colors: ['#1A5276', '#2E86C1', '#F0E68C', '#E67E22', '#FDFEFE'] },
  { name: 'Art Deco', colors: ['#1B1B1B', '#D4AF37', '#F5F5DC', '#800020', '#C0C0C0'] },
  { name: 'Vintage Rose', colors: ['#C9A9A6', '#E8D5D0', '#F2E8E5', '#8B6F6E', '#5C3D3E'] },
  { name: 'Sage & Stone', colors: ['#9CAF88', '#B5B8A8', '#D4C9B8', '#8B8178', '#5C5550'] },
  { name: 'Sunset Glow', colors: ['#FF6B6B', '#FFA07A', '#FFD93D', '#FF8E53', '#6C5B7B'] },
  { name: 'Arctic Frost', colors: ['#E8F4FD', '#B8D8E8', '#7FB3D3', '#4A90A4', '#2C5F72'] },
  { name: 'Moroccan Spice', colors: ['#C0392B', '#E67E22', '#F1C40F', '#1A5276', '#FDEBD0'] },
  { name: 'Garden Party', colors: ['#FF8FAB', '#FFB3C6', '#B5E48C', '#76C893', '#F9F7F3'] },
  { name: 'Parisian Chic', colors: ['#2C2C2C', '#D4C5A9', '#C4A882', '#F5F0EB', '#8B0000'] },
  { name: 'Nautical', colors: ['#003566', '#0077B6', '#90E0EF', '#F0F0F0', '#C81D25'] },
  { name: 'Candy Shop', colors: ['#FF69B4', '#FFB347', '#98FB98', '#87CEEB', '#DDA0DD'] },
  { name: 'Enchanted Forest', colors: ['#1B4332', '#2D6A4F', '#52B788', '#95D5B2', '#D8F3DC'] },
]

// ═══════════════════════════════════════════════════════════════════════
// COLOR SEARCH DATABASE
// ═══════════════════════════════════════════════════════════════════════

const COLOR_SEARCH_DB: { name: string; hex: string }[] = [
  { name: 'Red', hex: '#FF0000' }, { name: 'Crimson', hex: '#DC143C' },
  { name: 'Coral', hex: '#FF7F50' }, { name: 'Tomato', hex: '#FF6347' },
  { name: 'Orange', hex: '#FFA500' }, { name: 'Gold', hex: '#FFD700' },
  { name: 'Yellow', hex: '#FFFF00' }, { name: 'Lime', hex: '#00FF00' },
  { name: 'Green', hex: '#008000' }, { name: 'Forest', hex: '#228B22' },
  { name: 'Teal', hex: '#008080' }, { name: 'Cyan', hex: '#00FFFF' },
  { name: 'Sky Blue', hex: '#87CEEB' }, { name: 'Blue', hex: '#0000FF' },
  { name: 'Navy', hex: '#000080' }, { name: 'Indigo', hex: '#4B0082' },
  { name: 'Purple', hex: '#800080' }, { name: 'Violet', hex: '#EE82EE' },
  { name: 'Magenta', hex: '#FF00FF' }, { name: 'Pink', hex: '#FFC0CB' },
  { name: 'Hot Pink', hex: '#FF69B4' }, { name: 'Rose', hex: '#FF007F' },
  { name: 'Brown', hex: '#A52A2A' }, { name: 'Chocolate', hex: '#D2691E' },
  { name: 'Tan', hex: '#D2B48C' }, { name: 'Terracotta', hex: '#C67B5C' },
  { name: 'Cream', hex: '#F5EFE0' }, { name: 'Ivory', hex: '#FAF8F5' },
  { name: 'White', hex: '#FFFFFF' }, { name: 'Silver', hex: '#C0C0C0' },
  { name: 'Gray', hex: '#808080' }, { name: 'Charcoal', hex: '#404040' },
  { name: 'Black', hex: '#000000' }, { name: 'Sage', hex: '#9CAF88' },
  { name: 'Dusty Rose', hex: '#E8C4B8' }, { name: 'Blush', hex: '#F0D9D2' },
  { name: 'Mauve', hex: '#B5838D' }, { name: 'Lavender', hex: '#E6E6FA' },
  { name: 'Peach', hex: '#FFCBA4' }, { name: 'Mint', hex: '#A8DADC' },
  { name: 'Turquoise', hex: '#40E0D0' }, { name: 'Salmon', hex: '#FA8072' },
  { name: 'Burgundy', hex: '#8B1A2B' }, { name: 'Maroon', hex: '#800000' },
  { name: 'Olive', hex: '#808000' }, { name: 'Khaki', hex: '#F0E68C' },
  { name: 'Rust', hex: '#B7410E' }, { name: 'Plum', hex: '#5C374C' },
]

// ═══════════════════════════════════════════════════════════════════════
// LOCALSTORAGE HELPERS
// ═══════════════════════════════════════════════════════════════════════

interface SavedPalette {
  id: string
  name: string
  colors: string[]
  createdAt: string
}

interface PaletteSession {
  baseColor: string
  hexInput: string
  harmony: HarmonyType
  palette: string[]
  activeTab: string
}

const SESSION_KEY = 'artnew8-color-session'

function loadSavedPalettes(): SavedPalette[] {
  if (typeof window === 'undefined') return []
  try {
    const saved = localStorage.getItem('artnew8-palettes')
    if (saved) return JSON.parse(saved)
  } catch { /* ignore */ }
  return []
}

function savePalettesToStorage(palettes: SavedPalette[]) {
  if (typeof window === 'undefined') return
  try { localStorage.setItem('artnew8-palettes', JSON.stringify(palettes)) } catch { /* ignore */ }
}

function loadSession(): PaletteSession | null {
  if (typeof window === 'undefined') return null
  try {
    const saved = localStorage.getItem(SESSION_KEY)
    if (saved) return JSON.parse(saved)
  } catch { /* ignore */ }
  return null
}

function saveSession(session: PaletteSession) {
  if (typeof window === 'undefined') return
  try { localStorage.setItem(SESSION_KEY, JSON.stringify(session)) } catch { /* ignore */ }
}

// ═══════════════════════════════════════════════════════════════════════
// ACCESSIBILITY HELPERS
// ═══════════════════════════════════════════════════════════════════════

function calculateAccessibilityScore(colors: string[]): number {
  if (colors.length < 2) return 0
  let totalPass = 0
  let totalChecks = 0
  // Check all pairs
  for (let i = 0; i < colors.length; i++) {
    for (let j = i + 1; j < colors.length; j++) {
      totalChecks++
      const ratio = getContrastRatio(colors[i], colors[j])
      if (ratio >= 4.5) totalPass += 1
      else if (ratio >= 3) totalPass += 0.5
    }
    // Check against white and black
    totalChecks += 2
    if (getContrastRatio(colors[i], '#FFFFFF') >= 4.5) totalPass += 1
    else if (getContrastRatio(colors[i], '#FFFFFF') >= 3) totalPass += 0.5
    if (getContrastRatio(colors[i], '#000000') >= 4.5) totalPass += 1
    else if (getContrastRatio(colors[i], '#000000') >= 3) totalPass += 0.5
  }
  return totalChecks > 0 ? Math.round((totalPass / totalChecks) * 100) : 0
}

function getBestTextColor(bgHex: string): { color: string; ratio: number } {
  const whiteRatio = getContrastRatio(bgHex, '#FFFFFF')
  const blackRatio = getContrastRatio(bgHex, '#000000')
  if (whiteRatio >= blackRatio) return { color: '#FFFFFF', ratio: whiteRatio }
  return { color: '#000000', ratio: blackRatio }
}

// ═══════════════════════════════════════════════════════════════════════
// EXPORT ELEMENT BUILDER
// Generates a complete, self-contained DOM element for export.
// This is independent of which tab is active — no more "Element not found" errors
// and captures ALL data (not just what's visible on screen).
// ═══════════════════════════════════════════════════════════════════════

let exportIdCounter = 0

function buildPaletteExportElement(
  palette: string[],
  harmony: HarmonyType,
  accessibilityScore: number,
  bestTextColors: { color: string; ratio: number }[]
): HTMLElement {
  const exportId = `color-export-${++exportIdCounter}-${Date.now()}`
  const container = document.createElement('div')
  container.id = exportId
  container.style.cssText = 'position:absolute;left:-9999px;top:0;width:800px;background:#fff;font-family:system-ui,-apple-system,sans-serif;color:#1a1a1a;'

  // Build comprehensive export HTML with ALL palette data
  const swatchesHtml = palette.map((color, i) => {
    const { r, g, b } = hexToRGB(color)
    const hsl = hexToHSL(color)
    const name = getClosestColorName(color)
    const textColor = getContrastColor(color)
    const { tints, shades, tones } = generateTintsShadesTones(color)
    return `
      <div style="flex:1;min-width:140px;border:1px solid #e5e5e5;border-radius:12px;overflow:hidden;">
        <div style="height:100px;background:${color};display:flex;align-items:flex-end;padding:8px;">
          <span style="color:${textColor};font-size:14px;font-weight:700;font-family:monospace;">${color.toUpperCase()}</span>
        </div>
        <div style="padding:8px;background:#fff;">
          <div style="font-size:13px;font-weight:600;margin-bottom:4px;">${name}</div>
          <div style="font-size:11px;color:#666;font-family:monospace;">RGB(${r}, ${g}, ${b})</div>
          <div style="font-size:11px;color:#666;font-family:monospace;">HSL(${hsl.h}, ${hsl.s}%, ${hsl.l}%)</div>
          <div style="font-size:11px;color:#888;margin-top:4px;">Best text: ${bestTextColors[i]?.color === '#FFFFFF' ? 'White' : 'Black'} (${bestTextColors[i]?.ratio.toFixed(1)}:1)</div>
          <div style="margin-top:6px;">
            <div style="font-size:10px;color:#999;margin-bottom:2px;">Tints</div>
            <div style="display:flex;gap:2px;">${tints.map(t => `<div style="flex:1;height:16px;background:${t};border-radius:3px;border:1px solid #eee;"></div>`).join('')}</div>
            <div style="font-size:10px;color:#999;margin:2px 0;">Shades</div>
            <div style="display:flex;gap:2px;">${shades.map(s => `<div style="flex:1;height:16px;background:${s};border-radius:3px;border:1px solid #eee;"></div>`).join('')}</div>
            <div style="font-size:10px;color:#999;margin:2px 0;">Tones</div>
            <div style="display:flex;gap:2px;">${tones.map(t => `<div style="flex:1;height:16px;background:${t};border-radius:3px;border:1px solid #eee;"></div>`).join('')}</div>
          </div>
        </div>
      </div>`
  }).join('')

  // Palette preview bar
  const previewBar = palette.map(c => `<div style="flex:1;height:32px;background:${c};"></div>`).join('')

  // Contrast table
  let contrastRows = ''
  for (let i = 0; i < palette.length - 1; i++) {
    const c1 = palette[i], c2 = palette[i + 1]
    const ratio = getContrastRatio(c1, c2)
    const bgColor = i % 2 === 0 ? '#fff' : '#f9f9f9'
    contrastRows += `
      <tr style="background:${bgColor};">
        <td style="padding:6px 8px;font-size:12px;">
          <span style="display:inline-block;width:14px;height:14px;background:${c1};border-radius:3px;vertical-align:middle;border:1px solid #ddd;"></span>
          <span style="display:inline-block;width:14px;height:14px;background:${c2};border-radius:3px;vertical-align:middle;border:1px solid #ddd;margin-left:2px;"></span>
          <span style="margin-left:4px;">${i + 1}–${i + 2}</span>
        </td>
        <td style="padding:6px 8px;font-size:12px;text-align:right;font-family:monospace;">${ratio.toFixed(1)}:1</td>
        <td style="padding:6px 8px;font-size:11px;text-align:center;">
          <span style="display:inline-block;padding:2px 6px;border-radius:4px;font-size:10px;font-weight:600;${ratio >= 4.5 ? 'background:#dcfce7;color:#166534;' : ratio >= 3 ? 'background:#fef9c3;color:#854d0e;' : 'background:#fee2e2;color:#991b1b;'}">${ratio >= 4.5 ? 'Pass' : ratio >= 3 ? 'Large' : 'Fail'}</span>
        </td>
      </tr>`
  }

  // CSS Variables
  const cssVars = palette.map((c, i) => `  --palette-${i + 1}: ${c};`).join('\n')

  container.innerHTML = `
    <div style="padding:24px;">
      <!-- Header -->
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:2px solid #f0f0f0;">
        <div style="width:40px;height:40px;background:linear-gradient(135deg,#8b5cf6,#a855f7);border-radius:10px;display:flex;align-items:center;justify-content:center;">
          <span style="color:#fff;font-size:18px;">🎨</span>
        </div>
        <div>
          <div style="font-size:20px;font-weight:700;">Color Palette</div>
          <div style="font-size:13px;color:#888;">${harmony} harmony · ArtNew8 Studio</div>
        </div>
        <div style="margin-left:auto;text-align:right;">
          <div style="font-size:12px;color:#888;">Accessibility</div>
          <div style="font-size:18px;font-weight:700;color:${accessibilityScore >= 70 ? '#16a34a' : accessibilityScore >= 40 ? '#d97706' : '#dc2626'};">${accessibilityScore}%</div>
        </div>
      </div>

      <!-- Preview Bar -->
      <div style="display:flex;border-radius:8px;overflow:hidden;border:1px solid #e5e5e5;margin-bottom:20px;">
        ${previewBar}
      </div>

      <!-- Color Swatches -->
      <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px;">
        ${swatchesHtml}
      </div>

      <!-- Contrast Table -->
      <div style="margin-bottom:20px;">
        <div style="font-size:14px;font-weight:600;margin-bottom:8px;">WCAG Contrast Ratios</div>
        <table style="width:100%;border-collapse:collapse;border:1px solid #e5e5e5;border-radius:8px;overflow:hidden;">
          <thead>
            <tr style="background:#f5f5f5;">
              <th style="padding:8px;text-align:left;font-size:12px;font-weight:600;">Pair</th>
              <th style="padding:8px;text-align:right;font-size:12px;font-weight:600;">Ratio</th>
              <th style="padding:8px;text-align:center;font-size:12px;font-weight:600;">AA</th>
            </tr>
          </thead>
          <tbody>${contrastRows}</tbody>
        </table>
      </div>

      <!-- CSS Variables -->
      <div style="background:#f9f9f9;border:1px solid #e5e5e5;border-radius:8px;padding:12px;">
        <div style="font-size:12px;font-weight:600;margin-bottom:6px;">CSS Variables</div>
        <pre style="font-size:11px;font-family:monospace;color:#555;margin:0;white-space:pre-wrap;">:root {\n${cssVars}\n}</pre>
      </div>

      <!-- Footer -->
      <div style="margin-top:16px;text-align:center;font-size:10px;color:#bbb;">
        Generated by ArtNew8 Studio — Tools for handmade sellers
      </div>
    </div>
  `

  return container
}

// ═══════════════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════════════

export function ColorPaletteGenerator({ onSupportClick }: { onSupportClick: () => void }) {
  const { incrementUsage, canUse, getRemaining } = useUsageTracker()
  const { updateFromColors } = useSharedData()

  // Core state
  const [baseColor, setBaseColor] = useState('#C67B5C')
  const [hexInput, setHexInput] = useState('C67B5C')
  const [harmony, setHarmony] = useState<HarmonyType>('complementary')
  const [palette, setPalette] = useState<string[]>([])
  const [activeTab, setActiveTab] = useState('create')

  // UI state
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null)
  const [copiedAll, setCopiedAll] = useState(false)
  const [showLimitPopup, setShowLimitPopup] = useState(false)
  const [showAutoSaved, setShowAutoSaved] = useState(false)
  const [restoredSession, setRestoredSession] = useState(false)

  // Export states
  const [exportingImage, setExportingImage] = useState(false)
  const [exportingPDF, setExportingPDF] = useState(false)
  const [copiedCSS, setCopiedCSS] = useState(false)
  const [copiedTailwind, setCopiedTailwind] = useState(false)
  const [copiedSCSS, setCopiedSCSS] = useState(false)

  // Product Mockup state
  const [isGeneratingMockup, setIsGeneratingMockup] = useState(false)
  const [mockupImageUrl, setMockupImageUrl] = useState<string | null>(null)
  const [mockupError, setMockupError] = useState<string | null>(null)
  const [mockupProductType, setMockupProductType] = useState('handmade craft item')

  // Save/Load
  const [savedPalettes, setSavedPalettes] = useState<SavedPalette[]>(() => {
    if (typeof window === 'undefined') return []
    return loadSavedPalettes()
  })
  const [saveName, setSaveName] = useState('')
  const [isSaved, setIsSaved] = useState(false)

  // Color blindness
  const [colorBlindnessType, setColorBlindnessType] = useState<'protanopia' | 'deuteranopia' | 'tritanopia' | null>(null)

  // Image extraction
  const [extractingImage, setExtractingImage] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Color search
  const [searchQuery, setSearchQuery] = useState('')

  const initialized = useRef(false)
  const remaining = getRemaining()

  // ── Market insights for trending color indicators ────────────────
  const { insights: marketInsights } = useMarketInsights()

  // Compute which palette colors are "trending" or "in season"
  const trendingColorsSet = useMemo(() => {
    if (!marketInsights) return { trending: new Set<string>(), seasonal: new Set<string>() }
    const trending = new Set(marketInsights.colors.trending.map(c => c.toUpperCase()))
    const seasonal = new Set(marketInsights.colors.seasonal.map(c => c.toUpperCase()))
    return { trending, seasonal }
  }, [marketInsights])

  // Check if a hex color is close enough to a trending/seasonal color
  const getColorTrendStatus = useCallback((hex: string): 'trending' | 'seasonal' | null => {
    if (!marketInsights) return null
    const { r, g, b } = hexToRGB(hex)
    // Check trending colors — within 50 RGB distance
    for (const trendHex of marketInsights.colors.trending) {
      const t = hexToRGB(trendHex)
      const dist = Math.sqrt((r - t.r) ** 2 + (g - t.g) ** 2 + (b - t.b) ** 2)
      if (dist < 55) return 'trending'
    }
    // Check seasonal colors
    for (const seasonHex of marketInsights.colors.seasonal) {
      const s = hexToRGB(seasonHex)
      const dist = Math.sqrt((r - s.r) ** 2 + (g - s.g) ** 2 + (b - s.b) ** 2)
      if (dist < 55) return 'seasonal'
    }
    return null
  }, [marketInsights])

  // ── Auto-restore session ────────────────────────────────────────
  useEffect(() => {
    if (initialized.current) return
    initialized.current = true
    const session = loadSession()
    if (session) {
      setBaseColor(session.baseColor)
      setHexInput(session.hexInput)
      setHarmony(session.harmony)
      if (session.activeTab) setActiveTab(session.activeTab)
      if (session.palette?.length > 0) {
        setPalette(session.palette)
        setRestoredSession(true)
        setTimeout(() => setRestoredSession(false), 3000)
      }
    }
  }, [])

  // ── Auto-save session (debounced) ───────────────────────────────
  useEffect(() => {
    if (palette.length === 0 && !hexInput) return
    const timer = setTimeout(() => {
      saveSession({ baseColor, hexInput, harmony, palette, activeTab })
      setShowAutoSaved(true)
      setTimeout(() => setShowAutoSaved(false), 2000)
    }, 1000)
    return () => clearTimeout(timer)
  }, [baseColor, hexInput, harmony, palette, activeTab])

  // ── Handlers ────────────────────────────────────────────────────
  const handleColorPickerChange = useCallback((value: string) => {
    setBaseColor(value)
    setHexInput(value.replace('#', ''))
    setPalette(generatePalette(value, harmony))
    setIsSaved(false)
  }, [harmony])

  const handleHexInputChange = useCallback((value: string) => {
    const clean = value.replace(/[^0-9a-fA-F]/g, '').slice(0, 6)
    setHexInput(clean)
    if (clean.length === 6) {
      const newColor = `#${clean}`
      setBaseColor(newColor)
      setPalette(generatePalette(newColor, harmony))
      setIsSaved(false)
    }
  }, [harmony])

  const generateNewPalette = useCallback(() => {
    if (!canUse()) { setShowLimitPopup(true); return }
    const success = incrementUsage('colors', 'generate')
    if (!success) { setShowLimitPopup(true); return }
    const newPalette = generatePalette(baseColor, harmony)
    setPalette(newPalette)
    setIsSaved(false)
    setActiveTab('palette')
    updateFromColors({ paletteColors: newPalette, paletteName: `${harmony} palette` })
  }, [baseColor, harmony, canUse, incrementUsage, updateFromColors])

  const handleSurpriseMe = useCallback(() => {
    if (!canUse()) { setShowLimitPopup(true); return }
    const success = incrementUsage('colors', 'surprise')
    if (!success) { setShowLimitPopup(true); return }
    // Sometimes start from a preset, sometimes random
    const usePreset = Math.random() > 0.5
    if (usePreset) {
      const preset = CRAFT_PALETTES[Math.floor(Math.random() * CRAFT_PALETTES.length)]
      setPalette(preset.colors)
      setBaseColor(preset.colors[2] || preset.colors[0])
      setHexInput((preset.colors[2] || preset.colors[0]).replace('#', ''))
      updateFromColors({ paletteColors: preset.colors, paletteName: preset.name })
    } else {
      const h = Math.floor(Math.random() * 360)
      const s = 40 + Math.floor(Math.random() * 45)
      const l = 30 + Math.floor(Math.random() * 40)
      const newBase = hslToHex(h, s, l)
      setBaseColor(newBase)
      setHexInput(newBase.replace('#', ''))
      const randomHarmony = HARMONY_OPTIONS[Math.floor(Math.random() * HARMONY_OPTIONS.length)].value
      setHarmony(randomHarmony)
      const newPalette = generatePalette(newBase, randomHarmony)
      setPalette(newPalette)
      updateFromColors({ paletteColors: newPalette, paletteName: `${randomHarmony} palette` })
    }
    setIsSaved(false)
    setActiveTab('palette')
  }, [canUse, incrementUsage, updateFromColors])

  const handleImageUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!canUse()) { setShowLimitPopup(true); return }
    const success = incrementUsage('colors', 'image-extract')
    if (!success) { setShowLimitPopup(true); return }
    setExtractingImage(true)
    try {
      const colors = await extractColorsFromImage(file)
      setPalette(colors)
      setBaseColor(colors[2] || colors[0])
      setHexInput((colors[2] || colors[0]).replace('#', ''))
      setIsSaved(false)
      setActiveTab('palette')
      updateFromColors({ paletteColors: colors, paletteName: 'Image extract' })
    } finally {
      setExtractingImage(false)
    }
  }, [canUse, incrementUsage, updateFromColors])

  const copyColor = useCallback((hex: string, index: number) => {
    navigator.clipboard.writeText(hex)
    setCopiedIndex(index)
    setTimeout(() => setCopiedIndex(null), 1500)
  }, [])

  const copyAllColors = useCallback(() => {
    if (palette.length === 0) return
    navigator.clipboard.writeText(palette.join(', '))
    setCopiedAll(true)
    setTimeout(() => setCopiedAll(false), 1500)
  }, [palette])

  const saveCurrentPalette = useCallback(() => {
    if (palette.length === 0) return
    const name = saveName.trim() || `Palette ${savedPalettes.length + 1}`
    const newSaved: SavedPalette = { id: Date.now().toString(), name, colors: palette, createdAt: new Date().toISOString() }
    const updated = [newSaved, ...savedPalettes]
    setSavedPalettes(updated)
    savePalettesToStorage(updated)
    setSaveName('')
    setIsSaved(true)
  }, [palette, saveName, savedPalettes])

  const deleteSavedPalette = useCallback((id: string) => {
    const updated = savedPalettes.filter(p => p.id !== id)
    setSavedPalettes(updated)
    savePalettesToStorage(updated)
  }, [savedPalettes])

  const applyCraftPalette = useCallback((cp: CraftPalette) => {
    setPalette(cp.colors)
    setBaseColor(cp.colors[2] || cp.colors[0])
    setHexInput((cp.colors[2] || cp.colors[0]).replace('#', ''))
    setIsSaved(false)
    setActiveTab('palette')
    updateFromColors({ paletteColors: cp.colors, paletteName: cp.name })
  }, [updateFromColors])

  const applySavedPalette = useCallback((sp: SavedPalette) => {
    setPalette(sp.colors)
    setBaseColor(sp.colors[2] || sp.colors[0])
    setHexInput((sp.colors[2] || sp.colors[0]).replace('#', ''))
    setIsSaved(false)
    setActiveTab('palette')
    updateFromColors({ paletteColors: sp.colors, paletteName: sp.name })
  }, [updateFromColors])

  const handleExportImage = async () => {
    if (palette.length === 0) return
    setExportingImage(true)
    try {
      // Build a self-contained export element (doesn't depend on which tab is active)
      const container = buildPaletteExportElement(palette, harmony, accessibilityScore, bestTextColors)
      document.body.appendChild(container)
      await downloadAsImage(container.id, 'color-palette')
      document.body.removeChild(container)
    } catch (err) {
      console.error('Image export failed:', err)
    } finally {
      setExportingImage(false)
    }
  }

  const handleExportPDF = async () => {
    if (palette.length === 0) return
    setExportingPDF(true)
    try {
      // Build a self-contained export element (doesn't depend on which tab is active)
      const container = buildPaletteExportElement(palette, harmony, accessibilityScore, bestTextColors)
      document.body.appendChild(container)
      await downloadAsPDF(container.id, 'color-palette')
      document.body.removeChild(container)
    } catch (err) {
      console.error('PDF export failed:', err)
    } finally {
      setExportingPDF(false)
    }
  }

  const handleCopyCSS = useCallback(() => {
    if (palette.length === 0) return
    navigator.clipboard.writeText(generateCSSVariables(palette))
    setCopiedCSS(true); setTimeout(() => setCopiedCSS(false), 1500)
  }, [palette])

  const handleCopyTailwind = useCallback(() => {
    if (palette.length === 0) return
    navigator.clipboard.writeText(generateTailwindConfig(palette))
    setCopiedTailwind(true); setTimeout(() => setCopiedTailwind(false), 1500)
  }, [palette])

  const handleCopySCSS = useCallback(() => {
    if (palette.length === 0) return
    navigator.clipboard.writeText(generateSCSSVariables(palette))
    setCopiedSCSS(true); setTimeout(() => setCopiedSCSS(false), 1500)
  }, [palette])

  // Product Mockup handler
  const handleGenerateMockup = useCallback(async () => {
    if (palette.length === 0) return
    if (!canUse()) {
      setShowLimitPopup(true)
      return
    }
    setIsGeneratingMockup(true)
    setMockupError(null)
    setMockupImageUrl(null)
    try {
      const sessionId = typeof window !== 'undefined' ? localStorage.getItem('artnew8-session-id') || '' : ''
      const res = await fetch('/api/ai/generate-mockup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          colors: palette,
          productType: mockupProductType || 'handmade craft item',
          sessionId,
        }),
      })
      if (res.status === 429) {
        toast({ title: 'Please wait', description: 'Too many requests. Try again in a minute.' })
        return
      }
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Request failed' }))
        throw new Error(err.error || 'Request failed')
      }
      const data = await res.json()
      incrementUsage('colors', 'product-mockup')
      setMockupImageUrl(data.imageUrl)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong'
      setMockupError(message)
      toast({ title: 'Mockup generation failed', description: message, variant: 'destructive' })
    } finally {
      setIsGeneratingMockup(false)
    }
  }, [palette, mockupProductType, canUse, incrementUsage])

  // Color search results
  const searchResults = searchQuery.trim().length > 0
    ? COLOR_SEARCH_DB.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : []

  // Simulated palette for color blindness
  const simulatedPalette = colorBlindnessType && palette.length > 0
    ? palette.map(c => simulateColorBlindness(c, colorBlindnessType))
    : null

  // Accessibility score
  const accessibilityScore = palette.length > 0 ? calculateAccessibilityScore(palette) : 0

  // Best text color for each palette color
  const bestTextColors = palette.map(c => getBestTextColor(c))

  // ═══════════════════════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════════════════════

  return (
    <Card className="w-full overflow-hidden">
      <LimitPopup
        open={showLimitPopup}
        onClose={() => setShowLimitPopup(false)}
        onSupportClick={onSupportClick}
        remaining={remaining}
      />

      <CardHeader>
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500/10 to-purple-500/10 shrink-0">
              <Palette className="h-5 w-5 text-violet-600" />
            </div>
            <div className="min-w-0">
              <CardTitle className="text-xl truncate">Color Palette Generator</CardTitle>
              <CardDescription className="truncate">Create harmonious palettes for your craft projects</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {restoredSession && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-1 text-sm text-primary">
                <RotateCcw className="h-3 w-3" /> Session restored
              </motion.div>
            )}
            {showAutoSaved && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-1 text-sm text-muted-foreground">
                <Check className="h-3 w-3 text-green-600" /> Auto-saved
              </motion.div>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-2 sm:grid-cols-4 mb-4">
            <TabsTrigger value="create" className="gap-1 text-xs sm:text-sm">
              <Sparkles className="h-3.5 w-3.5" /> Create
            </TabsTrigger>
            <TabsTrigger value="palette" className="gap-1 text-xs sm:text-sm">
              <Palette className="h-3.5 w-3.5" /> Palette
            </TabsTrigger>
            <TabsTrigger value="analyze" className="gap-1 text-xs sm:text-sm">
              <Accessibility className="h-3.5 w-3.5" /> Analyze
            </TabsTrigger>
            <TabsTrigger value="export" className="gap-1 text-xs sm:text-sm">
              <Share2 className="h-3.5 w-3.5" /> Export
            </TabsTrigger>
          </TabsList>

          {/* ─────────── TAB: CREATE ─────────── */}
          <TabsContent value="create" className="space-y-5">
            {/* Base Color Picker */}
            <div className="space-y-2">
              <Label className="text-base font-semibold">Base Color</Label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={baseColor}
                  onChange={(e) => handleColorPickerChange(e.target.value)}
                  className="h-10 w-14 cursor-pointer rounded-md border border-border p-0.5"
                />
                <div className="flex items-center gap-1.5">
                  <span className="text-sm text-muted-foreground">#</span>
                  <Input
                    value={hexInput}
                    onChange={(e) => handleHexInputChange(e.target.value)}
                    placeholder="C67B5C"
                    className="w-28 font-mono text-sm uppercase"
                    maxLength={6}
                  />
                </div>
                <div
                  className="h-10 w-10 rounded-md border border-border shadow-sm"
                  style={{ backgroundColor: baseColor }}
                />
              </div>
            </div>

            <Separator />

            {/* Harmony Type */}
            <div className="space-y-2">
              <Label className="text-base font-semibold">Harmony Type</Label>
              <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
                {HARMONY_OPTIONS.map((opt) => (
                  <Tooltip key={opt.value}>
                    <TooltipTrigger asChild>
                      <Button
                        variant={harmony === opt.value ? 'default' : 'outline'}
                        size="sm"
                        className={`h-auto min-h-[44px] py-2 text-xs sm:text-sm truncate ${harmony === opt.value ? 'bg-gradient-to-r from-violet-500 to-purple-500 text-white' : ''}`}
                        onClick={() => setHarmony(opt.value)}
                      >
                        <span className="truncate">{opt.label}</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent><p>{opt.description}</p></TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>

            <Separator />

            {/* Generate + Surprise Me */}
            <div className="flex items-center gap-2">
              <Button
                onClick={generateNewPalette}
                disabled={!canUse()}
                className="flex-1 gap-2 bg-gradient-to-r from-violet-500 to-purple-500 hover:from-violet-600 hover:to-purple-600 text-white"
              >
                <Sparkles className="h-4 w-4" />
                Generate Palette
              </Button>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    onClick={handleSurpriseMe}
                    disabled={!canUse()}
                    className="gap-1.5 border-violet-300 text-violet-700 hover:bg-violet-50"
                  >
                    <Dice5 className="h-4 w-4" />
                    Surprise Me
                  </Button>
                </TooltipTrigger>
                <TooltipContent><p>Generate a random beautiful palette</p></TooltipContent>
              </Tooltip>
            </div>

            <div className="text-sm text-muted-foreground text-center">
              {remaining}/10 uses remaining today
            </div>

            <Separator />

            {/* Image Color Extraction */}
            <div className="space-y-2">
              <Label className="text-base font-semibold flex items-center gap-2">
                <ImageIcon className="h-4 w-4 text-violet-500" />
                Extract from Image
              </Label>
              <p className="text-sm text-muted-foreground">Upload an image to extract 5 dominant colors</p>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                className="hidden"
                onChange={handleImageUpload}
              />
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 w-full"
                onClick={() => fileInputRef.current?.click()}
                disabled={extractingImage || !canUse()}
              >
                <Upload className="h-3.5 w-3.5" />
                {extractingImage ? 'Extracting...' : 'Upload Image'}
              </Button>
            </div>

            <Separator />

            {/* Color Search */}
            <div className="space-y-2">
              <Label className="text-base font-semibold flex items-center gap-2">
                <Search className="h-4 w-4 text-violet-500" />
                Color Search
              </Label>
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name (e.g. sage, coral, dusty rose)"
                className="text-sm"
              />
              <AnimatePresence>
                {searchResults.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="max-h-32 overflow-y-auto rounded-md border bg-card"
                  >
                    {searchResults.map((c) => (
                      <button
                        key={c.name}
                        className="flex items-center gap-2 w-full px-3 py-1.5 text-sm hover:bg-muted transition-colors text-left"
                        onClick={() => {
                          handleColorPickerChange(c.hex)
                          setSearchQuery('')
                        }}
                      >
                        <span className="h-4 w-4 rounded-sm border flex-shrink-0" style={{ backgroundColor: c.hex }} />
                        <span className="font-medium">{c.name}</span>
                        <span className="text-muted-foreground font-mono">{c.hex}</span>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <Separator />

            {/* Craft Presets */}
            <div className="space-y-2">
              <Label className="text-base font-semibold">Craft Presets</Label>
              <div className="max-h-64 overflow-y-auto space-y-1.5 pr-1">
                {CRAFT_PALETTES.map((cp) => (
                  <button
                    key={cp.name}
                    className="w-full flex items-center gap-2.5 p-2 rounded-lg border border-border/50 hover:border-violet-300 hover:bg-violet-50/50 transition-all text-left group min-w-0"
                    onClick={() => applyCraftPalette(cp)}
                  >
                    <div className="flex gap-0.5 flex-shrink-0">
                      {cp.colors.map((c, i) => (
                        <span
                          key={i}
                          className="h-6 w-5 rounded-sm border border-border/30 group-hover:scale-110 transition-transform"
                          style={{ backgroundColor: c }}
                        />
                      ))}
                    </div>
                    <span className="text-sm font-medium text-foreground overflow-hidden text-ellipsis whitespace-nowrap min-w-0">{cp.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <Separator />

            {/* Trending Colors from Market Insights */}
            {marketInsights && (marketInsights.colors.trending.length > 0 || marketInsights.colors.seasonal.length > 0) && (
              <div className="space-y-2">
                <Label className="text-base font-semibold flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-[#C96A2B]" />
                  Trending in Crafts
                </Label>
                <p className="text-xs text-muted-foreground">
                  Colors currently trending in the handmade market — click to use as base color
                </p>
                <div className="space-y-3">
                  {marketInsights.colors.trending.length > 0 && (
                    <div>
                      <span className="text-[10px] text-muted-foreground uppercase tracking-wide font-semibold">🔥 Trending Now</span>
                      <div className="flex flex-wrap gap-2 mt-1.5">
                        {marketInsights.colors.trending.map((color, i) => (
                          <button
                            key={`trend-${i}`}
                            onClick={() => handleColorPickerChange(color)}
                            className="group flex items-center gap-1.5 px-2 py-1 rounded-lg border border-border/50 hover:border-emerald-300 hover:bg-emerald-50/50 transition-all"
                          >
                            <span
                              className="h-5 w-5 rounded-full border border-border/30 group-hover:scale-110 transition-transform"
                              style={{ backgroundColor: color }}
                            />
                            <span className="text-[10px] font-mono text-muted-foreground">{color}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  {marketInsights.colors.seasonal.length > 0 && (
                    <div>
                      <span className="text-[10px] text-muted-foreground uppercase tracking-wide font-semibold">🌿 In Season</span>
                      <div className="flex flex-wrap gap-2 mt-1.5">
                        {marketInsights.colors.seasonal.map((color, i) => (
                          <button
                            key={`season-${i}`}
                            onClick={() => handleColorPickerChange(color)}
                            className="group flex items-center gap-1.5 px-2 py-1 rounded-lg border border-border/50 hover:border-amber-300 hover:bg-amber-50/50 transition-all"
                          >
                            <span
                              className="h-5 w-5 rounded-full border border-border/30 group-hover:scale-110 transition-transform"
                              style={{ backgroundColor: color }}
                            />
                            <span className="text-[10px] font-mono text-muted-foreground">{color}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  {marketInsights.colors.insights.length > 0 && (
                    <p className="text-[10px] text-muted-foreground leading-relaxed">
                      💡 {marketInsights.colors.insights[0]}
                    </p>
                  )}
                </div>
              </div>
            )}
          </TabsContent>

          {/* ─────────── TAB: PALETTE ─────────── */}
          <TabsContent value="palette" className="space-y-5">
            {palette.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                <Palette className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No palette generated yet.</p>
                <p className="text-sm">Go to the Create tab to generate one.</p>
              </div>
            ) : (
              <div className="space-y-5" id="color-results">
                {/* Palette header */}
                <div className="flex items-center justify-between" data-export-ignore>
                  <Label className="text-base font-semibold">Generated Palette</Label>
                  <Button variant="ghost" size="sm" className="gap-1.5 text-sm" onClick={copyAllColors}>
                    {copiedAll ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5" />}
                    {copiedAll ? 'Copied!' : 'Copy All'}
                  </Button>
                </div>

                {/* Color Swatches with HEX, RGB, HSL, Name */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {palette.map((color, i) => {
                    const { r, g, b } = hexToRGB(color)
                    const hsl = hexToHSL(color)
                    const colorName = getClosestColorName(color)
                    const textColor = getContrastColor(color)
                    const trendStatus = getColorTrendStatus(color)
                    return (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="min-w-0"
                      >
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button
                              onClick={() => copyColor(color, i)}
                              className="group w-full rounded-xl border border-border/50 overflow-hidden shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5 min-h-[44px]"
                            >
                              <div
                                className="h-20 sm:h-24 relative flex items-end p-2"
                                style={{ backgroundColor: color }}
                              >
                                {/* Trending / In Season badge */}
                                {trendStatus && (
                                  <span
                                    className={`absolute top-1.5 right-1.5 text-[8px] font-bold px-1.5 py-0.5 rounded-full ${
                                      trendStatus === 'trending'
                                        ? 'bg-emerald-500/90 text-white'
                                        : 'bg-amber-500/90 text-white'
                                    }`}
                                    title={trendStatus === 'trending' ? 'Trending in crafts' : 'In Season'}
                                  >
                                    {trendStatus === 'trending' ? '🔥 Trending' : '🌿 Season'}
                                  </span>
                                )}
                                {copiedIndex === i && (
                                  <div className="absolute inset-0 flex items-center justify-center" style={{ backgroundColor: `${color}cc` }}>
                                    <Check className="h-5 w-5" style={{ color: textColor }} />
                                  </div>
                                )}
                                <span className="text-xs sm:text-sm font-mono font-bold truncate" style={{ color: textColor }}>
                                  {color.toUpperCase()}
                                </span>
                              </div>
                              <div className="p-2 space-y-0.5 bg-card overflow-hidden">
                                <p className="text-xs sm:text-sm text-muted-foreground overflow-hidden text-ellipsis whitespace-nowrap">{colorName}</p>
                                <p className="text-xs font-mono text-muted-foreground/70 truncate">
                                  RGB({r},{g},{b})
                                </p>
                                <p className="text-xs font-mono text-muted-foreground/70 truncate">
                                  HSL({hsl.h},{hsl.s}%,{hsl.l}%)
                                </p>
                              </div>
                            </button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{color} · RGB({r},{g},{b}) · HSL({hsl.h},{hsl.s}%,{hsl.l}%) · {colorName}</p>
                          </TooltipContent>
                        </Tooltip>
                      </motion.div>
                    )
                  })}
                </div>

                {/* Palette Preview Bar */}
                <div className="flex h-10 w-full overflow-hidden rounded-lg border border-border/50 shadow-sm">
                  {palette.map((color, i) => (
                    <div
                      key={i}
                      className="flex-1 transition-all hover:flex-[1.5]"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>

                {/* Color Variations */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold">Color Variations</Label>
                  <div className="space-y-3">
                    {palette.map((color, i) => {
                      const { tints, shades, tones } = generateTintsShadesTones(color)
                      const colorName = getClosestColorName(color)
                      return (
                        <div key={i} className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="h-4 w-4 rounded-sm border flex-shrink-0" style={{ backgroundColor: color }} />
                            <span className="text-sm font-medium text-muted-foreground">{colorName}</span>
                          </div>
                          <div className="flex gap-4">
                            <div className="flex-1 space-y-0.5">
                              <span className="text-sm text-muted-foreground/60 uppercase tracking-wider">Tints</span>
                              <div className="flex gap-0.5">
                                {tints.map((t, j) => (
                                  <Tooltip key={j}>
                                    <TooltipTrigger asChild>
                                      <button
                                        onClick={() => copyColor(t, 100 + i * 10 + j)}
                                        className="h-6 flex-1 rounded-sm border border-border/20 hover:scale-110 transition-transform"
                                        style={{ backgroundColor: t }}
                                      />
                                    </TooltipTrigger>
                                    <TooltipContent><p>{t}</p></TooltipContent>
                                  </Tooltip>
                                ))}
                              </div>
                            </div>
                            <div className="flex-1 space-y-0.5">
                              <span className="text-sm text-muted-foreground/60 uppercase tracking-wider">Shades</span>
                              <div className="flex gap-0.5">
                                {shades.map((s, j) => (
                                  <Tooltip key={j}>
                                    <TooltipTrigger asChild>
                                      <button
                                        onClick={() => copyColor(s, 200 + i * 10 + j)}
                                        className="h-6 flex-1 rounded-sm border border-border/20 hover:scale-110 transition-transform"
                                        style={{ backgroundColor: s }}
                                      />
                                    </TooltipTrigger>
                                    <TooltipContent><p>{s}</p></TooltipContent>
                                  </Tooltip>
                                ))}
                              </div>
                            </div>
                            <div className="flex-1 space-y-0.5">
                              <span className="text-sm text-muted-foreground/60 uppercase tracking-wider">Tones</span>
                              <div className="flex gap-0.5">
                                {tones.map((t, j) => (
                                  <Tooltip key={j}>
                                    <TooltipTrigger asChild>
                                      <button
                                        onClick={() => copyColor(t, 300 + i * 10 + j)}
                                        className="h-6 flex-1 rounded-sm border border-border/20 hover:scale-110 transition-transform"
                                        style={{ backgroundColor: t }}
                                      />
                                    </TooltipTrigger>
                                    <TooltipContent><p>{t}</p></TooltipContent>
                                  </Tooltip>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>

                <Separator />

                {/* Palette Mockup Preview */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold flex items-center gap-2">
                    <LayoutDashboard className="h-4 w-4 text-violet-500" />
                    Mockup Preview
                  </Label>

                  {/* Product Card Mockup */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="rounded-xl border border-border/50 overflow-hidden shadow-sm">
                      <p className="text-sm text-muted-foreground text-center py-1.5 font-medium uppercase tracking-wider">Product Card</p>
                      <div
                        className="h-8"
                        style={{ backgroundColor: palette[0] }}
                      />
                      <div className="p-3 space-y-2" style={{ backgroundColor: palette[4] || '#FFFFFF' }}>
                        <div
                          className="h-2.5 w-3/4 rounded-full"
                          style={{ backgroundColor: palette[1] }}
                        />
                        <div
                          className="h-2 w-1/2 rounded-full"
                          style={{ backgroundColor: palette[1], opacity: 0.5 }}
                        />
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-bold" style={{ color: palette[2] || '#000000' }}>$24.99</span>
                          <span
                            className="text-sm px-2 py-0.5 rounded-full"
                            style={{ backgroundColor: palette[2], color: getContrastColor(palette[2]) }}
                          >
                            Buy
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Social Media Post Mockup */}
                    <div className="rounded-xl border border-border/50 overflow-hidden shadow-sm">
                      <p className="text-sm text-muted-foreground text-center py-1.5 font-medium uppercase tracking-wider">Social Post</p>
                      <div
                        className="h-24 flex items-center justify-center"
                        style={{ backgroundColor: palette[0] }}
                      >
                        <div className="text-center">
                          <Shirt className="h-6 w-6 mx-auto mb-1" style={{ color: getContrastColor(palette[0]) }} />
                          <span className="text-sm font-bold" style={{ color: getContrastColor(palette[0]) }}>Your Brand</span>
                        </div>
                      </div>
                      <div className="p-3 space-y-1.5" style={{ backgroundColor: palette[4] || '#FFFFFF' }}>
                        <div
                          className="h-2 w-full rounded-full"
                          style={{ backgroundColor: palette[3] || palette[1] }}
                        />
                        <div
                          className="h-2 w-4/5 rounded-full"
                          style={{ backgroundColor: palette[3] || palette[1], opacity: 0.5 }}
                        />
                        <div className="flex gap-1 pt-1">
                          {palette.slice(0, 3).map((c, i) => (
                            <span
                              key={i}
                              className="h-4 w-8 rounded-full"
                              style={{ backgroundColor: c }}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Product Mockup (generated) */}
                {remaining > 0 && (
                  <div className="space-y-3">
                    <Label className="text-base font-semibold flex items-center gap-2">
                      <ImageIcon className="h-4 w-4 text-violet-500" />
                      Product Mockup
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Generate a realistic product mockup using your palette colors.
                    </p>
                    <div className="flex items-center gap-2">
                      <Input
                        value={mockupProductType}
                        onChange={(e) => setMockupProductType(e.target.value)}
                        placeholder="e.g., handmade candle, greeting card"
                        className="flex-1 text-sm h-9"
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleGenerateMockup}
                        disabled={isGeneratingMockup || palette.length === 0}
                        className="gap-1.5 border-violet-200 text-violet-700 hover:bg-violet-50 shrink-0"
                      >
                        {isGeneratingMockup ? (
                          <>
                            <div className="size-3.5 animate-spin rounded-full border-2 border-violet-300 border-t-transparent" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Camera className="size-3.5" />
                            Generate
                          </>
                        )}
                      </Button>
                    </div>

                    {mockupError && (
                      <p className="text-xs text-destructive break-words">{mockupError}</p>
                    )}

                    {mockupImageUrl && (
                      <Card className="overflow-hidden border-violet-200">
                        <div className="relative">
                          <img
                            src={mockupImageUrl}
                            alt="Product mockup"
                            className="w-full h-auto max-w-full"
                          />
                        </div>
                        <CardContent className="p-3">
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-muted-foreground">
                              Product mockup with your palette
                            </p>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="gap-1"
                              onClick={() => {
                                const link = document.createElement('a')
                                link.href = mockupImageUrl
                                link.download = 'product-mockup.png'
                                link.click()
                              }}
                            >
                              <Download className="size-3.5" />
                              Save
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          {/* ─────────── TAB: ANALYZE ─────────── */}
          <TabsContent value="analyze" className="space-y-5">
            {palette.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                <Accessibility className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No palette to analyze.</p>
                <p className="text-sm">Generate a palette first.</p>
              </div>
            ) : (
              <>
                {/* Accessibility Score */}
                <div className="rounded-xl border border-border/50 p-4 text-center space-y-2">
                  <Label className="text-base font-semibold">Overall Accessibility Score</Label>
                  <div className="relative h-24 w-24 mx-auto">
                    <svg className="h-24 w-24 -rotate-90" viewBox="0 0 36 36">
                      <path
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="currentColor"
                        className="text-muted/30"
                        strokeWidth="3"
                      />
                      <path
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke={accessibilityScore >= 70 ? '#22c55e' : accessibilityScore >= 40 ? '#f59e0b' : '#ef4444'}
                        strokeWidth="3"
                        strokeDasharray={`${accessibilityScore}, 100`}
                        strokeLinecap="round"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl font-bold">{accessibilityScore}%</span>
                    </div>
                  </div>
                  <Badge
                    variant={accessibilityScore >= 70 ? 'default' : accessibilityScore >= 40 ? 'secondary' : 'destructive'}
                    className="text-sm"
                  >
                    {accessibilityScore >= 70 ? 'Good Accessibility' : accessibilityScore >= 40 ? 'Moderate Accessibility' : 'Poor Accessibility'}
                  </Badge>
                  <p className="text-sm text-muted-foreground">
                    {accessibilityScore >= 70
                      ? 'This palette works well for most users with visual impairments.'
                      : accessibilityScore >= 40
                        ? 'Some color combinations may be hard to distinguish. Consider adjusting.'
                        : 'Many combinations fail WCAG standards. Major adjustments recommended.'}
                  </p>
                </div>

                {/* Quick Verdict */}
                <div className="rounded-xl border border-border/50 p-4 space-y-2">
                  <Label className="text-base font-semibold">Best Text Colors</Label>
                  <p className="text-sm text-muted-foreground mb-2">Recommended text color for each palette swatch</p>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                    {palette.map((color, i) => {
                      const best = bestTextColors[i]
                      return (
                        <div key={i} className="text-center space-y-1 min-w-0">
                          <div
                            className="h-12 rounded-lg border border-border/30 relative"
                            style={{ backgroundColor: color }}
                          >
                            <span
                              className="absolute inset-0 flex items-center justify-center text-xs sm:text-sm font-bold"
                              style={{ color: best.color }}
                            >
                              Aa
                            </span>
                          </div>
                          <span className="text-xs sm:text-sm font-mono text-muted-foreground truncate block">
                            {best.color === '#FFFFFF' ? 'White' : 'Black'}
                          </span>
                          <span className="text-xs sm:text-sm text-muted-foreground/60 block">
                            {best.ratio.toFixed(1)}:1
                          </span>
                        </div>
                      )
                    })}
                  </div>
                </div>

                {/* WCAG Contrast Table */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold flex items-center gap-2">
                    <Accessibility className="h-4 w-4 text-violet-500" />
                    WCAG Contrast Ratios
                  </Label>
                  <div className="rounded-md border overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-muted/50">
                          <th className="px-2 py-1.5 text-left font-medium">Pair</th>
                          <th className="px-2 py-1.5 text-right font-medium">Ratio</th>
                          <th className="px-2 py-1.5 text-center font-medium">AA</th>
                          <th className="px-2 py-1.5 text-center font-medium">AAA</th>
                        </tr>
                      </thead>
                      <tbody>
                        {palette.slice(0, -1).map((c1, i) => {
                          const c2 = palette[i + 1]
                          const ratio = getContrastRatio(c1, c2)
                          return (
                            <tr key={i} className={i % 2 === 0 ? '' : 'bg-muted/20'}>
                              <td className="px-2 py-1.5">
                                <span className="flex items-center gap-1">
                                  <span className="inline-block w-3 h-3 rounded-sm border" style={{ backgroundColor: c1 }} />
                                  <span className="inline-block w-3 h-3 rounded-sm border" style={{ backgroundColor: c2 }} />
                                  <span className="ml-1">{i + 1}–{i + 2}</span>
                                </span>
                              </td>
                              <td className="px-2 py-1.5 text-right font-mono">{ratio.toFixed(1)}:1</td>
                              <td className="px-2 py-1.5 text-center">
                                {ratio >= 4.5 ? <Badge variant="default" className="text-sm px-1 py-0">Pass</Badge>
                                  : ratio >= 3 ? <Badge variant="secondary" className="text-sm px-1 py-0">Large</Badge>
                                    : <Badge variant="destructive" className="text-sm px-1 py-0">Fail</Badge>}
                              </td>
                              <td className="px-2 py-1.5 text-center">
                                {ratio >= 7 ? <Badge variant="default" className="text-sm px-1 py-0">Pass</Badge>
                                  : ratio >= 4.5 ? <Badge variant="secondary" className="text-sm px-1 py-0">Large</Badge>
                                    : <Badge variant="destructive" className="text-sm px-1 py-0">Fail</Badge>}
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                  <div className="flex gap-3 text-sm text-muted-foreground">
                    <span><Badge variant="default" className="text-sm px-1 py-0 mr-1 shrink-0">Pass</Badge> Normal text</span>
                    <span><Badge variant="secondary" className="text-sm px-1 py-0 mr-1 shrink-0">Large</Badge> Large text only</span>
                    <span><Badge variant="destructive" className="text-sm px-1 py-0 mr-1 shrink-0">Fail</Badge> Not accessible</span>
                  </div>
                </div>

                {/* Color Blindness Simulator */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold flex items-center gap-2">
                    <Eye className="h-4 w-4 text-violet-500" />
                    Color Blindness Simulator
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    About 8% of men and 0.5% of women have some form of color vision deficiency.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {([
                      { type: null, label: 'Normal Vision' },
                      { type: 'protanopia' as const, label: 'Protanopia' },
                      { type: 'deuteranopia' as const, label: 'Deuteranopia' },
                      { type: 'tritanopia' as const, label: 'Tritanopia' },
                    ]).map(({ type, label }) => (
                      <Button
                        key={label}
                        variant={colorBlindnessType === type ? 'default' : 'outline'}
                        size="sm"
                        className={`text-sm h-7 ${colorBlindnessType === type ? 'bg-gradient-to-r from-violet-500 to-purple-500 text-white' : ''}`}
                        onClick={() => setColorBlindnessType(type)}
                      >
                        {label}
                      </Button>
                    ))}
                  </div>

                  {colorBlindnessType && simulatedPalette && (
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">
                        How your palette appears with {colorBlindnessType}:
                      </p>
                      <div className="flex h-10 w-full overflow-hidden rounded-lg border border-border/50 shadow-sm">
                        {simulatedPalette.map((color, i) => (
                          <div
                            key={i}
                            className="flex-1 transition-all hover:flex-[1.5]"
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                      <div className="grid grid-cols-3 sm:grid-cols-5 gap-1">
                        {simulatedPalette.map((color, i) => (
                          <div key={i} className="text-center min-w-0">
                            <div
                              className="h-8 rounded border border-border/30"
                              style={{ backgroundColor: color }}
                            />
                            <span className="text-xs sm:text-sm font-mono text-muted-foreground uppercase hidden sm:block truncate">{color}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}
          </TabsContent>

          {/* ─────────── TAB: EXPORT ─────────── */}
          <TabsContent value="export" className="space-y-5">
            {palette.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                <Share2 className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No palette to export.</p>
                <p className="text-sm">Generate a palette first.</p>
              </div>
            ) : (
              <>
                {/* Copy formats */}
                <div className="space-y-2" data-export-ignore>
                  <Label className="text-base font-semibold">Copy to Clipboard</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1.5 text-sm"
                      onClick={copyAllColors}
                    >
                      {copiedAll ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5" />}
                      {copiedAll ? 'Copied!' : 'Copy All HEX'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1.5 text-sm"
                      onClick={handleCopyCSS}
                    >
                      {copiedCSS ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Code2 className="h-3.5 w-3.5" />}
                      {copiedCSS ? 'Copied!' : 'Copy CSS Variables'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1.5 text-sm"
                      onClick={handleCopyTailwind}
                    >
                      {copiedTailwind ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Code2 className="h-3.5 w-3.5" />}
                      {copiedTailwind ? 'Copied!' : 'Copy Tailwind Config'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1.5 text-sm"
                      onClick={handleCopySCSS}
                    >
                      {copiedSCSS ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Code2 className="h-3.5 w-3.5" />}
                      {copiedSCSS ? 'Copied!' : 'Copy SCSS Variables'}
                    </Button>
                  </div>
                </div>

                {/* Preview export format */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Preview</Label>
                  <div className="rounded-lg border bg-muted/30 p-3 max-h-32 overflow-y-auto">
                    <pre className="text-sm font-mono text-muted-foreground whitespace-pre-wrap">
                      {generateCSSVariables(palette)}
                    </pre>
                  </div>
                </div>

                <Separator />

                {/* Download */}
                <div className="space-y-2" data-export-ignore>
                  <Label className="text-base font-semibold">Download</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1.5 text-sm"
                      onClick={handleExportImage}
                      disabled={exportingImage}
                    >
                      <Download className="h-3.5 w-3.5" />
                      {exportingImage ? 'Exporting...' : 'Download as Image'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1.5 text-sm"
                      onClick={handleExportPDF}
                      disabled={exportingPDF}
                    >
                      <FileText className="h-3.5 w-3.5" />
                      {exportingPDF ? 'Exporting...' : 'Download as PDF'}
                    </Button>
                  </div>
                </div>

                <Separator />

                {/* Save / Load */}
                <div className="space-y-3" data-export-ignore>
                  <Label className="text-base font-semibold">Save & Load Palettes</Label>

                  {/* Save current */}
                  <div className="flex items-center gap-2">
                    <Input
                      value={saveName}
                      onChange={(e) => setSaveName(e.target.value)}
                      placeholder="Name your palette..."
                      className="flex-1 text-sm"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={saveCurrentPalette}
                      disabled={isSaved}
                      className="gap-1.5"
                    >
                      <Save className="h-3.5 w-3.5" />
                      {isSaved ? 'Saved!' : 'Save'}
                    </Button>
                  </div>

                  {/* Saved palettes list */}
                  {savedPalettes.length > 0 && (
                    <div className="max-h-48 overflow-y-auto space-y-1.5">
                      <p className="text-sm text-muted-foreground">Click a palette to apply it</p>
                      {savedPalettes.map((sp) => (
                        <div
                          key={sp.id}
                          className="flex items-center gap-2 p-2 rounded-lg border border-border/50 hover:border-violet-300 cursor-pointer transition-all group"
                          onClick={() => applySavedPalette(sp)}
                        >
                          <div className="flex gap-0.5 flex-shrink-0">
                            {sp.colors.map((c, i) => (
                              <span key={i} className="h-5 w-4 rounded-sm border border-border/30" style={{ backgroundColor: c }} />
                            ))}
                          </div>
                          <span className="text-sm font-medium text-foreground flex-1 overflow-hidden text-ellipsis whitespace-nowrap">{sp.name}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={(e) => { e.stopPropagation(); deleteSavedPalette(sp.id) }}
                          >
                            <Trash2 className="h-3 w-3 text-destructive" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>

      {/* Donation prompt - shown after results */}
      {palette.length > 0 && (
        <ToolDonationPrompt onSupportClick={onSupportClick} />
      )}
    </Card>
  )
}
