'use client'

import { Heart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useUsageTracker } from '@/hooks/use-usage-tracker'

export function SupportFooter({ onSupportClick }: { onSupportClick: () => void }) {
  const { dailyUsage } = useUsageTracker()

  return (
    <footer className="mt-auto border-t border-border/60 bg-card/50 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-3 text-sm text-muted-foreground min-w-0">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium shrink-0">
              {dailyUsage} tool {dailyUsage === 1 ? 'use' : 'uses'} today
            </span>
            <span className="hidden sm:inline shrink-0">·</span>
            <span className="text-xs sm:text-sm min-w-0 break-words">
              Made with <Heart className="inline size-3 fill-current text-primary" /> by crafters,
              for crafters. Free daily uses, community-powered — your support helps us reach more artisans worldwide.
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-primary hover:text-primary hover:bg-primary/10 gap-1.5 text-xs shrink-0"
            onClick={onSupportClick}
          >
            <Heart className="size-3 fill-current" />
            Join Us
          </Button>
        </div>
      </div>
    </footer>
  )
}
