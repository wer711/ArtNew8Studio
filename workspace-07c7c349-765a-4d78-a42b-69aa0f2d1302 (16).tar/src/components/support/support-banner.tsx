'use client'

import { useState } from 'react'
import { X, Heart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { motion, AnimatePresence } from 'framer-motion'

const BANNER_DISMISSED_KEY = 'artnew8-banner-dismissed'
const BANNER_RESHOW_DAYS = 7

function getInitialVisibility(): boolean {
  if (typeof window === 'undefined') return false
  try {
    const dismissed = localStorage.getItem(BANNER_DISMISSED_KEY)
    if (dismissed) {
      const dismissedAt = new Date(dismissed)
      const now = new Date()
      const diffDays = (now.getTime() - dismissedAt.getTime()) / (1000 * 60 * 60 * 24)
      if (diffDays < BANNER_RESHOW_DAYS) {
        return false
      }
    }
    return true
  } catch {
    return true
  }
}

export function SupportBanner({ onSupportClick }: { onSupportClick: () => void }) {
  const [visible, setVisible] = useState(getInitialVisibility)

  const handleDismiss = () => {
    setVisible(false)
    try {
      localStorage.setItem(BANNER_DISMISSED_KEY, new Date().toISOString())
    } catch {
      // localStorage not available
    }
  }

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3, ease: 'easeInOut' }}
          className="overflow-hidden"
        >
          <div className="relative bg-primary/5 border-b border-primary/20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between gap-4 min-w-0">
              <p className="text-sm text-foreground/80 leading-snug min-w-0 break-words">
                Join us to help build tools for artisans worldwide.{' '}
                Every contribution powers the tools you love.
              </p>
              <div className="flex items-center gap-2 shrink-0">
                <Button
                  size="sm"
                  variant="outline"
                  className="border-primary/30 bg-primary/5 hover:bg-primary/10 text-primary gap-1.5 h-7 text-xs"
                  onClick={onSupportClick}
                >
                  <Heart className="size-3 fill-current" />
                  Support Us
                </Button>
                <button
                  onClick={handleDismiss}
                  className="text-muted-foreground hover:text-foreground transition-colors p-0.5 rounded-sm hover:bg-muted/50"
                  aria-label="Dismiss banner"
                >
                  <X className="size-3.5" />
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
