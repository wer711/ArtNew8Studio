'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Heart, ArrowRight, Sparkles, Zap, Wrench, Infinity, MessageCircle, HandHeart, Share2 } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface LimitPopupProps {
  open: boolean
  onClose: () => void
  onSupportClick: () => void
  onCustomizeClick?: () => void
  onUnlimitedClick?: () => void
  remaining: number
}

export function LimitPopup({ open, onClose, onSupportClick, onCustomizeClick, onUnlimitedClick, remaining }: LimitPopupProps) {
  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/30 backdrop-blur-sm z-[60]"
            onClick={onClose}
          />

          {/* Popup */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed inset-0 z-[70] flex items-center justify-center p-4 pointer-events-none"
          >
            <div className="bg-[#FDFAF6] border border-[#DDD0C0] rounded-2xl shadow-xl max-w-sm w-full pointer-events-auto overflow-hidden">
              {/* Content */}
              <div className="px-5 pb-5 pt-5 space-y-3">
                {/* Icon + Friendly message */}
                <div className="text-center space-y-2">
                  <div className="size-12 rounded-full bg-[#C96A2B]/10 flex items-center justify-center mx-auto">
                    <HandHeart className="size-6 text-[#C96A2B]" />
                  </div>
                  <h3 className="text-lg font-bold text-[#2C1810]">
                    Daily Tool Uses Refresh Tomorrow
                  </h3>
                  <p className="text-sm text-[#6B5744] leading-relaxed break-words">
                    You&apos;ve used all 20 free daily uses for today — that&apos;s a lot of crafting! Come back tomorrow for 20 more free uses. If you&apos;d like to support us and get bonus uses that carry over, we&apos;d love to have you as a contributor.
                  </p>
                </div>

                {/* The Honest Reason */}
                <div className="rounded-lg bg-[#2C1810]/[0.03] border border-[#2C1810]/5 p-3 space-y-1.5">
                  <p className="text-xs font-semibold text-[#2C1810] uppercase tracking-wide">
                    Why there&apos;s a daily cap
                  </p>
                  <p className="text-xs text-[#6B5744] leading-relaxed break-words">
                    Each tool uses real AI that costs real resources. The daily cap ensures every crafter gets a fair chance to use the tools each day. We&apos;re working hard to raise this limit as our community grows.
                  </p>
                </div>

                {/* Our Vision */}
                <div className="rounded-lg border border-[#5B8A6F]/20 bg-[#5B8A6F]/5 p-3 space-y-1.5">
                  <p className="text-xs font-semibold text-[#5B8A6F] uppercase tracking-wide flex items-center gap-1.5">
                    <Sparkles className="size-3" />
                    Our Dream
                  </p>
                  <p className="text-xs text-[#6B5744] leading-relaxed break-words">
                    We&apos;re building a <strong className="text-[#5B8A6F]">crafter-owned marketplace</strong> —
                    0% commission, no corporate middlemen. Artisans keep everything they earn.
                    Supporting ArtNew8 helps bring this vision to life for artisans everywhere.
                  </p>
                </div>

                {/* Join the movement + Bonus info */}
                <div className="rounded-lg border border-[#C96A2B]/15 bg-[#C96A2B]/5 p-3 space-y-2">
                  <p className="text-sm font-medium text-[#2C1810] text-center">
                    Join us — be part of the movement
                  </p>
                  <div className="flex items-start gap-2">
                    <Zap className="size-4 text-[#5B8A6F] shrink-0 mt-0.5" />
                    <p className="text-xs text-[#6B5744] leading-relaxed break-words">
                      <strong className="text-[#5B8A6F]">Contributors receive bonus uses</strong> as a thank-you — they carry over across days.
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Share2 className="size-4 text-[#C96A2B] shrink-0 mt-0.5" />
                    <p className="text-xs text-[#6B5744] leading-relaxed break-words">
                      Found us helpful? <strong className="text-[#C96A2B]">Share ArtNew8 with a fellow crafter</strong> —
                      that helps us more than any ad.
                    </p>
                  </div>
                </div>

                {/* Actions */}
                <div className="space-y-2 pt-1">
                  <Button
                    className="w-full bg-[#C96A2B] hover:bg-[#A85420] text-white gap-2"
                    onClick={() => {
                      onClose()
                      onSupportClick()
                    }}
                  >
                    <Heart className="size-4 fill-current" />
                    Join ArtNew8 Studio
                    <ArrowRight className="size-4" />
                  </Button>

                  {/* Custom services alternatives */}
                  {(onCustomizeClick || onUnlimitedClick) && (
                    <div className="pt-0.5">
                      <div className="flex gap-2">
                        {onCustomizeClick && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1 h-8 text-xs gap-1 border-amber-300 text-amber-700 hover:bg-amber-50"
                            onClick={() => {
                              onClose()
                              onCustomizeClick()
                            }}
                          >
                            <Wrench className="size-3" />
                            Customize
                          </Button>
                        )}
                        {onUnlimitedClick && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1 h-8 text-xs gap-1 border-[#5B8A6F]/40 text-[#5B8A6F] hover:bg-[#5B8A6F]/5"
                            onClick={() => {
                              onClose()
                              onUnlimitedClick()
                            }}
                          >
                            <Infinity className="size-3" />
                            Unlimited
                          </Button>
                        )}
                      </div>
                    </div>
                  )}

                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full text-[#9C8070] text-xs"
                    onClick={onClose}
                  >
                    Come back tomorrow for 20 more free daily uses — we&apos;ll be here!
                  </Button>

                  {/* WhatsApp contact */}
                  <p className="text-[12px] text-[#9C8070] text-center mt-1">
                    Need more now?{' '}
                    <a
                      href="https://wa.me/213696212465?text=Hi!%20I%20need%20unlimited%20access%20to%20ArtNew8%20Studio%20tools.%20Can%20you%20help%3F"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-0.5 text-[#5B8A6F] hover:text-[#5B8A6F]/80 underline underline-offset-2"
                    >
                      <MessageCircle className="size-3" />
                      Talk to us on WhatsApp
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
