'use client'

import { useState, useRef, useEffect } from 'react'
import dynamic from 'next/dynamic'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Calculator,
  Tag,
  Truck,
  Palette,
  Heart,
  ArrowRight,
  Users,
  Facebook,
  ExternalLink,
  Sparkles,
  ChevronDown,
  Loader2,
  Zap,
  TrendingUp,
  Globe,
  Paintbrush,
  Shield,
  Eye,
  Layers,
  MousePointerClick,
  ListChecks,
  Rocket,
  ShieldCheck,
  Home as HomeIcon,
  Scissors,
  Ruler,
  Flower2,
  Package,
  Gem,
  PenTool,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { TooltipProvider } from '@/components/ui/tooltip'
import { SupportSection } from '@/components/support/support-section'
import { WhatsAppFab } from '@/components/support/whatsapp-fab'
import { CustomServicesForm } from '@/components/support/custom-services-form'
import { ServiceSuggestionBanner } from '@/components/support/service-suggestion-banner'
import { useUsageTracker } from '@/hooks/use-usage-tracker'
import { LogoMark } from '@/components/logo-mark'

// Dynamic imports for tool components — with preload functions for instant switching
const pricingLoader = () => import('@/components/tools/pricing-calculator')
const tagLoader = () => import('@/components/tools/tag-generator').then(mod => ({ default: mod.TagGenerator }))
const shippingLoader = () => import('@/components/tools/shipping-estimator').then(mod => ({ default: mod.ShippingEstimator }))
const colorLoader = () => import('@/components/tools/color-palette').then(mod => ({ default: mod.ColorPaletteGenerator }))
const aiLoader = () => import('@/components/tools/ai-assistant').then(mod => ({ default: mod.AIAssistant }))

const PricingCalculator = dynamic(pricingLoader, {
  ssr: false,
  loading: () => <ToolLoadingSkeleton />,
})

const TagGenerator = dynamic(tagLoader, {
  ssr: false,
  loading: () => <ToolLoadingSkeleton />,
})

const ShippingEstimator = dynamic(shippingLoader, {
  ssr: false,
  loading: () => <ToolLoadingSkeleton />,
})

const ColorPaletteGenerator = dynamic(colorLoader, {
  ssr: false,
  loading: () => <ToolLoadingSkeleton />,
})

const AIAssistant = dynamic(aiLoader, {
  ssr: false,
  loading: () => <ToolLoadingSkeleton />,
})

// Prefetch all tool modules in the background after page loads
// This eliminates the 1-2 second delay when opening a tool for the first time
function usePrefetchTools() {
  useEffect(() => {
    // Start prefetching immediately after mount — no artificial delay
    // Using requestIdleCallback to avoid competing with critical rendering
    const prefetchAll = () => {
      Promise.all([
        pricingLoader(),
        tagLoader(),
        shippingLoader(),
        colorLoader(),
        aiLoader(),
      ]).catch(() => {
        // Silently ignore prefetch failures — tools will still load on demand
      })
    }

    if ('requestIdleCallback' in window) {
      (window as unknown as { requestIdleCallback: (cb: () => void) => number }).requestIdleCallback(prefetchAll)
    } else {
      // Fallback: small delay for browsers without requestIdleCallback
      setTimeout(prefetchAll, 200)
    }
  }, [])
}

// DonationConfirmation removed — PayPal JS SDK handles the entire flow in-page

// Loading skeleton
function ToolLoadingSkeleton() {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Skeleton className="size-10 rounded-xl" />
        <div className="space-y-2 flex-1">
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-3 w-64" />
        </div>
      </div>
      <Skeleton className="h-40 w-full rounded-xl" />
      <Skeleton className="h-32 w-full rounded-xl" />
      <Skeleton className="h-24 w-full rounded-xl" />
    </div>
  )
}

// ─── Tool Definitions ───────────────────────────────────────
const TOOLS = [
  {
    id: 'pricing',
    title: 'Pricing Calculator',
    shortTitle: 'Pricing',
    description: 'Calculate selling prices with material costs, labor, overhead, and platform fees compared across Etsy, Amazon, Shopify & more.',
    helps: '87% of handmade sellers undercharge. This tool shows you your real price in seconds.',
    icon: Calculator,
    benefitIcon: TrendingUp,
    gradient: 'from-orange-50 via-amber-50/50 to-orange-100/30',
    iconBg: 'bg-gradient-to-br from-[#C96A2B] to-amber-600',
    iconColor: 'text-white',
    borderColor: 'hover:border-[#C96A2B]/40',
    accentColor: 'bg-[#C96A2B]',
    accentOklch: '#C96A2B',
    toolAccentVar: '--tool-accent: #C96A2B',
  },
  {
    id: 'tags',
    title: 'Tag Generator',
    shortTitle: 'Tags',
    description: 'Generate SEO-optimized tags for Etsy & Amazon listings. Smart keyword matching from 330+ craft-specific tags.',
    helps: 'The right tags = more views, more sales. Generate 13 SEO-optimized tags instantly.',
    icon: Tag,
    benefitIcon: Zap,
    gradient: 'from-rose-50 via-pink-50/50 to-rose-100/30',
    iconBg: 'bg-gradient-to-br from-rose-500 to-pink-500',
    iconColor: 'text-white',
    borderColor: 'hover:border-rose-300',
    accentColor: 'bg-rose-500',
    accentOklch: '#e11d48',
    toolAccentVar: '--tool-accent: #e11d48',
  },
  {
    id: 'shipping',
    title: 'Shipping Estimator',
    shortTitle: 'Shipping',
    description: 'Estimate international shipping costs for handmade crafts with customs tips for 8 regions.',
    helps: 'Stop guessing shipping costs. Get accurate estimates for 8 global regions — before you list.',
    icon: Truck,
    benefitIcon: Globe,
    gradient: 'from-teal-50 via-cyan-50/50 to-teal-100/30',
    iconBg: 'bg-gradient-to-br from-teal-500 to-cyan-500',
    iconColor: 'text-white',
    borderColor: 'hover:border-teal-300',
    accentColor: 'bg-teal-500',
    accentOklch: '#14b8a6',
    toolAccentVar: '--tool-accent: #14b8a6',
  },
  {
    id: 'colors',
    title: 'Color Palette',
    shortTitle: 'Colors',
    description: 'Create harmonious color palettes with 6 harmony types and craft-ready presets. Click to copy any color.',
    helps: 'A cohesive color story makes your shop look premium. Create it in one click.',
    icon: Palette,
    benefitIcon: Paintbrush,
    gradient: 'from-violet-50 via-purple-50/50 to-violet-100/30',
    iconBg: 'bg-gradient-to-br from-violet-500 to-purple-500',
    iconColor: 'text-white',
    borderColor: 'hover:border-violet-300',
    accentColor: 'bg-violet-500',
    accentOklch: '#8b5cf6',
    toolAccentVar: '--tool-accent: #8b5cf6',
  },
  {
    id: 'ai',
    title: 'AI Assistant',
    shortTitle: 'AI',
    description: 'Smart pricing research, AI description writer, tag suggestions, and product image generation — powered by AI.',
    helps: 'Your AI business partner — write listings, research prices, and generate product images. Free daily uses.',
    icon: Sparkles,
    benefitIcon: Zap,
    gradient: 'from-emerald-50 via-teal-50/50 to-emerald-100/30',
    iconBg: 'bg-gradient-to-br from-[#5B8A6F] to-teal-600',
    iconColor: 'text-white',
    borderColor: 'hover:border-[#5B8A6F]/40',
    accentColor: 'bg-[#5B8A6F]',
    accentOklch: '#5B8A6F',
    toolAccentVar: '--tool-accent: #5B8A6F',
  },
]

// Mobile bottom nav items - includes Home + tools
const BOTTOM_NAV_ITEMS = [
  { id: '__home__', label: 'Home', icon: HomeIcon, accentColor: '' },
  ...TOOLS.map(tool => ({
    id: tool.id,
    label: tool.shortTitle,
    icon: tool.icon,
    accentColor: tool.accentColor,
  })),
]

// Stats data - CORRECT VALUES
const STATS = [
  { label: 'Craft Tools', value: 5, suffix: '', prefix: '', icon: Layers },
  { label: 'Craft Tags', value: 330, suffix: '+', prefix: '', icon: Tag },
  { label: 'AI Features', value: 7, suffix: '', prefix: '', icon: Sparkles },
  { label: 'Shipping Regions', value: 8, suffix: '', prefix: '', icon: Globe },
]

// Features data
const FEATURES = [
  {
    icon: Shield,
    title: 'No Sign-up Required',
    description: 'Jump right in — all tools work instantly with zero accounts or logins.',
  },
  {
    icon: Layers,
    title: 'Multi-Platform',
    description: 'Optimized for Etsy, Amazon, Shopify and more — one tool, every marketplace.',
  },
  {
    icon: Paintbrush,
    title: 'Craft-Specific',
    description: 'Built by artisans for artisans — every feature tailored to handmade businesses.',
  },
  {
    icon: Eye,
    title: 'Privacy First',
    description: 'Your data stays in your browser. Nothing is stored, tracked, or shared.',
  },
  {
    icon: Zap,
    title: 'Instant Results',
    description: 'No waiting, no loading — get your answers the moment you click.',
  },
  {
    icon: Heart,
    title: 'Community Driven',
    description: 'Shaped by 500+ artisans in our community. Suggest a feature — we actually build it.',
  },
]

// How it works steps
const STEPS = [
  {
    step: 1,
    icon: MousePointerClick,
    title: 'Pick Your Tool',
    description: '5 specialized tools, each solving a real problem for handmade sellers.',
  },
  {
    step: 2,
    icon: ListChecks,
    title: 'Enter Your Numbers',
    description: 'Add your costs, keywords, destination, or product idea — no account, no setup.',
  },
  {
    step: 3,
    icon: Rocket,
    title: 'Get Instant Results',
    description: 'Prices, tags, shipping estimates, palettes — ready to copy and use immediately.',
  },
]

// Pinterest icon component
function PinterestIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z"/>
    </svg>
  )
}

// LogoMark is now a dynamic SVG component — no image loading, no 404s
// Imported from @/components/logo-mark

// ─── Animated Counter Component ─────────────────────────────
function AnimatedCounter({ target, suffix = '', prefix = '' }: { target: number; suffix?: string; prefix?: string }) {
  const [count, setCount] = useState(0)
  const [hasAnimated, setHasAnimated] = useState(false)
  const ref = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true)
          const duration = 1500
          const startTime = Date.now()

          const animate = () => {
            const elapsed = Date.now() - startTime
            const progress = Math.min(elapsed / duration, 1)
            // Ease out cubic — always counts UP from 0 to target
            const eased = 1 - Math.pow(1 - progress, 3)
            setCount(Math.round(eased * target))
            if (progress < 1) {
              requestAnimationFrame(animate)
            }
          }
          requestAnimationFrame(animate)
        }
      },
      { threshold: 0.5 }
    )

    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [target, hasAnimated])

  return (
    <span ref={ref} className="tabular-nums">
      {prefix}{count}{suffix}
    </span>
  )
}

// ─── Hero Decorative Elements — Animated Craft Tools Background ────
function HeroDecorations() {
  return (
    <div className="absolute inset-0 overflow-hidden hero-decorative" aria-hidden="true">
      {/* Gradient mesh background */}
      <div className="hero-gradient-mesh absolute inset-0" />

      {/* Floating craft elements — 10 icons with staggered animations */}
      <div className="absolute top-[8%] left-[6%] animate-float-craft-1 opacity-[0.08]">
        <Scissors className="size-8 text-[#C96A2B]" />
      </div>
      <div className="absolute top-[18%] right-[10%] animate-float-craft-2 opacity-[0.10]">
        <Palette className="size-10 text-[#5B8A6F]" />
      </div>
      <div className="absolute bottom-[22%] left-[12%] animate-float-craft-3 opacity-[0.07]">
        <Tag className="size-7 text-[#C96A2B]" />
      </div>
      <div className="absolute top-[55%] right-[6%] animate-float-craft-4 opacity-[0.09]">
        <Truck className="size-9 text-[#5B8A6F]" />
      </div>
      <div className="absolute top-[5%] left-[42%] animate-float-craft-5 opacity-[0.06]">
        <Sparkles className="size-6 text-[#C96A2B]" />
      </div>
      <div className="absolute bottom-[32%] right-[28%] animate-float-craft-6 opacity-[0.08]">
        <Calculator className="size-12 text-[#5B8A6F]" />
      </div>
      <div className="absolute top-[38%] left-[4%] animate-float-craft-7 opacity-[0.06]">
        <Ruler className="size-10 text-[#C96A2B]" />
      </div>
      <div className="absolute bottom-[12%] right-[18%] animate-float-craft-8 opacity-[0.07]">
        <Flower2 className="size-8 text-[#5B8A6F]" />
      </div>
      <div className="absolute top-[70%] left-[35%] animate-float-craft-9 opacity-[0.06]">
        <Package className="size-7 text-[#C96A2B]" />
      </div>
      <div className="absolute top-[25%] left-[22%] animate-float-craft-10 opacity-[0.05]">
        <PenTool className="size-6 text-[#5B8A6F]" />
      </div>

      {/* Subtle dot pattern overlay */}
      <div className="craft-pattern absolute inset-0 opacity-30" />
    </div>
  )
}

// ─── Usage Counter Badge (color-coded pill) ──────────────────
// Uses suppressHydrationWarning to avoid mismatch between server (default maxDaily)
// and client (actual usage from localStorage). React will reconcile on client.
function UsageCounterBadge({ remaining, maxDaily }: { remaining: number; maxDaily: number }) {
  // Color coding: green (≥60%), amber (30-59%), red (<30%)
  const ratio = remaining / maxDaily
  let colorClasses: string
  if (remaining === Infinity) {
    // Admin mode — show infinity badge
    colorClasses = 'bg-purple-500/10 text-purple-600 border-purple-500/20'
  } else if (ratio >= 0.6) {
    colorClasses = 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
  } else if (ratio >= 0.3) {
    colorClasses = 'bg-amber-500/10 text-amber-600 border-amber-500/20'
  } else {
    colorClasses = 'bg-red-500/10 text-red-600 border-red-500/20'
  }

  return (
    <div
      className={`hidden sm:flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-semibold transition-colors ${colorClasses}`}
      title={`${remaining === Infinity ? 'Unlimited' : remaining} daily uses remaining today`}
      suppressHydrationWarning
    >
      <Zap className="size-3" />
      <span suppressHydrationWarning>{remaining === Infinity ? '∞' : remaining}</span>
    </div>
  )
}

// ─── Main Content Component ─────────────────────────────────
function HomeContent() {
  const [activeTool, setActiveTool] = useState<string | null>(null)
  // Auto-open support section if returning from PayPal
  const [showSupport, setShowSupport] = useState(() => {
    if (typeof window === 'undefined') return false
    try {
      const params = new URLSearchParams(window.location.search)
      const donationStatus = params.get('donation')
      const paypalReturn = params.get('paypal_return')
      return donationStatus === 'return' || donationStatus === 'cancel' || paypalReturn === '1'
    } catch {
      return false
    }
  })
  const [showCustomService, setShowCustomService] = useState<'customize' | 'unlimited' | null>(null)
  const toolRef = useRef<HTMLDivElement>(null)
  const { isAdmin, setAdminMode, tryActivateAdmin, getRemaining } = useUsageTracker()
  const [showAdminConfirm, setShowAdminConfirm] = useState(false)
  const [adminPassword, setAdminPassword] = useState('')

  // Prefetch tool modules in the background for instant loading
  usePrefetchTools()

  // Handle PayPal return: scroll to support section if returning from PayPal
  useEffect(() => {
    const url = new URL(window.location.href)
    const donationStatus = url.searchParams.get('donation')
    const paypalReturn = url.searchParams.get('paypal_return')

    if (donationStatus === 'return' || donationStatus === 'cancel' || paypalReturn === '1') {
      // Scroll to support section after it renders
      setTimeout(() => {
        toolRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }, 500)
    } else {
      // Clean up stale params if NOT a PayPal return
      const paramsToClean = ['paypal_return', 'paypal_cancel', 'PayerID']
      let changed = false
      paramsToClean.forEach(param => {
        if (url.searchParams.has(param)) {
          url.searchParams.delete(param)
          changed = true
        }
      })
      if (changed) {
        window.history.replaceState({}, '', url.toString())
      }
    }
  }, [])

  const openTool = (toolId: string) => {
    setActiveTool(toolId)
    setShowSupport(false)
    setShowCustomService(null)
    setTimeout(() => {
      toolRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }, 100)
  }

  const openSupport = () => {
    setShowSupport(true)
    setActiveTool(null)
    setShowCustomService(null)
    setTimeout(() => {
      toolRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }, 100)
  }

  // Scroll to donation form and focus on Name field
  const scrollToDonationForm = () => {
    setShowSupport(true)
    setActiveTool(null)
    setShowCustomService(null)
    setTimeout(() => {
      toolRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
      // Focus on the Name input after a short delay
      setTimeout(() => {
        const nameInput = document.getElementById('support-form-name')
        if (nameInput) {
          nameInput.focus()
          // Add pulse animation to the form card
          const formCard = nameInput.closest('[data-support-form]')
          if (formCard) {
            formCard.classList.add('form-pulse')
            setTimeout(() => formCard.classList.remove('form-pulse'), 1500)
          }
        }
      }, 300)
    }, 100)
  }

  const openCustomService = (type: 'customize' | 'unlimited') => {
    setShowCustomService(type)
    setShowSupport(false)
    setActiveTool(null)
    setTimeout(() => {
      toolRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }, 100)
  }

  const goHome = () => {
    setActiveTool(null)
    setShowSupport(false)
    setShowCustomService(null)

    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleLogoClick = () => {
    goHome()
  }

  // Hidden admin activation: Ctrl+Shift+A
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        e.preventDefault()
        if (isAdmin) {
          setAdminMode(false)
        } else {
          setShowAdminConfirm(true)
        }
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [isAdmin, setAdminMode])

  const handleAdminConfirm = () => {
    const success = tryActivateAdmin(adminPassword)
    if (success) {
      setShowAdminConfirm(false)
      setAdminPassword('')
    }
  }

  const handleBottomNavClick = (id: string) => {
    if (id === '__home__') {
      goHome()
    } else {
      openTool(id)
    }
  }

  const activeToolData = TOOLS.find(t => t.id === activeTool)
  const isToolActive = activeTool !== null || showSupport || showCustomService !== null

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.08, delayChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] },
    },
  }

  return (
    <TooltipProvider delayDuration={300}>
      <div className="min-h-screen flex flex-col bg-[#FDFAF6] overflow-x-hidden">
        {/* ─── Header ─────────────────────────────────────── */}
        <header className="border-b border-[#DDD0C0] bg-[#FDFAF6]/80 backdrop-blur-md sticky top-0 z-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-4">
            <div className="flex items-center justify-between">
              <button
                onClick={handleLogoClick}
                className="flex items-center gap-2.5 hover:opacity-80 transition-opacity"
              >
                <LogoMark className="h-11 sm:h-12 w-auto" />
                <div className="text-left">
                  <h1 className="text-base sm:text-lg font-bold text-[#2C1810] tracking-tight leading-tight">
                    <span className="font-bold">Art</span><span className="text-[#C96A2B] font-bold">New8</span>{' '}
                    <span className="text-[#6B5744] text-[10px] sm:text-xs font-normal block sm:inline sm:ml-1">Studio</span>
                  </h1>
                  <p className="text-[10px] sm:text-xs text-[#9C8070] leading-tight">
                    Tools for artisans, by artisans
                  </p>
                </div>
                {isAdmin && (
                  <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20 text-[10px] px-1.5 py-0 h-5 gap-0.5">
                    <ShieldCheck className="size-3" />
                    Admin
                  </Badge>
                )}
              </button>

              <div className="flex items-center gap-1 sm:gap-2">
                {/* Pinterest */}
                <a
                  href="https://www.pinterest.com/artnew8/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center size-7 sm:size-8 rounded-lg text-[#6B5744] hover:text-[#E60023] hover:bg-[#F0E6D3] transition-colors"
                  aria-label="Follow on Pinterest"
                >
                  <PinterestIcon className="size-3.5 sm:size-4" />
                </a>
                {/* Facebook */}
                <a
                  href="https://www.facebook.com/share/g/1HLBeMbAVJ/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs font-medium text-[#6B5744] hover:text-[#2C1810] hover:bg-[#F0E6D3] transition-colors"
                >
                  <Facebook className="size-3.5" />
                  <span className="hidden sm:inline">Community</span>
                </a>
                {/* Usage Counter Badge */}
                <UsageCounterBadge remaining={getRemaining()} maxDaily={20} />
                <Button
                  variant="outline"
                  size="sm"
                  className="border-[#C96A2B]/30 text-[#C96A2B] hover:bg-[#F0E6D3] hover:text-[#C96A2B] gap-1 text-xs h-7 sm:h-8 px-2 sm:px-3"
                  onClick={scrollToDonationForm}
                >
                  <Heart className="size-3 sm:size-3.5" />
                  <span className="hidden sm:inline">Support Us</span>
                  <span className="sm:hidden">Back Us</span>
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* ─── Tool Tab Navigation (Desktop) ─────────────── */}
        {isToolActive && (
          <div className="hidden md:block border-b border-[#DDD0C0] bg-[#FDFAF6]/60 backdrop-blur-md sticky top-[57px] z-40">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center gap-1 overflow-x-auto scrollbar-none">
                <button
                  onClick={goHome}
                  className="flex items-center gap-1.5 px-3 py-2.5 text-sm font-medium text-[#6B5744] hover:text-[#2C1810] transition-colors shrink-0 border-b-2 border-transparent"
                >
                  <HomeIcon className="size-3.5" />
                  Home
                </button>
                <div className="w-px h-5 bg-[#DDD0C0]/50 mx-1 shrink-0" />
                {TOOLS.map(tool => {
                  const isActive = activeTool === tool.id
                  return (
                    <button
                      key={tool.id}
                      onClick={() => openTool(tool.id)}
                      className={`flex items-center gap-1.5 px-3 py-2.5 text-sm font-medium transition-colors shrink-0 border-b-2 ${
                        isActive
                          ? 'border-[#C96A2B] text-[#C96A2B]'
                          : 'border-transparent text-[#6B5744] hover:text-[#2C1810]'
                      }`}
                    >
                      <tool.icon className="size-3.5" />
                      {tool.shortTitle}
                    </button>
                  )
                })}
              </div>
            </div>
          </div>
        )}

        {/* ─── Admin Confirmation Dialog ──────────────────── */}
        <AnimatePresence>
          {showAdminConfirm && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="fixed inset-0 bg-black/30 backdrop-blur-sm z-[60]"
                onClick={() => { setShowAdminConfirm(false); setAdminPassword('') }}
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                className="fixed inset-0 z-[70] flex items-center justify-center p-4 pointer-events-none"
              >
                <div className="bg-[#FDFAF6] border border-[#DDD0C0] rounded-2xl shadow-xl max-w-xs w-full pointer-events-auto overflow-hidden p-5 space-y-4">
                  <div className="size-12 rounded-full bg-amber-500/10 flex items-center justify-center mx-auto">
                    <ShieldCheck className="size-6 text-amber-600" />
                  </div>
                  <h3 className="text-base font-bold text-[#2C1810] text-center">
                    Admin Mode
                  </h3>
                  <p className="text-xs text-[#9C8070] text-center">
                    Enter admin password. Access is restricted to this device only.
                  </p>
                  <input
                    type="password"
                    value={adminPassword}
                    onChange={e => setAdminPassword(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleAdminConfirm()}
                    placeholder="Admin password"
                    className="w-full rounded-lg border border-[#DDD0C0] bg-[#FFFFFF] px-3 py-2 text-sm text-[#2C1810] outline-none focus:ring-2 focus:ring-[#C96A2B]/20 focus:border-[#C96A2B]"
                    autoFocus
                  />
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 border-[#DDD0C0]"
                      onClick={() => { setShowAdminConfirm(false); setAdminPassword('') }}
                    >
                      Cancel
                    </Button>
                    <Button
                      size="sm"
                      className="flex-1 bg-amber-600 hover:bg-amber-700 text-white gap-1.5"
                      onClick={handleAdminConfirm}
                    >
                      <ShieldCheck className="size-3.5" />
                      Activate
                    </Button>
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* ─── Main Content ───────────────────────────────── */}
        <main className="flex-1 overflow-x-hidden">
          <AnimatePresence mode="wait">
            {!activeTool && !showSupport && !showCustomService && (
              <motion.div
                key="hero"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >

                {/* ═══ HERO SECTION ═══════════════════════════ */}
                <section className="relative overflow-hidden bg-gradient-to-br from-[#FDFAF6] via-[#F5F0E8] to-[#FDFAF6]">
                  <HeroDecorations />

                  <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 sm:pt-20 pb-8 sm:pb-12">
                    <div className="text-center max-w-2xl mx-auto space-y-5">
                      {/* Animated Badge */}
                      <motion.div
                        initial={{ opacity: 0, y: 12, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        transition={{ duration: 0.5, delay: 0.1 }}
                      >
                        <Badge
                          variant="secondary"
                          className="animate-badge-shimmer text-[#C96A2B] border-[#C96A2B]/20 bg-[#F0E6D3] px-3 sm:px-4 py-2 text-[10px] sm:text-sm font-medium"
                        >
                          <Sparkles className="size-3 sm:size-3.5 mr-1 animate-pulse-soft" />
                          <span className="hidden sm:inline">No Account Needed · Your Data Stays Private</span>
                          <span className="sm:hidden">No Account · Your Data Stays Private</span>
                        </Badge>
                      </motion.div>

                      {/* Main heading */}
                      <motion.h2
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.7, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
                        className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-[#2C1810] tracking-tight leading-[1.1] text-balance"
                      >
                        Run Your Craft Business{' '}
                        <motion.span
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.6, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
                          className="text-[#C96A2B] relative"
                        >
                          Like a Pro
                          <motion.span
                            initial={{ scaleX: 0 }}
                            animate={{ scaleX: 1 }}
                            transition={{ duration: 0.6, delay: 0.9, ease: [0.16, 1, 0.3, 1] }}
                            className="absolute -bottom-1 left-0 right-0 h-1 bg-gradient-to-r from-[#C96A2B] via-[#5B8A6F] to-[#C96A2B] rounded-full origin-left"
                          />
                        </motion.span>
                        {' '}— For Crafters Like You
                      </motion.h2>

                      {/* Subtitle */}
                      <motion.p
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
                        className="text-[#6B5744] text-sm sm:text-lg max-w-lg mx-auto leading-relaxed text-pretty"
                      >
                        The only toolkit built exclusively for handmade sellers — by artisans, for artisans. Pricing, SEO tags, shipping, color palettes, and AI — all in one place. Free daily uses, no account needed.
                      </motion.p>

                      {/* CTA Buttons */}
                      <motion.div
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.6, ease: [0.16, 1, 0.3, 1] }}
                        className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2"
                      >
                        <Button
                          size="lg"
                          className="animate-cta-glow bg-[#C96A2B] hover:bg-[#A85420] text-white gap-2 text-sm sm:text-base px-6 sm:px-8 rounded-lg w-full sm:w-auto"
                          onClick={() => {
                            const el = document.getElementById('tools-section')
                            el?.scrollIntoView({ behavior: 'smooth' })
                          }}
                        >
                          Explore the Tools
                          <ArrowRight className="size-4" />
                        </Button>
                        <Button
                          size="lg"
                          variant="outline"
                          className="gap-2 text-sm sm:text-base px-6 sm:px-8 rounded-lg border-[#C96A2B] text-[#C96A2B] hover:bg-[#F0E6D3] hover:text-[#C96A2B] w-full sm:w-auto"
                          onClick={scrollToDonationForm}
                        >
                          <Heart className="size-4" />
                          Support This Project
                        </Button>
                      </motion.div>
                    </div>
                  </div>
                </section>

                {/* ═══ STATS SECTION ══════════════════════════ */}
                <section className="bg-[#F5F0E8] max-w-full py-8 sm:py-12">
                  <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      {STATS.map((stat, index) => (
                        <motion.div
                          key={stat.label}
                          initial={{ opacity: 0, y: 20 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          viewport={{ once: true, margin: '-50px' }}
                          transition={{ duration: 0.5, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
                        >
                          <Card className="stat-card-glow text-center py-4 px-3 sm:py-5 sm:px-4 hover:shadow-md transition-shadow bg-[#FDFAF6] border-[#DDD0C0] overflow-hidden">
                            <div className="flex items-center justify-center mb-2">
                              <div className="size-7 sm:size-8 rounded-lg bg-[#C96A2B]/10 flex items-center justify-center">
                                <stat.icon className="size-3.5 sm:size-4 text-[#C96A2B]" />
                              </div>
                            </div>
                            <div className="text-xl sm:text-3xl font-extrabold text-[#C96A2B] tracking-tight">
                              <AnimatedCounter
                                target={stat.value}
                                suffix={stat.suffix}
                                prefix={stat.prefix}
                              />
                            </div>
                            <div className="text-[10px] sm:text-sm text-[#6B5744] mt-1 font-medium leading-tight line-clamp-2">
                              {stat.label}
                            </div>
                          </Card>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </section>

                {/* ═══ TOOLS GRID ═════════════════════════════ */}
                <section id="tools-section" className="bg-[#EDE7DA] max-w-full pb-10 sm:pb-14 pt-10 sm:pt-14">
                  <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                    <motion.div
                      initial={{ opacity: 0, y: 16 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: '-50px' }}
                      transition={{ duration: 0.5 }}
                      className="text-center mb-8 sm:mb-10"
                    >
                      <h3 className="text-xl sm:text-2xl font-bold text-[#2C1810] tracking-tight">
                        Your Crafting Toolkit
                      </h3>
                      <p className="text-sm text-[#6B5744] mt-1.5 max-w-md mx-auto">
                        Five powerful tools designed to streamline every aspect of your handmade business.
                      </p>
                    </motion.div>

                    <motion.div
                      variants={containerVariants}
                      initial="hidden"
                      whileInView="visible"
                      viewport={{ once: true, margin: '-80px' }}
                      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 sm:gap-5 lg:gap-6"
                    >
                      {TOOLS.map((tool) => (
                        <motion.div key={tool.id} variants={itemVariants}>
                          <Card
                            className={`tool-card-accent card-hover-lift group cursor-pointer transition-all duration-300 border-[#DDD0C0]/50 ${tool.borderColor} bg-gradient-to-br ${tool.gradient} overflow-hidden`}
                            style={{ '--tool-accent': tool.accentOklch } as React.CSSProperties}
                            onClick={() => openTool(tool.id)}
                          >
                            <CardContent className="p-4 sm:p-5 lg:p-6">
                              {/* Animated icon */}
                              <motion.div
                                className={`size-10 sm:size-12 rounded-xl ${tool.iconBg} flex items-center justify-center mb-3 sm:mb-4 shadow-sm group-hover:shadow-lg transition-all duration-300`}
                                whileHover={{ scale: 1.12, rotate: 3 }}
                                transition={{ type: 'spring', stiffness: 400, damping: 15 }}
                              >
                                <tool.icon className="size-5 sm:size-6 text-white" />
                              </motion.div>

                              {/* Title */}
                              <h4 className="font-bold text-[#2C1810] text-sm sm:text-base mb-1.5 tracking-tight">
                                {tool.title}
                              </h4>

                              {/* Description */}
                              <p className="text-[#6B5744] text-xs sm:text-sm leading-relaxed mb-3">
                                {tool.description}
                              </p>

                              {/* Benefit line */}
                              <div className="flex items-start gap-1.5 text-xs leading-relaxed mb-3">
                                <tool.benefitIcon className="size-3.5 shrink-0 mt-0.5 text-[#C96A2B]/70" />
                                <span className="text-[#2C1810]/80 font-medium break-words">{tool.helps}</span>
                              </div>

                              {/* CTA */}
                              <div className="flex items-center text-xs font-semibold text-[#C96A2B] gap-1 opacity-0 group-hover:opacity-100 transition-all duration-200 group-hover:translate-x-0.5">
                                Open tool
                                <ArrowRight className="size-3.5" />
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </motion.div>
                  </div>
                </section>

                {/* ═══ FEATURES SECTION ═══════════════════════ */}
                <section className="bg-[#FDFAF6] max-w-full py-10 sm:py-16">
                  <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                    <motion.div
                      initial={{ opacity: 0, y: 16 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: '-50px' }}
                      transition={{ duration: 0.5 }}
                      className="text-center mb-8 sm:mb-10"
                    >
                      <h3 className="text-xl sm:text-2xl font-bold text-[#2C1810] tracking-tight">
                        Everything a Handmade Seller Needs — Built for You
                      </h3>
                      <p className="text-sm text-[#6B5744] mt-1.5 max-w-md mx-auto">
                        Everything you need, nothing you don&apos;t.
                      </p>
                    </motion.div>

                    <motion.div
                      variants={containerVariants}
                      initial="hidden"
                      whileInView="visible"
                      viewport={{ once: true, margin: '-80px' }}
                      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6"
                    >
                      {FEATURES.map((feature) => (
                        <motion.div key={feature.title} variants={itemVariants}>
                          <div className="group flex items-start gap-4 p-5 sm:p-6 rounded-xl border border-[#DDD0C0]/50 bg-[#F5F0E8]/50 hover:bg-[#F5F0E8] hover:shadow-md transition-all duration-300">
                            <div className="feature-icon-ring shrink-0">
                              <div className="size-10 rounded-full bg-[#C96A2B]/10 flex items-center justify-center group-hover:bg-[#C96A2B]/15 transition-colors duration-300">
                                <feature.icon className="size-5 text-[#C96A2B]" />
                              </div>
                            </div>
                            <div>
                              <h4 className="font-semibold text-[#2C1810] text-sm sm:text-base mb-1 tracking-tight">
                                {feature.title}
                              </h4>
                              <p className="text-[#6B5744] text-xs sm:text-sm leading-relaxed">
                                {feature.description}
                              </p>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </motion.div>
                  </div>
                </section>

                {/* ═══ HOW IT WORKS ═══════════════════════════ */}
                <section className="bg-[#F5F0E8] max-w-full py-10 sm:py-16">
                  <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                    <motion.div
                      initial={{ opacity: 0, y: 16 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: '-50px' }}
                      transition={{ duration: 0.5 }}
                      className="text-center mb-8 sm:mb-10"
                    >
                      <h3 className="text-xl sm:text-2xl font-bold text-[#2C1810] tracking-tight">
                        Get Started in Under 60 Seconds
                      </h3>
                      <p className="text-sm text-[#6B5744] mt-1.5 max-w-md mx-auto">
                        Three simple steps to better craft business management.
                      </p>
                    </motion.div>

                    <div className="relative">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
                        {STEPS.map((step, index) => (
                          <motion.div
                            key={step.step}
                            initial={{ opacity: 0, y: 24 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5, delay: index * 0.15, ease: [0.16, 1, 0.3, 1] }}
                            className="relative text-center"
                          >
                            {/* Step number */}
                            <div className="inline-flex items-center justify-center mb-4">
                              <div className="relative">
                                <div className="size-16 rounded-2xl bg-[#C96A2B]/10 flex items-center justify-center">
                                  <step.icon className="size-7 text-[#C96A2B]" />
                                </div>
                                <div className="absolute -top-2 -right-2 size-6 rounded-full bg-[#C96A2B] text-white text-xs font-bold flex items-center justify-center shadow-sm">
                                  {step.step}
                                </div>
                              </div>
                            </div>

                            <h4 className="font-bold text-[#2C1810] text-sm sm:text-base mb-1.5 tracking-tight">
                              {step.title}
                            </h4>
                            <p className="text-[#6B5744] text-xs sm:text-sm leading-relaxed max-w-[260px] mx-auto">
                              {step.description}
                            </p>

                            {/* Connector line (hidden on mobile) */}
                            {index < STEPS.length - 1 && (
                              <div className="hidden sm:block absolute top-8 left-[calc(50%+48px)] right-[calc(-50%+48px)]">
                                <div className="step-connector h-[2px] rounded-full" />
                              </div>
                            )}
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>
                </section>

                {/* ═══ COMMUNITY CTA ═══════════════════════════ */}
                <section className="max-w-full pb-14 sm:pb-20 bg-gradient-to-br from-[#F5F0E8] to-[#EDE7DA]">
                  <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: '-50px' }}
                      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                    >
                      <div className="gradient-border">
                        <div className="relative overflow-hidden rounded-[calc(var(--radius-lg)-1.5px)] bg-[#F5F0E8] p-8 sm:p-10 text-center noise-texture">
                          <div className="relative z-10">
                            <div className="flex items-center justify-center gap-2 mb-3">
                              <Users className="size-4 sm:size-5 text-[#C96A2B] shrink-0" />
                              <span className="text-base sm:text-xl font-bold text-[#2C1810] break-words">Help Us Build the Crafter-Owned Marketplace</span>
                            </div>
                            <p className="text-sm sm:text-base text-[#6B5744] max-w-lg mx-auto mb-5 leading-relaxed">
                              We&apos;re artisans like you, building tools for all craftsmen worldwide. Support us so we can continue and provide better tools — and reach the ultimate goal for all craftsmen around the world: a marketplace where you keep what you earn, 0% commission, no corporate middlemen.
                            </p>
                            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                              <Button
                                className="animate-cta-glow bg-[#C96A2B] hover:bg-[#A85420] text-white gap-2 text-sm px-6 rounded-lg w-full sm:w-auto"
                                onClick={scrollToDonationForm}
                              >
                                <Heart className="size-4" />
                                Support This Project
                              </Button>
                              <a
                                href="https://www.facebook.com/share/g/1HLBeMbAVJ/"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="w-full sm:w-auto"
                              >
                                <Button
                                  variant="outline"
                                  className="gap-2 text-sm rounded-lg border-[#C96A2B] text-[#C96A2B] hover:bg-[#F0E6D3] w-full sm:w-auto"
                                >
                                  <Facebook className="size-4" />
                                  Join Community
                                </Button>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  </div>
                </section>

              </motion.div>
            )}
          </AnimatePresence>

          {/* ─── Active Tool View ─────────────────────────── */}
          <AnimatePresence mode="wait">
            {(activeTool || showSupport || showCustomService) && (
              <motion.div
                key={activeTool || showCustomService || 'support'}
                ref={toolRef}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className={`max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 ${isToolActive ? 'pb-24 md:pb-6' : ''}`}
              >
                {/* Back navigation - only on mobile, desktop uses tab bar */}
                <button
                  onClick={goHome}
                  className="md:hidden inline-flex items-center gap-1.5 text-sm text-[#6B5744] hover:text-[#2C1810] transition-colors mb-4 group"
                >
                  <ChevronDown className="size-4 rotate-90 group-hover:-translate-x-0.5 transition-transform" />
                  Back to all tools
                </button>

                {/* Tool header */}
                {activeToolData && (
                  <div className="flex items-center gap-3 mb-6">
                    <div className={`size-10 rounded-xl ${activeToolData.iconBg} flex items-center justify-center shadow-sm`}>
                      <activeToolData.icon className="size-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-lg sm:text-xl font-bold text-[#2C1810]">{activeToolData.title}</h2>
                      <p className="text-xs sm:text-sm text-[#6B5744]">{activeToolData.description}</p>
                    </div>
                  </div>
                )}

                {/* Tool content */}
                {activeTool === 'pricing' && (
                  <div className="space-y-4">
                    <PricingCalculator onSupportClick={openSupport} />
                    <ServiceSuggestionBanner
                      toolName="Pricing Calculator"
                      onCustomizeClick={() => openCustomService('customize')}
                      onUnlimitedClick={() => openCustomService('unlimited')}
                      variant="compact"
                    />
                  </div>
                )}
                {activeTool === 'tags' && (
                  <div className="space-y-4">
                    <TagGenerator onSupportClick={openSupport} />
                    <ServiceSuggestionBanner
                      toolName="Tag Generator"
                      onCustomizeClick={() => openCustomService('customize')}
                      onUnlimitedClick={() => openCustomService('unlimited')}
                      variant="compact"
                    />
                  </div>
                )}
                {activeTool === 'shipping' && (
                  <div className="max-w-2xl mx-auto space-y-4">
                    <ShippingEstimator onSupportClick={openSupport} />
                    <ServiceSuggestionBanner
                      toolName="Shipping Estimator"
                      onCustomizeClick={() => openCustomService('customize')}
                      onUnlimitedClick={() => openCustomService('unlimited')}
                      variant="compact"
                    />
                  </div>
                )}
                {activeTool === 'colors' && (
                  <div className="max-w-2xl mx-auto space-y-4">
                    <ColorPaletteGenerator onSupportClick={openSupport} />
                    <ServiceSuggestionBanner
                      toolName="Color Palette"
                      onCustomizeClick={() => openCustomService('customize')}
                      onUnlimitedClick={() => openCustomService('unlimited')}
                      variant="compact"
                    />
                  </div>
                )}
                {activeTool === 'ai' && (
                  <div className="max-w-4xl mx-auto space-y-4">
                    <AIAssistant onSupportClick={openSupport} />
                  </div>
                )}
                {showSupport && <SupportSection />}

                {showCustomService && (
                  <CustomServicesForm
                    initialType={showCustomService}
                    onBack={goHome}
                  />
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* ─── Footer ─────────────────────────────────────── */}
        <footer className="mt-auto border-t border-[#DDD0C0] bg-[#FDFAF6] pb-16 md:pb-0 overflow-hidden">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-5">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm text-[#9C8070] min-w-0">
                <LogoMark className="h-6 w-auto shrink-0" />
                <span className="font-medium text-[#2C1810] whitespace-nowrap">ArtNew8 Studio</span>
                <span className="hidden sm:inline">·</span>
                <span className="text-xs hidden sm:inline truncate">Community-powered, built for crafters.</span>
              </div>
              <div className="flex items-center gap-3 sm:gap-4 flex-wrap justify-center">
                <a
                  href="https://www.pinterest.com/artnew8/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-[#6B5744] hover:text-[#E60023] transition-colors"
                >
                  <PinterestIcon className="size-3.5" />
                  Pinterest
                </a>
                <a
                  href="https://www.facebook.com/share/g/1HLBeMbAVJ/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-[#6B5744] hover:text-[#2C1810] transition-colors"
                >
                  <Facebook className="size-3.5" />
                  Community
                </a>
                <button
                  onClick={scrollToDonationForm}
                  className="inline-flex items-center gap-1.5 text-xs text-[#C96A2B] hover:text-[#A85420] transition-colors"
                >
                  <Heart className="size-3" />
                  Support Us
                </button>
                <a
                  href="https://www.artnew8.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-[#6B5744] hover:text-[#2C1810] transition-colors"
                >
                  <ExternalLink className="size-3" />
                  Blog
                </a>
              </div>
            </div>
          </div>
        </footer>

        {/* WhatsApp FAB */}
        <WhatsAppFab
          onCustomTool={() => openCustomService('customize')}
          onUnlimitedAccess={() => openCustomService('unlimited')}
        />

        {/* ─── Mobile Bottom Navigation ───────────────────── */}
        <nav
          className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-[#FDFAF6]/95 backdrop-blur-md border-t border-[#DDD0C0]/60 overflow-hidden"
          style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
          aria-label="Tool navigation"
        >
          <div className="flex items-center justify-around h-[58px]">
            {BOTTOM_NAV_ITEMS.map(item => {
              const isHome = item.id === '__home__'
              const isActive = isHome ? (!activeTool && !showSupport && !showCustomService) : activeTool === item.id
              return (
                <button
                  key={item.id}
                  onClick={() => handleBottomNavClick(item.id)}
                  className={`relative flex flex-col items-center justify-center gap-0.5 flex-1 min-w-0 h-full transition-colors duration-200 ${
                    isActive
                      ? 'text-[#C96A2B]'
                      : 'text-[#9C8070] hover:text-[#2C1810]'
                  }`}
                  aria-label={item.label}
                  aria-current={isActive ? 'page' : undefined}
                >
                  {/* Active indicator */}
                  <AnimatePresence>
                    {isActive && (
                      <motion.div
                        layoutId="nav-indicator"
                        className="nav-indicator"
                        initial={{ scaleX: 0 }}
                        animate={{ scaleX: 1 }}
                        exit={{ scaleX: 0 }}
                        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                      />
                    )}
                  </AnimatePresence>
                  <item.icon className="size-[18px] shrink-0" />
                  <span className="text-[10px] leading-tight font-medium truncate w-full text-center px-0.5">{item.label}</span>
                </button>
              )
            })}
          </div>
        </nav>
      </div>
    </TooltipProvider>
  )
}

export default function Home() {
  return <HomeContent />
}
