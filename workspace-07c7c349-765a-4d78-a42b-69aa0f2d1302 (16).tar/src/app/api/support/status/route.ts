import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

/**
 * Check the payment status of a donation
 * Used by the frontend to poll for verification
 * Supports both `ref` (database ID) and `email` lookups
 */
export async function GET(request: NextRequest) {
  try {
    const referenceId = request.nextUrl.searchParams.get('ref')
    const email = request.nextUrl.searchParams.get('email')

    if (!referenceId && !email) {
      return NextResponse.json({ error: 'Reference ID or email is required.' }, { status: 400 })
    }

    let submission = null

    if (referenceId) {
      submission = await db.supportSubmission.findUnique({
        where: { id: referenceId },
      })
    }

    // If not found by ref, try email (most recent)
    if (!submission && email) {
      submission = await db.supportSubmission.findFirst({
        where: { email: email.trim().toLowerCase() },
        orderBy: { createdAt: 'desc' },
      })
    }

    if (!submission) {
      return NextResponse.json({
        referenceId: referenceId || null,
        status: 'pending',
        verified: false,
        message: 'No matching contribution found. If you just completed payment, it may take a moment to process.',
      })
    }

    const isVerified = submission.paymentStatus === 'captured' && !!submission.verifiedAt

    return NextResponse.json({
      referenceId: submission.id,
      status: submission.paymentStatus,
      verified: isVerified,
      amount: submission.amount,
      tier: submission.tier,
      bonusAttempts: submission.bonusAttempts,
      bonusClaimed: submission.bonusClaimed,
      name: submission.name,
      verifiedAt: submission.verifiedAt?.toISOString() || null,
    })
  } catch (error) {
    console.error('Status check error:', error)
    // Return a non-error response so the frontend can continue polling
    return NextResponse.json({
      referenceId: null,
      status: 'pending',
      verified: false,
      message: 'Unable to check status at this time. Will retry.',
    })
  }
}
