import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Detect serverless environments (Vercel, Netlify) — read-only filesystem except /tmp
const isServerless = typeof process !== 'undefined' && 
  (!!process.env.VERCEL || !!process.env.NETLIFY || !!process.env.AWS_LAMBDA_FUNCTION_NAME)

function createPrismaClient(): PrismaClient {
  // On serverless platforms, SQLite must use /tmp for write access
  if (isServerless) {
    return new PrismaClient({
      datasources: {
        db: {
          url: 'file:/tmp/artnew8.db',
        },
      },
      log: [],
    })
  }

  return new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query'] : [],
  })
}

export const db = globalForPrisma.prisma ?? createPrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db

// Graceful shutdown
if (typeof process !== 'undefined') {
  process.on('beforeExit', async () => {
    await db.$disconnect()
  })
}
