'use client'

/**
 * Export utility for downloading tool results as images or PDFs
 *
 * Uses `html-to-image` (SVG foreignObject approach) for image capture
 * and `jsPDF` for PDF generation.
 *
 * Why html-to-image instead of html2canvas?
 * - html2canvas tries to RE-IMPLEMENT CSS parsing → crashes on oklch/oklab
 * - html-to-image uses the browser's OWN rendering via SVG foreignObject
 *   → the browser handles all CSS (oklch, CSS vars, gradients, etc.)
 * - Result: reliable, accurate captures with zero CSS compatibility issues
 */

/**
 * Common options for html-to-image captures
 */
async function captureElement(element: HTMLElement): Promise<string> {
  const { toPng, getFontEmbedCSS } = await import('html-to-image')

  // Pre-fetch font CSS so text renders correctly in the captured image
  let fontEmbedCSS: string | undefined
  try {
    fontEmbedCSS = await getFontEmbedCSS(element)
  } catch {
    // If font embedding fails, continue without it
  }

  // Hide export-ignore elements before capture
  const hiddenEls: HTMLElement[] = []
  element.querySelectorAll('[data-export-ignore]').forEach((el) => {
    const htmlEl = el as HTMLElement
    htmlEl.dataset.prevDisplay = htmlEl.style.display
    htmlEl.style.display = 'none'
    hiddenEls.push(htmlEl)
  })

  // Expand all collapsed accordion sections for full capture
  const expandedAccordions: HTMLElement[] = []
  element.querySelectorAll('[data-state="collapsed"]').forEach((el) => {
    const htmlEl = el as HTMLElement
    htmlEl.setAttribute('data-state', 'open')
    expandedAccordions.push(htmlEl)
  })

  // Also expand accordion content panels that may be hidden
  const expandedContents: HTMLElement[] = []
  element.querySelectorAll('[data-state="closed"]').forEach((el) => {
    const htmlEl = el as HTMLElement
    htmlEl.setAttribute('data-state', 'open')
    expandedContents.push(htmlEl)
  })

  // Remove max-height constraints temporarily (e.g., packaging tips, scroll containers)
  const maxHeightEls: { el: HTMLElement; originalMaxH: string; originalOverflow: string }[] = []
  element.querySelectorAll('[class*="max-h-"]').forEach((el) => {
    const htmlEl = el as HTMLElement
    const computed = window.getComputedStyle(htmlEl).maxHeight
    if (computed && computed !== 'none' && computed !== '0px') {
      maxHeightEls.push({
        el: htmlEl,
        originalMaxH: htmlEl.style.maxHeight,
        originalOverflow: htmlEl.style.overflow,
      })
      htmlEl.style.maxHeight = 'none'
      htmlEl.style.overflow = 'visible'
    }
  })

  // Also handle AccordionContent elements that use data-state for visibility
  const accordionContentEls: { el: HTMLElement; originalHeight: string; originalOverflow: string }[] = []
  element.querySelectorAll('[data-radix-accordion-content]').forEach((el) => {
    const htmlEl = el as HTMLElement
    const computed = window.getComputedStyle(htmlEl)
    if (computed.display === 'none' || computed.height === '0px') {
      accordionContentEls.push({
        el: htmlEl,
        originalHeight: htmlEl.style.height,
        originalOverflow: htmlEl.style.overflow,
      })
      htmlEl.style.display = 'block'
      htmlEl.style.height = 'auto'
      htmlEl.style.overflow = 'visible'
    }
  })

  // Wait a tick for DOM to update after expanding
  await new Promise((resolve) => setTimeout(resolve, 100))

  try {
    const dataUrl = await toPng(element, {
      backgroundColor: '#ffffff',
      pixelRatio: 2,
      cacheBust: true,
      skipAutoScale: true,
      fontEmbedCSS,
      style: {
        paddingTop: '24px',
        paddingBottom: '24px',
        paddingLeft: '24px',
        paddingRight: '24px',
      },
      filter: (node: Node) => {
        // Skip hidden/export-ignore elements
        if (node instanceof HTMLElement && node.dataset?.prevDisplay !== undefined && node.style.display === 'none') {
          return false
        }
        // Skip script tags
        if (node instanceof HTMLScriptElement) return false
        return true
      },
    })

    return dataUrl
  } finally {
    // Restore hidden elements
    hiddenEls.forEach((el) => {
      el.style.display = el.dataset.prevDisplay || ''
      delete el.dataset.prevDisplay
    })

    // Restore collapsed accordion sections
    expandedAccordions.forEach((el) => {
      el.setAttribute('data-state', 'collapsed')
    })

    // Restore closed accordion sections
    expandedContents.forEach((el) => {
      el.setAttribute('data-state', 'closed')
    })

    // Restore max-height constraints
    maxHeightEls.forEach(({ el, originalMaxH, originalOverflow }) => {
      el.style.maxHeight = originalMaxH
      el.style.overflow = originalOverflow
    })

    // Restore accordion content elements
    accordionContentEls.forEach(({ el, originalHeight, originalOverflow }) => {
      el.style.height = originalHeight
      el.style.overflow = originalOverflow
      el.style.display = ''
    })
  }
}

/**
 * Capture a DOM element as a PNG image and download it
 */
export async function downloadAsImage(
  elementId: string,
  filename: string = 'artnew8-result'
): Promise<void> {
  const element = document.getElementById(elementId)
  if (!element) {
    throw new Error(`Element not found: ${elementId}`)
  }

  const dataUrl = await captureElement(element)

  const link = document.createElement('a')
  link.download = `${filename}.png`
  link.href = dataUrl
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

/**
 * Capture a DOM element and download as PDF
 */
export async function downloadAsPDF(
  elementId: string,
  filename: string = 'artnew8-result'
): Promise<void> {
  const element = document.getElementById(elementId)
  if (!element) {
    throw new Error(`Element not found: ${elementId}`)
  }

  const { jsPDF } = await import('jspdf')
  const dataUrl = await captureElement(element)

  // Convert data URL to image to get dimensions
  const img = new Image()
  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve()
    img.onerror = reject
    img.src = dataUrl
  })

  const imgWidth = img.naturalWidth
  const imgHeight = img.naturalHeight

  // Calculate PDF dimensions (A4)
  const pdfWidth = 210
  const pdfHeight = 297
  const margin = 10
  const maxWidth = pdfWidth - margin * 2
  const maxHeight = pdfHeight - margin * 2

  // pixelRatio was 2, so divide by 2 for logical size
  const logicalWidth = imgWidth / 2
  const logicalHeight = imgHeight / 2

  const ratio = Math.min(maxWidth / logicalWidth, maxHeight / logicalHeight)
  const scaledWidth = logicalWidth * ratio
  const scaledHeight = logicalHeight * ratio

  const pdf = new jsPDF({
    orientation: logicalWidth > logicalHeight ? 'landscape' : 'portrait',
    unit: 'mm',
    format: 'a4',
  })

  const x = (pdfWidth - scaledWidth) / 2
  const y = margin

  pdf.addImage(dataUrl, 'PNG', x, y, scaledWidth, scaledHeight)
  pdf.save(`${filename}.pdf`)
}

/**
 * Export data as CSV file
 */
export function downloadAsCSV(
  csvContent: string,
  filename: string = 'artnew8-export'
): void {
  const BOM = '\uFEFF' // UTF-8 BOM for Excel compatibility
  const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = `${filename}.csv`
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

/**
 * Auto-save data to localStorage with debouncing
 */
export function createAutoSave<T>(
  key: string,
  getData: () => T,
  delay: number = 1000
): { save: () => void; cancel: () => void; load: () => T | null } {
  let timer: ReturnType<typeof setTimeout> | null = null

  return {
    save: () => {
      if (timer) clearTimeout(timer)
      timer = setTimeout(() => {
        try {
          const data = getData()
          localStorage.setItem(key, JSON.stringify(data))
        } catch {
          // storage full or unavailable
        }
      }, delay)
    },
    cancel: () => {
      if (timer) {
        clearTimeout(timer)
        timer = null
      }
    },
    load: () => {
      try {
        const saved = localStorage.getItem(key)
        if (saved) return JSON.parse(saved) as T
      } catch {
        // ignore
      }
      return null
    },
  }
}
