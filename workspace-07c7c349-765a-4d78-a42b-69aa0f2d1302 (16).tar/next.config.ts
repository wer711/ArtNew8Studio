import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Vercel handles Next.js natively — no special output mode needed
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  allowedDevOrigins: [
    "preview-chat-57483e63-6483-431a-a017-0b3401746b56.space-z.ai",
    ".space-z.ai",
  ],
  // Sharp must be external — native binary doesn't bundle in serverless
  serverExternalPackages: ["sharp"],
  images: {
    unoptimized: true,
  },
};

export default nextConfig;
