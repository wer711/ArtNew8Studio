import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ArtNew8 Studio — Free Tools for Handmade Sellers",
  description: "Free pricing calculator, SEO tag generator, shipping estimator, color palette tool, and AI assistant for Etsy, Amazon & Shopify sellers. No signup required.",
  keywords: ["craft tools", "pricing calculator", "Etsy tags", "handmade pricing", "craft business", "shipping estimator", "color palette", "AI assistant", "artisan tools", "artnew8"],
  authors: [{ name: "ArtNew8 Studio" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "ArtNew8 Studio — Free Tools for Handmade Sellers",
    description: "Free pricing calculator, SEO tag generator, shipping estimator, color palette tool, and AI assistant for handmade sellers. No signup required.",
    siteName: "ArtNew8 Studio",
    type: "website",
    url: "https://artnew8-studio.netlify.app/",
  },
  twitter: {
    card: "summary_large_image",
    title: "ArtNew8 Studio — Free Tools for Handmade Sellers",
    description: "Pricing, tags, shipping, color palettes & AI — all free for handmade sellers.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
