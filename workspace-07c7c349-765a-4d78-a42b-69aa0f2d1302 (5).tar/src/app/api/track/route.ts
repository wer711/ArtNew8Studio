import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { tool, action, sessionId } = body

    if (!tool || !action) {
      return NextResponse.json(
        { error: 'Tool and action are required.' },
        { status: 400 }
      )
    }

    const validTools = ['pricing', 'tags', 'profit', 'shipping', 'colors']
    if (!validTools.includes(tool)) {
      return NextResponse.json(
        { error: 'Invalid tool name.' },
        { status: 400 }
      )
    }

    await db.toolEvent.create({
      data: {
        tool,
        action,
        sessionId: sessionId || null,
      },
    })

    return NextResponse.json({ success: true }, { status: 200 })
  } catch (error) {
    console.error('Tracking error:', error)
    return NextResponse.json({ error: 'Failed to track event.' }, { status: 500 })
  }
}

export async function GET() {
  try {
    const totalEvents = await db.toolEvent.count()

    const eventsByTool = await db.toolEvent.groupBy({
      by: ['tool'],
      _count: { tool: true },
      orderBy: { _count: { tool: 'desc' } },
    })

    const eventsByAction = await db.toolEvent.groupBy({
      by: ['action'],
      _count: { action: true },
      orderBy: { _count: { action: 'desc' } },
    })

    const recentEvents = await db.toolEvent.findMany({
      take: 50,
      orderBy: { createdAt: 'desc' },
    })

    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const todayEvents = await db.toolEvent.count({
      where: { createdAt: { gte: today } },
    })

    const weekAgo = new Date()
    weekAgo.setDate(weekAgo.getDate() - 7)
    const weekEvents = await db.toolEvent.count({
      where: { createdAt: { gte: weekAgo } },
    })

    const monthAgo = new Date()
    monthAgo.setDate(monthAgo.getDate() - 30)
    const monthEvents = await db.toolEvent.count({
      where: { createdAt: { gte: monthAgo } },
    })

    const dailyCounts = await db.$queryRaw<
      { date: string; count: number }[]
    >`
      SELECT DATE(createdAt) as date, COUNT(*) as count
      FROM ToolEvent
      WHERE createdAt >= datetime('now', '-30 days')
      GROUP BY DATE(createdAt)
      ORDER BY date ASC
    `

    const totalSupporters = await db.supportSubmission.count()
    const totalDonations = await db.supportSubmission.aggregate({
      _sum: { amount: true },
    })

    return NextResponse.json({
      totalEvents,
      todayEvents,
      weekEvents,
      monthEvents,
      eventsByTool: eventsByTool.map(e => ({ tool: e.tool, count: e._count.tool })),
      eventsByAction: eventsByAction.map(e => ({ action: e.action, count: e._count.action })),
      recentEvents,
      dailyCounts,
      totalSupporters,
      totalDonationAmount: totalDonations._sum.amount || 0,
    })
  } catch (error) {
    console.error('Analytics error:', error)
    return NextResponse.json({ error: 'Failed to fetch analytics.' }, { status: 500 })
  }
}
