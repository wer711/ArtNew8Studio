import { NextRequest, NextResponse } from 'next/server'
import { chatCompletion } from '@/lib/ai-service'
import { TAG_CATEGORIES, getSeasonalTags } from '@/lib/tag-database'

// ─── In-memory rate limiter ────────────────────────────────────────────────
const rateLimitMap = new Map<string, { count: number; resetAt: number }>()
const RATE_LIMIT_WINDOW = 60_000 // 1 minute
const MAX_REQUESTS_PER_WINDOW = 6 // max 6 requests per minute per session

function checkRateLimit(sessionId: string): { allowed: boolean; remaining: number } {
  const now = Date.now()
  const entry = rateLimitMap.get(sessionId)

  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(sessionId, { count: 1, resetAt: now + RATE_LIMIT_WINDOW })
    return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - 1 }
  }

  if (entry.count >= MAX_REQUESTS_PER_WINDOW) {
    return { allowed: false, remaining: 0 }
  }

  entry.count++
  return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - entry.count }
}

// Clean up old entries every 5 minutes
setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of rateLimitMap.entries()) {
    if (now > entry.resetAt) {
      rateLimitMap.delete(key)
    }
  }
}, 300_000)

// ─── Local tag fallback ────────────────────────────────────────────────────
function getLocalTagSuggestions(keyword: string, platform: string): string[] {
  const allCategories = [...TAG_CATEGORIES, getSeasonalTags()]
  const allTags = [...new Set(allCategories.flatMap((c) => c.tags))]
  const keywordLower = keyword.toLowerCase()
  const words = keywordLower
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length >= 2)

  const scored = allTags.map((tag) => {
    const tagLower = tag.toLowerCase()
    let score = 0

    // Exact match gets highest score
    if (tagLower === keywordLower) score += 10

    // Tag contains keyword
    if (tagLower.includes(keywordLower)) score += 5

    // Keyword contains tag
    if (keywordLower.includes(tagLower)) score += 3

    // Word-level matching
    for (const word of words) {
      if (tagLower.includes(word)) score += 2
    }

    // Multi-word tags are more valuable (long-tail)
    const tagWords = tag.split(/\s+/).length
    if (tagWords >= 2) score += 1
    if (tagWords >= 3) score += 1

    return { tag, score }
  })

  return scored
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 13)
    .map((s) => s.tag)
}

// ─── POST handler ──────────────────────────────────────────────────────────

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { keyword, platform, sessionId } = body as {
      keyword: string
      platform: string
      sessionId?: string
    }

    if (!keyword?.trim()) {
      return NextResponse.json(
        { error: 'Keyword is required.' },
        { status: 400 }
      )
    }

    // Rate limiting
    const sid = sessionId || 'anonymous'
    const { allowed, remaining } = checkRateLimit(sid)
    if (!allowed) {
      return NextResponse.json(
        { error: 'Too many requests. Please wait a moment and try again.' },
        { status: 429 }
      )
    }

    const platformLabel = platform === 'amazon' ? 'Amazon Handmade' : platform === 'shopify' ? 'Shopify' : 'Etsy'

    try {
      const content = await chatCompletion({
        systemPrompt: `You are an expert ${platformLabel} tag researcher for handmade craft sellers. Your job is to suggest highly relevant, search-optimized tags that will help handmade products get found by buyers. Follow these rules:
- Suggest 10-15 tags
- Tags should be lowercase, 2-4 words each
- Include a mix of broad and long-tail (specific) tags
- Focus on buyer search intent, not seller jargon
- Include seasonal, occasion-based, and gift-related tags when relevant
- Avoid duplicate or near-duplicate tags
- Tags should be specific to handmade/craft items
- Return ONLY a JSON array of tag strings, nothing else
- Example format: ["handmade card", "birthday gift for her", "paper craft"]`,
        userMessage: `Suggest ${platformLabel} tags for a handmade craft product related to: "${keyword.trim()}"`,
        temperature: 0.8,
        maxTokens: 500,
      })

      // Parse the tags from the response
      let tags: string[] = []
      try {
        const jsonMatch = content.match(/\[[\s\S]*?\]/)
        if (jsonMatch) {
          tags = JSON.parse(jsonMatch[0])
        }
      } catch {
        tags = content
          .split(/[,\n]/)
          .map((t: string) => t.trim().replace(/^["'-]|["'-]$/g, '').toLowerCase())
          .filter((t: string) => t.length > 0 && t.length <= 50)
      }

      // Ensure tags are clean and lowercase
      tags = tags
        .map((t: string) => t.toLowerCase().trim())
        .filter((t: string) => t.length > 0 && t.length <= 50)
        .slice(0, 15)

      return NextResponse.json({
        tags,
        remaining,
        source: 'ai',
      })
    } catch (aiError) {
      // AI failed — fall back to local tag database
      console.warn('AI tag suggestion failed, using local fallback:', aiError)

      const tags = getLocalTagSuggestions(keyword.trim(), platform)

      if (tags.length === 0) {
        return NextResponse.json(
          { error: 'No tag suggestions found. Try a different keyword.' },
          { status: 404 }
        )
      }

      return NextResponse.json({
        tags,
        remaining,
        source: 'local',
      })
    }
  } catch (error) {
    console.error('Suggest tags error:', error)
    return NextResponse.json(
      { error: 'Failed to generate tag suggestions. Please try again.' },
      { status: 500 }
    )
  }
}
