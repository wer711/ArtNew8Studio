import { NextRequest, NextResponse } from 'next/server'
import { generateImage } from '@/lib/ai-service'

// ─── In-memory rate limiter ────────────────────────────────────────────────
const rateLimitMap = new Map<string, { count: number; resetAt: number }>()
const RATE_LIMIT_WINDOW = 60_000
const MAX_REQUESTS_PER_WINDOW = 4

function checkRateLimit(sessionId: string): { allowed: boolean; remaining: number } {
  const now = Date.now()
  const entry = rateLimitMap.get(sessionId)

  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(sessionId, { count: 1, resetAt: now + RATE_LIMIT_WINDOW })
    return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - 1 }
  }

  if (entry.count >= MAX_REQUESTS_PER_WINDOW) {
    return { allowed: false, remaining: 0 }
  }

  entry.count++
  return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - entry.count }
}

setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of rateLimitMap.entries()) {
    if (now > entry.resetAt) rateLimitMap.delete(key)
  }
}, 300_000)

// ─── Generate SVG placeholder when image generation fails ──────────────────
function generatePlaceholderSVG(colors: string[], productType: string): string {
  const colorStops = colors.map((c, i) => {
    const offset = (i / colors.length) * 100
    return `<stop offset="${offset}%" stop-color="${c}"/>`
  }).join('')
  const midStop = colors.length > 0 ? `<stop offset="50%" stop-color="${colors[Math.floor(colors.length / 2)]}"/>` : ''

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
    <defs>
      <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
        ${colorStops}${midStop}
      </linearGradient>
    </defs>
    <rect width="512" height="512" fill="url(#bg)" rx="16"/>
    <text x="256" y="240" text-anchor="middle" font-family="Arial, sans-serif" font-size="20" fill="white" opacity="0.9">Product Mockup</text>
    <text x="256" y="275" text-anchor="middle" font-family="Arial, sans-serif" font-size="16" fill="white" opacity="0.7">${productType || 'Handmade Craft'}</text>
  </svg>`

  return `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`
}

// ─── POST handler ──────────────────────────────────────────────────────────

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { colors, productType, sessionId } = body as {
      colors: string[]
      productType: string
      sessionId?: string
    }

    if (!colors?.length) {
      return NextResponse.json(
        { error: 'Colors are required.' },
        { status: 400 }
      )
    }

    const sid = sessionId || 'anonymous'
    const { allowed, remaining } = checkRateLimit(sid)
    if (!allowed) {
      return NextResponse.json(
        { error: 'Too many requests. Please wait a moment and try again.' },
        { status: 429 }
      )
    }

    const colorNames = colors.map((c: string) => c.toUpperCase()).join(', ')
    const product = productType?.trim() || 'handmade craft item'

    const prompt = `Product mockup for handmade ${product} craft item with color palette [${colorNames}], professional product photography, white background, studio lighting, clean minimalist composition, high quality, commercial product shot, soft shadows, elegant presentation`

    try {
      const imageBase64 = await generateImage({ prompt })

      if (!imageBase64) {
        throw new Error('Image generation returned empty result')
      }

      const imageUrl = `data:image/png;base64,${imageBase64}`

      return NextResponse.json({
        imageUrl,
        remaining,
        source: 'ai',
      })
    } catch (aiError) {
      // AI image generation failed — return a placeholder SVG
      console.warn('AI mockup generation failed, using placeholder:', aiError)

      const placeholderUrl = generatePlaceholderSVG(colors, product)

      return NextResponse.json({
        imageUrl: placeholderUrl,
        remaining,
        source: 'placeholder',
        notice: 'AI image generation is temporarily unavailable. A placeholder image has been generated instead.',
      })
    }
  } catch (error) {
    console.error('Generate mockup error:', error)
    return NextResponse.json(
      { error: 'Failed to generate product mockup. Please try again.' },
      { status: 500 }
    )
  }
}
