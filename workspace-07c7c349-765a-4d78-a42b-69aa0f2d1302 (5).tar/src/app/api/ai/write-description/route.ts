import { NextRequest, NextResponse } from 'next/server'
import { chatCompletion } from '@/lib/ai-service'

// ─── In-memory rate limiter ────────────────────────────────────────────────
const rateLimitMap = new Map<string, { count: number; resetAt: number }>()
const RATE_LIMIT_WINDOW = 60_000
const MAX_REQUESTS_PER_WINDOW = 6

function checkRateLimit(sessionId: string): { allowed: boolean; remaining: number } {
  const now = Date.now()
  const entry = rateLimitMap.get(sessionId)

  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(sessionId, { count: 1, resetAt: now + RATE_LIMIT_WINDOW })
    return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - 1 }
  }

  if (entry.count >= MAX_REQUESTS_PER_WINDOW) {
    return { allowed: false, remaining: 0 }
  }

  entry.count++
  return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - entry.count }
}

setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of rateLimitMap.entries()) {
    if (now > entry.resetAt) rateLimitMap.delete(key)
  }
}, 300_000)

// ─── Local description template fallback ───────────────────────────────────
function generateLocalDescription(
  productName: string,
  materials: string[] | undefined,
  category: string | undefined,
  platform: string,
  style: string
): string {
  const materialsList = materials?.length
    ? `Crafted with care using ${materials.join(', ')}, `
    : ''
  const categoryLabel = category || 'handmade craft'

  const templates: Record<string, string> = {
    professional: `${productName} — A beautifully handcrafted ${categoryLabel} piece made with attention to detail and quality.

${materialsList}this item showcases the artistry and dedication that goes into every handmade creation.

✨ Key Features:
• Handmade with premium materials
• Unique, one-of-a-kind design
• Perfect for ${platform} shoppers who value craftsmanship
• Made with love and care

📏 Dimensions & Details:
Please refer to the listing photos for size details.

🎁 Perfect For:
Looking for a thoughtful gift? This ${categoryLabel} item is ideal for anyone who appreciates handmade quality and unique design.

Care instructions included with purchase. Order now and add a touch of handcrafted beauty to your life!`,

    casual: `Hey there! 👋 Check out this amazing ${productName}! 

${materialsList}every piece is made with so much love and care. It's the kind of ${categoryLabel} that makes you smile every time you see it. 😊

Here's what makes it special:
✨ Totally handmade — no two are exactly alike!
✨ Perfect gift idea for someone special (or treat yourself! 🎁)
✨ Made with quality materials that last

Whether you're shopping for a gift or something special for yourself, this ${categoryLabel} piece is sure to delight. Grab yours before they're gone! 💕`,

    storytelling: `Every piece tells a story, and this ${productName} has a special one.

In a quiet workshop, skilled hands shape each element with patience and passion. ${materialsList}the result is a ${categoryLabel} creation that carries the warmth and intention of its maker.

There's something magical about handmade items — they hold a piece of the artisan's heart, a moment of creativity frozen in time. When you hold this piece, you can feel the dedication that went into every detail.

This isn't just a ${categoryLabel} item. It's a connection between maker and owner, a small piece of art that brightens your day.

Bring this story into your home today. 🌟`,

    'seo-optimized': `${productName} | Handmade ${categoryLabel} | Premium Quality Craft

${materialsList}this handcrafted ${categoryLabel} item combines traditional techniques with modern design. Each piece is carefully made by hand, ensuring exceptional quality and unique character you won't find in mass-produced items.

Featured Highlights:
• Handmade ${categoryLabel} with premium craftsmanship
• Unique design — perfect for home decor or gifting
• Quality materials for lasting beauty
• Available now on ${platform}

Popular searches: handmade ${categoryLabel}, ${productName.toLowerCase()}, artisan crafted, unique gift, quality handmade

This ${productName} is perfect for anyone seeking authentic, handcrafted quality. Shop our collection of handmade ${categoryLabel} items — each one made with care and attention to detail.`,
  }

  return templates[style] || templates.professional
}

// ─── POST handler ──────────────────────────────────────────────────────────

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { productName, materials, category, platform, style, sessionId } = body as {
      productName: string
      materials?: string[]
      category?: string
      platform?: string
      style?: 'professional' | 'casual' | 'storytelling' | 'seo-optimized'
      sessionId?: string
    }

    if (!productName?.trim()) {
      return NextResponse.json(
        { error: 'Product name is required.' },
        { status: 400 }
      )
    }

    const sid = sessionId || 'anonymous'
    const { allowed, remaining } = checkRateLimit(sid)
    if (!allowed) {
      return NextResponse.json(
        { error: 'Too many requests. Please wait a moment and try again.' },
        { status: 429 }
      )
    }

    const platformLabel = platform === 'amazon' ? 'Amazon' : platform === 'shopify' ? 'Shopify' : 'Etsy'
    const styleLabel = style || 'professional'
    const materialsList = materials?.length ? `Materials used: ${materials.join(', ')}` : ''
    const categoryLabel = category || 'handmade craft'

    const styleInstructions: Record<string, string> = {
      professional: 'Write in a polished, professional tone that conveys quality and craftsmanship. Use clear, confident language.',
      casual: 'Write in a warm, friendly, conversational tone as if talking to a friend. Use approachable language and occasional emojis.',
      storytelling: 'Tell the story behind the creation — the inspiration, the process, the care that goes into each piece. Make it emotional and personal.',
      'seo-optimized': 'Write an SEO-optimized description that naturally incorporates relevant keywords for search discovery while remaining engaging and readable. Include key product features prominently.',
    }

    try {
      const content = await chatCompletion({
        systemPrompt: `You are an expert copywriter specializing in ${platformLabel} product descriptions for handmade craft items. ${styleInstructions[styleLabel]}

Write a compelling product description for ${platformLabel}. Include:
1. An attention-grabbing opening line
2. Key features and benefits (bullet points)
3. Materials and dimensions (if provided)
4. Perfect gift for / occasion suggestions
5. Care instructions (if applicable)
6. A closing call-to-action

Rules:
- Keep it between 150-300 words
- Make it feel authentic and handmade
- Use sensory language when describing the product
- Include relevant keywords naturally for SEO
- Return the description as plain text (not JSON)

${materialsList}`,
        userMessage: `Write a ${styleLabel} product description for a handmade ${categoryLabel} item called "${productName.trim()}" to be sold on ${platformLabel}.`,
        temperature: 0.8,
        maxTokens: 800,
      })

      if (content?.trim()) {
        return NextResponse.json({
          description: content,
          style: styleLabel,
          platform: platformLabel,
          remaining,
          source: 'ai',
        })
      }

      throw new Error('AI returned empty content')
    } catch (aiError) {
      // AI failed — fall back to local template
      console.warn('AI description generation failed, using local fallback:', aiError)

      const localDesc = generateLocalDescription(
        productName.trim(),
        materials,
        category,
        platformLabel,
        styleLabel
      )

      return NextResponse.json({
        description: localDesc,
        style: styleLabel,
        platform: platformLabel,
        remaining,
        source: 'local',
      })
    }
  } catch (error) {
    console.error('Write description error:', error)
    return NextResponse.json(
      { error: 'Failed to generate product description. Please try again.' },
      { status: 500 }
    )
  }
}
