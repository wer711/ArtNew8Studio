import { NextRequest, NextResponse } from 'next/server'
import { chatCompletion } from '@/lib/ai-service'

// ─── In-memory rate limiter ────────────────────────────────────────────────
const rateLimitMap = new Map<string, { count: number; resetAt: number }>()
const RATE_LIMIT_WINDOW = 60_000
const MAX_REQUESTS_PER_WINDOW = 4

function checkRateLimit(sessionId: string): { allowed: boolean; remaining: number } {
  const now = Date.now()
  const entry = rateLimitMap.get(sessionId)

  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(sessionId, { count: 1, resetAt: now + RATE_LIMIT_WINDOW })
    return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - 1 }
  }

  if (entry.count >= MAX_REQUESTS_PER_WINDOW) {
    return { allowed: false, remaining: 0 }
  }

  entry.count++
  return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - entry.count }
}

setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of rateLimitMap.entries()) {
    if (now > entry.resetAt) rateLimitMap.delete(key)
  }
}, 300_000)

// ─── Local price estimate fallback ─────────────────────────────────────────
function getLocalPriceEstimate(product: string, category: string): {
  priceRange: { min: number; max: number; avg: number }
  sources: { name: string; url: string; price: string }[]
  advice: string
} {
  const productLower = product.toLowerCase()

  // Basic heuristic pricing based on common handmade categories
  let min = 10
  let max = 50
  let avg = 25

  if (productLower.includes('jewelry') || productLower.includes('necklace') || productLower.includes('bracelet')) {
    min = 15; max = 75; avg = 35
  } else if (productLower.includes('candle') || productLower.includes('soap') || productLower.includes('bath')) {
    min = 8; max = 30; avg = 16
  } else if (productLower.includes('card') || productLower.includes('greeting')) {
    min = 4; max = 15; avg = 7
  } else if (productLower.includes('pottery') || productLower.includes('ceramic') || productLower.includes('mug')) {
    min = 20; max = 60; avg = 32
  } else if (productLower.includes('leather') || productLower.includes('wallet') || productLower.includes('bag')) {
    min = 25; max = 100; avg = 50
  } else if (productLower.includes('print') || productLower.includes('art') || productLower.includes('download')) {
    min = 5; max = 40; avg = 18
  } else if (productLower.includes('knit') || productLower.includes('crochet') || productLower.includes('scarf')) {
    min = 20; max = 65; avg = 35
  } else if (productLower.includes('wedding') || productLower.includes('bridal')) {
    min = 30; max = 150; avg = 65
  }

  return {
    priceRange: { min, max, avg },
    sources: [
      { name: 'Etsy market average', url: 'https://etsy.com', price: `$${avg}` },
      { name: 'Amazon Handmade range', url: 'https://amazon.com/handmade', price: `$${min}-$${max}` },
    ],
    advice: `Based on general handmade market data, ${product} in the ${category || 'handmade craft'} category typically sells for $${min}-$${max}. Consider your materials, time, and uniqueness when pricing. Research similar items on Etsy for more specific pricing.`,
  }
}

// ─── POST handler ──────────────────────────────────────────────────────────

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { product, category, sessionId } = body as {
      product: string
      category: string
      sessionId?: string
    }

    if (!product?.trim()) {
      return NextResponse.json(
        { error: 'Product name is required.' },
        { status: 400 }
      )
    }

    const sid = sessionId || 'anonymous'
    const { allowed, remaining } = checkRateLimit(sid)
    if (!allowed) {
      return NextResponse.json(
        { error: 'Too many requests. Please wait a moment and try again.' },
        { status: 429 }
      )
    }

    const categoryLabel = category || 'general handmade'

    try {
      const content = await chatCompletion({
        systemPrompt: `You are an expert market researcher for handmade craft products. Analyze the product described and provide realistic pricing information based on your knowledge of current market trends on platforms like Etsy, Amazon Handmade, and Shopify. Return a JSON object with this exact format:
{
  "priceRange": { "min": <number>, "max": <number>, "avg": <number> },
  "sources": [
    { "name": "<product/store type>", "url": "<platform url or 'market estimate'>", "price": "<price string>" }
  ],
  "advice": "<brief pricing advice for this specific product>"
}
- All prices should be in USD
- Include up to 5 source entries with realistic market prices
- Base your estimates on current handmade market trends
- Include advice specific to this product category
- Return ONLY the JSON object, nothing else`,
        userMessage: `Analyze market pricing for handmade "${product.trim()}" in the category: ${categoryLabel}. What are typical selling prices on Etsy, Amazon Handmade, and similar platforms?`,
        temperature: 0.5,
        maxTokens: 800,
      })

      let result
      try {
        const jsonMatch = content.match(/\{[\s\S]*\}/)
        if (jsonMatch) {
          result = JSON.parse(jsonMatch[0])
        }
      } catch {
        result = null
      }

      // Validate the result structure
      if (result?.priceRange && typeof result.priceRange.min === 'number') {
        if (!Array.isArray(result.sources)) {
          result.sources = []
        }
        return NextResponse.json({
          priceRange: result.priceRange,
          sources: result.sources.slice(0, 5),
          advice: result.advice || '',
          remaining,
          source: 'ai',
        })
      }

      // If AI response was malformed, fall back to local
      throw new Error('AI response was malformed')
    } catch (aiError) {
      // AI failed — fall back to local estimates
      console.warn('AI price research failed, using local fallback:', aiError)

      const localResult = getLocalPriceEstimate(product.trim(), categoryLabel)
      return NextResponse.json({
        priceRange: localResult.priceRange,
        sources: localResult.sources,
        advice: localResult.advice,
        remaining,
        source: 'local',
      })
    }
  } catch (error) {
    console.error('Research price error:', error)
    return NextResponse.json(
      { error: 'Failed to research market prices. Please try again.' },
      { status: 500 }
    )
  }
}
