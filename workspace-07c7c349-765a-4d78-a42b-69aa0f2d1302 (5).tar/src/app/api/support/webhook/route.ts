import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

/**
 * PayPal Webhook Handler
 * 
 * Receives PayPal webhook events and processes them.
 * Set up this URL in your PayPal Developer Dashboard:
 * https://your-domain.com/api/support/webhook
 * 
 * Required events to subscribe to:
 * - PAYMENT.CAPTURE.COMPLETED
 * - PAYMENT.CAPTURE.DENIED
 * - PAYMENT.CAPTURE.REFUNDED
 * 
 * NOTE: When PayPal REST API credentials are configured, you can
 * add signature verification. For now, we do basic event processing.
 */

// Simple IP-based rate limiting for webhook security
const webhookCallTimestamps: number[] = []
const RATE_LIMIT_WINDOW = 60_000 // 1 minute
const RATE_LIMIT_MAX = 30 // max calls per minute

function isRateLimited(): boolean {
  const now = Date.now()
  // Clean old timestamps
  while (webhookCallTimestamps.length > 0 && webhookCallTimestamps[0] < now - RATE_LIMIT_WINDOW) {
    webhookCallTimestamps.shift()
  }
  return webhookCallTimestamps.length >= RATE_LIMIT_MAX
}

export async function POST(request: NextRequest) {
  try {
    // Rate limiting
    if (isRateLimited()) {
      return NextResponse.json({ error: 'Rate limited' }, { status: 429 })
    }
    webhookCallTimestamps.push(Date.now())

    const body = await request.text()

    // Parse the event
    let event: Record<string, unknown>
    try {
      event = JSON.parse(body)
    } catch {
      console.error('PayPal webhook: Invalid JSON body')
      return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
    }

    const eventType = event.event_type as string | undefined

    if (!eventType) {
      console.error('PayPal webhook: Missing event_type')
      return NextResponse.json({ error: 'Missing event_type' }, { status: 400 })
    }

    console.log(`PayPal webhook received: ${eventType}`)

    // TODO: Add webhook signature verification when PayPal REST API is configured
    // For now, we trust incoming events but log them for audit
    const WEBHOOK_SECRET = process.env.PAYPAL_WEBHOOK_ID
    if (WEBHOOK_SECRET) {
      // In production, verify the webhook signature here
      // using the PayPal Webhook Verification API
      console.log('PayPal webhook: Signature verification skipped (implement when REST API is configured)')
    }

    switch (eventType) {
      case 'PAYMENT.CAPTURE.COMPLETED': {
        const resource = event.resource as Record<string, unknown> | undefined
        const capture = resource || {}

        // Try to find by custom_id (our reference) or order_id
        const customId = capture.custom_id as string | undefined
        const orderId = (capture.supplementary_data as Record<string, unknown> | undefined)?.related_ids 
          ? ((capture.supplementary_data as Record<string, Record<string, string>>).related_ids?.order_id)
          : (capture.order_id as string | undefined) || (capture.id as string | undefined)

        let submission = null

        if (customId) {
          submission = await db.supportSubmission.findUnique({
            where: { id: customId },
          })
        }

        if (!submission && orderId) {
          submission = await db.supportSubmission.findFirst({
            where: { paypalOrderId: orderId },
          })
        }

        if (submission && submission.paymentStatus !== 'captured') {
          await db.supportSubmission.update({
            where: { id: submission.id },
            data: {
              paymentStatus: 'captured',
              paypalTransactionId: (capture.id as string) || null,
              paypalPayerEmail: ((capture.payer as Record<string, string>)?.email_address) || null,
              verifiedAt: new Date(),
            },
          })

          // Send to Google Sheets
          const GOOGLE_SHEETS_WEBHOOK_URL = process.env.GOOGLE_SHEETS_WEBHOOK_URL || ''
          if (GOOGLE_SHEETS_WEBHOOK_URL) {
            try {
              await fetch(GOOGLE_SHEETS_WEBHOOK_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  name: submission.name,
                  email: submission.email,
                  phone: submission.phone,
                  amount: submission.amount,
                  tier: submission.tier,
                  message: submission.message,
                  paypalTransactionId: capture.id,
                  verifiedAt: new Date().toISOString(),
                  source: 'webhook',
                }),
              })
            } catch {
              // Continue
            }
          }
        }
        break
      }

      case 'PAYMENT.CAPTURE.DENIED': {
        const resource = event.resource as Record<string, unknown> | undefined
        const orderId = (resource?.order_id as string) || (resource?.id as string)
        if (orderId) {
          const submission = await db.supportSubmission.findFirst({
            where: { paypalOrderId: orderId },
          })
          if (submission) {
            await db.supportSubmission.update({
              where: { id: submission.id },
              data: { paymentStatus: 'failed' },
            })
          }
        }
        break
      }

      case 'PAYMENT.CAPTURE.REFUNDED': {
        const resource = event.resource as Record<string, unknown> | undefined
        const orderId = (resource?.order_id as string) || (resource?.id as string)
        if (orderId) {
          const submission = await db.supportSubmission.findFirst({
            where: { paypalOrderId: orderId },
          })
          if (submission) {
            await db.supportSubmission.update({
              where: { id: submission.id },
              data: { paymentStatus: 'refunded' },
            })
          }
        }
        break
      }

      default:
        console.log(`Unhandled webhook event: ${eventType}`)
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error('PayPal webhook error:', error)
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 })
  }
}

// PayPal sends GET requests for verification in some cases
export async function GET() {
  return NextResponse.json({ status: 'webhook_active' })
}
