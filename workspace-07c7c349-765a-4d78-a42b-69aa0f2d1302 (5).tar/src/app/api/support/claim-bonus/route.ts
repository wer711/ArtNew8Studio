import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

/**
 * Claim bonus attempts after a verified donation
 * Marks the bonus as claimed so it can only be used once
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { referenceId } = body

    if (!referenceId) {
      return NextResponse.json({ error: 'Reference ID is required.' }, { status: 400 })
    }

    const submission = await db.supportSubmission.findUnique({
      where: { id: referenceId },
    })

    if (!submission) {
      return NextResponse.json({ error: 'Donation record not found.' }, { status: 404 })
    }

    // Only allow claiming for verified payments
    if (submission.paymentStatus !== 'captured' || !submission.verifiedAt) {
      return NextResponse.json(
        { error: 'Payment not yet verified.' },
        { status: 400 }
      )
    }

    // Check if already claimed
    if (submission.bonusClaimed) {
      return NextResponse.json(
        { error: 'Bonus already claimed.', bonusAttempts: submission.bonusAttempts },
        { status: 200 }
      )
    }

    // Mark as claimed
    await db.supportSubmission.update({
      where: { id: referenceId },
      data: { bonusClaimed: true },
    })

    return NextResponse.json({
      success: true,
      bonusAttempts: submission.bonusAttempts,
      tier: submission.tier,
      amount: submission.amount,
      name: submission.name,
    })
  } catch (error) {
    console.error('Claim bonus error:', error)
    return NextResponse.json({ error: 'Something went wrong.' }, { status: 500 })
  }
}
