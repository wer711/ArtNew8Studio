import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

/**
 * Register a PayPal NCP (Named Checkout Page) donation
 *
 * This is the simplest payment method:
 * 1. User fills form on our site
 * 2. User pays via PayPal NCP link (paypal.com/ncp/payment/xxx)
 * 3. After payment, user returns and data is registered
 *
 * This endpoint:
 * - Saves the donation to the database
 * - Sends data to Google Sheets
 * - Returns tier and bonus info
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, amount, tier, bonusAttempts, message, source } = body as {
      name: string
      email: string
      amount: number
      tier: string
      bonusAttempts: number
      message?: string
      source?: string
    }

    // Validate required fields
    if (!name?.trim()) {
      return NextResponse.json({ error: 'Name is required.' }, { status: 400 })
    }
    if (!email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Valid email is required.' }, { status: 400 })
    }
    if (!amount || amount < 1) {
      return NextResponse.json({ error: 'Amount must be at least $1.' }, { status: 400 })
    }

    // Save to database
    const submission = await db.supportSubmission.create({
      data: {
        name: name.trim(),
        email: email.trim(),
        amount,
        tier: tier || 'seedling',
        message: message?.trim() || null,
        paymentStatus: 'captured',
        bonusAttempts: bonusAttempts || 5,
        bonusClaimed: true,
        verifiedAt: new Date(),
      },
    })

    // Send to Google Sheets
    const GOOGLE_SHEETS_WEBHOOK_URL = process.env.GOOGLE_SHEETS_WEBHOOK_URL || ''
    if (GOOGLE_SHEETS_WEBHOOK_URL) {
      try {
        await fetch(GOOGLE_SHEETS_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: name.trim(),
            email: email.trim(),
            amount,
            currency: 'USD',
            tier: tier || 'seedling',
            message: message?.trim() || '',
            bonusAttempts: bonusAttempts || 5,
            status: 'completed',
            source: source || 'paypal_ncp',
            transactionId: `NCP-${submission.id}`,
            timestamp: new Date().toISOString(),
          }),
        })
      } catch {
        // Continue — database is the primary storage
      }
    }

    return NextResponse.json({
      success: true,
      id: submission.id,
      amount,
      tier: tier || 'seedling',
      bonusAttempts: bonusAttempts || 5,
      message: 'Donation registered successfully.',
    })
  } catch (error) {
    console.error('Register NCP donation error:', error)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again later.' },
      { status: 500 }
    )
  }
}
