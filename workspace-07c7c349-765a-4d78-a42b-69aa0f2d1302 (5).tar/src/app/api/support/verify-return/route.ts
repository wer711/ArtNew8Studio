import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Calculate bonus attempts based on donation amount (tiered)
function calculateBonusAttempts(amount: number): number {
  if (amount >= 50) return 50
  if (amount >= 25) return 30
  if (amount >= 10) return 20
  if (amount >= 5) return 10
  if (amount >= 1) return 5
  return 0
}

// Get tier name based on donation amount
function getDonorTier(amount: number): string {
  if (amount >= 50) return 'champion'
  if (amount >= 25) return 'hero'
  if (amount >= 10) return 'supporter'
  if (amount >= 5) return 'friend'
  return 'seedling'
}

/**
 * Verify PayPal Standard Checkout return
 *
 * Handles three verification levels:
 * 1. PDT verification (best) — uses PayPal's PDT system with identity token
 * 2. URL parameter verification (good) — checks st=Completed and amt matches
 * 3. Return-based verification (basic) — trusts the return if we have a valid ref ID
 *    (PayPal only redirects after payment or when user clicks "Return to merchant")
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { tx, ref, amt, st, cm } = body as {
      tx?: string   // PayPal transaction ID
      ref?: string  // Our reference ID (custom field)
      amt?: string  // Amount paid
      st?: string   // Status (Completed, Pending, etc.)
      cm?: string   // Custom field (our reference ID)
    }

    // Use either ref or cm as our reference ID
    const referenceId = ref || cm

    if (!referenceId) {
      return NextResponse.json(
        { error: 'Missing reference ID.' },
        { status: 400 }
      )
    }

    // Find the pending submission
    const submission = await db.supportSubmission.findUnique({
      where: { id: referenceId },
    })

    if (!submission) {
      return NextResponse.json(
        { error: 'Donation record not found.' },
        { status: 404 }
      )
    }

    // Already captured?
    if (submission.paymentStatus === 'captured' && submission.verifiedAt) {
      return NextResponse.json({
        success: true,
        verified: true,
        amount: submission.amount,
        tier: submission.tier,
        bonusAttempts: submission.bonusAttempts,
        message: 'Payment already verified and bonus granted.',
      })
    }

    const bonusAttempts = submission.bonusAttempts || calculateBonusAttempts(submission.amount)
    const tier = submission.tier || getDonorTier(submission.amount)

    // ─── LEVEL 1: PDT Verification (best) ───
    const pdtToken = process.env.PAYPAL_PDT_IDENTITY_TOKEN || ''
    let pdtVerified = false
    let pdtData: Record<string, string> = {}

    if (tx && pdtToken) {
      try {
        const isSandbox = process.env.PAYPAL_SANDBOX === 'true'
        const pdtUrl = isSandbox
          ? 'https://ipnpb.sandbox.paypal.com/cgi-bin/webscr'
          : 'https://ipnpb.paypal.com/cgi-bin/webscr'

        const pdtResponse = await fetch(pdtUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: `cmd=_notify-synch&tx=${encodeURIComponent(tx)}&at=${encodeURIComponent(pdtToken)}`,
        })

        const pdtText = await pdtResponse.text()
        const lines = pdtText.split('\n')

        if (lines[0]?.trim() === 'SUCCESS') {
          pdtVerified = true
          // Parse PDT response
          for (let i = 1; i < lines.length; i++) {
            const eqIndex = lines[i].indexOf('=')
            if (eqIndex > 0) {
              const key = lines[i].substring(0, eqIndex)
              const value = decodeURIComponent(lines[i].substring(eqIndex + 1).replace(/\+/g, ' '))
              pdtData[key] = value
            }
          }
        }
      } catch (err) {
        console.error('PDT verification error:', err)
      }
    }

    // ─── Check PDT verification result ───
    if (pdtVerified) {
      const paidAmount = parseFloat(pdtData.payment_gross || pdtData.mc_gross || '0')
      const paymentStatus = pdtData.payment_status

      if (paymentStatus === 'Completed' && Math.abs(paidAmount - submission.amount) < 0.01) {
        // PDT verified successfully!
        await markCaptured(referenceId, tx || pdtData.txn_id, pdtData.payer_email)
        await sendToGoogleSheets(submission, tier, bonusAttempts, tx || pdtData.txn_id, 'paypal_standard_pdt')

        return NextResponse.json({
          success: true,
          verified: true,
          amount: submission.amount,
          tier,
          bonusAttempts,
          transactionId: tx || pdtData.txn_id,
          message: 'Payment verified via PayPal PDT. Your bonus has been granted.',
        })
      }

      if (paymentStatus === 'Pending') {
        return NextResponse.json({
          success: false,
          pending: true,
          message: 'Payment is pending. Bonus will be added once payment clears.',
        })
      }

      // PDT says payment not completed
      return NextResponse.json(
        { error: `Payment status: ${paymentStatus}. If you were charged, please contact us via WhatsApp.`, verificationFailed: true },
        { status: 402 }
      )
    }

    // ─── LEVEL 2: URL Parameter Verification (good) ───
    // PayPal Auto Return includes tx, st, amt in the URL
    if (st && amt) {
      const paidAmount = parseFloat(amt)
      const paymentStatus = st

      if (paymentStatus === 'Completed' && paidAmount >= submission.amount) {
        // URL parameters indicate completed payment
        await markCaptured(referenceId, tx || null, null)
        await sendToGoogleSheets(submission, tier, bonusAttempts, tx, 'paypal_standard_auto_return')

        return NextResponse.json({
          success: true,
          verified: true,
          amount: submission.amount,
          tier,
          bonusAttempts,
          transactionId: tx,
          message: 'Payment verified successfully! Your bonus has been granted.',
        })
      }

      if (paymentStatus === 'Pending') {
        return NextResponse.json({
          success: false,
          pending: true,
          message: 'Payment is pending. Bonus will be added once payment clears.',
        })
      }

      // URL parameters say payment not completed
      return NextResponse.json(
        { error: `Payment status: ${paymentStatus}. If you were charged, please contact us via WhatsApp.`, verificationFailed: true },
        { status: 402 }
      )
    }

    // ─── LEVEL 3: Return-Based Verification (basic) ───
    // No PDT and no URL parameters — the user was redirected from PayPal.
    // PayPal only redirects to the return URL after payment completion or
    // when the user clicks "Return to merchant" on the payment page.
    // We trust the return and mark as "return_verified" (not fully PDT-verified,
    // but the user did visit PayPal and come back).
    if (tx) {
      // We have a transaction ID — likely Auto Return without full params
      // Trust it and record the transaction
      await markCaptured(referenceId, tx, null)
      await sendToGoogleSheets(submission, tier, bonusAttempts, tx, 'paypal_standard_return_tx')

      return NextResponse.json({
        success: true,
        verified: true,
        amount: submission.amount,
        tier,
        bonusAttempts,
        transactionId: tx,
        message: 'Payment recorded. Your bonus has been granted.',
      })
    }

    // No transaction data at all — the user clicked "Return to merchant" manually.
    // This could mean payment was completed or cancelled.
    // We mark as "pending_verification" and let the webhook/IPN confirm later.
    // However, for a good UX, we still add bonus attempts tentatively.
    await db.supportSubmission.update({
      where: { id: referenceId },
      data: {
        paymentStatus: 'pending_verification',
      },
    })

    await sendToGoogleSheets(submission, tier, bonusAttempts, null, 'paypal_standard_return_pending')

    return NextResponse.json({
      success: true,
      verified: true,
      amount: submission.amount,
      tier,
      bonusAttempts,
      transactionId: null,
      message: 'Thank you! Your payment is being confirmed. Your bonus has been granted.',
      pendingConfirmation: true,
    })
  } catch (error) {
    console.error('Verify return error:', error)
    return NextResponse.json(
      { error: 'Something went wrong during payment verification.' },
      { status: 500 }
    )
  }
}

// Helper: Mark submission as captured
async function markCaptured(referenceId: string, transactionId: string | null, payerEmail: string | null) {
  await db.supportSubmission.update({
    where: { id: referenceId },
    data: {
      paymentStatus: 'captured',
      paypalTransactionId: transactionId,
      paypalPayerEmail: payerEmail,
      verifiedAt: new Date(),
    },
  })
}

// Helper: Send donation data to Google Sheets
async function sendToGoogleSheets(
  submission: { name: string; email: string; phone: string | null; amount: number; message: string | null; createdAt: Date },
  tier: string,
  bonusAttempts: number,
  transactionId: string | null,
  source: string
) {
  const GOOGLE_SHEETS_WEBHOOK_URL = process.env.GOOGLE_SHEETS_WEBHOOK_URL || ''
  if (!GOOGLE_SHEETS_WEBHOOK_URL) return

  try {
    await fetch(GOOGLE_SHEETS_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: submission.name,
        email: submission.email,
        phone: submission.phone,
        amount: submission.amount,
        tier,
        message: submission.message,
        bonusAttempts,
        paypalTransactionId: transactionId,
        status: source.includes('pending') ? 'pending_verification' : 'captured',
        source,
        createdAt: submission.createdAt.toISOString(),
        capturedAt: new Date().toISOString(),
      }),
    })
  } catch {
    // Continue — database is the primary storage
  }
}
