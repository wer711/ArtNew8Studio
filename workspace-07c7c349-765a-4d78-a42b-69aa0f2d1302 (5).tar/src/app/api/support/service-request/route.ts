import { NextRequest, NextResponse } from 'next/server'

// Google Sheets webhook URL from environment
const GOOGLE_SHEETS_WEBHOOK_URL = process.env.GOOGLE_SHEETS_WEBHOOK_URL

interface CustomizeRequest {
  type: 'customize'
  name: string
  email: string
  phone: string
  toolName: string
  projectDescription: string
  specificNeeds: string
  budget: string
  timeline: string
}

interface UnlimitedRequest {
  type: 'unlimited'
  name: string
  email: string
  phone: string
  usageReason: string
  toolsUsed: string[]
  expectedVolume: string
}

type ServiceRequestBody = CustomizeRequest | UnlimitedRequest

export async function POST(request: NextRequest) {
  try {
    const body: ServiceRequestBody = await request.json()

    // Validate common fields
    if (!body.name?.trim()) {
      return NextResponse.json({ error: 'Name is required.' }, { status: 400 })
    }
    if (!body.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
      return NextResponse.json({ error: 'Valid email is required.' }, { status: 400 })
    }

    // Type-specific validation
    if (body.type === 'customize') {
      if (!body.toolName?.trim()) {
        return NextResponse.json({ error: 'Tool name is required.' }, { status: 400 })
      }
      if (!body.projectDescription?.trim()) {
        return NextResponse.json({ error: 'Project description is required.' }, { status: 400 })
      }
      if (!body.specificNeeds?.trim()) {
        return NextResponse.json({ error: 'Specific needs are required.' }, { status: 400 })
      }
    } else if (body.type === 'unlimited') {
      if (!body.usageReason?.trim()) {
        return NextResponse.json({ error: 'Usage reason is required.' }, { status: 400 })
      }
      if (!body.toolsUsed || body.toolsUsed.length === 0) {
        return NextResponse.json({ error: 'At least one tool must be selected.' }, { status: 400 })
      }
    } else {
      return NextResponse.json({ error: 'Invalid request type.' }, { status: 400 })
    }

    // Build row data for Google Sheets
    const timestamp = new Date().toISOString()
    let rowData: Record<string, string>

    if (body.type === 'customize') {
      rowData = {
        timestamp,
        type: 'Tool Customization',
        name: body.name.trim(),
        email: body.email.trim(),
        phone: body.phone?.trim() || '',
        toolName: body.toolName.trim(),
        projectDescription: body.projectDescription.trim(),
        specificNeeds: body.specificNeeds.trim(),
        budget: body.budget || 'Not specified',
        timeline: body.timeline || 'Flexible',
        toolsUsed: body.toolName,
        expectedVolume: '',
        usageReason: '',
        status: 'New',
      }
    } else {
      rowData = {
        timestamp,
        type: 'Unlimited Access',
        name: body.name.trim(),
        email: body.email.trim(),
        phone: body.phone?.trim() || '',
        toolName: '',
        projectDescription: '',
        specificNeeds: '',
        budget: '',
        timeline: '',
        toolsUsed: body.toolsUsed.join(', '),
        expectedVolume: body.expectedVolume || 'Not specified',
        usageReason: body.usageReason.trim(),
        status: 'New',
      }
    }

    // Send to Google Sheets if webhook is configured
    if (GOOGLE_SHEETS_WEBHOOK_URL) {
      try {
        await fetch(GOOGLE_SHEETS_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(rowData),
        })
      } catch (sheetsError) {
        console.error('Google Sheets webhook failed:', sheetsError)
        // Don't fail the request - data is still sent via WhatsApp
      }
    }

    return NextResponse.json({
      success: true,
      message: 'Service request recorded successfully.',
      type: body.type,
    })
  } catch (error) {
    console.error('Service request error:', error)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again later.' },
      { status: 500 }
    )
  }
}
