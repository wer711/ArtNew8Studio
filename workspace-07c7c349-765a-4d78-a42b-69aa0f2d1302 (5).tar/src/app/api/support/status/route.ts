import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

/**
 * Check the payment status of a donation
 * Used by the frontend to poll for verification
 */
export async function GET(request: NextRequest) {
  try {
    const referenceId = request.nextUrl.searchParams.get('ref')

    if (!referenceId) {
      return NextResponse.json({ error: 'Reference ID is required.' }, { status: 400 })
    }

    const submission = await db.supportSubmission.findUnique({
      where: { id: referenceId },
    })

    if (!submission) {
      return NextResponse.json({ error: 'Donation record not found.' }, { status: 404 })
    }

    const isVerified = submission.paymentStatus === 'captured' && !!submission.verifiedAt

    return NextResponse.json({
      referenceId: submission.id,
      status: submission.paymentStatus,
      verified: isVerified,
      amount: submission.amount,
      tier: submission.tier,
      bonusAttempts: submission.bonusAttempts,
      bonusClaimed: submission.bonusClaimed,
      name: submission.name,
      verifiedAt: submission.verifiedAt?.toISOString() || null,
    })
  } catch (error) {
    console.error('Status check error:', error)
    return NextResponse.json({ error: 'Something went wrong.' }, { status: 500 })
  }
}
