import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

/**
 * GET /api/support - List support submissions (for admin purposes)
 * POST /api/support - Legacy endpoint, redirects to new flow
 * 
 * NOTE: New donations should use:
 * - POST /api/support/create - Create pending donation + PayPal order
 * - POST /api/support/capture - Capture/verify PayPal payment
 * - POST /api/support/webhook - PayPal webhook handler
 * - GET /api/support/status - Check payment status
 * - POST /api/support/claim-bonus - Claim bonus after verification
 */

export async function GET() {
  try {
    const submissions = await db.supportSubmission.findMany({
      orderBy: { createdAt: 'desc' },
      take: 50,
    })

    return NextResponse.json({
      total: submissions.length,
      verified: submissions.filter(s => s.paymentStatus === 'captured').length,
      pending: submissions.filter(s => s.paymentStatus === 'pending').length,
      submissions,
    })
  } catch (error) {
    console.error('List support error:', error)
    return NextResponse.json({ error: 'Something went wrong.' }, { status: 500 })
  }
}

// Legacy POST endpoint - now requires payment verification
// Do NOT use this for new donations - use /api/support/create instead
export async function POST(request: NextRequest) {
  return NextResponse.json(
    {
      error: 'This endpoint is deprecated. Use /api/support/create to create a donation with PayPal verification.',
      newEndpoints: {
        create: 'POST /api/support/create',
        capture: 'POST /api/support/capture',
        webhook: 'POST /api/support/webhook',
        status: 'GET /api/support/status',
        claimBonus: 'POST /api/support/claim-bonus',
      },
    },
    { status: 410 }
  )
}
