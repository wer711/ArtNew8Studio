import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { captureOrder } from '@/lib/paypal'

interface CaptureBody {
  orderId: string
  referenceId: string
}

export async function POST(request: NextRequest) {
  try {
    const body: CaptureBody = await request.json()

    if (!body.orderId) {
      return NextResponse.json(
        { error: 'PayPal Order ID is required.' },
        { status: 400 }
      )
    }

    if (!body.referenceId) {
      return NextResponse.json(
        { error: 'Reference ID is required.' },
        { status: 400 }
      )
    }

    // Find the pending submission
    const submission = await db.supportSubmission.findUnique({
      where: { id: body.referenceId },
    })

    if (!submission) {
      return NextResponse.json(
        { error: 'Donation record not found.' },
        { status: 404 }
      )
    }

    // Already fully captured?
    if (submission.paymentStatus === 'captured' && submission.verifiedAt) {
      return NextResponse.json({
        success: true,
        verified: true,
        amount: submission.amount,
        tier: submission.tier,
        bonusAttempts: submission.bonusAttempts,
        message: 'Payment already verified and bonus granted.',
      })
    }

    // Verify the PayPal Order ID matches
    if (submission.paypalOrderId && submission.paypalOrderId !== body.orderId) {
      return NextResponse.json(
        { error: 'Order ID mismatch. Possible fraud detected.' },
        { status: 403 }
      )
    }

    // Capture the order via PayPal API
    let captureResult
    try {
      captureResult = await captureOrder(body.orderId)
    } catch (err) {
      console.error('PayPal capture failed:', err)
      return NextResponse.json(
        { error: 'Payment verification failed. If you were charged, please contact us via WhatsApp with your receipt.', captureFailed: true },
        { status: 402 }
      )
    }

    if (!captureResult.captured) {
      // Payment not completed
      await db.supportSubmission.update({
        where: { id: body.referenceId },
        data: { paymentStatus: 'failed' },
      })

      return NextResponse.json(
        { error: 'Payment was not completed. Please try again.', captureFailed: true },
        { status: 402 }
      )
    }

    // Payment captured successfully!
    await db.supportSubmission.update({
      where: { id: body.referenceId },
      data: {
        paymentStatus: 'captured',
        paypalOrderId: body.orderId,
        paypalTransactionId: captureResult.transactionId || null,
        paypalPayerEmail: captureResult.payerEmail || null,
        verifiedAt: new Date(),
      },
    })

    // Send to Google Sheets if webhook URL is configured
    const GOOGLE_SHEETS_WEBHOOK_URL = process.env.GOOGLE_SHEETS_WEBHOOK_URL || ''
    if (GOOGLE_SHEETS_WEBHOOK_URL) {
      try {
        await fetch(GOOGLE_SHEETS_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: submission.name,
            email: submission.email,
            phone: submission.phone,
            amount: submission.amount,
            tier: submission.tier,
            message: submission.message,
            bonusAttempts: submission.bonusAttempts,
            paypalTransactionId: captureResult.transactionId,
            paypalOrderId: body.orderId,
            status: 'captured',
            source: 'paypal_sdk',
            createdAt: submission.createdAt.toISOString(),
            capturedAt: new Date().toISOString(),
          }),
        })
      } catch {
        // Continue — database is the primary storage
      }
    }

    return NextResponse.json({
      success: true,
      verified: true,
      amount: submission.amount,
      tier: submission.tier,
      bonusAttempts: submission.bonusAttempts,
      transactionId: captureResult.transactionId,
      message: 'Payment verified successfully! Your bonus has been granted.',
    })
  } catch (error) {
    console.error('Capture donation error:', error)
    return NextResponse.json(
      { error: 'Something went wrong during payment verification.' },
      { status: 500 }
    )
  }
}
