import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createOrder, isPayPalConfigured } from '@/lib/paypal'

// Calculate bonus attempts based on donation amount (tiered)
function calculateBonusAttempts(amount: number): number {
  if (amount >= 50) return 50
  if (amount >= 25) return 30
  if (amount >= 10) return 20
  if (amount >= 5) return 10
  if (amount >= 1) return 5
  return 0
}

// Get tier name based on donation amount
function getDonorTier(amount: number): string {
  if (amount >= 50) return 'champion'
  if (amount >= 25) return 'hero'
  if (amount >= 10) return 'supporter'
  if (amount >= 5) return 'friend'
  return 'seedling'
}

interface CreateDonationBody {
  name: string
  email: string
  phone?: string
  amount: number
  message?: string
}

export async function POST(request: NextRequest) {
  try {
    // Determine payment mode
    const hasApiCredentials = isPayPalConfigured()
    const businessEmail = process.env.PAYPAL_BUSINESS_EMAIL || ''
    const hasBusinessEmail = !!businessEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(businessEmail)

    if (!hasApiCredentials && !hasBusinessEmail) {
      return NextResponse.json(
        { error: 'PayPal is not configured. Please add either PAYPAL_BUSINESS_EMAIL or PAYPAL_CLIENT_ID+PAYPAL_CLIENT_SECRET to the .env file.', notConfigured: true },
        { status: 503 }
      )
    }

    const body: CreateDonationBody = await request.json()

    // Validate required fields
    if (!body.name?.trim()) {
      return NextResponse.json({ error: 'Name is required.' }, { status: 400 })
    }
    if (!body.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
      return NextResponse.json({ error: 'Valid email is required.' }, { status: 400 })
    }
    const amount = parseFloat(String(body.amount))
    if (isNaN(amount) || amount < 1) {
      return NextResponse.json({ error: 'Amount must be at least $1.' }, { status: 400 })
    }
    if (amount > 10000) {
      return NextResponse.json({ error: 'Amount cannot exceed $10,000.' }, { status: 400 })
    }

    const bonusAttempts = calculateBonusAttempts(amount)
    const tier = getDonorTier(amount)

    // Create pending donation in database
    const submission = await db.supportSubmission.create({
      data: {
        name: body.name.trim(),
        email: body.email.trim(),
        phone: body.phone?.trim() || null,
        amount,
        message: body.message?.trim() || null,
        tier,
        paymentStatus: 'pending',
        bonusAttempts,
      },
    })

    // ─── MODE 1: PayPal JS SDK (Client ID + Secret) ───
    if (hasApiCredentials) {
      try {
        const order = await createOrder({
          amount,
          referenceId: submission.id,
          name: body.name.trim(),
          email: body.email.trim(),
        })

        // Save the PayPal Order ID to the database
        await db.supportSubmission.update({
          where: { id: submission.id },
          data: { paypalOrderId: order.orderId },
        })

        return NextResponse.json({
          mode: 'paypal_sdk',
          orderId: order.orderId,
          referenceId: submission.id,
          amount,
          tier,
          bonusAttempts,
        })
      } catch (paypalError) {
        console.error('PayPal order creation failed:', paypalError)
        await db.supportSubmission.update({
          where: { id: submission.id },
          data: { paymentStatus: 'failed' },
        })

        return NextResponse.json(
          { error: paypalError instanceof Error ? paypalError.message : 'Failed to create PayPal order. Please try again.' },
          { status: 502 }
        )
      }
    }

    // ─── MODE 2: PayPal Standard Checkout (Business Email) ───
    // Return the info needed to construct the PayPal Standard form
    const isSandbox = process.env.PAYPAL_SANDBOX === 'true'
    const paypalBaseUrl = isSandbox
      ? 'https://www.sandbox.paypal.com/cgi-bin/webscr'
      : 'https://www.paypal.com/cgi-bin/webscr'

    // Build return URL (base URL of the site)
    const host = request.headers.get('host') || 'localhost:3000'
    const protocol = host.startsWith('localhost') ? 'http' : 'https'
    const baseUrl = `${protocol}://${host}`

    return NextResponse.json({
      mode: 'paypal_standard',
      referenceId: submission.id,
      amount,
      tier,
      bonusAttempts,
      // PayPal Standard form data
      paypalUrl: paypalBaseUrl,
      businessEmail,
      itemName: `ArtNew8 Studio Donation - ${body.name.trim()}`,
      customId: submission.id,
      returnUrl: `${baseUrl}/?donation=return&ref=${submission.id}`,
      cancelUrl: `${baseUrl}/?donation=cancel&ref=${submission.id}`,
      notifyUrl: `${baseUrl}/api/support/webhook`,
    })
  } catch (error) {
    console.error('Create donation error:', error)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again later.' },
      { status: 500 }
    )
  }
}
