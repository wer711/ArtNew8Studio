import { NextResponse } from 'next/server'
import { isPayPalConfigured, getPayPalClientId } from '@/lib/paypal'

/**
 * Check PayPal configuration status
 * Returns info about which payment methods are available
 */
export async function GET() {
  const hasApiCredentials = isPayPalConfigured()
  const clientId = hasApiCredentials ? getPayPalClientId() : ''
  const sandbox = process.env.PAYPAL_SANDBOX === 'true'

  const businessEmail = process.env.PAYPAL_BUSINESS_EMAIL || ''
  const hasBusinessEmail = !!businessEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(businessEmail)

  const hasPdtToken = !!process.env.PAYPAL_PDT_IDENTITY_TOKEN

  // Determine which payment mode to use
  let paymentMode: 'none' | 'standard' | 'sdk' = 'none'
  if (hasApiCredentials) {
    paymentMode = 'sdk' // Best: in-page popup with full verification
  } else if (hasBusinessEmail) {
    paymentMode = 'standard' // Good: new tab with return URL + PDT verification
  }

  return NextResponse.json({
    configured: paymentMode !== 'none',
    paymentMode,
    // SDK mode fields
    clientId, // Client ID is safe to expose publicly
    sandbox,
    // Standard mode fields
    businessEmail,
    hasPdtToken,
  })
}
