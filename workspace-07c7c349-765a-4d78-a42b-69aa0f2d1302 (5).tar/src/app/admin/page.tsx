'use client'

import { useState, useEffect } from 'react'
import {
  BarChart3,
  Users,
  DollarSign,
  Calendar,
  ArrowLeft,
  Activity,
  Eye,
  TrendingUp,
  Shield,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'

interface AnalyticsData {
  totalEvents: number
  todayEvents: number
  weekEvents: number
  monthEvents: number
  eventsByTool: { tool: string; count: number }[]
  eventsByAction: { action: string; count: number }[]
  recentEvents: {
    id: string
    tool: string
    action: string
    sessionId: string | null
    createdAt: string
  }[]
  dailyCounts: { date: string; count: number }[]
  totalSupporters: number
  totalDonationAmount: number
}

const ADMIN_PASSWORD = 'artnew8admin'
const TOOL_NAMES: Record<string, string> = {
  pricing: 'Pricing Calculator',
  tags: 'Tag Generator',
  profit: 'Profit Tracker',
  shipping: 'Shipping Estimator',
  colors: 'Color Palette',
}

const TOOL_COLORS: Record<string, string> = {
  pricing: 'bg-orange-500/10 text-orange-600',
  tags: 'bg-rose-500/10 text-rose-600',
  profit: 'bg-emerald-500/10 text-emerald-600',
  shipping: 'bg-sky-500/10 text-sky-600',
  colors: 'bg-violet-500/10 text-violet-600',
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState('')
  const [data, setData] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
    } else {
      setError('Incorrect password')
    }
  }

  useEffect(() => {
    if (isAuthenticated) {
      fetchData()
    }
  }, [isAuthenticated])

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/track')
      if (res.ok) {
        const json = await res.json()
        setData(json)
      }
    } catch (err) {
      console.error('Failed to fetch analytics:', err)
    } finally {
      setLoading(false)
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-sm">
          <CardHeader className="text-center">
            <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-2">
              <Shield className="size-6 text-primary" />
            </div>
            <CardTitle>Admin Access</CardTitle>
            <CardDescription>Enter the admin password to view analytics</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-3">
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                autoFocus
              />
              {error && <p className="text-xs text-destructive">{error}</p>}
              <Button type="submit" className="w-full">Access Dashboard</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (loading || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse text-muted-foreground">Loading analytics...</div>
      </div>
    )
  }

  const maxToolCount = Math.max(...data.eventsByTool.map(t => t.count), 1)
  const maxDailyCount = Math.max(...data.dailyCounts.map(d => d.count), 1)

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <BarChart3 className="size-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">artnew8 studio — Analytics</h1>
              <p className="text-xs text-muted-foreground">Private admin dashboard</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={fetchData} className="gap-1.5">
            <Activity className="size-3.5" />
            Refresh
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Card>
            <CardContent className="pt-4 pb-3">
              <div className="flex items-center gap-2 mb-1">
                <Eye className="size-4 text-primary" />
                <span className="text-xs text-muted-foreground">Total Events</span>
              </div>
              <p className="text-2xl font-bold">{data.totalEvents.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3">
              <div className="flex items-center gap-2 mb-1">
                <Calendar className="size-4 text-primary" />
                <span className="text-xs text-muted-foreground">Today</span>
              </div>
              <p className="text-2xl font-bold">{data.todayEvents.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3">
              <div className="flex items-center gap-2 mb-1">
                <Users className="size-4 text-primary" />
                <span className="text-xs text-muted-foreground">Supporters</span>
              </div>
              <p className="text-2xl font-bold">{data.totalSupporters.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3">
              <div className="flex items-center gap-2 mb-1">
                <DollarSign className="size-4 text-primary" />
                <span className="text-xs text-muted-foreground">Donations</span>
              </div>
              <p className="text-2xl font-bold">${data.totalDonationAmount.toLocaleString()}</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Most Used Tools */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="size-4 text-primary" />
                Most Used Tools
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {data.eventsByTool.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6">No tool usage data yet</p>
              ) : (
                data.eventsByTool.map(item => (
                  <div key={item.tool} className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className={TOOL_COLORS[item.tool] || ''}>
                          {TOOL_NAMES[item.tool] || item.tool}
                        </Badge>
                      </div>
                      <span className="text-sm font-semibold tabular-nums">{item.count}</span>
                    </div>
                    <div className="h-2 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full bg-primary/60 transition-all"
                        style={{ width: `${(item.count / maxToolCount) * 100}%` }}
                      />
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          {/* Daily Activity (last 30 days) */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Activity className="size-4 text-primary" />
                Daily Activity (30 days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {data.dailyCounts.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6">No daily data yet</p>
              ) : (
                <div className="flex items-end gap-1 h-32">
                  {data.dailyCounts.map(day => (
                    <div
                      key={day.date}
                      className="flex-1 bg-primary/40 rounded-t-sm hover:bg-primary/60 transition-colors relative group"
                      style={{ height: `${(day.count / maxDailyCount) * 100}%` }}
                      title={`${day.date}: ${day.count} events`}
                    >
                      <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-foreground text-background text-[9px] px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                        {day.count}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                {data.dailyCounts.length > 0 && (
                  <>
                    <span>{data.dailyCounts[0]?.date}</span>
                    <span>{data.dailyCounts[data.dailyCounts.length - 1]?.date}</span>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Breakdown */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Action Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {data.eventsByAction.map(item => (
                <Badge key={item.action} variant="secondary" className="py-1 px-2.5">
                  {item.action}: <span className="font-semibold ml-1">{item.count}</span>
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Events */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Recent Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-64 overflow-y-auto custom-scrollbar">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-xs text-muted-foreground">
                    <th className="pb-2 font-medium">Tool</th>
                    <th className="pb-2 font-medium">Action</th>
                    <th className="pb-2 font-medium">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {data.recentEvents.map(event => (
                    <tr key={event.id} className="border-b last:border-0">
                      <td className="py-1.5">
                        <Badge variant="secondary" className={`text-[10px] ${TOOL_COLORS[event.tool] || ''}`}>
                          {TOOL_NAMES[event.tool] || event.tool}
                        </Badge>
                      </td>
                      <td className="py-1.5 text-muted-foreground text-xs">{event.action}</td>
                      <td className="py-1.5 text-xs text-muted-foreground">
                        {new Date(event.createdAt).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
