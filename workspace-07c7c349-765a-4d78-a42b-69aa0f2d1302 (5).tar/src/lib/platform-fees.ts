// Platform fee data for pricing calculator and profit dashboard
export interface PlatformFee {
  name: string
  listingFee: number
  transactionFee: number // percentage
  paymentProcessing: number // percentage
  paymentFixed: number // fixed amount per transaction
  currency: string
  website: string
}

export const PLATFORMS: Record<string, PlatformFee> = {
  etsy: {
    name: 'Etsy',
    listingFee: 0.20,
    transactionFee: 6.5,
    paymentProcessing: 3.0,
    paymentFixed: 0.25,
    currency: 'USD',
    website: 'etsy.com',
  },
  amazon_handmade: {
    name: 'Amazon Handmade',
    listingFee: 0,
    transactionFee: 15.0,
    paymentProcessing: 2.9,
    paymentFixed: 0.30,
    currency: 'USD',
    website: 'amazon.com/handmade',
  },
  shopify: {
    name: 'Shopify',
    listingFee: 0,
    transactionFee: 2.0,
    paymentProcessing: 2.9,
    paymentFixed: 0.30,
    currency: 'USD',
    website: 'shopify.com',
  },
  ebay: {
    name: 'eBay',
    listingFee: 0.35,
    transactionFee: 13.25,
    paymentProcessing: 2.9,
    paymentFixed: 0.30,
    currency: 'USD',
    website: 'ebay.com',
  },
  gumroad: {
    name: 'Gumroad',
    listingFee: 0,
    transactionFee: 10.0,
    paymentProcessing: 2.9,
    paymentFixed: 0.30,
    currency: 'USD',
    website: 'gumroad.com',
  },
}

export const CURRENCIES = [
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
] as const

export function calculatePlatformFees(platform: PlatformFee, price: number): {
  listingFee: number
  transactionFee: number
  paymentProcessing: number
  totalFees: number
  netProfit: number
} {
  const listingFee = platform.listingFee
  const transactionFee = (price * platform.transactionFee) / 100
  const paymentProcessing = (price * platform.paymentProcessing) / 100 + platform.paymentFixed
  const totalFees = listingFee + transactionFee + paymentProcessing
  const netProfit = price - totalFees

  return { listingFee, transactionFee, paymentProcessing, totalFees, netProfit }
}
