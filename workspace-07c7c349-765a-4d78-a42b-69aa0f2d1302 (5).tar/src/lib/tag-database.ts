// Tag and keyword database for craft products
// Organized by categories for the Tag Generator tool
// V2 - Expanded with competition scores, platform data, and more categories

export interface TagCategory {
  id: string
  name: string
  icon: string
  tags: string[]
  description?: string
}

export interface TagMeta {
  competition: 'low' | 'medium' | 'high'
  volume: 'low' | 'medium' | 'high'
  platforms: ('etsy' | 'amazon' | 'shopify')[]
}

// Algorithmic competition/volume estimation based on tag characteristics
export function estimateTagMeta(tag: string): TagMeta {
  const words = tag.trim().split(/\s+/)
  const wordCount = words.length
  const charLen = tag.trim().length

  // Multi-word, specific tags = low competition, high value
  // Single generic words = high competition, medium volume
  let competition: TagMeta['competition']
  let volume: TagMeta['volume']

  if (wordCount >= 3) {
    competition = 'low'
    volume = 'medium'
  } else if (wordCount === 2 && charLen >= 10) {
    competition = 'low'
    volume = 'high'
  } else if (wordCount === 2) {
    competition = 'medium'
    volume = 'high'
  } else if (charLen >= 8) {
    competition = 'medium'
    volume = 'medium'
  } else {
    competition = 'high'
    volume = 'low'
  }

  // Seasonal and trending tags get volume boost
  const trendingWords = ['2025', 'gift', 'wedding', 'christmas', 'birthday', 'valentine', 'mother', 'baby']
  const tagLower = tag.toLowerCase()
  if (trendingWords.some(w => tagLower.includes(w))) {
    volume = 'high'
  }

  // Platform relevance
  const platforms: TagMeta['platforms'] = ['etsy']
  if (tagLower.includes('handmade') || tagLower.includes('craft') || tagLower.includes('artisan')) {
    platforms.push('shopify')
  }
  if (wordCount <= 2 || tagLower.includes('gift') || tagLower.includes('decor')) {
    platforms.push('amazon')
  }

  return { competition, volume, platforms }
}

export const TAG_CATEGORIES: TagCategory[] = [
  {
    id: 'product-type',
    name: 'Product Type',
    icon: '📦',
    description: 'What type of product are you selling?',
    tags: [
      // Cards
      'handmade card', 'greeting card', 'pop up card', 'paper flower card',
      '3d card', 'birthday card', 'wedding card', 'anniversary card',
      'valentine card', 'mother day card', 'father day card', 'christmas card',
      'thank you card', 'sympathy card', 'congratulations card', 'new baby card',
      'engagement card', 'retirement card', 'graduation card', 'get well card',
      // Paper crafts
      'paper flowers', 'paper bouquet', 'paper rose', 'paper peony',
      'paper sunflower', 'paper tulip', 'paper daisy', 'paper lavender',
      'paper wreath', 'paper centerpiece', 'paper corsage', 'paper boutonniere',
      'origami', 'quilling', 'paper cutting', 'paper craft',
      'paper sculpture', 'paper art', 'paper decoration', 'paper ornament',
      // Jewelry
      'handmade jewelry', 'beaded jewelry', 'wire jewelry', 'resin jewelry',
      'polymer clay jewelry', 'metal jewelry', 'silver jewelry', 'gold jewelry',
      'necklace', 'bracelet', 'earrings', 'ring',
      'pendant', 'brooch', 'anklet', 'charm',
      // Candles & Soap
      'soy candle', 'beeswax candle', 'handmade candle', 'aromatherapy candle',
      'scented candle', 'pillar candle', 'votive candle', 'tealight',
      'handmade soap', 'organic soap', 'bath bomb', 'butter soap',
      // Textile & Fiber
      'knitted scarf', 'crochet hat', 'handwoven', 'macrame',
      'embroidery', 'cross stitch', 'needlepoint', 'tufting',
      'felt craft', 'wool craft', 'yarn craft', 'fiber art',
      // Home Decor
      'wall art', 'wall hanging', 'dream catcher', 'mirror frame',
      'decorative pillow', 'table runner', 'coaster set', 'plant pot',
      'vase', 'picture frame', 'shelf decor', 'door wreath',
      // Pottery & Ceramic
      'handmade pottery', 'ceramic mug', 'clay art', 'stoneware',
      'glazed pottery', 'hand thrown', 'raku', 'terracotta pot',
      // Wood & Leather
      'wooden craft', 'carved wood', 'wood burning', 'laser cut',
      'handmade leather', 'leather wallet', 'leather bag', 'leather journal',
      // Bath & Beauty
      'lip balm', 'body scrub', 'bath salt', 'lotion bar',
      'solid perfume', 'hair accessory', 'hair clip', 'scrunchie',
      // Prints & Digital
      'art print', 'digital download', 'printable art', 'watercolor print',
      'illustration', 'photography print', 'canvas print', 'poster',
    ],
  },
  {
    id: 'occasion',
    name: 'Occasion',
    icon: '🎉',
    description: 'What occasion is this product for?',
    tags: [
      'birthday', 'wedding', 'anniversary', 'valentine day',
      'mother day', 'father day', 'christmas', 'new year',
      'halloween', 'thanksgiving', 'easter', 'spring',
      'summer', 'autumn', 'winter', 'baby shower',
      'bridal shower', 'engagement', 'retirement', 'graduation',
      'housewarming', 'get well', 'sympathy', 'just because',
      'love', 'friendship', 'thank you', 'congratulations',
      'new home', 'new job', 'prom', 'quinceanera',
      'back to school', 'teacher appreciation', 'first day', 'gender reveal',
      'sweet 16', 'bar mitzvah', 'bat mitzvah', 'confirmation',
    ],
  },
  {
    id: 'material',
    name: 'Material & Style',
    icon: '✂️',
    description: 'What materials and style does your product feature?',
    tags: [
      'handmade', 'handcrafted', 'paper', 'cardstock',
      'crepe paper', 'tissue paper', 'kraft paper', 'recycled paper',
      'glitter', 'foil', 'lace', 'ribbon',
      'dried flowers', 'pressed flowers', 'pearl', 'rhinestone',
      'minimalist', 'vintage', 'rustic', 'boho',
      'elegant', 'luxury', 'modern', 'romantic',
      'whimsical', 'colorful', 'pastel', 'neutral',
      'eco friendly', 'sustainable', 'biodegradable', 'organic',
      'gemstone', 'crystal', 'sea glass', 'driftwood',
      'cotton', 'linen', 'silk', 'velvet',
      'copper', 'brass', 'sterling silver', 'gold plated',
      'acrylic', 'resin', 'epoxy', 'polymer clay',
    ],
  },
  {
    id: 'technique',
    name: 'Technique',
    icon: '🎨',
    description: 'What crafting technique is used?',
    tags: [
      'paper quilling', 'origami', 'paper cutting', 'paper folding',
      'die cutting', 'embossing', 'layering', '3d paper craft',
      'paper sculpting', 'decoupage', 'paper piecing', 'iris folding',
      'tea bag folding', 'paper tole', 'kirigami', 'papercraft',
      'hand cut', 'hand folded', 'hand glued', 'hand painted',
      'watercolor', 'calligraphy', 'letterpress', 'stamp',
      'pop up mechanism', 'paper engineering', 'paper mosaic', 'paper punching',
      'wire wrapping', 'metal stamping', 'lost wax casting', 'enamel',
      'wheel throwing', 'slab building', 'coil pottery', 'glazing',
      'macrame knot', 'crochet', 'knitting', 'weaving',
      'embroidery stitch', 'applique', 'screen printing', 'block printing',
      'wood carving', 'pyrography', 'leather tooling', 'bookbinding',
    ],
  },
  {
    id: 'recipient',
    name: 'Recipient',
    icon: '💝',
    description: 'Who is this product for?',
    tags: [
      'for her', 'for him', 'for mom', 'for dad',
      'for wife', 'for husband', 'for girlfriend', 'for boyfriend',
      'for sister', 'for brother', 'for friend', 'for teacher',
      'for grandma', 'for grandpa', 'for daughter', 'for son',
      'for bride', 'for groom', 'for couple', 'for baby',
      'for coworker', 'for boss', 'for neighbor', 'for hostess',
      'for women', 'for men', 'for kids', 'for teen',
      'for pet', 'for cat lover', 'for dog lover', 'for plant lover',
      'for book lover', 'for coffee lover', 'for music lover', 'for artist',
      'for nurse', 'for doctor', 'for student', 'for new mom',
    ],
  },
  {
    id: 'color',
    name: 'Color Theme',
    icon: '🌸',
    description: 'What color theme does your product feature?',
    tags: [
      'pink', 'rose gold', 'blush', 'red',
      'burgundy', 'gold', 'silver', 'white',
      'ivory', 'cream', 'black', 'navy',
      'blue', 'teal', 'green', 'sage green',
      'purple', 'lavender', 'peach', 'coral',
      'yellow', 'orange', 'multi color', 'ombre',
      'pastel', 'rainbow', 'metallic', 'monochrome',
      'earth tone', 'terracotta', 'dusty rose', 'muted',
      'neon', 'iridescent', 'holographic', 'transparent',
      'wood tone', 'natural', 'boho color', 'jewel tone',
    ],
  },
  {
    id: 'trending',
    name: 'Trending 2025',
    icon: '🔥',
    description: 'Currently trending keywords for maximum visibility',
    tags: [
      'cottagecore', 'cottage core', 'dark academia', 'cottage aesthetic',
      'grandmacore', 'flower craft', 'paper flower wall', 'diy decor',
      'sustainable gift', 'eco gift', 'personalized gift', 'custom card',
      'gift for craft lover', 'craft kit', 'diy kit', 'craft supply',
      'paper flower template', 'card making kit', 'craft tutorial', 'paper art gift',
      'aesthetic gift', 'instagram worthy', 'tiktok trend', 'viral gift',
      'unique gift', 'one of a kind', 'small business', 'shop small',
      'maker gift', 'artisan made', 'slow made', 'conscious gift',
      'quiet luxury', 'old money aesthetic', 'coastal grandmother', 'dopamine decor',
      'mushroom decor', 'botanical', 'cottage garden', 'whimsical decor',
      'y2k aesthetic', 'retro revival', 'maximalist', 'minimalist living',
    ],
  },
  {
    id: 'use-case',
    name: 'Use & Setting',
    icon: '🏠',
    description: 'Where and how will this product be used?',
    tags: [
      'home decor', 'wall decor', 'table decor', 'shelf decor',
      'kitchen decor', 'bathroom decor', 'bedroom decor', 'nursery decor',
      'office decor', 'patio decor', 'garden decor', 'entryway decor',
      'wedding decor', 'party decor', 'event decor', 'photo prop',
      'daily use', 'special occasion', 'seasonal decor', 'holiday decor',
      'outdoor', 'indoor', 'travel', 'work from home',
      'self care', 'wellness', 'meditation', 'relaxation',
      'organization', 'storage', 'display', 'collection',
    ],
  },
  {
    id: 'price-point',
    name: 'Value & Gifting',
    icon: '💎',
    description: 'Price positioning and gift-worthiness',
    tags: [
      'budget friendly', 'affordable gift', 'stocking stuffer', 'under 25',
      'under 50', 'luxury gift', 'premium', 'high end',
      'gift set', 'gift box', 'gift basket', 'care package',
      'gift for under 10', 'best seller', 'bestseller', 'top rated',
      '5 star review', 'customer favorite', 'repeat buyer', 'loyalty reward',
    ],
  },
]

// Seasonal tags that rotate based on current month
export function getSeasonalTags(): TagCategory {
  const month = new Date().getMonth() // 0-11

  const seasonalMap: Record<number, { name: string; tags: string[] }> = {
    0: { name: 'Winter / New Year', tags: ['new year card', 'winter wonderland', 'snowflake', 'new year wishes', 'resolution', 'fresh start', 'cozy winter', 'winter decor', 'snowman', 'ice crystal'] },
    1: { name: "Valentine's Season", tags: ['valentine card', 'love card', 'heart card', 'rose card', 'galentine', 'love letter', 'xoxo', 'be mine', 'couple gift', 'date night'] },
    2: { name: "Spring / Mother's Day Prep", tags: ['spring card', 'mother day card', 'floral card', 'spring flowers', 'mom card', 'best mom', 'mama card', 'spring bouquet', 'garden party', 'spring decor'] },
    3: { name: 'Easter / Spring', tags: ['easter card', 'spring celebration', 'bunny card', 'egg card', 'pastel card', 'spring garden', 'rebirth', 'new beginnings', 'easter basket', 'spring craft'] },
    4: { name: "Wedding Season Start / Father's Day Prep", tags: ['wedding card', 'father day card', 'dad card', 'groom card', 'bride card', 'wedding wishes', 'best dad', 'father figure', 'wedding season', 'outdoor wedding'] },
    5: { name: 'Summer / Graduation', tags: ['summer card', 'graduation card', 'grad card', 'class of 2025', 'summer flowers', 'beach theme', 'tropical', 'sunshine card', 'pool party', 'summer vibe'] },
    6: { name: 'Summer Vibes', tags: ['summer party', 'pool party', 'bbq invite', 'summer birthday', 'tropical card', 'vacation', 'sunshine wishes', 'ice cream', 'beach day', 'surf theme'] },
    7: { name: 'Back to School', tags: ['back to school', 'teacher card', 'student card', 'good luck card', 'school supplies', 'study card', 'autumn preview', 'apple card', 'teacher gift', 'dorm decor'] },
    8: { name: 'Autumn / Fall', tags: ['autumn card', 'fall card', 'thanksgiving', 'harvest', 'pumpkin card', 'fall leaves', 'grateful', 'fall wreath', 'cozy autumn', 'harvest moon'] },
    9: { name: 'Halloween Season', tags: ['halloween card', 'spooky card', 'pumpkin', 'ghost card', 'trick or treat', 'boo card', 'haunted', 'witch card', 'halloween decor', 'costume party'] },
    10: { name: 'Holiday Prep', tags: ['christmas card', 'holiday card', 'advent calendar', 'xmas card', 'festive', 'winter holiday', 'season greeting', 'noel', 'holiday prep', 'gift wrapping'] },
    11: { name: 'Christmas / Year End', tags: ['merry christmas', 'happy holiday', 'new year card', 'year in review', 'festive card', 'holiday wishes', 'peace on earth', 'joy card', 'christmas gift', 'year end'] },
  }

  const current = seasonalMap[month] || seasonalMap[0]
  return {
    id: 'seasonal',
    name: `🕐 ${current.name}`,
    icon: '🕐',
    description: 'Tags trending this season',
    tags: current.tags,
  }
}

// Etsy max tags
export const ETSY_MAX_TAGS = 13

// Amazon max keywords
export const AMAZON_MAX_KEYWORDS = 250

// Etsy title max chars
export const ETSY_TITLE_MAX_CHARS = 140

// Get all unique tags across all categories
export function getAllTags(): string[] {
  const seasonal = getSeasonalTags()
  const allCategories = [...TAG_CATEGORIES, seasonal]
  return [...new Set(allCategories.flatMap(c => c.tags))]
}
