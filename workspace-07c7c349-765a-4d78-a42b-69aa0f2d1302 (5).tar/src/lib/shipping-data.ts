// Shipping cost estimation data
export interface ShippingZone {
  name: string
  regions: string[]
}

export interface ShippingRate {
  category: string
  weightMax: number // grams
  us: number
  uk: number
  eu: number
  ca: number
  au: number
}

export const SHIPPING_ZONES: ShippingZone[] = [
  { name: 'United States', regions: ['US'] },
  { name: 'United Kingdom', regions: ['UK'] },
  { name: 'European Union', regions: ['EU'] },
  { name: 'Canada', regions: ['CA'] },
  { name: 'Australia', regions: ['AU'] },
]

// Approximate international shipping rates for small craft items (in USD)
export const SHIPPING_RATES: ShippingRate[] = [
  { category: 'Letter/Flat', weightMax: 100, us: 1.50, uk: 3.50, eu: 4.00, ca: 2.50, au: 4.50 },
  { category: 'Small Package', weightMax: 250, us: 4.50, uk: 8.00, eu: 9.00, ca: 6.00, au: 10.00 },
  { category: 'Medium Package', weightMax: 500, us: 7.00, uk: 12.00, eu: 14.00, ca: 9.00, au: 15.00 },
  { category: 'Large Package', weightMax: 1000, us: 12.00, uk: 18.00, eu: 22.00, ca: 15.00, au: 22.00 },
  { category: 'Extra Large', weightMax: 2000, us: 18.00, uk: 28.00, eu: 32.00, ca: 22.00, au: 35.00 },
]

// Domestic shipping rates (from US)
export const DOMESTIC_RATES = {
  us: [
    { category: 'Letter/Flat', weightMax: 100, rate: 0.73 },
    { category: 'Small Package', weightMax: 250, rate: 3.50 },
    { category: 'Medium Package', weightMax: 500, rate: 5.00 },
    { category: 'Large Package', weightMax: 1000, rate: 7.50 },
    { category: 'Extra Large', weightMax: 2000, rate: 10.00 },
  ],
}

// Common package sizes for handmade cards
export const PACKAGE_SIZES = [
  { name: 'A2 Card (4.25"×5.5")', weight: 30, category: 'Letter/Flat' },
  { name: 'A7 Card (5"×7")', weight: 40, category: 'Letter/Flat' },
  { name: '5"×7" with Envelope', weight: 50, category: 'Small Package' },
  { name: 'Pop-up Card Box', weight: 120, category: 'Small Package' },
  { name: 'Card Set (5 cards)', weight: 200, category: 'Small Package' },
  { name: 'Paper Flower Bouquet', weight: 350, category: 'Medium Package' },
  { name: 'Large Gift Box', weight: 600, category: 'Large Package' },
  { name: 'Wedding Suite Set', weight: 1000, category: 'Large Package' },
]

// Customs tips by region
export const CUSTOMS_TIPS: Record<string, string[]> = {
  US: [
    'Items under $800 generally enter duty-free',
    'Mark as "Handmade greeting card" on customs form',
    'Use HS code 4817.30 for greeting cards',
  ],
  UK: [
    'Items under £135 are VAT-free for gifts',
    'Mark as "Handmade paper goods"',
    'Include commercial invoice for items over £135',
  ],
  EU: [
    'Items under €150 are generally duty-free',
    'VAT may apply depending on destination country',
    'Mark as "Handmade paper craft" on customs form',
  ],
  CA: [
    'Items under CAD $20 are duty and tax-free',
    'Gifts under CAD $60 are duty-free',
    'Mark as "Handmade greeting card"',
  ],
  AU: [
    'Items under AUD $1000 are duty-free',
    'GST may apply for commercial items',
    'Mark as "Handmade paper goods"',
  ],
}
