/**
 * AI Service — z-ai-web-dev-sdk (primary) + OpenAI (optional fallback)
 * 
 * Uses z-ai-web-dev-sdk as the primary AI provider since it requires
 * no API key configuration and works in all environments.
 * 
 * If an OpenAI API key is configured (OPENAI_API_KEY or
 * OPENAI_API_KEY_ENCRYPTED in .env.local), OpenAI can be used as
 * a fallback or alternative provider.
 */

import crypto from 'crypto'

// ─── Check if OpenAI key is available ──────────────────────
function hasOpenAIKey(): boolean {
  return !!(process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENCRYPTED)
}

// ─── Decrypt API Key ────────────────────────────────────────
function getDecryptedApiKey(): string | null {
  // If plain key is available (simpler setup), use it directly
  if (process.env.OPENAI_API_KEY) {
    return process.env.OPENAI_API_KEY
  }

  // Otherwise, decrypt the encrypted key from .env.local
  const encryptedKey = process.env.OPENAI_API_KEY_ENCRYPTED
  const ivHex = process.env.OPENAI_API_KEY_IV

  if (!encryptedKey || !ivHex) {
    return null
  }

  try {
    const secret = 'artnew8-enc-2025-key'
    const key = Buffer.from(secret.padEnd(32).slice(0, 32))
    const iv = Buffer.from(ivHex, 'hex')
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv)
    let decrypted = decipher.update(encryptedKey, 'hex', 'utf8')
    decrypted += decipher.final('utf8')
    return decrypted
  } catch (error) {
    console.error('Failed to decrypt API key:', error)
    return null
  }
}

// ─── z-ai-web-dev-sdk Client (primary) ─────────────────────
let _zaiClient: Awaited<ReturnType<typeof import('z-ai-web-dev-sdk').default['create']>> | null = null

async function getZAIClient() {
  if (_zaiClient) return _zaiClient
  try {
    const ZAI = (await import('z-ai-web-dev-sdk')).default
    _zaiClient = await ZAI.create()
    return _zaiClient
  } catch (error) {
    console.error('Failed to initialize z-ai-web-dev-sdk:', error)
    return null
  }
}

// ─── OpenAI Client (optional fallback) ─────────────────────
let _openaiClient: InstanceType<typeof import('openai').default> | null = null
let _openaiAvailable: boolean | null = null

async function getOpenAIClient() {
  if (_openaiClient) return _openaiClient

  const apiKey = getDecryptedApiKey()
  if (!apiKey) return null

  try {
    const OpenAI = (await import('openai')).default
    const options: ConstructorParameters<typeof OpenAI>[0] = { apiKey }
    if (process.env.OPENAI_BASE_URL) {
      options.baseURL = process.env.OPENAI_BASE_URL
    }
    _openaiClient = new OpenAI(options)
    return _openaiClient
  } catch (error) {
    console.error('Failed to initialize OpenAI client:', error)
    return null
  }
}

// ─── Chat Completion Helper (z-ai primary, OpenAI fallback) ─
export async function chatCompletion(options: {
  systemPrompt: string
  userMessage: string
  model?: string
  maxTokens?: number
  temperature?: number
}): Promise<string> {
  // Try z-ai-web-dev-sdk first (no API key needed)
  const zai = await getZAIClient()
  if (zai) {
    try {
      const completion = await zai.chat.completions.create({
        model: options.model || 'glm-4-flash',
        messages: [
          { role: 'system', content: options.systemPrompt },
          { role: 'user', content: options.userMessage },
        ],
        thinking: { type: 'disabled' },
      })
      return completion.choices?.[0]?.message?.content || ''
    } catch (error) {
      console.error('z-ai-web-dev-sdk chat completion failed:', error)
      // Fall through to OpenAI if available
    }
  }

  // Fallback: OpenAI (only if API key is configured)
  if (_openaiAvailable !== false && hasOpenAIKey()) {
    try {
      const client = await getOpenAIClient()
      if (client) {
        const completion = await client.chat.completions.create({
          model: options.model || 'gpt-4o-mini',
          max_tokens: options.maxTokens || 1000,
          temperature: options.temperature || 0.7,
          messages: [
            { role: 'system', content: options.systemPrompt },
            { role: 'user', content: options.userMessage },
          ],
        })
        _openaiAvailable = true
        return completion.choices?.[0]?.message?.content || ''
      }
    } catch (error: unknown) {
      const apiError = error as { status?: number; type?: string; code?: string }
      if (
        apiError.status === 403 ||
        apiError.code === 'unsupported_country_region_territory' ||
        apiError.type === 'request_forbidden'
      ) {
        console.log('OpenAI API blocked, disabling OpenAI fallback')
        _openaiAvailable = false
      } else {
        throw error
      }
    }
  }

  throw new Error('AI service unavailable. Both z-ai-web-dev-sdk and OpenAI failed. Please try again later.')
}

// ─── Image Generation Helper (z-ai primary, OpenAI fallback) ─
export async function generateImage(options: {
  prompt: string
  size?: '1024x1024' | '512x512' | '256x256'
  model?: string
}): Promise<string | null> {
  // Try z-ai-web-dev-sdk first
  const zai = await getZAIClient()
  if (zai) {
    try {
      const response = await zai.images.generations.create({
        prompt: options.prompt,
        size: options.size || '1024x1024',
      })
      return response.data?.[0]?.base64 || null
    } catch (error) {
      console.error('z-ai-web-dev-sdk image generation failed:', error)
      // Fall through to OpenAI if available
    }
  }

  // Fallback: OpenAI (only if API key is configured)
  if (_openaiAvailable !== false && hasOpenAIKey()) {
    try {
      const client = await getOpenAIClient()
      if (client) {
        const response = await client.images.generate({
          model: options.model || 'dall-e-3',
          prompt: options.prompt,
          size: options.size || '1024x1024',
          n: 1,
          response_format: 'b64_json',
        })
        _openaiAvailable = true
        return response.data?.[0]?.b64_json || null
      }
    } catch (error: unknown) {
      const apiError = error as { status?: number; code?: string; type?: string }
      if (
        apiError.status === 403 ||
        apiError.code === 'unsupported_country_region_territory' ||
        apiError.type === 'request_forbidden'
      ) {
        console.log('OpenAI API blocked, disabling OpenAI fallback')
        _openaiAvailable = false
      } else {
        throw error
      }
    }
  }

  throw new Error('Image generation unavailable. Both z-ai-web-dev-sdk and OpenAI failed.')
}

// ─── JSON Chat Completion (for structured responses) ────────
export async function chatCompletionJSON<T>(options: {
  systemPrompt: string
  userMessage: string
  model?: string
  maxTokens?: number
  temperature?: number
}): Promise<T | null> {
  const content = await chatCompletion(options)
  try {
    const jsonMatch = content.match(/\{[\s\S]*\}|\[[\s\S]*\]/)
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]) as T
    }
  } catch {
    // JSON parse failed
  }
  return null
}
