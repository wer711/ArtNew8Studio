/**
 * WhatsApp integration utilities
 * Handles generating WhatsApp links and sending form data
 */

const WHATSAPP_NUMBER = '213696212465'

/**
 * Generate a WhatsApp chat link with pre-filled message
 */
export function getWhatsAppLink(message: string): string {
  const encoded = encodeURIComponent(message)
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encoded}`
}

/**
 * Generate message for Tool Customization request
 */
export function generateCustomToolMessage(data: {
  name: string
  email: string
  phone: string
  toolName: string
  projectDescription: string
  specificNeeds: string
  budget: string
  timeline: string
}): string {
  return `🛠️ *Tool Customization Request — artnew8 studio*

👤 Name: ${data.name}
📧 Email: ${data.email}
📱 Phone: ${data.phone || 'N/A'}

🔧 Tool to Customize: ${data.toolName}
📋 Project Description: ${data.projectDescription}
🎯 Specific Needs: ${data.specificNeeds}
💰 Budget: ${data.budget || 'To discuss'}
⏰ Timeline: ${data.timeline || 'Flexible'}

---
Sent from artnew8 studio`
}

/**
 * Generate message for Unlimited Access request
 */
export function generateUnlimitedAccessMessage(data: {
  name: string
  email: string
  phone: string
  usageReason: string
  toolsUsed: string[]
  expectedVolume: string
}): string {
  return `♾️ *Unlimited Access Request — artnew8 studio*

👤 Name: ${data.name}
📧 Email: ${data.email}
📱 Phone: ${data.phone || 'N/A'}

📝 Why Unlimited: ${data.usageReason}
🧰 Tools Needed: ${data.toolsUsed.join(', ')}
📊 Expected Volume: ${data.expectedVolume}

---
Sent from artnew8 studio`
}

/**
 * Open WhatsApp with pre-filled message
 */
export function openWhatsApp(message: string): void {
  const link = getWhatsAppLink(message)
  window.open(link, '_blank', 'noopener,noreferrer')
}
