/**
 * PayPal Orders API Integration
 *
 * Uses PayPal REST API v2 to create and capture orders.
 * Requires PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET in .env
 *
 * Flow:
 * 1. Create Order → returns orderID
 * 2. User approves payment in PayPal popup
 * 3. Capture Order → verifies and completes payment
 */

const PAYPAL_API_BASE = process.env.PAYPAL_SANDBOX === 'true'
  ? 'https://api-m.sandbox.paypal.com'
  : 'https://api-m.paypal.com'

// Cache the access token
let cachedToken: { token: string; expiresAt: number } | null = null

/**
 * Get PayPal Access Token using Client Credentials
 */
async function getAccessToken(): Promise<string> {
  const clientId = process.env.PAYPAL_CLIENT_ID
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET

  if (!clientId || !clientSecret) {
    throw new Error('PayPal credentials not configured. Please set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET in .env')
  }

  // Use cached token if still valid (with 30s buffer)
  if (cachedToken && cachedToken.expiresAt > Date.now() + 30_000) {
    return cachedToken.token
  }

  const auth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64')

  const response = await fetch(`${PAYPAL_API_BASE}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  })

  if (!response.ok) {
    const errorText = await response.text()
    console.error('PayPal auth error:', errorText)
    throw new Error('Failed to authenticate with PayPal. Check your credentials.')
  }

  const data = await response.json()
  cachedToken = {
    token: data.access_token,
    expiresAt: Date.now() + (data.expires_in * 1000),
  }

  return data.access_token
}

/**
 * Check if PayPal is configured
 */
export function isPayPalConfigured(): boolean {
  return !!(process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET)
}

/**
 * Get the PayPal Client ID for frontend SDK
 */
export function getPayPalClientId(): string {
  return process.env.PAYPAL_CLIENT_ID || ''
}

/**
 * Create a PayPal Order
 * @returns Order ID from PayPal
 */
export async function createOrder(options: {
  amount: number
  referenceId: string
  name: string
  email: string
}): Promise<{ orderId: string; status: string }> {
  const accessToken = await getAccessToken()

  const orderPayload = {
    intent: 'CAPTURE',
    purchase_units: [
      {
        reference_id: options.referenceId,
        custom_id: options.referenceId,
        description: `ArtNew8 Studio Donation - ${options.name}`,
        amount: {
          currency_code: 'USD',
          value: options.amount.toFixed(2),
        },
        payee: {
          email_address: undefined as string | undefined,
        },
      },
    ],
    application_context: {
      brand_name: 'ArtNew8 Studio',
      landing_page: 'DONATION' as const,
      shipping_preference: 'NO_SHIPPING' as const,
      user_action: 'PAY_NOW' as const,
      // Return URL is handled by the PayPal JS SDK on the client side
    },
  }

  // Remove undefined payee
  delete orderPayload.purchase_units[0].payee

  const response = await fetch(`${PAYPAL_API_BASE}/v2/checkout/orders`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      'PayPal-Request-Id': `artnew8-${options.referenceId}-${Date.now()}`,
    },
    body: JSON.stringify(orderPayload),
  })

  if (!response.ok) {
    const errorText = await response.text()
    console.error('PayPal create order error:', errorText)
    throw new Error('Failed to create PayPal order. Please try again.')
  }

  const data = await response.json()
  return {
    orderId: data.id,
    status: data.status,
  }
}

/**
 * Capture a PayPal Order (complete the payment)
 * @returns Capture result with payment details
 */
export async function captureOrder(orderId: string): Promise<{
  captured: boolean
  transactionId?: string
  payerEmail?: string
  amount?: number
  currency?: string
  status: string
}> {
  const accessToken = await getAccessToken()

  const response = await fetch(`${PAYPAL_API_BASE}/v2/checkout/orders/${orderId}/capture`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
  })

  if (!response.ok) {
    const errorText = await response.text()
    console.error('PayPal capture order error:', errorText)

    // If order already captured, try to get its details
    if (errorText.includes('ORDER_ALREADY_CAPTURED')) {
      return {
        captured: true,
        status: 'already_captured',
      }
    }

    throw new Error('Failed to capture PayPal payment.')
  }

  const data = await response.json()
  const purchaseUnit = data.purchase_units?.[0]
  const capture = purchaseUnit?.payments?.captures?.[0]

  return {
    captured: capture?.status === 'COMPLETED',
    transactionId: capture?.id,
    payerEmail: data.payer?.email_address,
    amount: parseFloat(capture?.amount?.value || '0'),
    currency: capture?.amount?.currency_code || 'USD',
    status: data.status,
  }
}

/**
 * Get details of a PayPal Order
 */
export async function getOrderDetails(orderId: string): Promise<{
  status: string
  amount?: number
  customId?: string
}> {
  const accessToken = await getAccessToken()

  const response = await fetch(`${PAYPAL_API_BASE}/v2/checkout/orders/${orderId}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
    },
  })

  if (!response.ok) {
    throw new Error('Failed to get PayPal order details.')
  }

  const data = await response.json()
  const purchaseUnit = data.purchase_units?.[0]

  return {
    status: data.status,
    amount: parseFloat(purchaseUnit?.amount?.value || '0'),
    customId: purchaseUnit?.custom_id,
  }
}
