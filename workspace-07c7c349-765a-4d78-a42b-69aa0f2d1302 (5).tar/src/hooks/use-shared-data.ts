'use client'

import { create } from 'zustand'

/**
 * Shared data store for inter-tool communication
 * 
 * When a user calculates pricing, the data flows to:
 * - Tag Generator (suggested tags based on product type/materials)
 * - Shipping Estimator (weight from materials)
 * - Color Palette (theme from product category)
 * 
 * When a user generates tags:
 * - Pricing Calculator (product name for template naming)
 * 
 * When a user estimates shipping:
 * - Pricing Calculator (add shipping to overhead)
 */

export interface SharedProductData {
  // From Pricing Calculator
  productName?: string
  materials?: { name: string; cost: number; qty: number }[]
  totalCost?: number
  sellingPrice?: number
  currency?: string
  profitMargin?: number
  hoursSpent?: number
  hourlyRate?: number
  
  // From Tag Generator
  tags?: string[]
  productDescription?: string
  
  // From Shipping Estimator
  shippingCost?: number
  destinationZone?: string
  packageWeight?: number
  
  // From Color Palette
  paletteColors?: string[]
  paletteName?: string
}

interface SharedDataState {
  data: SharedProductData
  lastUpdatedBy: string | null
  
  // Actions
  updateFromPricing: (data: {
    productName?: string
    materials?: { name: string; cost: number; qty: number }[]
    totalCost?: number
    sellingPrice?: number
    currency?: string
    profitMargin?: number
    hoursSpent?: number
    hourlyRate?: number
  }) => void
  
  updateFromTags: (data: {
    tags?: string[]
    productDescription?: string
    productName?: string
  }) => void
  
  updateFromShipping: (data: {
    shippingCost?: number
    destinationZone?: string
    packageWeight?: number
  }) => void
  
  updateFromColors: (data: {
    paletteColors?: string[]
    paletteName?: string
  }) => void
  
  clearSharedData: () => void
}

export const useSharedData = create<SharedDataState>((set) => ({
  data: {},
  lastUpdatedBy: null,
  
  updateFromPricing: (pricingData) => {
    set((state) => ({
      lastUpdatedBy: 'pricing',
      data: {
        ...state.data,
        ...pricingData,
      },
    }))
    // Auto-save to localStorage
    try {
      const updated = { ...set.getState().data }
      localStorage.setItem('artnew8-shared-data', JSON.stringify(updated))
    } catch {
      // ignore
    }
  },
  
  updateFromTags: (tagData) => {
    set((state) => ({
      lastUpdatedBy: 'tags',
      data: {
        ...state.data,
        ...tagData,
      },
    }))
    try {
      const updated = { ...set.getState().data }
      localStorage.setItem('artnew8-shared-data', JSON.stringify(updated))
    } catch {
      // ignore
    }
  },
  
  updateFromShipping: (shippingData) => {
    set((state) => ({
      lastUpdatedBy: 'shipping',
      data: {
        ...state.data,
        ...shippingData,
      },
    }))
    try {
      const updated = { ...set.getState().data }
      localStorage.setItem('artnew8-shared-data', JSON.stringify(updated))
    } catch {
      // ignore
    }
  },
  
  updateFromColors: (colorData) => {
    set((state) => ({
      lastUpdatedBy: 'colors',
      data: {
        ...state.data,
        ...colorData,
      },
    }))
    try {
      const updated = { ...set.getState().data }
      localStorage.setItem('artnew8-shared-data', JSON.stringify(updated))
    } catch {
      // ignore
    }
  },
  
  clearSharedData: () => {
    set({ data: {}, lastUpdatedBy: null })
    try {
      localStorage.removeItem('artnew8-shared-data')
    } catch {
      // ignore
    }
  },
}))

// Load shared data from localStorage on init
if (typeof window !== 'undefined') {
  try {
    const saved = localStorage.getItem('artnew8-shared-data')
    if (saved) {
      const parsed = JSON.parse(saved)
      useSharedData.setState({ data: parsed })
    }
  } catch {
    // ignore
  }
}
