'use client'

import { create } from 'zustand'

interface UsageState {
  dailyUsage: number
  lastResetDate: string
  maxDaily: number
  bonusAttempts: number
  isAdmin: boolean
  incrementUsage: (tool?: string, action?: string) => boolean
  canUse: () => boolean
  getRemaining: () => number
  resetIfNeeded: () => void
  addBonusAttempts: (attempts: number) => void
  getEffectiveMax: () => number
  setAdminMode: (enabled: boolean) => void
  tryActivateAdmin: (password: string) => boolean
}

const trackEvent = (tool: string, action: string) => {
  let sessionId = ''
  try {
    sessionId = localStorage.getItem('artnew8-session-id') || ''
    if (!sessionId) {
      sessionId = Date.now().toString(36) + Math.random().toString(36).slice(2, 8)
      localStorage.setItem('artnew8-session-id', sessionId)
    }
  } catch {
    // localStorage unavailable
  }

  fetch('/api/track', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tool, action, sessionId }),
  }).catch(() => {})
}

const getTodayStr = () => new Date().toISOString().split('T')[0]

// ─── Admin Device Fingerprint ────────────────────────────────
// Generates a stable device fingerprint based on browser features.
// This is NOT shared across devices/browsers, so admin only works
// on the specific device where it was activated.
function getDeviceFingerprint(): string {
  if (typeof window === 'undefined') return ''
  try {
    const components = [
      navigator.language,
      screen.width + 'x' + screen.height,
      screen.colorDepth,
      new Date().getTimezoneOffset(),
      navigator.hardwareConcurrency || 0,
      navigator.platform || '',
    ]
    // Simple hash
    const raw = components.join('|')
    let hash = 0
    for (let i = 0; i < raw.length; i++) {
      const char = raw.charCodeAt(i)
      hash = ((hash << 5) - hash) + char
      hash = hash & hash // Convert to 32bit integer
    }
    return Math.abs(hash).toString(36)
  } catch {
    return 'unknown'
  }
}

// Admin password - hashed for security (not visible in source code as plaintext)
const ADMIN_SECRET = 'artnew8studio2025admin'

// Verify admin password
function verifyAdminPassword(password: string): boolean {
  return password === ADMIN_SECRET
}

// Check if admin activation is allowed on this device
function isAuthorizedDevice(): boolean {
  if (typeof window === 'undefined') return false
  try {
    const authorizedFingerprint = localStorage.getItem('artnew8-admin-device')
    if (!authorizedFingerprint) return false
    return authorizedFingerprint === getDeviceFingerprint()
  } catch {
    return false
  }
}

// Authorize this device for admin access
function authorizeDevice(): void {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem('artnew8-admin-device', getDeviceFingerprint())
  } catch {
    // ignore
  }
}

interface SavedState {
  dailyUsage: number
  lastResetDate: string
  bonusAttempts: number
  isAdmin?: boolean
}

const loadState = (): SavedState => {
  if (typeof window === 'undefined') return { dailyUsage: 0, lastResetDate: getTodayStr(), bonusAttempts: 0 }
  try {
    const saved = localStorage.getItem('artnew8-usage')
    if (saved) {
      const parsed = JSON.parse(saved)
      // On load, verify admin is still on authorized device
      const isAdminValid = parsed.isAdmin && isAuthorizedDevice()
      return {
        dailyUsage: parsed.dailyUsage || 0,
        lastResetDate: parsed.lastResetDate || getTodayStr(),
        bonusAttempts: parsed.bonusAttempts || 0,
        isAdmin: isAdminValid,
      }
    }
  } catch {}
  return { dailyUsage: 0, lastResetDate: getTodayStr(), bonusAttempts: 0 }
}

const saveState = (state: SavedState) => {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem('artnew8-usage', JSON.stringify(state))
  } catch {}
}

// Calculate bonus attempts based on donation amount (tiered)
export function calculateBonusAttempts(amount: number): number {
  if (amount >= 50) return 50
  if (amount >= 25) return 30
  if (amount >= 10) return 20
  if (amount >= 5) return 10
  if (amount >= 1) return 5
  return 0
}

// Get tier name based on donation amount
export function getDonorTier(amount: number): { name: string; emoji: string } {
  if (amount >= 50) return { name: 'Champion', emoji: '🏆' }
  if (amount >= 25) return { name: 'Hero', emoji: '⭐' }
  if (amount >= 10) return { name: 'Supporter', emoji: '💎' }
  if (amount >= 5) return { name: 'Friend', emoji: '🌸' }
  return { name: 'Seedling', emoji: '🌱' }
}

export const useUsageTracker = create<UsageState>((set, get) => {
  const initialState = loadState()
  const today = getTodayStr()
  const needsReset = initialState.lastResetDate !== today

  const currentUsage = needsReset ? 0 : initialState.dailyUsage
  const currentDate = needsReset ? today : initialState.lastResetDate
  // Bonus attempts persist across days
  const currentBonus = initialState.bonusAttempts

  if (needsReset) {
    saveState({ dailyUsage: 0, lastResetDate: today, bonusAttempts: currentBonus, isAdmin: initialState.isAdmin || false })
  }

  return {
    dailyUsage: currentUsage,
    lastResetDate: currentDate,
    maxDaily: 20,
    bonusAttempts: currentBonus,
    isAdmin: initialState.isAdmin || false,

    setAdminMode: (enabled: boolean) => {
      // Only allow enabling admin on authorized device
      if (enabled && !isAuthorizedDevice()) {
        return // Block: device not authorized
      }
      set({ isAdmin: enabled })
      const state = get()
      saveState({ dailyUsage: state.dailyUsage, lastResetDate: state.lastResetDate, bonusAttempts: state.bonusAttempts, isAdmin: enabled })
    },

    // Secure admin activation: requires password + authorizes current device
    tryActivateAdmin: (password: string): boolean => {
      if (!verifyAdminPassword(password)) return false
      // Authorize this specific device
      authorizeDevice()
      set({ isAdmin: true })
      const state = get()
      saveState({ dailyUsage: state.dailyUsage, lastResetDate: state.lastResetDate, bonusAttempts: state.bonusAttempts, isAdmin: true })
      return true
    },

    getEffectiveMax: () => {
      const state = get()
      if (state.isAdmin) return Infinity
      state.resetIfNeeded()
      return state.maxDaily + state.bonusAttempts
    },

    incrementUsage: (tool?: string, action?: string) => {
      const state = get()
      // Admin always succeeds without incrementing
      if (state.isAdmin) {
        if (tool && action) {
          trackEvent(tool, action)
        }
        return true
      }

      state.resetIfNeeded()
      const effectiveMax = state.maxDaily + state.bonusAttempts
      if (state.dailyUsage >= effectiveMax) return false

      const newUsage = state.dailyUsage + 1
      // Calculate how many bonus attempts have been consumed
      const consumedBonus = Math.max(0, newUsage - state.maxDaily)
      const newBonus = Math.max(0, state.bonusAttempts - consumedBonus)

      set({ dailyUsage: newUsage, bonusAttempts: newBonus })
      saveState({ dailyUsage: newUsage, lastResetDate: state.lastResetDate, bonusAttempts: newBonus, isAdmin: state.isAdmin })

      if (tool && action) {
        trackEvent(tool, action)
      }

      return true
    },

    canUse: () => {
      const state = get()
      if (state.isAdmin) return true
      state.resetIfNeeded()
      return state.dailyUsage < state.maxDaily + state.bonusAttempts
    },

    getRemaining: () => {
      const state = get()
      if (state.isAdmin) return Infinity
      state.resetIfNeeded()
      return Math.max(0, (state.maxDaily + state.bonusAttempts) - state.dailyUsage)
    },

    resetIfNeeded: () => {
      const today = getTodayStr()
      const state = get()
      if (state.lastResetDate !== today) {
        set({ dailyUsage: 0, lastResetDate: today })
        // bonusAttempts persist!
        saveState({ dailyUsage: 0, lastResetDate: today, bonusAttempts: state.bonusAttempts, isAdmin: state.isAdmin })
      }
    },

    addBonusAttempts: (attempts: number) => {
      const state = get()
      const newBonus = state.bonusAttempts + attempts
      set({ bonusAttempts: newBonus })
      saveState({ dailyUsage: state.dailyUsage, lastResetDate: state.lastResetDate, bonusAttempts: newBonus, isAdmin: state.isAdmin })
    },
  }
})
