'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Wrench,
  Infinity,
  ArrowRight,
  ArrowLeft,
  MessageCircle,
  Send,
  Check,
  Loader2,
  Phone,
  Sparkles,
  Zap,
  Shield,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  generateCustomToolMessage,
  generateUnlimitedAccessMessage,
  openWhatsApp,
} from '@/lib/whatsapp'

type ServiceType = 'customize' | 'unlimited'

interface CustomServicesFormProps {
  initialType?: ServiceType
  onBack?: () => void
}

// ─── Tool Customization Form ────────────────────────────────────────────────

function CustomizeToolForm({ onBack }: { onBack?: () => void }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    toolName: '',
    projectDescription: '',
    specificNeeds: '',
    budget: '',
    timeline: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSent, setIsSent] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!formData.name.trim()) { setError('Please enter your name.'); return }
    if (!formData.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setError('Please enter a valid email.'); return
    }
    if (!formData.toolName.trim()) { setError('Please select or name the tool to customize.'); return }
    if (!formData.projectDescription.trim()) { setError('Please describe your project.'); return }
    if (!formData.specificNeeds.trim()) { setError('Please describe your specific needs.'); return }

    setIsSubmitting(true)

    try {
      // 1. Send to Google Sheets via API
      await fetch('/api/support/service-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'customize',
          ...formData,
        }),
      }).catch(() => {}) // Non-blocking

      // 2. Open WhatsApp with pre-filled message
      const message = generateCustomToolMessage(formData)
      openWhatsApp(message)

      setIsSent(true)
    } catch {
      setError('Something went wrong. Please try again or contact us directly on WhatsApp.')
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isSent) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-lg mx-auto"
      >
        <Card className="border-emerald-200">
          <CardContent className="pt-8 text-center space-y-4">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', damping: 15, stiffness: 200, delay: 0.2 }}
              className="size-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto"
            >
              <Check className="size-10 text-emerald-600" />
            </motion.div>

            <h3 className="text-2xl font-bold text-foreground">Request Sent!</h3>
            <p className="text-muted-foreground leading-relaxed">
              Your customization request has been sent via WhatsApp. We&apos;ll review your needs
              and get back to you within <strong className="text-foreground">24 hours</strong> with
              a personalized proposal.
            </p>

            <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 space-y-1">
              <p className="text-xs text-primary font-medium flex items-center justify-center gap-1.5">
                <Shield className="size-3.5" />
                Your data has been recorded securely
              </p>
              <p className="text-xs text-muted-foreground">
                All information is stored in our system and shared only with our team.
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <Button variant="outline" size="sm" onClick={onBack}>
                <ArrowLeft className="size-3.5 mr-1" />
                Back to Tools
              </Button>
              <a href="https://wa.me/213696212465" target="_blank" rel="noopener noreferrer">
                <Button size="sm" className="bg-[#25D366] hover:bg-[#20bd5a] text-white gap-1.5">
                  <MessageCircle className="size-3.5" />
                  Continue on WhatsApp
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-lg mx-auto"
    >
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3 mb-1">
            <div className="size-10 rounded-xl bg-amber-100 flex items-center justify-center">
              <Wrench className="size-5 text-amber-600" />
            </div>
            <div>
              <CardTitle className="text-lg">Customize a Tool</CardTitle>
              <CardDescription>Get a personalized version of any tool for your project</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* What you get */}
          <div className="rounded-lg border border-amber-200 bg-amber-50/50 p-3 mb-5 space-y-2">
            <p className="text-xs font-medium text-amber-700">What you get:</p>
            <ul className="text-xs text-amber-600 space-y-1">
              <li className="flex items-start gap-1.5">
                <Sparkles className="size-3 shrink-0 mt-0.5" />
                Tool redesigned specifically for your craft niche
              </li>
              <li className="flex items-start gap-1.5">
                <Zap className="size-3 shrink-0 mt-0.5" />
                Custom features, formulas, and presets for your workflow
              </li>
              <li className="flex items-start gap-1.5">
                <Shield className="size-3 shrink-0 mt-0.5" />
                Your branding and preferences built into the tool
              </li>
            </ul>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="ct-name" className="text-xs">Name <span className="text-destructive">*</span></Label>
                <Input id="ct-name" name="name" placeholder="Your name" value={formData.name} onChange={handleChange} required className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ct-email" className="text-xs">Email <span className="text-destructive">*</span></Label>
                <Input id="ct-email" name="email" type="email" placeholder="you@example.com" value={formData.email} onChange={handleChange} required className="h-9" />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="ct-phone" className="text-xs">Phone / WhatsApp (optional)</Label>
              <Input id="ct-phone" name="phone" type="tel" placeholder="+213 ..." value={formData.phone} onChange={handleChange} className="h-9" />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="ct-tool" className="text-xs">Tool to Customize <span className="text-destructive">*</span></Label>
              <Select value={formData.toolName} onValueChange={v => setFormData(prev => ({ ...prev, toolName: v }))}>
                <SelectTrigger id="ct-tool" className="h-9">
                  <SelectValue placeholder="Select a tool" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pricing Calculator">Pricing Calculator</SelectItem>
                  <SelectItem value="Tag Generator">Tag Generator</SelectItem>
                  <SelectItem value="Shipping Estimator">Shipping Estimator</SelectItem>
                  <SelectItem value="Color Palette">Color Palette</SelectItem>
                  <SelectItem value="Multiple Tools">Multiple Tools</SelectItem>
                  <SelectItem value="New Custom Tool">New Custom Tool (from scratch)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="ct-project" className="text-xs">Project Description <span className="text-destructive">*</span></Label>
              <Textarea
                id="ct-project"
                name="projectDescription"
                placeholder="Describe your craft business and what you sell..."
                value={formData.projectDescription}
                onChange={handleChange}
                rows={3}
                className="text-sm"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="ct-needs" className="text-xs">Specific Customization Needs <span className="text-destructive">*</span></Label>
              <Textarea
                id="ct-needs"
                name="specificNeeds"
                placeholder="e.g., Add support for DZD currency, custom material categories for candle-making, integrate with my local supplier pricing..."
                value={formData.specificNeeds}
                onChange={handleChange}
                rows={3}
                className="text-sm"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="ct-budget" className="text-xs">Budget (optional)</Label>
                <Select value={formData.budget} onValueChange={v => setFormData(prev => ({ ...prev, budget: v }))}>
                  <SelectTrigger id="ct-budget" className="h-9">
                    <SelectValue placeholder="Select range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Under $50">Under $50</SelectItem>
                    <SelectItem value="$50 - $100">$50 – $100</SelectItem>
                    <SelectItem value="$100 - $250">$100 – $250</SelectItem>
                    <SelectItem value="$250+">$250+</SelectItem>
                    <SelectItem value="To discuss">Let&apos;s discuss</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ct-timeline" className="text-xs">Timeline (optional)</Label>
                <Select value={formData.timeline} onValueChange={v => setFormData(prev => ({ ...prev, timeline: v }))}>
                  <SelectTrigger id="ct-timeline" className="h-9">
                    <SelectValue placeholder="Select timeline" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ASAP">ASAP</SelectItem>
                    <SelectItem value="1-2 weeks">1–2 weeks</SelectItem>
                    <SelectItem value="1 month">Within a month</SelectItem>
                    <SelectItem value="Flexible">Flexible</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {error && (
              <div className="p-2.5 rounded-lg bg-destructive/10 border border-destructive/20 text-xs text-destructive text-center">
                {error}
              </div>
            )}

            <Button
              type="submit"
              className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white gap-2 h-11"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  Sending via WhatsApp...
                </>
              ) : (
                <>
                  <Send className="size-4" />
                  Send Request via WhatsApp
                  <ArrowRight className="size-4" />
                </>
              )}
            </Button>

            <p className="text-[11px] text-muted-foreground text-center leading-relaxed">
              Your request will be sent via WhatsApp with all details pre-filled.
              Your data is also recorded in our system for follow-up.
            </p>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  )
}

// ─── Unlimited Access Form ──────────────────────────────────────────────────

function UnlimitedAccessForm({ onBack }: { onBack?: () => void }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    usageReason: '',
    toolsUsed: [] as string[],
    expectedVolume: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSent, setIsSent] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const toggleTool = (tool: string) => {
    setFormData(prev => ({
      ...prev,
      toolsUsed: prev.toolsUsed.includes(tool)
        ? prev.toolsUsed.filter(t => t !== tool)
        : [...prev.toolsUsed, tool],
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!formData.name.trim()) { setError('Please enter your name.'); return }
    if (!formData.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setError('Please enter a valid email.'); return
    }
    if (!formData.usageReason.trim()) { setError('Please tell us why you need unlimited access.'); return }
    if (formData.toolsUsed.length === 0) { setError('Please select at least one tool.'); return }

    setIsSubmitting(true)

    try {
      // 1. Send to Google Sheets via API
      await fetch('/api/support/service-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'unlimited',
          ...formData,
        }),
      }).catch(() => {}) // Non-blocking

      // 2. Open WhatsApp with pre-filled message
      const message = generateUnlimitedAccessMessage(formData)
      openWhatsApp(message)

      setIsSent(true)
    } catch {
      setError('Something went wrong. Please try again or contact us directly on WhatsApp.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const availableTools = [
    'Pricing Calculator',
    'Tag Generator',
    'Shipping Estimator',
    'Color Palette',
  ]

  if (isSent) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-lg mx-auto"
      >
        <Card className="border-emerald-200">
          <CardContent className="pt-8 text-center space-y-4">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', damping: 15, stiffness: 200, delay: 0.2 }}
              className="size-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto"
            >
              <Check className="size-10 text-emerald-600" />
            </motion.div>

            <h3 className="text-2xl font-bold text-foreground">Request Sent!</h3>
            <p className="text-muted-foreground leading-relaxed">
              Your unlimited access request has been sent via WhatsApp. We&apos;ll review your usage
              needs and get back to you with a plan within <strong className="text-foreground">24 hours</strong>.
            </p>

            <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 space-y-1">
              <p className="text-xs text-primary font-medium flex items-center justify-center gap-1.5">
                <Infinity className="size-3.5" />
                Unlimited access removes daily limits for intensive use
              </p>
              <p className="text-xs text-muted-foreground">
                Your data has been recorded securely and shared only with our team.
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <Button variant="outline" size="sm" onClick={onBack}>
                <ArrowLeft className="size-3.5 mr-1" />
                Back to Tools
              </Button>
              <a href="https://wa.me/213696212465" target="_blank" rel="noopener noreferrer">
                <Button size="sm" className="bg-[#25D366] hover:bg-[#20bd5a] text-white gap-1.5">
                  <MessageCircle className="size-3.5" />
                  Continue on WhatsApp
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-lg mx-auto"
    >
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3 mb-1">
            <div className="size-10 rounded-xl bg-emerald-100 flex items-center justify-center">
              <Infinity className="size-5 text-emerald-600" />
            </div>
            <div>
              <CardTitle className="text-lg">Unlimited Tool Access</CardTitle>
              <CardDescription>Remove daily limits — use all tools without restriction</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* What you get */}
          <div className="rounded-lg border border-emerald-200 bg-emerald-50/50 p-3 mb-5 space-y-2">
            <p className="text-xs font-medium text-emerald-700">What you get:</p>
            <ul className="text-xs text-emerald-600 space-y-1">
              <li className="flex items-start gap-1.5">
                <Infinity className="size-3 shrink-0 mt-0.5" />
                Unlimited daily uses across all tools
              </li>
              <li className="flex items-start gap-1.5">
                <Zap className="size-3 shrink-0 mt-0.5" />
                Priority access to new features and tools
              </li>
              <li className="flex items-start gap-1.5">
                <Shield className="size-3 shrink-0 mt-0.5" />
                Direct support via WhatsApp
              </li>
            </ul>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="ua-name" className="text-xs">Name <span className="text-destructive">*</span></Label>
                <Input id="ua-name" name="name" placeholder="Your name" value={formData.name} onChange={handleChange} required className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ua-email" className="text-xs">Email <span className="text-destructive">*</span></Label>
                <Input id="ua-email" name="email" type="email" placeholder="you@example.com" value={formData.email} onChange={handleChange} required className="h-9" />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="ua-phone" className="text-xs">Phone / WhatsApp (optional)</Label>
              <Input id="ua-phone" name="phone" type="tel" placeholder="+213 ..." value={formData.phone} onChange={handleChange} className="h-9" />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs">Which tools do you need? <span className="text-destructive">*</span></Label>
              <div className="flex flex-wrap gap-2">
                {availableTools.map(tool => {
                  const isSelected = formData.toolsUsed.includes(tool)
                  return (
                    <button
                      key={tool}
                      type="button"
                      onClick={() => toggleTool(tool)}
                      className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-all border cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-100 text-emerald-700 border-emerald-300'
                          : 'bg-muted/50 text-muted-foreground border-transparent hover:bg-muted hover:text-foreground'
                      }`}
                    >
                      {isSelected && <Check className="size-3" />}
                      {tool}
                    </button>
                  )
                })}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="ua-reason" className="text-xs">Why do you need unlimited access? <span className="text-destructive">*</span></Label>
              <Textarea
                id="ua-reason"
                name="usageReason"
                placeholder="e.g., I run a craft business with 50+ products and need to price them all this week..."
                value={formData.usageReason}
                onChange={handleChange}
                rows={3}
                className="text-sm"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="ua-volume" className="text-xs">Expected Usage Volume</Label>
              <Select value={formData.expectedVolume} onValueChange={v => setFormData(prev => ({ ...prev, expectedVolume: v }))}>
                <SelectTrigger id="ua-volume" className="h-9">
                  <SelectValue placeholder="How often will you use the tools?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A few times a week">A few times a week</SelectItem>
                  <SelectItem value="Daily">Daily</SelectItem>
                  <SelectItem value="Multiple times daily">Multiple times daily</SelectItem>
                  <SelectItem value="For a team/business">For a team or business</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {error && (
              <div className="p-2.5 rounded-lg bg-destructive/10 border border-destructive/20 text-xs text-destructive text-center">
                {error}
              </div>
            )}

            <Button
              type="submit"
              className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white gap-2 h-11"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  Sending via WhatsApp...
                </>
              ) : (
                <>
                  <Send className="size-4" />
                  Send Request via WhatsApp
                  <ArrowRight className="size-4" />
                </>
              )}
            </Button>

            <p className="text-[11px] text-muted-foreground text-center leading-relaxed">
              Your request will be sent via WhatsApp with all details pre-filled.
              Your data is also recorded in our system for follow-up.
            </p>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  )
}

// ─── Main Custom Services Form ──────────────────────────────────────────────

export function CustomServicesForm({ initialType, onBack }: CustomServicesFormProps) {
  const [activeType, setActiveType] = useState<ServiceType | null>(initialType || null)

  // Show selection screen
  if (!activeType) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h2 className="text-xl sm:text-2xl font-bold text-foreground">
            Need Something Special?
          </h2>
          <p className="text-sm text-muted-foreground max-w-md mx-auto leading-relaxed">
            Beyond the free daily uses, we offer personalized services to match your craft business needs.
            Contact us directly on WhatsApp to get started.
          </p>
        </div>

        {/* Two service cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Customize Tool */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card
              className="cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 border-amber-200 bg-gradient-to-br from-amber-50/50 to-amber-100/30"
              onClick={() => setActiveType('customize')}
            >
              <CardContent className="p-6 space-y-3">
                <div className="size-12 rounded-2xl bg-amber-100 flex items-center justify-center">
                  <Wrench className="size-6 text-amber-600" />
                </div>
                <h3 className="font-bold text-base">Customize a Tool</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Get any tool redesigned specifically for your craft niche. Custom features, presets,
                  currencies, and formulas built just for you.
                </p>
                <div className="flex flex-wrap gap-1.5">
                  <Badge variant="secondary" className="text-[10px] bg-amber-100">Custom presets</Badge>
                  <Badge variant="secondary" className="text-[10px] bg-amber-100">Your branding</Badge>
                  <Badge variant="secondary" className="text-[10px] bg-amber-100">Local currencies</Badge>
                </div>
                <div className="flex items-center text-xs font-semibold text-amber-600 gap-1 pt-1">
                  Get started <ArrowRight className="size-3.5" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Unlimited Access */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card
              className="cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 border-emerald-200 bg-gradient-to-br from-emerald-50/50 to-emerald-100/30"
              onClick={() => setActiveType('unlimited')}
            >
              <CardContent className="p-6 space-y-3">
                <div className="size-12 rounded-2xl bg-emerald-100 flex items-center justify-center">
                  <Infinity className="size-6 text-emerald-600" />
                </div>
                <h3 className="font-bold text-base">Unlimited Access</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Remove daily limits on all tools. Perfect for power users and businesses who need
                  intensive, unrestricted access every day.
                </p>
                <div className="flex flex-wrap gap-1.5">
                  <Badge variant="secondary" className="text-[10px] bg-emerald-100">No daily limits</Badge>
                  <Badge variant="secondary" className="text-[10px] bg-emerald-100">All tools</Badge>
                  <Badge variant="secondary" className="text-[10px] bg-emerald-100">Priority support</Badge>
                </div>
                <div className="flex items-center text-xs font-semibold text-emerald-600 gap-1 pt-1">
                  Get started <ArrowRight className="size-3.5" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Direct WhatsApp CTA */}
        <div className="text-center">
          <Separator className="my-4" />
          <p className="text-xs text-muted-foreground mb-3">
            Prefer to chat directly? Reach us on WhatsApp anytime.
          </p>
          <a href="https://wa.me/213696212465" target="_blank" rel="noopener noreferrer">
            <Button variant="outline" className="gap-2 border-[#25D366]/30 text-[#25D366] hover:bg-[#25D366]/10">
              <Phone className="size-4" />
              Chat on WhatsApp
            </Button>
          </a>
        </div>
      </div>
    )
  }

  // Show the active form
  return (
    <div className="space-y-4">
      {/* Back to services selection */}
      <button
        onClick={() => setActiveType(null)}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors group"
      >
        <ArrowLeft className="size-4 group-hover:-translate-x-0.5 transition-transform" />
        Back to service options
      </button>

      <AnimatePresence mode="wait">
        {activeType === 'customize' && <CustomizeToolForm key="customize" onBack={onBack} />}
        {activeType === 'unlimited' && <UnlimitedAccessForm key="unlimited" onBack={onBack} />}
      </AnimatePresence>
    </div>
  )
}
