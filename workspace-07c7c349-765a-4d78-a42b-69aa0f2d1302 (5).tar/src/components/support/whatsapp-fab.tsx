'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { MessageCircle, X, Wrench, Infinity, Phone } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface WhatsAppFabProps {
  onCustomTool?: () => void
  onUnlimitedAccess?: () => void
}

export function WhatsAppFab({ onCustomTool, onUnlimitedAccess }: WhatsAppFabProps) {
  const [isOpen, setIsOpen] = useState(false)

  const handleOpenWhatsApp = () => {
    window.open('https://wa.me/213696212465', '_blank', 'noopener,noreferrer')
  }

  return (
    <div className="fixed bottom-20 md:bottom-6 right-4 z-50 flex flex-col items-end gap-2">
      {/* Expanded menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className="flex flex-col gap-2 mb-2"
          >
            {/* Customize Tool */}
            <button
              onClick={() => {
                setIsOpen(false)
                onCustomTool?.()
              }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-card border border-border shadow-lg hover:shadow-xl transition-all text-sm font-medium text-foreground hover:bg-accent group"
            >
              <div className="size-7 rounded-lg bg-amber-100 flex items-center justify-center">
                <Wrench className="size-3.5 text-amber-600" />
              </div>
              <span>Customize a Tool</span>
            </button>

            {/* Unlimited Access */}
            <button
              onClick={() => {
                setIsOpen(false)
                onUnlimitedAccess?.()
              }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-card border border-border shadow-lg hover:shadow-xl transition-all text-sm font-medium text-foreground hover:bg-accent group"
            >
              <div className="size-7 rounded-lg bg-emerald-100 flex items-center justify-center">
                <Infinity className="size-3.5 text-emerald-600" />
              </div>
              <span>Unlimited Access</span>
            </button>

            {/* Direct WhatsApp */}
            <button
              onClick={() => {
                setIsOpen(false)
                handleOpenWhatsApp()
              }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#25D366] shadow-lg hover:shadow-xl transition-all text-sm font-medium text-white hover:bg-[#20bd5a] group"
            >
              <div className="size-7 rounded-lg bg-white/20 flex items-center justify-center">
                <Phone className="size-3.5" />
              </div>
              <span>Chat on WhatsApp</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FAB button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className={`size-14 rounded-full shadow-lg flex items-center justify-center transition-colors duration-200 ${
          isOpen
            ? 'bg-card border border-border text-foreground'
            : 'bg-[#25D366] text-white hover:bg-[#20bd5a]'
        }`}
        aria-label={isOpen ? 'Close menu' : 'Open WhatsApp & services'}
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              <X className="size-6" />
            </motion.div>
          ) : (
            <motion.div
              key="whatsapp"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              <MessageCircle className="size-6" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>
    </div>
  )
}
