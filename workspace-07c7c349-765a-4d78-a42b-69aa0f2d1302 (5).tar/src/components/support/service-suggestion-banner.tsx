'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Wrench, Infinity, X, ArrowRight, MessageCircle, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface ServiceSuggestionBannerProps {
  toolName: string
  onCustomizeClick?: () => void
  onUnlimitedClick?: () => void
  variant?: 'default' | 'compact'
}

export function ServiceSuggestionBanner({
  toolName,
  onCustomizeClick,
  onUnlimitedClick,
  variant = 'default',
}: ServiceSuggestionBannerProps) {
  const [dismissed, setDismissed] = useState(false)

  if (dismissed) return null

  // Compact variant for inside tool cards
  if (variant === 'compact') {
    return (
      <div className="relative rounded-lg border border-primary/10 bg-primary/[0.03] p-2.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Sparkles className="size-3.5 text-primary shrink-0" />
          <p className="text-[11px] text-muted-foreground truncate">
            Need <strong className="text-foreground">custom {toolName}</strong> or unlimited uses?
          </p>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={onCustomizeClick}
            className="text-[10px] font-medium text-amber-600 hover:underline whitespace-nowrap"
          >
            Customize
          </button>
          <span className="text-muted-foreground/30">·</span>
          <button
            onClick={onUnlimitedClick}
            className="text-[10px] font-medium text-emerald-600 hover:underline whitespace-nowrap"
          >
            Unlimited
          </button>
        </div>
      </div>
    )
  }

  // Default variant - more visible
  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative rounded-xl border border-primary/15 bg-gradient-to-r from-primary/[0.03] via-primary/[0.05] to-primary/[0.03] p-4"
    >
      <button
        onClick={() => setDismissed(true)}
        className="absolute top-2 right-2 size-6 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
      >
        <X className="size-3.5" />
      </button>

      <div className="flex items-start gap-3">
        <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
          <Sparkles className="size-4 text-primary" />
        </div>
        <div className="space-y-2 min-w-0">
          <p className="text-sm font-medium text-foreground">
            Want more from the {toolName}?
          </p>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-xs gap-1 border-amber-300 text-amber-700 hover:bg-amber-50"
              onClick={onCustomizeClick}
            >
              <Wrench className="size-3" />
              Customize this tool
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-xs gap-1 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
              onClick={onUnlimitedClick}
            >
              <Infinity className="size-3" />
              Unlimited uses
            </Button>
            <a href="https://wa.me/213696212465" target="_blank" rel="noopener noreferrer">
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-xs gap-1 border-[#25D366]/30 text-[#25D366] hover:bg-[#25D366]/10"
              >
                <MessageCircle className="size-3" />
                WhatsApp
              </Button>
            </a>
          </div>
          <p className="text-[11px] text-muted-foreground">
            Get a version built for your craft niche, or remove daily limits for intensive use.
          </p>
        </div>
      </div>
    </motion.div>
  )
}
