'use client'

import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Heart,
  Check,
  Shield,
  Zap,
  Sparkles,
  Facebook,
  ExternalLink,
  Loader2,
  AlertTriangle,
  ArrowRight,
  RotateCcw,
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { useUsageTracker, calculateBonusAttempts, getDonorTier } from '@/hooks/use-usage-tracker'

// ─── Google Apps Script Web App URL ─────────────────────────
const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbz8DeCB94U9WnjbJe-7CzIiKq43H3QQExUQ4peL0flQbiEnCo-aUalfTbKHFNxGThK6DA/exec'

// ─── Types ───────────────────────────────────────────────────
interface DonationData {
  name: string
  email: string
  phone: string
  amount: string
  message: string
  timestamp: string
}

type ConfirmState = 'loading' | 'success' | 'error' | 'manual'

// ─── Component ───────────────────────────────────────────────
export function DonationConfirmation() {
  const { addBonusAttempts, getRemaining } = useUsageTracker()

  const [state, setState] = useState<ConfirmState>('loading')
  const [donationData, setDonationData] = useState<DonationData | null>(null)
  const [bonusAdded, setBonusAdded] = useState(0)
  const [sheetStatus, setSheetStatus] = useState<'pending' | 'sent' | 'failed' | 'skipped'>('pending')
  const [errorMsg, setErrorMsg] = useState('')

  // Load donation data from localStorage (saved before PayPal redirect)
  const loadDonationData = useCallback((): DonationData | null => {
    try {
      const saved = localStorage.getItem('artnew8-pending-donation')
      if (saved) {
        const data = JSON.parse(saved) as DonationData
        // Clear the pending data after reading
        localStorage.removeItem('artnew8-pending-donation')
        return data
      }
    } catch {
      // ignore
    }
    return null
  }, [])

  // Send donation data to Google Sheets via Apps Script
  const sendToGoogleSheet = useCallback(async (data: DonationData) => {
    if (!APPS_SCRIPT_URL) {
      setSheetStatus('skipped')
      return
    }

    try {
      const response = await fetch(APPS_SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors', // Google Apps Script requires no-cors
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: data.name,
          email: data.email,
          phone: data.phone,
          amount: data.amount,
          currency: 'USD',
          message: data.message,
          status: 'completed',
          source: 'paypal_ncp',
          timestamp: data.timestamp,
        }),
      })

      // no-cors mode means we can't read the response,
      // but if the fetch completes without error, we assume success
      setSheetStatus('sent')
    } catch (error) {
      console.error('Failed to send to Google Sheet:', error)
      setSheetStatus('failed')
    }
  }, [])

  // Also save to local storage as backup record
  const saveToLocalStorage = useCallback((data: DonationData, tier: string, bonus: number) => {
    try {
      const existing = JSON.parse(localStorage.getItem('artnew8-donations') || '[]')
      existing.push({
        ...data,
        tier,
        bonusAttempts: bonus,
        verifiedAt: new Date().toISOString(),
        source: 'paypal_return',
      })
      localStorage.setItem('artnew8-donations', JSON.stringify(existing))
    } catch {
      // ignore
    }
  }, [])

  // Main initialization effect
  useEffect(() => {
    const init = async () => {
      const data = loadDonationData()

      if (!data) {
        // No pending donation data — user may have arrived here directly
        setState('manual')
        return
      }

      setDonationData(data)

      const amount = parseFloat(data.amount) || 0
      const bonus = calculateBonusAttempts(amount)
      const tierInfo = getDonorTier(amount)

      // Add bonus attempts
      addBonusAttempts(bonus)
      setBonusAdded(bonus)

      // Save to localStorage backup
      saveToLocalStorage(data, tierInfo.name, bonus)

      // Send to Google Sheets (async, non-blocking)
      sendToGoogleSheet(data)

      // Show success
      setState('success')
    }

    // Small delay for smooth animation
    const timer = setTimeout(init, 800)
    return () => clearTimeout(timer)
  }, [loadDonationData, addBonusAttempts, saveToLocalStorage, sendToGoogleSheet])

  // Retry sending to Google Sheet
  const retrySheet = async () => {
    if (donationData) {
      setSheetStatus('pending')
      await sendToGoogleSheet(donationData)
    }
  }

  // Clean URL (remove PayPal parameters)
  useEffect(() => {
    const url = new URL(window.location.href)
    let changed = false
    const paramsToRemove = ['donation', 'tx', 'st', 'amt', 'cc', 'cm', 'item_number', 'item_name', 'PayerID', 'token']
    paramsToRemove.forEach(param => {
      if (url.searchParams.has(param)) {
        url.searchParams.delete(param)
        changed = true
      }
    })
    if (changed) {
      window.history.replaceState({}, '', url.toString())
    }
  }, [])

  const currentTier = donationData ? getDonorTier(parseFloat(donationData.amount) || 0) : null

  // ─── Loading State ─────────────────────────────────────────
  if (state === 'loading') {
    return (
      <div className="max-w-lg mx-auto">
        <Card className="border-primary/20">
          <CardContent className="pt-12 pb-12 text-center space-y-5">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
              className="size-16 rounded-full border-4 border-primary/20 border-t-primary mx-auto"
            />
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <h3 className="text-xl font-bold text-foreground">Confirming Your Donation...</h3>
              <p className="text-sm text-muted-foreground mt-2">
                We&apos;re verifying your contribution. This will just take a moment.
              </p>
            </motion.div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // ─── Manual State (no pending donation data found) ────────
  if (state === 'manual') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-lg mx-auto"
      >
        <Card className="border-primary/20">
          <CardContent className="pt-8 text-center space-y-5">
            <div className="size-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
              <Heart className="size-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold text-foreground">Thank You for Your Support!</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              If you just completed a PayPal donation, your contribution is being processed.
              Your bonus tool uses will be added automatically once confirmed.
            </p>
            <div className="rounded-lg border border-primary/20 bg-primary/5 p-3">
              <p className="text-xs text-muted-foreground">
                You currently have <strong className="text-foreground">{getRemaining()}</strong> tool uses remaining today.
              </p>
            </div>
            <Button
              className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2"
              onClick={() => window.location.href = '/'}
            >
              <ArrowRight className="size-4" />
              Back to Tools
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  // ─── Error State ──────────────────────────────────────────
  if (state === 'error') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-lg mx-auto"
      >
        <Card className="border-destructive/20">
          <CardContent className="pt-8 text-center space-y-4">
            <div className="size-14 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
              <AlertTriangle className="size-7 text-destructive" />
            </div>
            <h3 className="text-lg font-bold text-foreground">Something Went Wrong</h3>
            <p className="text-sm text-muted-foreground">
              {errorMsg || 'We couldn\'t confirm your donation. Please try again or contact us.'}
            </p>
            <div className="flex flex-col gap-2">
              <Button
                className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2"
                onClick={() => {
                  setState('loading')
                  window.location.reload()
                }}
              >
                <RotateCcw className="size-4" />
                Try Again
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-muted-foreground"
                onClick={() => window.location.href = '/'}
              >
                Back to Tools
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  // ─── Success State ────────────────────────────────────────
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      className="max-w-lg mx-auto"
    >
      <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-primary/[0.02] overflow-hidden">
        {/* Top accent bar */}
        <div className="h-1.5 bg-gradient-to-r from-primary via-orange-400 to-rose-400" />

        <CardContent className="pt-8 text-center space-y-5">
          {/* Celebration icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', damping: 15, stiffness: 200, delay: 0.2 }}
            className="size-20 rounded-full bg-primary/20 flex items-center justify-center mx-auto"
          >
            <span className="text-4xl">{currentTier?.emoji || '💚'}</span>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h3 className="text-2xl font-bold text-foreground">
              Thank You, {donationData?.name || 'Friend'}!
            </h3>
            <p className="text-muted-foreground mt-2 leading-relaxed">
              Your contribution of{' '}
              <strong className="text-foreground">${donationData?.amount || '0'} USD</strong> has been{' '}
              <strong className="text-primary">received</strong> and recorded as a{' '}
              <strong className="text-primary">{currentTier?.name || 'Seedling'}</strong> tier donation.
              You&apos;re now part of the founding contributors of the future artisan marketplace.
            </p>
          </motion.div>

          {/* Bonus attempts info */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="rounded-xl border border-primary/20 bg-primary/5 p-4 space-y-2"
          >
            <div className="flex items-center justify-center gap-2">
              <Zap className="size-5 text-primary" />
              <span className="font-bold text-primary text-lg">+{bonusAdded} Extra Tool Uses</span>
            </div>
            <p className="text-xs text-muted-foreground">
              These bonus attempts carry over across days and are added to your daily free uses.
              You now have <strong className="text-foreground">{getRemaining()}</strong> remaining uses today.
            </p>
          </motion.div>

          {/* Google Sheet sync status */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.55 }}
          >
            {sheetStatus === 'sent' && (
              <div className="flex items-center justify-center gap-1.5 text-xs text-emerald-600">
                <Check className="size-3.5" />
                <span>Recorded in Google Sheets</span>
              </div>
            )}
            {sheetStatus === 'pending' && (
              <div className="flex items-center justify-center gap-1.5 text-xs text-amber-600">
                <Loader2 className="size-3.5 animate-spin" />
                <span>Syncing to Google Sheets...</span>
              </div>
            )}
            {sheetStatus === 'failed' && (
              <button
                onClick={retrySheet}
                className="flex items-center justify-center gap-1.5 text-xs text-destructive hover:text-destructive/80"
              >
                <AlertTriangle className="size-3.5" />
                <span>Sheet sync failed — tap to retry</span>
              </button>
            )}
            {sheetStatus === 'skipped' && (
              <div className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
                <Shield className="size-3.5" />
                <span>Payment confirmed via PayPal</span>
              </div>
            )}
          </motion.div>

          {/* Badges */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="flex flex-wrap items-center justify-center gap-2 pt-1"
          >
            <Badge className="bg-primary/10 text-primary border-primary/20">
              <Heart className="size-3 fill-current mr-1" />
              {currentTier?.name || 'Seedling'} Contributor
            </Badge>
            <Badge className="bg-primary/10 text-primary border-primary/20">
              <Sparkles className="size-3 mr-1" />
              Priority Access
            </Badge>
            <Badge className="bg-primary/10 text-primary border-primary/20">
              <Check className="size-3 mr-1" />
              Founders Wall
            </Badge>
          </motion.div>

          <Separator className="my-3" />

          {/* What's next */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="space-y-4"
          >
            <p className="text-sm text-muted-foreground">
              Want even more uses? Donate again to unlock higher tiers with more bonus attempts.
              Every contribution brings us closer to the artisan marketplace.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
              <a
                href="https://www.paypal.com/ncp/payment/7TUYHE9XTU6AG"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="outline" size="sm" className="gap-1.5">
                  <Heart className="size-3.5" />
                  Donate Again
                </Button>
              </a>
              <a
                href="https://www.facebook.com/share/g/1HLBeMbAVJ/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="outline" size="sm" className="gap-1.5">
                  <Facebook className="size-3.5" />
                  Share with Friends
                </Button>
              </a>
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                onClick={() => window.location.href = '/'}
              >
                <ArrowRight className="size-3.5" />
                Back to Tools
              </Button>
            </div>
          </motion.div>

          {/* Confirmation email notice */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="rounded-lg border border-border/50 bg-muted/30 p-3"
          >
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              Your donation has been securely recorded. PayPal will send a receipt to your email.
              Thank you for being part of the artnew8 community! 💛
            </p>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
