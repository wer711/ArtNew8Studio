'use client'

import { Heart, Sparkles, Coffee } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { motion } from 'framer-motion'

interface ToolDonationPromptProps {
  onSupportClick: () => void
}

export function ToolDonationPrompt({ onSupportClick }: ToolDonationPromptProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="mt-6"
    >
      <div className="relative overflow-hidden rounded-xl border border-primary/15 bg-gradient-to-br from-primary/[0.03] via-primary/[0.06] to-primary/[0.03]">
        <div className="px-5 py-4 sm:px-6 sm:py-5 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex items-center gap-3 flex-1">
            <div className="size-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Coffee className="size-5 text-primary" />
            </div>
            <div>
              <h4 className="text-base font-semibold text-foreground flex items-center gap-1.5">
                Found this helpful?
                <Sparkles className="size-3.5 text-primary/60" />
              </h4>
              <p className="text-sm text-muted-foreground mt-0.5 leading-relaxed">
                We work hard building these free tools for artisans. A small tip or donation helps us keep improving and creating more for everyone.
              </p>
            </div>
          </div>
          <Button
            onClick={onSupportClick}
            className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2 shrink-0 text-sm"
          >
            <Heart className="size-4 fill-current" />
            Support Us
          </Button>
        </div>
      </div>
    </motion.div>
  )
}
