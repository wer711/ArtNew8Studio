'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Heart, ArrowRight, Sparkles, Shield, Zap, Wrench, Infinity, MessageCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface LimitPopupProps {
  open: boolean
  onClose: () => void
  onSupportClick: () => void
  onCustomizeClick?: () => void
  onUnlimitedClick?: () => void
  remaining: number
}

export function LimitPopup({ open, onClose, onSupportClick, onCustomizeClick, onUnlimitedClick, remaining }: LimitPopupProps) {
  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/30 backdrop-blur-sm z-[60]"
            onClick={onClose}
          />

          {/* Popup */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed inset-0 z-[70] flex items-center justify-center p-4 pointer-events-none"
          >
            <div className="bg-[#FDFAF6] border border-[#DDD0C0] rounded-2xl shadow-xl max-w-sm w-full pointer-events-auto overflow-hidden">
              {/* Content */}
              <div className="px-5 pb-5 pt-5 text-center space-y-3">
                {/* Icon */}
                <div className="size-14 rounded-full bg-[#C96A2B]/10 flex items-center justify-center mx-auto">
                  <Sparkles className="size-7 text-[#C96A2B]" />
                </div>

                {/* Title */}
                <h3 className="text-lg font-bold text-[#2C1810]">
                  You&apos;ve Used Your 20 Free Uses Today
                </h3>

                {/* Logical explanation */}
                <div className="space-y-2 text-left">
                  <p className="text-sm text-[#6B5744] leading-relaxed">
                    Every tool calculation uses real server resources that cost real money.
                    We give <strong className="text-[#2C1810]">20 free uses daily</strong> because we believe
                    every crafter deserves access — but we can&apos;t sustain unlimited free usage alone.
                  </p>

                  <div className="rounded-lg bg-[#C96A2B]/5 border border-[#C96A2B]/10 p-3 space-y-1.5">
                    <p className="text-sm font-medium text-[#2C1810]">
                      Here&apos;s the honest truth:
                    </p>
                    <p className="text-xs text-[#6B5744] leading-relaxed">
                      We&apos;re not a big tech company with investor money. We&apos;re crafters building tools for crafters.
                      Your support doesn&apos;t just unlock more uses — it funds a <strong className="text-[#C96A2B]">fair marketplace</strong> where
                      handmade sellers come first.
                    </p>
                  </div>
                </div>

                {/* Bonus preview */}
                <div className="rounded-lg border border-[#5B8A6F]/30 bg-[#5B8A6F]/5 p-2.5 flex items-center gap-2">
                  <Zap className="size-4 text-[#5B8A6F] shrink-0" />
                  <p className="text-xs text-[#5B8A6F] text-left">
                    <strong>Donors get bonus uses!</strong> Even $1 unlocks 5 extra uses that carry over across days.
                  </p>
                </div>

                <p className="text-sm text-[#C96A2B] font-medium">
                  Help us keep going — and reach the goal together.
                </p>

                {/* Main actions */}
                <div className="space-y-2 pt-1">
                  <Button
                    className="w-full bg-[#C96A2B] hover:bg-[#A85420] text-white gap-2"
                    onClick={() => {
                      onClose()
                      onSupportClick()
                    }}
                  >
                    <Heart className="size-4 fill-current" />
                    Support ArtNew8 Studio
                    <ArrowRight className="size-4" />
                  </Button>

                  {/* Custom services alternatives */}
                  {(onCustomizeClick || onUnlimitedClick) && (
                    <div className="pt-1">
                      <p className="text-[11px] text-[#9C8070] mb-2">Or get exactly what you need:</p>
                      <div className="flex gap-2">
                        {onCustomizeClick && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1 h-8 text-xs gap-1 border-amber-300 text-amber-700 hover:bg-amber-50"
                            onClick={() => {
                              onClose()
                              onCustomizeClick()
                            }}
                          >
                            <Wrench className="size-3" />
                            Customize
                          </Button>
                        )}
                        {onUnlimitedClick && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1 h-8 text-xs gap-1 border-[#5B8A6F]/40 text-[#5B8A6F] hover:bg-[#5B8A6F]/5"
                            onClick={() => {
                              onClose()
                              onUnlimitedClick()
                            }}
                          >
                            <Infinity className="size-3" />
                            Unlimited
                          </Button>
                        )}
                      </div>
                    </div>
                  )}

                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full text-[#9C8070] text-xs"
                    onClick={onClose}
                  >
                    Come back tomorrow for 20 more free uses
                  </Button>

                  {/* WhatsApp "need more" message */}
                  <p className="text-[13px] text-[#9C8070] mt-2">
                    Need more?{' '}
                    <a
                      href="https://wa.me/213696212465?text=Hi!%20I%20need%20unlimited%20access%20to%20ArtNew8%20Studio%20tools.%20Can%20you%20help%3F"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#5B8A6F] hover:text-[#5B8A6F]/80 underline underline-offset-2"
                    >
                      Contact us on WhatsApp for unlimited access or a custom plan.
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
