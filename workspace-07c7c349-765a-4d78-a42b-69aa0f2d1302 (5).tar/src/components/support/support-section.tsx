'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { motion } from 'framer-motion'
import {
  Heart,
  Check,
  Sparkles,
  Shield,
  Zap,
  RotateCcw,
  Loader2,
  MessageCircle,
  ExternalLink,
  ArrowRight,
  Clock,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { useUsageTracker, calculateBonusAttempts, getDonorTier } from '@/hooks/use-usage-tracker'

// ─── Constants ──────────────────────────────────────────────
const PAYPAL_NCP_URL = 'https://www.paypal.com/ncp/payment/7TUYHE9XTU6AG'
const FACEBOOK_GROUP = 'https://www.facebook.com/share/g/1HLBeMbAVJ/'
const WHATSAPP_NUMBER = '213696212465'

// Auto-polling settings
const POLL_INTERVAL_MS = 15_000  // Check every 15 seconds
const WHATSAPP_TIMEOUT_MS = 180_000  // Show WhatsApp after 3 minutes
const MAX_POLL_DURATION_MS = 300_000  // Stop polling after 5 minutes

// Preset donation amounts
const PRESET_AMOUNTS = [5, 10, 25, 50]

// ─── Types ──────────────────────────────────────────────────
interface FormData {
  name: string
  email: string
  amount: string
  message: string
}

type Step = 'form' | 'waiting' | 'success' | 'failed'

// ─── Animation ──────────────────────────────────────────────
const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
}

// ─── Bonus Preview ──────────────────────────────────────────
function BonusPreview({ amount }: { amount: string }) {
  const numAmount = parseFloat(amount)
  if (isNaN(numAmount) || numAmount < 1) return null

  const bonus = calculateBonusAttempts(numAmount)
  const tier = getDonorTier(numAmount)

  return (
    <div className="rounded-lg border border-[#C96A2B]/20 bg-[#C96A2B]/5 p-3 space-y-2">
      <div className="flex items-center gap-2 text-sm font-medium text-[#C96A2B]">
        <Zap className="size-4" />
        <span>Your contribution unlocks:</span>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-2xl">{tier.emoji}</span>
        <div>
          <p className="font-semibold text-sm text-[#2C1810]">{tier.name} Tier</p>
          <p className="text-xs text-[#9C8070]">+{bonus} extra tool uses (carry over across days)</p>
        </div>
      </div>
    </div>
  )
}

// ─── Main Component ─────────────────────────────────────────
export function SupportSection() {
  const { addBonusAttempts, getRemaining } = useUsageTracker()

  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    amount: '',
    message: '',
  })
  const [step, setStep] = useState<Step>('form')
  const [isProcessing, setIsProcessing] = useState(false)
  const [bonusAdded, setBonusAdded] = useState(0)
  const [error, setError] = useState('')
  const [pollCount, setPollCount] = useState(0)
  const [elapsedSeconds, setElapsedSeconds] = useState(0)
  const [referenceId, setReferenceId] = useState<string | null>(null)
  const [showWhatsAppFallback, setShowWhatsAppFallback] = useState(false)

  const pollTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const elapsedTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const startTimeRef = useRef<number>(0)

  const currentBonus = calculateBonusAttempts(parseFloat(formData.amount) || 0)
  const currentTier = getDonorTier(parseFloat(formData.amount) || 0)

  // ─── Cleanup timers on unmount ────────────────────────────
  useEffect(() => {
    return () => {
      if (pollTimerRef.current) clearInterval(pollTimerRef.current)
      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current)
    }
  }, [])

  // ─── Handle PayPal return (paypal_return=1) ─────────────
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const paypalReturn = params.get('paypal_return')

    if (paypalReturn === '1') {
      // Clean URL
      const url = new URL(window.location.href)
      url.searchParams.delete('paypal_return')
      url.searchParams.delete('PayerID')
      url.searchParams.delete('token')
      window.history.replaceState({}, '', url.toString())

      // Start auto-polling if we have pending donation data
      const saved = localStorage.getItem('artnew8-pending-donation')
      if (saved) {
        try {
          const parsed = JSON.parse(saved)
          setFormData(parsed)
        } catch {}
        handlePayPalReturn()
      }
    }
  }, [])

  // ─── Check payment status from server ─────────────────────
  const checkPaymentStatus = useCallback(async (refId: string, email: string) => {
    try {
      const params = new URLSearchParams()
      if (refId) params.set('ref', refId)
      if (email) params.set('email', email)

      const res = await fetch(`/api/support/status?${params.toString()}`)
      if (!res.ok) return null

      const data = await res.json()
      return data
    } catch {
      return null
    }
  }, [])

  // ─── Start auto-polling for payment verification ──────────
  const startPolling = useCallback((refId: string | null, email: string) => {
    // Clear any existing timers
    if (pollTimerRef.current) clearInterval(pollTimerRef.current)
    if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current)

    startTimeRef.current = Date.now()
    setPollCount(0)
    setElapsedSeconds(0)
    setShowWhatsAppFallback(false)

    // Start elapsed timer
    elapsedTimerRef.current = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000)
      setElapsedSeconds(elapsed)

      // Show WhatsApp fallback after 3 minutes
      if (elapsed >= 180 && !showWhatsAppFallback) {
        setShowWhatsAppFallback(true)
      }

      // Stop polling after 5 minutes
      if (elapsed >= 300) {
        if (pollTimerRef.current) clearInterval(pollTimerRef.current)
        if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current)
        setError('Payment verification timed out. If you completed your payment, please contact us via WhatsApp.')
        setStep('failed')
      }
    }, 1000)

    // Start polling timer
    let count = 0
    pollTimerRef.current = setInterval(async () => {
      count++
      setPollCount(count)

      const result = await checkPaymentStatus(refId || '', email)

      if (result?.verified) {
        // Payment confirmed by server! Grant bonus
        if (pollTimerRef.current) clearInterval(pollTimerRef.current)
        if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current)

        const bonus = result.bonusAttempts || calculateBonusAttempts(parseFloat(formData.amount) || 0)
        addBonusAttempts(bonus)
        setBonusAdded(bonus)

        // Save donation record locally
        try {
          const existing = JSON.parse(localStorage.getItem('artnew8-donations') || '[]')
          existing.push({
            name: formData.name,
            email: formData.email,
            amount: formData.amount,
            tier: result.tier || currentTier.name,
            bonusAttempts: bonus,
            timestamp: new Date().toISOString(),
            status: 'completed',
            source: 'auto_verified',
          })
          localStorage.setItem('artnew8-donations', JSON.stringify(existing))
        } catch {}

        // Clear pending donation
        try { localStorage.removeItem('artnew8-pending-donation') } catch {}

        setStep('success')
      }
    }, POLL_INTERVAL_MS)

    // Also do an immediate first check
    ;(async () => {
      const result = await checkPaymentStatus(refId || '', email)
      if (result?.verified) {
        if (pollTimerRef.current) clearInterval(pollTimerRef.current)
        if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current)

        const bonus = result.bonusAttempts || calculateBonusAttempts(parseFloat(formData.amount) || 0)
        addBonusAttempts(bonus)
        setBonusAdded(bonus)

        try {
          const existing = JSON.parse(localStorage.getItem('artnew8-donations') || '[]')
          existing.push({
            name: formData.name,
            email: formData.email,
            amount: formData.amount,
            tier: result.tier || currentTier.name,
            bonusAttempts: bonus,
            timestamp: new Date().toISOString(),
            status: 'completed',
            source: 'auto_verified',
          })
          localStorage.setItem('artnew8-donations', JSON.stringify(existing))
        } catch {}

        try { localStorage.removeItem('artnew8-pending-donation') } catch {}

        setStep('success')
      }
    })()
  }, [checkPaymentStatus, addBonusAttempts, formData, currentTier])

  // ─── Process PayPal Return ──────────────────────────────
  const handlePayPalReturn = async () => {
    let savedData: FormData | null = null
    try {
      const saved = localStorage.getItem('artnew8-pending-donation')
      if (saved) savedData = JSON.parse(saved)
    } catch {}

    if (!savedData) return

    setStep('waiting')
    setIsProcessing(true)

    try {
      const amount = parseFloat(savedData.amount) || 0

      // Register the pending donation on the server
      const registerRes = await fetch('/api/support/register-ncp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: savedData.name,
          email: savedData.email,
          amount,
          message: savedData.message,
          source: 'paypal_ncp_return',
        }),
      })

      let refId: string | null = null
      if (registerRes.ok) {
        const registerData = await registerRes.json()
        refId = registerData.id || null
        setReferenceId(refId)
      }

      // Start auto-polling — no manual confirmation needed!
      startPolling(refId, savedData.email.trim())
    } catch {
      setError('Something went wrong. Your payment is being processed.')
      // Still start polling as fallback
      startPolling(null, savedData?.email || '')
    } finally {
      setIsProcessing(false)
    }
  }

  // ─── Open PayPal NCP ───────────────────────────────────
  const openPayPal = () => {
    // Validate form
    if (!formData.name.trim()) {
      setError('Please enter your name.')
      return
    }
    if (!formData.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setError('Please enter a valid email address.')
      return
    }
    const amount = parseFloat(formData.amount)
    if (isNaN(amount) || amount < 1) {
      setError('Please select or enter an amount of at least $1.')
      return
    }

    setError('')

    // Save form data to localStorage before redirect
    try {
      localStorage.setItem('artnew8-pending-donation', JSON.stringify({
        name: formData.name.trim(),
        email: formData.email.trim(),
        amount: formData.amount,
        message: formData.message.trim(),
        timestamp: new Date().toISOString(),
      }))
    } catch {}

    // Register pending donation on server
    const bonus = calculateBonusAttempts(amount)
    const tier = getDonorTier(amount)

    fetch('/api/support/register-ncp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: formData.name.trim(),
        email: formData.email.trim(),
        amount,
        tier: tier.name,
        bonusAttempts: bonus,
        message: formData.message.trim(),
        source: 'paypal_ncp',
      }),
    }).then(async (res) => {
      if (res.ok) {
        const data = await res.json()
        setReferenceId(data.id || null)
      }
    }).catch(() => {})

    // Open PayPal NCP link in new tab
    window.open(PAYPAL_NCP_URL, '_blank')

    // Show waiting state and start auto-polling
    setStep('waiting')
    startPolling(null, formData.email.trim())
  }

  // ─── Reset form ────────────────────────────────────────
  const resetForm = () => {
    if (pollTimerRef.current) clearInterval(pollTimerRef.current)
    if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current)
    setStep('form')
    setFormData({ name: '', email: '', amount: '', message: '' })
    setBonusAdded(0)
    setError('')
    setPollCount(0)
    setElapsedSeconds(0)
    setShowWhatsAppFallback(false)
    setReferenceId(null)
  }

  // Format elapsed time
  const formatElapsed = (seconds: number) => {
    const m = Math.floor(seconds / 60)
    const s = seconds % 60
    return `${m}:${s.toString().padStart(2, '0')}`
  }

  // ═════════════════════════════════════════════════════════
  //  SUCCESS STATE
  // ═════════════════════════════════════════════════════════
  if (step === 'success') {
    const tier = getDonorTier(parseFloat(formData.amount) || 0)
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="max-w-lg mx-auto"
      >
        <Card className="border-[#C96A2B]/30 bg-gradient-to-br from-[#C96A2B]/5 to-[#C96A2B]/[0.02] overflow-hidden">
          <div className="h-1.5 bg-gradient-to-r from-[#C96A2B] via-orange-400 to-rose-400" />

          <CardContent className="pt-8 text-center space-y-5">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', damping: 15, stiffness: 200, delay: 0.2 }}
              className="size-20 rounded-full bg-[#C96A2B]/20 flex items-center justify-center mx-auto"
            >
              <span className="text-4xl">{tier.emoji}</span>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <h3 className="text-2xl font-bold text-[#2C1810]">
                Thank You, {formData.name}!
              </h3>
              <p className="text-[#6B5744] mt-2 leading-relaxed">
                Your contribution of <strong className="text-[#2C1810]">${formData.amount} USD</strong> has been
                <strong className="text-[#C96A2B]"> verified</strong> as a{' '}
                <strong className="text-[#C96A2B]">{tier.name}</strong> tier donation.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="rounded-xl border border-[#C96A2B]/20 bg-[#C96A2B]/5 p-4 space-y-2"
            >
              <div className="flex items-center justify-center gap-2">
                <Zap className="size-5 text-[#C96A2B]" />
                <span className="font-bold text-[#C96A2B] text-lg">+{bonusAdded} Extra Tool Uses</span>
              </div>
              <p className="text-xs text-[#9C8070]">
                These bonus attempts carry over across days. You now have <strong className="text-[#2C1810]">{getRemaining()}</strong> remaining uses today.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.55 }}
              className="flex items-center justify-center gap-1.5 text-xs text-[#5B8A6F]"
            >
              <Shield className="size-3.5" />
              <span>Verified by server · Recorded in Google Sheets</span>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="flex flex-wrap items-center justify-center gap-2 pt-1"
            >
              <Badge className="bg-[#C96A2B]/10 text-[#C96A2B] border-[#C96A2B]/20">
                <Heart className="size-3 fill-current mr-1" />
                {tier.name} Contributor
              </Badge>
              <Badge className="bg-[#C96A2B]/10 text-[#C96A2B] border-[#C96A2B]/20">
                <Sparkles className="size-3 mr-1" />
                Priority Access
              </Badge>
              <Badge className="bg-[#C96A2B]/10 text-[#C96A2B] border-[#C96A2B]/20">
                <Check className="size-3 mr-1" />
                Founders Wall
              </Badge>
            </motion.div>

            <Separator className="my-3 bg-[#DDD0C0]" />

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="space-y-3"
            >
              <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
                <Button variant="outline" size="sm" className="gap-1.5 border-[#DDD0C0]" onClick={resetForm}>
                  <RotateCcw className="size-3.5" />
                  Donate Again
                </Button>
                <a href={FACEBOOK_GROUP} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="gap-1.5 border-[#DDD0C0]">
                    Share with Friends
                  </Button>
                </a>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="rounded-lg border border-[#DDD0C0] bg-[#F5F0E8]/50 p-3"
            >
              <p className="text-[11px] text-[#9C8070] leading-relaxed">
                Your donation has been securely verified and recorded. PayPal will send a receipt to your email.
                Thank you for being part of the ArtNew8 community!
              </p>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  // ═════════════════════════════════════════════════════════
  //  WAITING STATE (Auto-polling — NO manual confirm button)
  // ═════════════════════════════════════════════════════════
  if (step === 'waiting') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-lg mx-auto"
      >
        <Card className="border-[#C96A2B]/20">
          <CardContent className="pt-6 space-y-5">
            <div className="text-center space-y-3">
              {/* Animated spinner */}
              <div className="size-14 rounded-full bg-[#003087]/10 flex items-center justify-center mx-auto relative">
                <Loader2 className="size-7 text-[#003087] animate-spin" />
              </div>

              <h3 className="text-lg font-bold text-[#2C1810]">
                Waiting for Payment Confirmation...
              </h3>

              <p className="text-sm text-[#6B5744] leading-relaxed">
                PayPal has opened in a new tab. Complete your donation of{' '}
                <strong className="text-[#2C1810]">${formData.amount} USD</strong> there.
                Your bonus will be added automatically once payment is confirmed.
              </p>

              {/* Bonus preview */}
              <div className="rounded-lg border border-[#C96A2B]/20 bg-[#C96A2B]/5 p-3">
                <div className="flex items-center justify-center gap-2 text-sm">
                  <span className="text-xl">{currentTier.emoji}</span>
                  <span className="font-medium text-[#C96A2B]">
                    {currentTier.name} Tier · +{currentBonus} extra uses
                  </span>
                </div>
              </div>

              {/* Polling status indicator */}
              <div className="rounded-lg border border-[#5B8A6F]/20 bg-[#5B8A6F]/5 p-3 text-left space-y-1.5">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-medium text-[#5B8A6F] flex items-center gap-1.5">
                    <Clock className="size-3" />
                    Checking payment status
                  </p>
                  <span className="text-xs text-[#5B8A6F]/70">{formatElapsed(elapsedSeconds)}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="flex-1 h-1.5 rounded-full bg-[#5B8A6F]/20 overflow-hidden">
                    <div
                      className="h-full bg-[#5B8A6F] rounded-full transition-all duration-500"
                      style={{ width: `${Math.min((pollCount / 20) * 100, 90)}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-[#5B8A6F]/70">Check #{pollCount}</span>
                </div>
                <p className="text-[10px] text-[#5B8A6F]/60">
                  Checking every 15 seconds · No action needed from you
                </p>
              </div>

              {isProcessing && (
                <div className="flex items-center justify-center gap-2">
                  <Loader2 className="size-5 text-[#C96A2B] animate-spin" />
                  <span className="text-sm text-[#6B5744]">Processing your payment...</span>
                </div>
              )}
            </div>

            <div className="flex flex-col gap-2">
              {/* Reopen PayPal link */}
              <a href={PAYPAL_NCP_URL} target="_blank" rel="noopener noreferrer" className="w-full">
                <Button
                  variant="outline"
                  className="w-full border-[#003087]/30 text-[#003087] gap-2 hover:bg-[#003087]/5"
                >
                  <ExternalLink className="size-4" />
                  Reopen PayPal
                </Button>
              </a>

              <Button
                variant="ghost"
                size="sm"
                className="w-full text-[#9C8070]"
                onClick={() => {
                  if (pollTimerRef.current) clearInterval(pollTimerRef.current)
                  if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current)
                  setStep('form')
                  setError('')
                }}
              >
                <ArrowRight className="size-3.5 mr-1" />
                Return to Tools
              </Button>
            </div>

            {/* WhatsApp fallback — only shown after 3 minutes */}
            {showWhatsAppFallback && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-lg border border-amber-200 bg-amber-50/50 p-3 space-y-1.5"
              >
                <p className="text-xs font-medium text-amber-700">
                  Taking longer than expected?
                </p>
                <p className="text-xs text-amber-600/80 leading-relaxed">
                  If you completed your payment but it is not being detected, contact us on WhatsApp with your receipt and we will add your bonus manually.
                </p>
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Hi, I made a donation to ArtNew8 Studio but my bonus uses were not added. My payment receipt: [attach receipt here]')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block"
                >
                  <Button variant="outline" size="sm" className="gap-1.5 border-green-300 text-green-700 hover:bg-green-50 text-xs">
                    <MessageCircle className="size-3" />
                    Contact via WhatsApp
                  </Button>
                </a>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  // ═════════════════════════════════════════════════════════
  //  FAILED STATE
  // ═════════════════════════════════════════════════════════
  if (step === 'failed') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-lg mx-auto"
      >
        <Card className="border-amber-200">
          <CardContent className="pt-6 space-y-5 text-center">
            <div className="size-14 rounded-full bg-amber-100 flex items-center justify-center mx-auto">
              <MessageCircle className="size-7 text-amber-600" />
            </div>
            <h3 className="text-lg font-bold text-[#2C1810]">Verification Timeout</h3>
            <p className="text-sm text-[#6B5744] leading-relaxed">
              {error || 'We could not verify your payment automatically. If you completed your payment, please contact us via WhatsApp.'}
            </p>

            <div className="space-y-3">
              <Button
                className="w-full bg-[#C96A2B] hover:bg-[#A85420] text-white gap-2"
                onClick={() => { setError(''); setStep('form') }}
              >
                <RotateCcw className="size-4" />
                Try Again
              </Button>

              <Button
                variant="ghost"
                size="sm"
                className="w-full text-[#9C8070]"
                onClick={resetForm}
              >
                <ArrowRight className="size-3.5 mr-1" />
                Return to Tools
              </Button>
            </div>

            <Separator className="bg-[#DDD0C0]" />

            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Hi, I made a donation to ArtNew8 Studio but something went wrong. My payment receipt: [attach receipt here]')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block"
            >
              <Button variant="outline" size="sm" className="gap-1.5 border-green-300 text-green-700 hover:bg-green-50">
                <MessageCircle className="size-3.5" />
                Contact via WhatsApp
              </Button>
            </a>
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  // ═════════════════════════════════════════════════════════
  //  FORM STATE (Default)
  // ═════════════════════════════════════════════════════════
  return (
    <div className="space-y-10 max-w-3xl mx-auto">
      {/* Hero / Story */}
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-50px' }}
        variants={fadeInUp}
        transition={{ duration: 0.6 }}
        className="text-center max-w-2xl mx-auto"
      >
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="h-px flex-1 bg-gradient-to-r from-transparent to-[#C96A2B]/30" />
          <Badge variant="secondary" className="bg-[#C96A2B]/10 text-[#C96A2B] border-[#C96A2B]/20 px-3 py-1">
            <Heart className="size-3 fill-current mr-1" />
            Our Story
          </Badge>
          <div className="h-px flex-1 bg-gradient-to-l from-transparent to-[#C96A2B]/30" />
        </div>
        <blockquote className="text-base sm:text-lg leading-relaxed text-[#2C1810]/90 space-y-3">
          <p>
            We&apos;re not a tech company. We started as a blog about paper flowers and discovered
            that <span className="font-semibold text-[#C96A2B]">thousands of artisans</span> share
            the same pain: fees that eat profits, algorithms that hide products, and marketplaces
            that don&apos;t understand handmade.
          </p>
          <p className="font-medium text-[#2C1810]">
            This project is a fight for fairness for crafters everywhere.
          </p>
        </blockquote>
      </motion.div>

      {/* The Truth */}
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-50px' }}
        variants={fadeInUp}
        transition={{ duration: 0.6 }}
      >
        <Card className="border-[#C96A2B]/15 bg-gradient-to-br from-[#C96A2B]/[0.03] via-[#F5F0E8] to-[#C96A2B]/[0.03]">
          <CardContent className="pt-6 space-y-3">
            <div className="text-center mb-3">
              <Badge variant="outline" className="border-[#C96A2B]/30 text-[#C96A2B]">
                The Honest Truth
              </Badge>
            </div>
            <p className="text-[#2C1810]/85 leading-relaxed text-center">
              Nothing is truly free. Your craft materials cost money. Your time costs money. Our tools
              cost money too. The difference? <span className="font-semibold text-[#C96A2B]">We give you value first</span>,
              then ask for fair exchange.
            </p>
            <Separator className="my-3 bg-[#C96A2B]/10" />
            <p className="text-[#2C1810] font-medium leading-relaxed text-center">
              Every contribution goes toward building <span className="text-[#C96A2B]">a marketplace that belongs to crafters</span> —
              not corporations. Your donation registers you as a founding contributor with priority access.
            </p>
          </CardContent>
        </Card>
      </motion.div>

      {/* Donation Form */}
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-50px' }}
        variants={fadeInUp}
        transition={{ duration: 0.6 }}
      >
        <Card data-support-form className="border-[#DDD0C0]">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2 text-[#2C1810]">
              <Heart className="size-5 text-[#C96A2B]" />
              Support the Project
            </CardTitle>
            <CardDescription className="text-[#6B5744]">
              Donate any amount to become a founding contributor. You&apos;ll be redirected to PayPal to complete your payment.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <form onSubmit={(e) => { e.preventDefault(); openPayPal() }} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="support-form-name" className="text-xs text-[#2C1810]">
                    Name <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="support-form-name"
                    name="name"
                    placeholder="Your name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    required
                    className="h-9 bg-white border-[#DDD0C0] focus:border-[#C96A2B] focus:ring-[#C96A2B]/20"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="support-form-email" className="text-xs text-[#2C1810]">
                    Email <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="support-form-email"
                    name="email"
                    type="email"
                    placeholder="you@email.com"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    required
                    className="h-9 bg-white border-[#DDD0C0] focus:border-[#C96A2B] focus:ring-[#C96A2B]/20"
                  />
                </div>
              </div>

              {/* Amount selection */}
              <div className="space-y-1.5">
                <Label className="text-xs text-[#2C1810]">
                  Donation Amount <span className="text-destructive">*</span>
                </Label>
                <div className="flex flex-wrap gap-2">
                  {PRESET_AMOUNTS.map(preset => (
                    <Button
                      key={preset}
                      type="button"
                      variant={formData.amount === String(preset) ? 'default' : 'outline'}
                      size="sm"
                      className={
                        formData.amount === String(preset)
                          ? 'bg-[#C96A2B] hover:bg-[#A85420] text-white'
                          : 'border-[#DDD0C0] text-[#6B5744] hover:border-[#C96A2B]/40 hover:text-[#C96A2B]'
                      }
                      onClick={() => setFormData(prev => ({ ...prev, amount: String(preset) }))}
                    >
                      ${preset}
                    </Button>
                  ))}
                  <div className="flex items-center gap-1">
                    <span className="text-xs text-[#9C8070]">$</span>
                    <Input
                      type="number"
                      min="1"
                      step="0.01"
                      placeholder="Custom"
                      value={!PRESET_AMOUNTS.includes(Number(formData.amount)) ? formData.amount : ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                      className="h-8 w-20 text-sm bg-white border-[#DDD0C0] focus:border-[#C96A2B] focus:ring-[#C96A2B]/20"
                    />
                  </div>
                </div>
              </div>

              {/* Bonus preview */}
              {formData.amount && parseFloat(formData.amount) >= 1 && <BonusPreview amount={formData.amount} />}

              {/* Message */}
              <div className="space-y-1.5">
                <Label htmlFor="support-form-message" className="text-xs text-[#2C1810]">
                  Message <span className="text-[#9C8070]">(optional)</span>
                </Label>
                <Textarea
                  id="support-form-message"
                  name="message"
                  placeholder="Leave a message or tell us what tool you'd love next..."
                  value={formData.message}
                  onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                  rows={2}
                  className="bg-white border-[#DDD0C0] focus:border-[#C96A2B] focus:ring-[#C96A2B]/20 text-sm resize-none"
                />
              </div>

              {/* Error */}
              {error && (
                <div className="p-2.5 rounded-lg bg-destructive/10 border border-destructive/20 text-xs text-destructive text-center">
                  {error}
                </div>
              )}

              {/* Submit button */}
              <Button
                type="submit"
                className="w-full bg-[#C96A2B] hover:bg-[#A85420] text-white gap-2 h-11 rounded-lg"
                disabled={!formData.name || !formData.email || !formData.amount || parseFloat(formData.amount) < 1}
              >
                <Heart className="size-4 fill-current" />
                Continue to PayPal
                <ArrowRight className="size-4" />
              </Button>

              <p className="text-[11px] text-[#9C8070] text-center leading-relaxed">
                You&apos;ll be redirected to PayPal to complete your payment securely.
                Bonus uses are added automatically after payment is confirmed.
              </p>
            </form>
          </CardContent>
        </Card>
      </motion.div>

      {/* Bonus Tiers */}
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-50px' }}
        variants={fadeInUp}
        transition={{ duration: 0.6 }}
      >
        <Card className="border-[#DDD0C0]">
          <CardContent className="pt-5">
            <h4 className="text-sm font-bold text-[#2C1810] text-center mb-4">Donation Tiers</h4>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {[
                { emoji: '🌱', name: 'Seedling', range: '$1–4', bonus: '+5' },
                { emoji: '🌸', name: 'Friend', range: '$5–9', bonus: '+10' },
                { emoji: '💎', name: 'Supporter', range: '$10–24', bonus: '+20' },
                { emoji: '⭐', name: 'Hero', range: '$25–49', bonus: '+30' },
                { emoji: '🏆', name: 'Champion', range: '$50+', bonus: '+50' },
              ].map(tier => (
                <div key={tier.name} className="text-center p-2 rounded-lg bg-[#F5F0E8]/60">
                  <span className="text-2xl">{tier.emoji}</span>
                  <p className="text-xs font-semibold text-[#2C1810] mt-1">{tier.name}</p>
                  <p className="text-[10px] text-[#9C8070]">{tier.range}</p>
                  <p className="text-xs font-bold text-[#C96A2B]">{tier.bonus} uses</p>
                </div>
              ))}
            </div>
            <div className="mt-3 flex items-center justify-center gap-1.5 text-xs text-[#5B8A6F]">
              <Shield className="size-3.5" />
              <span>Bonus uses carry over across days</span>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
