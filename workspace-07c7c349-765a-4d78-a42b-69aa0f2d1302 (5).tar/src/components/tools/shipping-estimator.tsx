'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import {
  Truck,
  Package,
  Scale,
  Globe,
  ChevronRight,
  Info,
  MapPin,
  DollarSign,
  Shield,
  Copy,
  Check,
  Lightbulb,
  Clock,
  Gift,
  Download,
  FileText,
  AlertCircle,
  Box,
} from 'lucide-react'
import { useUsageTracker } from '@/hooks/use-usage-tracker'
import { useSharedData } from '@/hooks/use-shared-data'
import {
  SHIPPING_RATES,
  SHIPPING_ZONES,
  PACKAGE_SIZES,
  CUSTOMS_TIPS,
  DOMESTIC_RATES,
} from '@/lib/shipping-data'
import { LimitPopup } from '@/components/support/limit-popup'
import { ToolDonationPrompt } from '@/components/support/tool-donation-prompt'
import { downloadAsImage, downloadAsPDF } from '@/lib/export-utils'
import { toast } from '@/hooks/use-toast'

type DestinationZone = 'us' | 'uk' | 'eu' | 'ca' | 'au'

const ORIGIN_COUNTRIES = [
  { value: 'us', label: 'United States', flag: '🇺🇸' },
  { value: 'uk', label: 'United Kingdom', flag: '🇬🇧' },
  { value: 'eu', label: 'European Union', flag: '🇪🇺' },
  { value: 'ca', label: 'Canada', flag: '🇨🇦' },
  { value: 'au', label: 'Australia', flag: '🇦🇺' },
]

const DELIVERY_TIMES: Record<string, Record<string, string>> = {
  us: { us: '2-5 days', uk: '7-14 days', eu: '7-14 days', ca: '5-10 days', au: '10-20 days' },
  uk: { us: '7-14 days', uk: '2-3 days', eu: '3-5 days', ca: '7-14 days', au: '10-20 days' },
  eu: { us: '7-14 days', uk: '3-5 days', eu: '2-5 days', ca: '7-14 days', au: '10-20 days' },
  ca: { us: '5-10 days', uk: '7-14 days', eu: '7-14 days', ca: '2-5 days', au: '10-20 days' },
  au: { us: '10-20 days', uk: '10-20 days', eu: '10-20 days', ca: '10-20 days', au: '2-5 days' },
}

const IMPORT_DUTY_INFO: Record<string, {
  deMinimis: string
  deMinimisValue: number
  dutyRate: number
  taxRate: number
  taxLabel: string
  currency: string
}> = {
  uk: { deMinimis: '£135', deMinimisValue: 135, dutyRate: 0.025, taxRate: 0.20, taxLabel: 'VAT', currency: 'GBP' },
  eu: { deMinimis: '€150', deMinimisValue: 150, dutyRate: 0.025, taxRate: 0.21, taxLabel: 'VAT', currency: 'EUR' },
  ca: { deMinimis: 'CAD $20', deMinimisValue: 20, dutyRate: 0.04, taxRate: 0.05, taxLabel: 'GST', currency: 'CAD' },
  au: { deMinimis: 'AUD $1000', deMinimisValue: 1000, dutyRate: 0.025, taxRate: 0.10, taxLabel: 'GST', currency: 'AUD' },
}

const PACKAGING_TIPS = [
  { title: 'Bubble Wrap Protection', tip: 'Wrap fragile items in at least 2 layers of small bubble wrap. For extra fragile items, use large bubble wrap as an outer layer.' },
  { title: 'Double-Box Technique', tip: 'Place your item in a smaller box with cushioning, then place that box inside a larger box with more padding. This absorbs impacts during transit.' },
  { title: 'Fill Empty Spaces', tip: 'Use packing peanuts, crumpled paper, or air pillows to fill all empty spaces. Items shift during transit and can break if they move.' },
  { title: 'Rigid Mailers for Cards', tip: 'Use rigid cardboard mailers for greeting cards and flat paper goods. Add a "Do Not Bend" sticker on both sides.' },
  { title: 'Seal Securely', tip: 'Use strong packing tape on all seams. H-taping (tape across all edges) prevents boxes from popping open during handling.' },
  { title: 'Mark as Fragile', tip: 'Write "FRAGILE" clearly on multiple sides of the package. While not always honored by carriers, it does encourage more careful handling.' },
  { title: 'Waterproof Protection', tip: 'Place paper goods and textiles in a clear plastic bag before boxing. This protects against rain, spills, and humidity during transit.' },
  { title: 'Weight Distribution', tip: 'Place heavier items at the bottom and lighter items on top. This prevents crushing and maintains balance for safer stacking.' },
]

const AUTO_SAVE_KEY = 'artnew8-shipping-state'

interface ShippingFormState {
  originCountry: string
  destinationZone: string
  selectedPackage: string
  customWeight: string
  activeWeight: number | null
  multiMode: boolean
  selectedZones: string[]
  itemPrice: string
}

function getRateForWeight(weightGrams: number, zone: DestinationZone): number | null {
  for (const rate of SHIPPING_RATES) {
    if (weightGrams <= rate.weightMax) {
      return rate[zone]
    }
  }
  return null
}

function getDomesticRate(weightGrams: number): number | null {
  for (const rate of DOMESTIC_RATES.us) {
    if (weightGrams <= rate.weightMax) {
      return rate.rate
    }
  }
  return null
}

function getCategoryForWeight(weightGrams: number): string {
  for (const rate of SHIPPING_RATES) {
    if (weightGrams <= rate.weightMax) {
      return rate.category
    }
  }
  return 'Extra Large'
}

function getZoneFlag(zoneName: string): string {
  return zoneName === 'United States' ? '🇺🇸'
    : zoneName === 'United Kingdom' ? '🇬🇧'
    : zoneName === 'European Union' ? '🇪🇺'
    : zoneName === 'Canada' ? '🇨🇦'
    : '🇦🇺'
}

function getZoneKey(zoneName: string): string {
  return zoneName === 'United States' ? 'us'
    : zoneName === 'United Kingdom' ? 'uk'
    : zoneName === 'European Union' ? 'eu'
    : zoneName === 'Canada' ? 'ca'
    : 'au'
}

export function ShippingEstimator({ onSupportClick }: { onSupportClick: () => void }) {
  const { incrementUsage, canUse, getRemaining } = useUsageTracker()
  const { data: sharedData, updateFromShipping } = useSharedData()

  const [originCountry, setOriginCountry] = useState<string>('us')
  const [destinationZone, setDestinationZone] = useState<string>('')
  const [selectedPackage, setSelectedPackage] = useState<string>('')
  const [customWeight, setCustomWeight] = useState<string>('')
  const [activeWeight, setActiveWeight] = useState<number | null>(null)
  const [results, setResults] = useState<{
    single: { zone: DestinationZone; cost: number; category: string } | null
    comparison: { zone: DestinationZone; name: string; cost: number | null; isDomestic: boolean }[]
  } | null>(null)
  const [copiedZone, setCopiedZone] = useState<string | null>(null)
  const [showLimitPopup, setShowLimitPopup] = useState(false)

  // New state
  const [multiMode, setMultiMode] = useState(false)
  const [selectedZones, setSelectedZones] = useState<string[]>([])
  const [itemPrice, setItemPrice] = useState<string>('')
  const [declaredValue, setDeclaredValue] = useState<string>('')
  const [dutyZone, setDutyZone] = useState<string>('uk')
  const [showAutoSaved, setShowAutoSaved] = useState(false)
  const [exportingImage, setExportingImage] = useState(false)
  const [exportingPDF, setExportingPDF] = useState(false)

  const initialized = useRef(false)

  // Auto-restore from localStorage
  useEffect(() => {
    if (initialized.current) return
    initialized.current = true
    try {
      const saved = localStorage.getItem(AUTO_SAVE_KEY)
      if (saved) {
        const data: ShippingFormState = JSON.parse(saved)
        if (data.originCountry) setOriginCountry(data.originCountry)
        if (data.destinationZone) setDestinationZone(data.destinationZone)
        if (data.selectedPackage) setSelectedPackage(data.selectedPackage)
        if (data.customWeight) setCustomWeight(data.customWeight)
        if (data.activeWeight) setActiveWeight(data.activeWeight)
        if (data.multiMode) setMultiMode(data.multiMode)
        if (data.selectedZones?.length) setSelectedZones(data.selectedZones)
        if (data.itemPrice) setItemPrice(data.itemPrice)
      }
    } catch { /* ignore */ }
  }, [])

  // Auto-save to localStorage (debounced)
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        const state: ShippingFormState = {
          originCountry,
          destinationZone,
          selectedPackage,
          customWeight,
          activeWeight,
          multiMode,
          selectedZones,
          itemPrice,
        }
        localStorage.setItem(AUTO_SAVE_KEY, JSON.stringify(state))
        setShowAutoSaved(true)
        setTimeout(() => setShowAutoSaved(false), 2000)
      } catch { /* ignore */ }
    }, 1000)
    return () => clearTimeout(timer)
  }, [originCountry, destinationZone, selectedPackage, customWeight, activeWeight, multiMode, selectedZones, itemPrice])

  // Pre-fill item price from shared data
  useEffect(() => {
    if (sharedData.sellingPrice && !itemPrice) {
      setItemPrice(sharedData.sellingPrice.toFixed(2))
    }
  }, [sharedData.sellingPrice, itemPrice])

  const handlePackageSelect = useCallback((pkgName: string) => {
    const pkg = PACKAGE_SIZES.find((p) => p.name === pkgName)
    if (pkg) {
      setSelectedPackage(pkgName === selectedPackage ? '' : pkgName)
      setCustomWeight('')
      setActiveWeight(pkg.weight)
    }
  }, [selectedPackage])

  const handleCustomWeightChange = useCallback((value: string) => {
    setCustomWeight(value)
    setSelectedPackage('')
    const num = parseFloat(value)
    if (!isNaN(num) && num > 0) {
      setActiveWeight(num)
    } else {
      setActiveWeight(null)
    }
  }, [])

  const calculateShipping = useCallback(() => {
    if (!activeWeight || activeWeight <= 0) return
    if (!canUse()) {
      setShowLimitPopup(true)
      return
    }

    const success = incrementUsage('shipping', 'calculate')
    if (!success) {
      setShowLimitPopup(true)
      return
    }

    const category = getCategoryForWeight(activeWeight)
    const origin = originCountry as DestinationZone

    const comparison = SHIPPING_ZONES.map((zone) => {
      const zoneKey = getZoneKey(zone.name) as DestinationZone
      const isDomestic = zoneKey === origin
      const cost = isDomestic ? getDomesticRate(activeWeight) : getRateForWeight(activeWeight, zoneKey)

      return {
        zone: zoneKey,
        name: zone.name,
        cost,
        isDomestic,
      }
    })

    let single = null
    if (!multiMode && destinationZone) {
      const destZone = destinationZone as DestinationZone
      const isDomestic = destZone === origin
      const cost = isDomestic
        ? getDomesticRate(activeWeight)
        : getRateForWeight(activeWeight, destZone)
      single = {
        zone: destZone,
        cost: cost ?? 0,
        category,
      }
      // Update shared data
      updateFromShipping({
        shippingCost: cost ?? 0,
        destinationZone: destZone,
        packageWeight: activeWeight,
      })
    } else if (multiMode && selectedZones.length > 0) {
      // Use the first selected zone for shared data
      const firstZone = selectedZones[0] as DestinationZone
      const isDomestic = firstZone === origin
      const cost = isDomestic ? getDomesticRate(activeWeight) : getRateForWeight(activeWeight, firstZone)
      updateFromShipping({
        shippingCost: cost ?? 0,
        destinationZone: firstZone,
        packageWeight: activeWeight,
      })
    }

    setResults({ single, comparison })
  }, [activeWeight, originCountry, destinationZone, multiMode, selectedZones, canUse, incrementUsage, updateFromShipping])

  const copyCost = useCallback((zone: string, cost: number | null) => {
    if (cost === null) return
    const text = `Shipping to ${zone}: $${cost.toFixed(2)} USD`
    navigator.clipboard.writeText(text)
    setCopiedZone(zone)
    setTimeout(() => setCopiedZone(null), 1500)
  }, [])

  const toggleZone = useCallback((zoneKey: string) => {
    setSelectedZones(prev =>
      prev.includes(zoneKey)
        ? prev.filter(z => z !== zoneKey)
        : [...prev, zoneKey]
    )
  }, [])

  const handleExportImage = async () => {
    setExportingImage(true)
    try {
      await downloadAsImage('shipping-results', 'shipping-estimate')
      toast({ title: 'Image downloaded', description: 'Shipping estimate saved as image' })
    } catch (err) {
      console.error('Image export failed:', err)
      toast({ title: 'Export failed', description: 'Could not generate image. Please try again.', variant: 'destructive' })
    } finally {
      setExportingImage(false)
    }
  }

  const handleExportPDF = async () => {
    setExportingPDF(true)
    try {
      await downloadAsPDF('shipping-results', 'shipping-estimate')
      toast({ title: 'PDF downloaded', description: 'Shipping estimate saved as PDF' })
    } catch (err) {
      console.error('PDF export failed:', err)
      toast({ title: 'Export failed', description: 'Could not generate PDF. Please try again.', variant: 'destructive' })
    } finally {
      setExportingPDF(false)
    }
  }

  const remaining = getRemaining()
  const priceNum = parseFloat(itemPrice) || 0

  // Filter comparison for multi-destination mode
  const displayComparison = results?.comparison.filter(item =>
    !multiMode || selectedZones.length === 0 || selectedZones.includes(item.zone)
  ) ?? []

  return (
    <Card className="w-full">
      {/* Limit Popup */}
      <LimitPopup
        open={showLimitPopup}
        onClose={() => setShowLimitPopup(false)}
        onSupportClick={onSupportClick}
        remaining={remaining}
      />

      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Truck className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-xl">Shipping Cost Estimator</CardTitle>
              <CardDescription>
                Estimate international shipping costs for your handmade crafts
              </CardDescription>
            </div>
          </div>
          {showAutoSaved && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground animate-in fade-in duration-300">
              <Check className="h-3 w-3 text-green-600" />
              Auto-saved
            </div>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Origin & Mode Toggle */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5 text-base font-medium">
              <Globe className="h-4 w-4 text-muted-foreground" />
              Shipping From
            </Label>
            <Select value={originCountry} onValueChange={setOriginCountry}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select origin" />
              </SelectTrigger>
              <SelectContent>
                {ORIGIN_COUNTRIES.map((country) => (
                  <SelectItem key={country.value} value={country.value}>
                    {country.flag} {country.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="flex items-center gap-1.5 text-base font-medium">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                {multiMode ? 'Select Destinations' : 'Shipping To'}
              </Label>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Multiple</span>
                <Switch
                  checked={multiMode}
                  onCheckedChange={setMultiMode}
                  className="scale-75"
                />
              </div>
            </div>

            {multiMode ? (
              <div className="space-y-2 rounded-md border p-3">
                {SHIPPING_ZONES.map((zone) => {
                  const zoneKey = getZoneKey(zone.name)
                  const flag = getZoneFlag(zone.name)
                  const isDomestic = zoneKey === originCountry
                  return (
                    <div key={zoneKey} className="flex items-center gap-2">
                      <Checkbox
                        id={`zone-${zoneKey}`}
                        checked={selectedZones.includes(zoneKey)}
                        onCheckedChange={() => toggleZone(zoneKey)}
                      />
                      <Label
                        htmlFor={`zone-${zoneKey}`}
                        className="text-sm cursor-pointer flex-1"
                      >
                        {flag} {zone.name}
                        {isDomestic && (
                          <Badge variant="secondary" className="ml-2 text-xs shrink-0">Domestic</Badge>
                        )}
                      </Label>
                    </div>
                  )
                })}
                {selectedZones.length > 0 && (
                  <p className="text-xs text-muted-foreground">
                    {selectedZones.length} destination{selectedZones.length > 1 ? 's' : ''} selected
                  </p>
                )}
              </div>
            ) : (
              <Select value={destinationZone} onValueChange={setDestinationZone}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select destination (or compare all)" />
                </SelectTrigger>
                <SelectContent>
                  {SHIPPING_ZONES.map((zone) => {
                    const flag = getZoneFlag(zone.name)
                    const zoneKey = getZoneKey(zone.name)
                    const isDomestic = zoneKey === originCountry
                    return (
                      <SelectItem key={zone.name} value={zoneKey}>
                        {flag} {zone.name}
                        {isDomestic && ' (Domestic)'}
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>
            )}
          </div>
        </div>

        <Separator />

        {/* Package Size Quick Select */}
        <div className="space-y-3">
          <Label className="flex items-center gap-1.5 text-base font-medium">
            <Package className="h-4 w-4 text-muted-foreground" />
            Quick Select Package Size
          </Label>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {PACKAGE_SIZES.map((pkg) => (
              <Tooltip key={pkg.name}>
                <TooltipTrigger asChild>
                  <Button
                    variant={selectedPackage === pkg.name ? 'default' : 'outline'}
                    size="sm"
                    className="h-auto flex-col gap-0.5 py-3 text-xs"
                    onClick={() => handlePackageSelect(pkg.name)}
                  >
                    <span className="font-medium leading-tight">{pkg.name}</span>
                    <span className="text-xs opacity-70">{pkg.weight}g</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{pkg.category} · {pkg.weight}g</p>
                </TooltipContent>
              </Tooltip>
            ))}
          </div>
        </div>

        {/* Custom Weight */}
        <div className="space-y-2">
          <Label className="flex items-center gap-1.5 text-base font-medium">
            <Scale className="h-4 w-4 text-muted-foreground" />
            Or Enter Custom Weight
          </Label>
          <div className="flex items-center gap-2">
            <Input
              type="number"
              placeholder="Enter weight"
              value={customWeight}
              onChange={(e) => handleCustomWeightChange(e.target.value)}
              min={1}
              max={2000}
              className="w-full sm:w-40"
            />
            <span className="text-sm sm:text-base text-muted-foreground">grams</span>
            {activeWeight && (
              <Badge variant="secondary" className="ml-2">
                {getCategoryForWeight(activeWeight)}
              </Badge>
            )}
          </div>
        </div>

        <Separator />

        {/* Calculate Button */}
        <div className="flex items-center justify-between">
          <Button
            onClick={calculateShipping}
            disabled={!activeWeight || activeWeight <= 0 || !canUse()}
            className="gap-2"
          >
            <DollarSign className="h-4 w-4" />
            Calculate Shipping
          </Button>
          <span className="text-xs text-muted-foreground">
            {remaining}/20 uses remaining today
          </span>
        </div>

        {/* Shared Data Banner */}
        {sharedData.sellingPrice && results && (
          <div className="flex items-start gap-2 p-3 rounded-lg bg-primary/5 border border-primary/10">
            <AlertCircle className="size-4 text-primary shrink-0 mt-0.5" />
            <div className="text-sm text-primary space-y-1">
              <p>
                Your selling price is <strong>${sharedData.sellingPrice.toFixed(2)}</strong>
                {results.single && (
                  <> — shipping to {results.single.zone.toUpperCase()} would cost <strong>${results.single.cost.toFixed(2)}</strong> ({((results.single.cost / sharedData.sellingPrice) * 100).toFixed(1)}% of price)</>
                )}
              </p>
              <p className="text-muted-foreground">
                Consider adding shipping cost to your price for &ldquo;free shipping&rdquo; listings.
              </p>
            </div>
          </div>
        )}

        {/* Results */}
        {results && (
          <div className="space-y-4" id="shipping-results">
            {/* Single Destination Result */}
            {results.single && (
              <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-base text-muted-foreground">Estimated cost to ship</p>
                    <p className="text-3xl font-bold text-primary">
                      ${results.single.cost.toFixed(2)} USD
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Category: {results.single.category} · Weight: {activeWeight}g
                      {DELIVERY_TIMES[originCountry]?.[results.single.zone] && (
                        <> · Est. delivery: {DELIVERY_TIMES[originCountry][results.single.zone]}</>
                      )}
                    </p>
                  </div>
                  <Tooltip data-export-ignore>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 shrink-0"
                        onClick={() => copyCost(results.single!.zone, results.single!.cost)}
                      >
                        {copiedZone === results.single.zone ? (
                          <Check className="h-4 w-4 text-green-600" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Copy cost</TooltipContent>
                  </Tooltip>
                </div>
              </div>
            )}

            {/* Comparison Table */}
            <div className="space-y-2">
              <h4 className="text-base font-medium flex items-center gap-1.5">
                <ChevronRight className="h-4 w-4 text-primary" />
                {multiMode ? 'Selected Destinations Comparison' : 'Compare All Destinations'}
              </h4>
              <div className="rounded-lg border overflow-x-auto -mx-2 px-2 sm:mx-0 sm:px-0">
                <table className="w-full text-sm sm:text-base min-w-[320px] sm:min-w-[480px]">
                  <thead>
                    <tr className="bg-muted/50">
                      <th className="px-3 py-2 text-left font-medium">Destination</th>
                      <th className="px-3 py-2 text-left font-medium">Type</th>
                      <th className="px-3 py-2 text-right font-medium">Est. Cost</th>
                      <th className="px-3 py-2 text-left font-medium">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Delivery
                        </span>
                      </th>
                      <th className="px-3 py-2 w-8"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {displayComparison.map((item, i) => (
                      <tr
                        key={item.zone}
                        className={`border-t ${i % 2 === 0 ? '' : 'bg-muted/20'} ${
                          !multiMode && destinationZone === item.zone ? 'bg-primary/5' : ''
                        }`}
                      >
                        <td className="px-3 py-2 font-medium">{item.name}</td>
                        <td className="px-3 py-2">
                          <Badge variant={item.isDomestic ? 'default' : 'outline'} className="text-xs min-w-[20px] text-center">
                            {item.isDomestic ? 'Domestic' : 'Intl'}
                          </Badge>
                        </td>
                        <td className="px-3 py-2 text-right font-semibold">
                          {item.cost !== null ? `$${item.cost.toFixed(2)}` : 'N/A'}
                        </td>
                        <td className="px-3 py-2 text-sm text-muted-foreground">
                          {DELIVERY_TIMES[originCountry]?.[item.zone] || '—'}
                        </td>
                        <td className="px-3 py-1" data-export-ignore>
                          {item.cost !== null && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => copyCost(item.zone, item.cost)}
                            >
                              {copiedZone === item.zone ? (
                                <Check className="h-3 w-3 text-green-600" />
                              ) : (
                                <Copy className="h-3 w-3" />
                              )}
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Import Duty Calculator */}
            <Accordion type="multiple" className="w-full">
              <AccordionItem value="import-duty">
                <AccordionTrigger className="text-base">
                  <span className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-primary" />
                    Customs & Import Duty Calculator
                  </span>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4">
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Destination for Duty Calc</Label>
                        <Select value={dutyZone} onValueChange={setDutyZone}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select zone" />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(IMPORT_DUTY_INFO).map(([key, info]) => (
                              <SelectItem key={key} value={key}>
                                {key.toUpperCase()} — De minimis: {info.deMinimis}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Declared Value (USD)</Label>
                        <Input
                          type="number"
                          placeholder="e.g., 50"
                          value={declaredValue}
                          onChange={(e) => setDeclaredValue(e.target.value)}
                          min={0}
                          className="w-full"
                        />
                      </div>
                    </div>
                    {declaredValue && parseFloat(declaredValue) > 0 && (() => {
                      const info = IMPORT_DUTY_INFO[dutyZone]
                      if (!info) return null
                      const value = parseFloat(declaredValue)
                      const isUnderDeMinimis = value < info.deMinimisValue
                      const duty = isUnderDeMinimis ? 0 : value * info.dutyRate
                      const taxableAmount = value + duty
                      const tax = isUnderDeMinimis ? 0 : taxableAmount * info.taxRate
                      const totalImportCost = duty + tax

                      return (
                        <div className="rounded-md border p-3 space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="text-sm sm:text-base font-medium">{dutyZone.toUpperCase()} Import Estimate</span>
                            <Badge variant={isUnderDeMinimis ? 'default' : 'destructive'} className="text-xs shrink-0">
                              {isUnderDeMinimis ? 'Under de minimis' : 'Dutiable'}
                            </Badge>
                          </div>
                          {isUnderDeMinimis ? (
                            <p className="text-sm text-muted-foreground">
                              Under {info.deMinimis} threshold — no duty or {info.taxLabel} applies
                            </p>
                          ) : (
                            <div className="text-sm space-y-0.5 text-muted-foreground">
                              <p>Est. Duty: ~${duty.toFixed(2)} ({(info.dutyRate * 100).toFixed(1)}%)</p>
                              <p>Est. {info.taxLabel}: ~${tax.toFixed(2)} ({(info.taxRate * 100).toFixed(0)}%)</p>
                              <p className="font-medium text-foreground">
                                Total import cost: ~${totalImportCost.toFixed(2)} ({((totalImportCost / value) * 100).toFixed(1)}%)
                              </p>
                            </div>
                          )}
                        </div>
                      )
                    })()}
                    <p className="text-sm text-muted-foreground break-words">
                      Estimates only. Actual duty rates vary by product category (HS code). Handmade crafts often qualify for lower rates.
                    </p>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Free Shipping Strategy */}
              <AccordionItem value="free-shipping">
                <AccordionTrigger className="text-base">
                  <span className="flex items-center gap-2">
                    <Gift className="h-4 w-4 text-primary" />
                    Free Shipping Strategy
                  </span>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Your Selling Price (USD)</Label>
                      <Input
                        type="number"
                        placeholder="e.g., 25.00"
                        value={itemPrice}
                        onChange={(e) => setItemPrice(e.target.value)}
                        min={0}
                        step="0.01"
                        className="w-full sm:w-40"
                      />
                      {sharedData.sellingPrice && !itemPrice && (
                        <p className="text-sm text-muted-foreground">
                          From Pricing Calculator: ${sharedData.sellingPrice.toFixed(2)}
                        </p>
                      )}
                    </div>
                    {priceNum > 0 && results && (
                      <div className="space-y-2">
                        {results.comparison.map((item) => {
                          if (item.cost === null) return null
                          const freeShipPrice = priceNum + item.cost
                          const shippingPercent = ((item.cost / freeShipPrice) * 100).toFixed(1)
                          return (
                            <div key={item.zone} className="rounded-md border p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                              <div className="text-sm sm:text-base min-w-0">
                                <span className="font-medium">{item.name}</span>
                                <span className="text-muted-foreground text-xs sm:text-sm ml-2">
                                  Shipping: ${item.cost.toFixed(2)}
                                </span>
                              </div>
                              <div className="text-right shrink-0">
                                <p className="text-sm sm:text-base font-semibold text-primary">
                                  ${freeShipPrice.toFixed(2)}
                                </p>
                                <p className="text-xs sm:text-sm text-muted-foreground">
                                  Shipping is {shippingPercent}% of total
                                </p>
                              </div>
                            </div>
                          )
                        })}
                        <div className="flex items-start gap-2 p-2 rounded-md bg-primary/5">
                          <Lightbulb className="size-3.5 text-primary shrink-0 mt-0.5" />
                          <p className="text-sm text-primary">
                            Set your price to include shipping and offer &ldquo;free shipping&rdquo; — buyers are 60% more likely to purchase when shipping appears free.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Customs Tips - existing */}
              {SHIPPING_ZONES.map((zone) => {
                const zoneKey = getZoneKey(zone.name) === 'us' ? 'US'
                  : getZoneKey(zone.name) === 'uk' ? 'UK'
                  : getZoneKey(zone.name) === 'eu' ? 'EU'
                  : getZoneKey(zone.name) === 'ca' ? 'CA'
                  : 'AU'
                const tips = CUSTOMS_TIPS[zoneKey]
                if (!tips) return null

                return (
                  <AccordionItem key={zoneKey} value={`customs-${zoneKey}`}>
                    <AccordionTrigger className="text-base">
                      <span className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-primary" />
                        Customs Tips for {zone.name}
                      </span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <ul className="space-y-1.5">
                        {tips.map((tip, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm sm:text-base text-muted-foreground">
                            <Info className="h-3.5 w-3.5 mt-0.5 shrink-0 text-primary" />
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                )
              })}
            </Accordion>

            {/* Packaging Tips */}
            <div className="space-y-3">
              <h4 className="text-sm sm:text-base font-medium flex items-center gap-1.5">
                <Box className="h-4 w-4 text-primary shrink-0" />
                <span>Packaging Tips for Fragile Handmade Items</span>
              </h4>
              <div className="grid gap-2 sm:grid-cols-2 max-h-64 overflow-y-auto">
                {PACKAGING_TIPS.map((tip, i) => (
                  <div key={i} className="rounded-md border p-3 space-y-1">
                    <p className="text-sm font-medium">{tip.title}</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{tip.tip}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Export Buttons */}
            <div className="flex flex-wrap gap-2" data-export-ignore>
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 text-xs"
                onClick={handleExportImage}
                disabled={exportingImage}
              >
                <Download className="h-3.5 w-3.5" />
                {exportingImage ? 'Exporting...' : 'Download as Image'}
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 text-xs"
                onClick={handleExportPDF}
                disabled={exportingPDF}
              >
                <FileText className="h-3.5 w-3.5" />
                {exportingPDF ? 'Exporting...' : 'Download as PDF'}
              </Button>
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter className="flex-col gap-2">
        <div className="flex items-start gap-2 p-3 rounded-lg bg-primary/5 border border-primary/10 w-full">
          <Lightbulb className="size-4 text-primary shrink-0 mt-0.5" />
          <p className="text-sm text-primary">
            Pro tip: Consider including shipping costs in your product price and offering &ldquo;free shipping&rdquo; — buyers are more likely to purchase when shipping appears free.
          </p>
        </div>
        <p className="text-sm text-muted-foreground/80 text-center">
          Estimates are approximate and based on standard postal rates. Actual costs may vary by carrier and service.
        </p>
      </CardFooter>

      {/* Donation prompt - shown after results */}
      {results && (
        <ToolDonationPrompt onSupportClick={onSupportClick} />
      )}
    </Card>
  )
}
