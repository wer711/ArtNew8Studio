'use client'

import { useState, useMemo, useCallback, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  TAG_CATEGORIES,
  getSeasonalTags,
  ETSY_MAX_TAGS,
  ETSY_TITLE_MAX_CHARS,
  estimateTagMeta,
  getAllTags,
  type TagCategory,
  type TagMeta,
} from '@/lib/tag-database'
import { useUsageTracker } from '@/hooks/use-usage-tracker'
import { useSharedData } from '@/hooks/use-shared-data'
import { createAutoSave, downloadAsImage, downloadAsPDF, downloadAsCSV } from '@/lib/export-utils'
import { toast } from '@/hooks/use-toast'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import { Progress } from '@/components/ui/progress'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Tooltip,
  TooltipTrigger,
  TooltipContent,
} from '@/components/ui/tooltip'
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '@/components/ui/accordion'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  Copy,
  Save,
  Trash2,
  ChevronUp,
  ChevronDown,
  Tag,
  Sparkles,
  FolderOpen,
  X,
  RotateCcw,
  TrendingUp,
  FileText,
  ImageIcon,
  Hash,
  AlertTriangle,
  CheckCircle2,
  Lightbulb,
  Zap,
  Package,
  Flower2,
  Gem,
  Flame,
  Gift,
  Plus,
  ArrowUp,
  ArrowDown,
  Minus,
  Download,
  FileSpreadsheet,
  Calendar,
  BarChart3,
  Target,
  ShoppingBag,
  Globe,
  Beaker,
  Scissors,
  TreePine,
  Droplets,
  Paintbrush,
  Dog,
  Sprout,
  Box,
  LayoutGrid,
  CircleDot,
} from 'lucide-react'
import { LimitPopup } from '@/components/support/limit-popup'
import { ToolDonationPrompt } from '@/components/support/tool-donation-prompt'

// ─── Types ───────────────────────────────────────────────────────────────────

interface TagSet {
  id: string
  name: string
  tags: string[]
  description?: string
  savedAt: string
}

interface AutoSaveData {
  description: string
  selectedTags: string[]
  customTagInput: string
}

interface ProductTemplate {
  id: string
  name: string
  icon: React.ReactNode
  description: string
  tags: string[]
}

// ─── Constants ───────────────────────────────────────────────────────────────

const STORAGE_KEY = 'artnew8-tag-sets'
const AUTO_SAVE_KEY = 'artnew8-tag-auto-save-v2'

// ─── Product Templates (15+) ─────────────────────────────────────────────────

const PRODUCT_TEMPLATES: ProductTemplate[] = [
  {
    id: 'greeting-cards',
    name: 'Greeting Cards',
    icon: <Gift className="size-4" />,
    description: 'Handmade greeting card with personalized message',
    tags: ['handmade card', 'greeting card', 'birthday card', 'handmade', 'paper', 'cardstock', 'handcrafted', 'personalized gift', 'for her', 'unique gift'],
  },
  {
    id: 'paper-flowers',
    name: 'Paper Flowers',
    icon: <Flower2 className="size-4" />,
    description: 'Handmade paper flower bouquet with crepe paper roses',
    tags: ['paper flowers', 'paper bouquet', 'paper rose', 'crepe paper', 'handmade', 'paper craft', 'wedding', 'floral card', 'spring', 'home decor'],
  },
  {
    id: 'jewelry',
    name: 'Jewelry',
    icon: <Gem className="size-4" />,
    description: 'Handcrafted beaded jewelry with gemstone and wire wrapping',
    tags: ['handmade jewelry', 'beaded', 'gemstone', 'wire wrapped', 'handcrafted', 'for her', 'gift for her', 'unique gift', 'artisan made', 'luxury'],
  },
  {
    id: 'candles',
    name: 'Candles',
    icon: <Flame className="size-4" />,
    description: 'Hand-poured soy candle with essential oils and dried flowers',
    tags: ['soy candle', 'handmade candle', 'aromatherapy', 'essential oils', 'eco friendly', 'sustainable', 'dried flowers', 'home decor', 'gift for her', 'relaxation'],
  },
  {
    id: 'quilling',
    name: 'Quilling Art',
    icon: <Package className="size-4" />,
    description: 'Paper quilling art with intricate rolled paper designs',
    tags: ['paper quilling', 'quilling', 'paper art', 'handmade', 'paper craft', 'paper rolling', 'wall art', 'frame', 'unique gift', 'artisan made'],
  },
  {
    id: 'wedding',
    name: 'Wedding Crafts',
    icon: <Gift className="size-4" />,
    description: 'Handmade wedding invitation and decoration set',
    tags: ['wedding card', 'wedding', 'invitation', 'bridal shower', 'bride card', 'elegant', 'romantic', 'white', 'gold', 'for couple'],
  },
  {
    id: 'pottery',
    name: 'Pottery',
    icon: <CircleDot className="size-4" />,
    description: 'Handmade ceramic pottery with glaze finish',
    tags: ['handmade pottery', 'ceramic mug', 'clay art', 'stoneware', 'hand thrown', 'glazed pottery', 'handcrafted', 'home decor', 'artisan made', 'unique gift'],
  },
  {
    id: 'knitted',
    name: 'Knitted Items',
    icon: <Box className="size-4" />,
    description: 'Hand knitted scarf with soft merino wool',
    tags: ['knitted scarf', 'handmade', 'merino wool', 'hand knitted', 'winter', 'cozy', 'for her', 'handcrafted', 'soft', 'warm'],
  },
  {
    id: 'bath-products',
    name: 'Bath Products',
    icon: <Droplets className="size-4" />,
    description: 'Handmade bath bombs with natural essential oils',
    tags: ['bath bomb', 'handmade soap', 'organic', 'essential oils', 'natural', 'self care', 'bath salt', 'eco friendly', 'gift for her', 'relaxation'],
  },
  {
    id: 'leather',
    name: 'Leather Goods',
    icon: <ShoppingBag className="size-4" />,
    description: 'Handmade leather wallet with tooling details',
    tags: ['handmade leather', 'leather wallet', 'leather bag', 'leather journal', 'handcrafted', 'for him', 'artisan made', 'premium', 'unique gift', 'handmade'],
  },
  {
    id: 'embroidery',
    name: 'Embroidery',
    icon: <Scissors className="size-4" />,
    description: 'Hand embroidered hoop art with floral design',
    tags: ['embroidery', 'embroidery stitch', 'hand embroidered', 'hoop art', 'wall art', 'handmade', 'floral', 'fiber art', 'home decor', 'for her'],
  },
  {
    id: 'wood-crafts',
    name: 'Wood Crafts',
    icon: <TreePine className="size-4" />,
    description: 'Hand carved wooden decorative bowl',
    tags: ['wooden craft', 'carved wood', 'wood burning', 'handmade', 'hand carved', 'natural', 'rustic', 'home decor', 'artisan made', 'unique gift'],
  },
  {
    id: 'resin-art',
    name: 'Resin Art',
    icon: <Beaker className="size-4" />,
    description: 'Epoxy resin art with geode design and gold leaf',
    tags: ['resin', 'resin jewelry', 'epoxy', 'geode', 'gold leaf', 'handmade', 'wall art', 'home decor', 'unique gift', 'modern'],
  },
  {
    id: 'macrame',
    name: 'Macrame',
    icon: <LayoutGrid className="size-4" />,
    description: 'Handmade macrame wall hanging with cotton cord',
    tags: ['macrame', 'macrame knot', 'wall hanging', 'cotton', 'boho', 'handmade', 'handcrafted', 'home decor', 'boho color', 'fiber art'],
  },
  {
    id: 'digital-downloads',
    name: 'Digital Downloads',
    icon: <Download className="size-4" />,
    description: 'Printable digital art and templates',
    tags: ['digital download', 'printable art', 'art print', 'instant download', 'digital', 'wall art', 'modern', 'illustration', 'poster', 'watercolor print'],
  },
  {
    id: 'prints-art',
    name: 'Prints & Art',
    icon: <Paintbrush className="size-4" />,
    description: 'Original watercolor art print on premium paper',
    tags: ['art print', 'watercolor print', 'illustration', 'canvas print', 'wall art', 'photography print', 'handmade', 'home decor', 'original art', 'fine art'],
  },
  {
    id: 'bath-bombs',
    name: 'Bath Bombs',
    icon: <Droplets className="size-4" />,
    description: 'Handmade fizzy bath bombs with dried flowers',
    tags: ['bath bomb', 'handmade', 'organic', 'dried flowers', 'self care', 'gift for her', 'relaxation', 'eco friendly', 'spa', 'natural'],
  },
  {
    id: 'plant-accessories',
    name: 'Plant Accessories',
    icon: <Sprout className="size-4" />,
    description: 'Handmade terracotta plant pot with drainage',
    tags: ['plant pot', 'terracotta pot', 'handmade', 'garden decor', 'indoor', 'home decor', 'ceramic', 'plant lover', 'green', 'for her'],
  },
  {
    id: 'pet-accessories',
    name: 'Pet Accessories',
    icon: <Dog className="size-4" />,
    description: 'Handmade pet bandana and collar set',
    tags: ['pet accessory', 'handmade', 'for pet', 'dog lover', 'cat lover', 'pet bandana', 'gift for dog lover', 'custom', 'cotton', 'for pet'],
  },
]

// ─── Seasonal Calendar Data ──────────────────────────────────────────────────

const SEASONAL_CALENDAR = [
  { month: 'Jan', label: 'Winter / New Year', tags: ['new year card', 'winter wonderland', 'snowflake'], peak: false },
  { month: 'Feb', label: "Valentine's", tags: ['valentine card', 'love card', 'heart card'], peak: true },
  { month: 'Mar', label: "Mother's Day Prep", tags: ['spring card', 'mother day card', 'floral card'], peak: false },
  { month: 'Apr', label: 'Easter / Spring', tags: ['easter card', 'spring celebration', 'bunny card'], peak: true },
  { month: 'May', label: 'Wedding Start', tags: ['wedding card', 'father day card', 'bride card'], peak: false },
  { month: 'Jun', label: 'Graduation', tags: ['graduation card', 'summer card', 'class of 2025'], peak: true },
  { month: 'Jul', label: 'Summer', tags: ['summer party', 'tropical card', 'beach day'], peak: false },
  { month: 'Aug', label: 'Back to School', tags: ['back to school', 'teacher card', 'student card'], peak: false },
  { month: 'Sep', label: 'Autumn', tags: ['autumn card', 'fall card', 'thanksgiving'], peak: true },
  { month: 'Oct', label: 'Halloween', tags: ['halloween card', 'spooky card', 'pumpkin'], peak: true },
  { month: 'Nov', label: 'Holiday Prep', tags: ['christmas card', 'holiday card', 'advent calendar'], peak: false },
  { month: 'Dec', label: 'Christmas', tags: ['merry christmas', 'festive card', 'holiday wishes'], peak: true },
]

// ─── Helpers ─────────────────────────────────────────────────────────────────

function loadTagSets(): TagSet[] {
  if (typeof window === 'undefined') return []
  try {
    const saved = localStorage.getItem(STORAGE_KEY)
    return saved ? JSON.parse(saved) : []
  } catch {
    return []
  }
}

function saveTagSets(sets: TagSet[]) {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sets))
  } catch {
    // storage full or unavailable
  }
}

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8)
}

function findMatchingTags(description: string, categories: TagCategory[]): Set<string> {
  const matched = new Set<string>()
  if (!description.trim()) return matched

  const words = description
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length >= 3)

  for (const category of categories) {
    for (const tag of category.tags) {
      const tagLower = tag.toLowerCase()
      for (const word of words) {
        if (tagLower.includes(word)) {
          matched.add(tag)
          break
        }
      }
    }
  }

  return matched
}

function getTagQuality(tag: string): 'Strong' | 'Medium' | 'Weak' {
  const words = tag.trim().split(/\s+/)
  const wordCount = words.length
  const charLen = tag.trim().length

  if (wordCount >= 3 && charLen >= 12) return 'Strong'
  if (wordCount >= 2 && charLen >= 8) return 'Strong'
  if (wordCount === 2 && charLen >= 6) return 'Medium'
  if (wordCount === 1 && charLen >= 6) return 'Medium'
  return 'Weak'
}

function findSimilarTags(tags: string[]): [string, string][] {
  const similar: [string, string][] = []
  const normalized = tags.map((t) => t.toLowerCase().replace(/[^a-z0-9\s]/g, ''))

  for (let i = 0; i < tags.length; i++) {
    for (let j = i + 1; j < tags.length; j++) {
      const a = normalized[i]
      const b = normalized[j]
      if (a === b || a.includes(b) || b.includes(a)) {
        similar.push([tags[i], tags[j]])
      } else {
        const wordsA = new Set(a.split(/\s+/))
        const wordsB = new Set(b.split(/\s+/))
        let common = 0
        wordsA.forEach((w) => { if (wordsB.has(w)) common++ })
        const maxLen = Math.max(wordsA.size, wordsB.size)
        if (maxLen > 0 && common / maxLen >= 0.8) {
          similar.push([tags[i], tags[j]])
        }
      }
    }
  }

  return similar
}

function generateLongTailKeywords(tags: string[]): string[] {
  if (tags.length < 2) return []

  const results: string[] = []
  for (let i = 0; i < Math.min(tags.length, 6); i++) {
    for (let j = i + 1; j < Math.min(tags.length, 6); j++) {
      const combined = `${tags[i]} ${tags[j]}`
      if (combined.length <= 50) {
        results.push(combined)
      }
    }
  }
  if (tags.length >= 3) {
    for (let i = 0; i < Math.min(tags.length, 4); i++) {
      for (let j = i + 1; j < Math.min(tags.length, 4); j++) {
        for (let k = j + 1; k < Math.min(tags.length, 4); k++) {
          const combined = `${tags[i]} ${tags[j]} ${tags[k]}`
          if (combined.length <= 50) {
            results.push(combined)
          }
        }
      }
    }
  }

  return results.slice(0, 12)
}

function generateEtsyTitle(tags: string[]): string {
  if (tags.length === 0) return ''
  const sorted = [...tags].sort((a, b) => {
    const aWords = a.split(/\s+/).length
    const bWords = b.split(/\s+/).length
    return bWords - aWords
  })
  const title = sorted.join(' | ')
  return title.slice(0, ETSY_TITLE_MAX_CHARS)
}

function calculateAuditScore(
  tagCount: number,
  qualityCounts: { strong: number; medium: number; weak: number },
  similarPairs: [string, string][],
  categoryCount: number
): number {
  let score = 0

  // Tag count score (0-40 points)
  if (tagCount >= ETSY_MAX_TAGS) score += 40
  else if (tagCount >= 10) score += 30 + (tagCount - 10) * 3
  else if (tagCount >= 7) score += 20 + (tagCount - 7) * 3
  else if (tagCount >= 4) score += 10 + (tagCount - 4) * 3
  else score += tagCount * 2.5

  // Quality distribution (0-25 points)
  const totalTags = Math.max(tagCount, 1)
  const strongRatio = qualityCounts.strong / totalTags
  const weakRatio = qualityCounts.weak / totalTags
  score += Math.round(strongRatio * 20 - weakRatio * 5 + 5)

  // Diversity - categories covered (0-20 points)
  if (categoryCount >= 5) score += 20
  else if (categoryCount >= 4) score += 16
  else if (categoryCount >= 3) score += 12
  else if (categoryCount >= 2) score += 8
  else if (categoryCount >= 1) score += 4

  // Duplicate penalty (0-15 points, minus for each pair)
  const dupPenalty = Math.min(similarPairs.length * 5, 15)
  score += 15 - dupPenalty

  return Math.max(0, Math.min(100, Math.round(score)))
}

function getRelatedTags(tag: string, allTags: string[], selectedTags: string[]): string[] {
  const tagLower = tag.toLowerCase()
  const words = tagLower.split(/\s+/)

  const related = allTags
    .filter((t) => {
      if (t === tag || selectedTags.includes(t)) return false
      const tLower = t.toLowerCase()
      return words.some((w) => w.length >= 3 && tLower.includes(w))
    })
    .slice(0, 3)

  return related
}

function getTagCategoryMap(categories: TagCategory[]): Map<string, string> {
  const map = new Map<string, string>()
  for (const cat of categories) {
    for (const tag of cat.tags) {
      if (!map.has(tag)) {
        map.set(tag, cat.id)
      }
    }
  }
  return map
}

// ─── Platform Badge Component ────────────────────────────────────────────────

function PlatformBadges({ platforms, size = 'sm' }: { platforms: TagMeta['platforms']; size?: 'sm' | 'lg' }) {
  const sizeClasses = size === 'lg'
    ? 'size-6 rounded text-xs'
    : 'size-5 rounded text-[10px]'

  return (
    <span className="inline-flex items-center gap-0.5 shrink-0">
      {platforms.includes('etsy') && (
        <span
          className={`inline-flex items-center justify-center ${sizeClasses} bg-orange-100 font-bold text-orange-700 leading-none`}
          title="Etsy"
        >
          E
        </span>
      )}
      {platforms.includes('amazon') && (
        <span
          className={`inline-flex items-center justify-center ${sizeClasses} bg-sky-100 font-bold text-sky-700 leading-none`}
          title="Amazon"
        >
          A
        </span>
      )}
      {platforms.includes('shopify') && (
        <span
          className={`inline-flex items-center justify-center ${sizeClasses} bg-green-100 font-bold text-green-700 leading-none`}
          title="Shopify"
        >
          S
        </span>
      )}
    </span>
  )
}

/** Get platform names as text for tooltip display */
function getPlatformNames(platforms: TagMeta['platforms']): string {
  const names: string[] = []
  if (platforms.includes('etsy')) names.push('Etsy')
  if (platforms.includes('amazon')) names.push('Amazon')
  if (platforms.includes('shopify')) names.push('Shopify')
  return names.join(', ')
}

/** Get competition label with emoji */
function getCompetitionLabel(level: TagMeta['competition']): string {
  if (level === 'low') return '🟢 Low competition'
  if (level === 'medium') return '🟡 Medium competition'
  return '🔴 High competition'
}

/** Get volume label with emoji */
function getVolumeLabel(level: TagMeta['volume']): string {
  if (level === 'high') return '📈 High volume'
  if (level === 'medium') return '📊 Medium volume'
  return '📉 Low volume'
}

// ─── Competition Indicator ───────────────────────────────────────────────────

function CompetitionDot({ level }: { level: TagMeta['competition'] }) {
  const color = level === 'low' ? 'bg-green-500' : level === 'medium' ? 'bg-amber-500' : 'bg-red-500'
  const label = level === 'low' ? 'Low competition' : level === 'medium' ? 'Medium competition' : 'High competition'
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span className={`size-2 rounded-full ${color} inline-block cursor-help`} />
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  )
}

// ─── Volume Indicator ────────────────────────────────────────────────────────

function VolumeIndicator({ level }: { level: TagMeta['volume'] }) {
  if (level === 'high') {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <ArrowUp className="size-3 text-green-600 cursor-help" />
        </TooltipTrigger>
        <TooltipContent>High search volume</TooltipContent>
      </Tooltip>
    )
  }
  if (level === 'medium') {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Minus className="size-3 text-amber-500 cursor-help" />
        </TooltipTrigger>
        <TooltipContent>Medium search volume</TooltipContent>
      </Tooltip>
    )
  }
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <ArrowDown className="size-3 text-red-400 cursor-help" />
      </TooltipTrigger>
      <TooltipContent>Low search volume</TooltipContent>
    </Tooltip>
  )
}

// ─── Audit Score Display ─────────────────────────────────────────────────────

function AuditScoreCard({ score }: { score: number }) {
  const circumference = 2 * Math.PI * 40
  const offset = circumference - (score / 100) * circumference
  const color = score >= 80 ? 'text-green-600' : score >= 60 ? 'text-amber-600' : score >= 40 ? 'text-orange-500' : 'text-red-500'
  const strokeColor = score >= 80 ? '#16a34a' : score >= 60 ? '#d97706' : score >= 40 ? '#f97316' : '#ef4444'
  const label = score >= 80 ? 'Excellent' : score >= 60 ? 'Good' : score >= 40 ? 'Fair' : 'Needs Work'

  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative size-24">
        <svg className="size-24 -rotate-90" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="40" fill="none" stroke="currentColor" className="text-muted/30" strokeWidth="8" />
          <circle
            cx="50" cy="50" r="40" fill="none"
            stroke={strokeColor}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className="transition-all duration-700"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`text-2xl font-bold ${color}`}>{score}</span>
          <span className="text-xs text-muted-foreground">/ 100</span>
        </div>
      </div>
      <span className={`text-xs font-medium ${color}`}>{label}</span>
    </div>
  )
}

// ─── CSS Pie Chart ───────────────────────────────────────────────────────────

function CSSPieChart({ segments }: { segments: { value: number; color: string; label: string }[] }) {
  const total = segments.reduce((s, seg) => s + seg.value, 0)
  if (total === 0) return <div className="size-20 rounded-full bg-muted/30" />

  let gradientParts: string[] = []
  let currentDeg = 0

  for (const seg of segments) {
    if (seg.value === 0) continue
    const deg = (seg.value / total) * 360
    gradientParts.push(`${seg.color} ${currentDeg}deg ${currentDeg + deg}deg`)
    currentDeg += deg
  }

  return (
    <div
      className="size-20 rounded-full"
      style={{ background: `conic-gradient(${gradientParts.join(', ')})` }}
    />
  )
}

// ─── Seasonal Calendar Component ─────────────────────────────────────────────

function SeasonalCalendar({ selectedTags }: { selectedTags: string[] }) {
  const currentMonth = new Date().getMonth()

  return (
    <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5 sm:gap-2">
      {SEASONAL_CALENDAR.map((m, i) => {
        const isCurrent = i === currentMonth
        const hasMatchingTags = m.tags.some((t) => selectedTags.includes(t))
        return (
          <Tooltip key={m.month}>
            <TooltipTrigger asChild>
              <div
                className={`
                  relative flex flex-col items-center justify-center p-1.5 rounded-md text-center cursor-help
                  transition-all border
                  ${isCurrent
                    ? 'bg-primary/10 border-primary/30 ring-1 ring-primary/20'
                    : hasMatchingTags
                      ? 'bg-green-50 border-green-200'
                      : 'bg-muted/30 border-transparent'
                  }
                  ${m.peak ? 'font-semibold' : ''}
                `}
              >
                <span className={`text-xs ${isCurrent ? 'text-primary font-bold' : 'text-muted-foreground'}`}>
                  {m.month}
                </span>
                {m.peak && (
                  <span className="absolute top-0.5 right-0.5 size-1.5 rounded-full bg-primary" />
                )}
                {hasMatchingTags && (
                  <CheckCircle2 className="size-2.5 text-green-600 mt-0.5" />
                )}
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              <p className="font-medium">{m.label}</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {m.tags.join(', ')}
              </p>
              {isCurrent && <p className="text-xs text-primary mt-1">Current month</p>}
              {m.peak && <p className="text-xs text-amber-500 mt-0.5">Peak season</p>}
            </TooltipContent>
          </Tooltip>
        )
      })}
    </div>
  )
}

// ─── Main Component ──────────────────────────────────────────────────────────

export function TagGenerator({ onSupportClick }: { onSupportClick: () => void }) {
  // Auto-save setup
  const autoSaveRef = useRef<ReturnType<typeof createAutoSave<AutoSaveData>> | null>(null)
  const [autoSaved, setAutoSaved] = useState(false)
  const autoSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // State
  const [description, setDescription] = useState('')
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [activeCategoryId, setActiveCategoryId] = useState<string | null>(null)
  const [customTagInput, setCustomTagInput] = useState('')
  const [saveDialogOpen, setSaveDialogOpen] = useState(false)
  const [tagSetName, setTagSetName] = useState('')
  const [savedSets, setSavedSets] = useState<TagSet[]>(() => loadTagSets())
  const [copied, setCopied] = useState<string | null>(null)
  const [showLimitPopup, setShowLimitPopup] = useState(false)
  const [hasAutoGenerated, setHasAutoGenerated] = useState(false)
  const [isExporting, setIsExporting] = useState(false)
  const [etsyTitleEdit, setEtsyTitleEdit] = useState<string | null>(null)

  // Smart Suggest state
  const [isSuggestingTags, setIsSuggestingTags] = useState(false)
  const [suggestError, setSuggestError] = useState<string | null>(null)
  const [lastSuggestTime, setLastSuggestTime] = useState(0)

  const usage = useUsageTracker()
  const sharedData = useSharedData()

  // Initialize auto-save and restore on mount
  useEffect(() => {
    autoSaveRef.current = createAutoSave<AutoSaveData>(
      AUTO_SAVE_KEY,
      () => ({ description, selectedTags, customTagInput }),
      1500
    )

    const saved = autoSaveRef.current.load()
    if (saved) {
      if (saved.description) setDescription(saved.description)
      if (saved.selectedTags && saved.selectedTags.length > 0) {
        setSelectedTags(saved.selectedTags)
      }
      if (saved.customTagInput) setCustomTagInput(saved.customTagInput)
    }

    return () => {
      autoSaveRef.current?.cancel()
    }
  }, [])

  // Trigger auto-save whenever data changes
  useEffect(() => {
    if (!autoSaveRef.current) return
    autoSaveRef.current.save()
    if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current)
    setAutoSaved(true)
    autoSaveTimerRef.current = setTimeout(() => setAutoSaved(false), 2000)
    return () => {
      if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current)
    }
  }, [description, selectedTags, customTagInput])

  // Update shared data when tags change
  useEffect(() => {
    if (selectedTags.length > 0 || description) {
      sharedData.updateFromTags({
        tags: selectedTags,
        productDescription: description,
        productName: description.split(/[|,]/)[0]?.trim() || undefined,
      })
    }
  }, [selectedTags, description])

  // Build all categories including seasonal
  const allCategories = useMemo<TagCategory[]>(() => {
    const seasonal = getSeasonalTags()
    return [...TAG_CATEGORIES, seasonal]
  }, [])

  // All unique tags
  const allTags = useMemo(() => getAllTags(), [])

  // Tag to category map
  const tagCategoryMap = useMemo(() => getTagCategoryMap(allCategories), [allCategories])

  // Compute matching tags based on description
  const matchedTags = useMemo(() => {
    return findMatchingTags(description, allCategories)
  }, [description, allCategories])

  // Seasonal category id
  const seasonalCategoryId = useMemo(() => getSeasonalTags().id, [])

  // Active category
  const activeCategory = useMemo(() => {
    if (!activeCategoryId) return null
    return allCategories.find((c) => c.id === activeCategoryId) ?? null
  }, [activeCategoryId, allCategories])

  // Sort tags: matched first, then alphabetically
  const sortedTags = useMemo(() => {
    if (!activeCategory) return []
    return [...activeCategory.tags].sort((a, b) => {
      const aMatch = matchedTags.has(a) ? 0 : 1
      const bMatch = matchedTags.has(b) ? 0 : 1
      if (aMatch !== bMatch) return aMatch - bMatch
      return a.localeCompare(b)
    })
  }, [activeCategory, matchedTags])

  // Suggested tags
  const suggestedTags = useMemo(() => {
    if (!description.trim()) return []
    const allT = allCategories.flatMap((c) => c.tags)
    return [...new Set(allT)].filter((t) => matchedTags.has(t))
  }, [description, allCategories, matchedTags])

  // Similar/duplicate tags
  const similarTagPairs = useMemo(() => findSimilarTags(selectedTags), [selectedTags])

  // Long-tail keyword suggestions
  const longTailKeywords = useMemo(() => generateLongTailKeywords(selectedTags), [selectedTags])

  // Etsy title
  const etsyTitle = useMemo(() => generateEtsyTitle(selectedTags), [selectedTags])
  const displayTitle = etsyTitleEdit !== null ? etsyTitleEdit : etsyTitle

  // Tag quality distribution
  const tagQualityCounts = useMemo(() => {
    let strong = 0
    let medium = 0
    let weak = 0
    selectedTags.forEach((tag) => {
      const q = getTagQuality(tag)
      if (q === 'Strong') strong++
      else if (q === 'Medium') medium++
      else weak++
    })
    return { strong, medium, weak }
  }, [selectedTags])

  // Competition distribution
  const competitionCounts = useMemo(() => {
    let low = 0
    let medium = 0
    let high = 0
    selectedTags.forEach((tag) => {
      const meta = estimateTagMeta(tag)
      if (meta.competition === 'low') low++
      else if (meta.competition === 'medium') medium++
      else high++
    })
    return { low, medium, high }
  }, [selectedTags])

  // Category coverage
  const categoryCoverage = useMemo(() => {
    const covered = new Set<string>()
    selectedTags.forEach((tag) => {
      const catId = tagCategoryMap.get(tag)
      if (catId) covered.add(catId)
    })
    return covered
  }, [selectedTags, tagCategoryMap])

  // Audit score
  const auditScore = useMemo(() => {
    return calculateAuditScore(
      selectedTags.length,
      tagQualityCounts,
      similarTagPairs,
      categoryCoverage.size
    )
  }, [selectedTags.length, tagQualityCounts, similarTagPairs, categoryCoverage])

  // Suggestion banner from shared data
  const sharedSuggestion = useMemo(() => {
    const data = sharedData.data
    const suggestions: string[] = []

    if (data.productName && !description) {
      suggestions.push(`Your pricing data suggests "${data.productName}" - use tags for that category`)
    }

    if (data.materials && data.materials.length > 0) {
      const materialNames = data.materials.map((m) => m.name.toLowerCase())
      const allT = allCategories.flatMap((c) => c.tags)
      const materialTags = allT.filter((t) =>
        materialNames.some((mn) => t.toLowerCase().includes(mn) || mn.includes(t.toLowerCase()))
      )
      const newMaterialTags = materialTags.filter((t) => !selectedTags.includes(t))
      if (newMaterialTags.length > 0) {
        suggestions.push(`Based on your materials, consider: ${newMaterialTags.slice(0, 3).join(', ')}`)
      }
    }

    return suggestions
  }, [sharedData.data, selectedTags, description, allCategories])

  // Auto-generate when description has more than 3 words
  const handleDescriptionChange = useCallback((value: string) => {
    setDescription(value)

    const wordCount = value.trim().split(/\s+/).filter(w => w.length >= 2).length
    if (wordCount > 3 && !hasAutoGenerated) {
      const newMatched = findMatchingTags(value, allCategories)
      const allT = allCategories.flatMap((c) => c.tags)
      const autoSuggested = [...new Set(allT)].filter((t) => newMatched.has(t))
      const toAdd = autoSuggested.filter((t) => !selectedTags.includes(t))
      const remaining = ETSY_MAX_TAGS - selectedTags.length
      if (toAdd.length > 0 && usage.canUse()) {
        usage.incrementUsage('tags', 'auto-generate')
        setSelectedTags((prev) => [...prev, ...toAdd.slice(0, remaining)])
      } else if (toAdd.length > 0 && !usage.canUse()) {
        setShowLimitPopup(true)
      }
      setHasAutoGenerated(true)
    }

    if (!value.trim()) {
      setHasAutoGenerated(false)
    }
  }, [allCategories, hasAutoGenerated, selectedTags, usage])

  // Tag operations
  const addTag = useCallback(
    (tag: string) => {
      if (selectedTags.length >= ETSY_MAX_TAGS) return
      if (selectedTags.includes(tag)) return
      setSelectedTags((prev) => [...prev, tag])
    },
    [selectedTags]
  )

  const removeTag = useCallback((tag: string) => {
    setSelectedTags((prev) => prev.filter((t) => t !== tag))
  }, [])

  const moveTag = useCallback((index: number, direction: 'up' | 'down') => {
    setSelectedTags((prev) => {
      const next = [...prev]
      const targetIndex = direction === 'up' ? index - 1 : index + 1
      if (targetIndex < 0 || targetIndex >= next.length) return prev
      ;[next[index], next[targetIndex]] = [next[targetIndex], next[index]]
      return next
    })
  }, [])

  const clearTags = useCallback(() => {
    setSelectedTags([])
    setEtsyTitleEdit(null)
  }, [])

  // Custom tag input
  const handleAddCustomTag = useCallback(() => {
    const tag = customTagInput.trim().toLowerCase()
    if (!tag) return
    if (selectedTags.length >= ETSY_MAX_TAGS) {
      toast({ title: 'Tag limit reached', description: `Maximum ${ETSY_MAX_TAGS} tags allowed` })
      return
    }
    if (selectedTags.includes(tag)) {
      toast({ title: 'Tag already added', description: `"${tag}" is already in your tag list` })
      return
    }
    setSelectedTags((prev) => [...prev, tag])
    setCustomTagInput('')
  }, [customTagInput, selectedTags])

  // Copy tags
  const handleCopy = useCallback((format: 'comma' | 'etsy' | 'hashtags' | 'csv') => {
    if (!usage.canUse()) {
      setShowLimitPopup(true)
      return
    }
    usage.incrementUsage('tags', 'copy')
    let text = ''
    if (format === 'comma') {
      text = selectedTags.join(', ')
    } else if (format === 'etsy') {
      text = selectedTags.join(', ')
    } else if (format === 'hashtags') {
      text = selectedTags.map((t) => `#${t.replace(/\s+/g, '')}`).join(' ')
    } else if (format === 'csv') {
      text = selectedTags.map((t) => `"${t}"`).join(',')
    }
    navigator.clipboard.writeText(text).then(() => {
      setCopied(format)
      const labels: Record<string, string> = {
        comma: 'Copied!',
        etsy: 'Copied for Etsy!',
        hashtags: 'Copied as Hashtags!',
        csv: 'Copied as CSV!',
      }
      toast({ title: labels[format], description: `${selectedTags.length} tags copied to clipboard` })
      setTimeout(() => setCopied(null), 2000)
    })
  }, [selectedTags, usage])

  // CSV file export
  const handleExportCSV = useCallback(() => {
    if (selectedTags.length === 0) {
      toast({ title: 'No tags to export', description: 'Add some tags first' })
      return
    }
    const csvContent = 'Tag,Quality,Competition,Volume,Platforms\n' +
      selectedTags.map((tag) => {
        const meta = estimateTagMeta(tag)
        const quality = getTagQuality(tag)
        return `"${tag}","${quality}","${meta.competition}","${meta.volume}","${meta.platforms.join('/')}"`
      }).join('\n')

    downloadAsCSV(csvContent, 'artnew8-tags')
    toast({ title: 'CSV exported!', description: `${selectedTags.length} tags saved as CSV` })
  }, [selectedTags])

  // Generate / auto-suggest
  const handleGenerate = useCallback(() => {
    if (!usage.canUse()) {
      setShowLimitPopup(true)
      return
    }
    usage.incrementUsage('tags', 'generate')
    const toAdd = suggestedTags.filter((t) => !selectedTags.includes(t))
    const remaining = ETSY_MAX_TAGS - selectedTags.length
    setSelectedTags((prev) => [...prev, ...toAdd.slice(0, remaining)])
  }, [suggestedTags, selectedTags, usage])

  // Save tag set
  const handleSave = useCallback(() => {
    if (!tagSetName.trim() || selectedTags.length === 0) return
    const newSet: TagSet = {
      id: generateId(),
      name: tagSetName.trim(),
      tags: [...selectedTags],
      description: description || undefined,
      savedAt: new Date().toISOString(),
    }
    const updated = [newSet, ...savedSets]
    setSavedSets(updated)
    saveTagSets(updated)
    setTagSetName('')
    setSaveDialogOpen(false)
    toast({ title: 'Tag set saved!', description: `"${newSet.name}" with ${newSet.tags.length} tags` })
  }, [tagSetName, selectedTags, savedSets, description])

  // Load tag set
  const handleLoadSet = useCallback((set: TagSet) => {
    if (set.tags && Array.isArray(set.tags)) {
      setSelectedTags([...set.tags])
      if (set.description) {
        setDescription(set.description)
      }
      setActiveCategoryId(null)
      setEtsyTitleEdit(null)
      toast({ title: 'Tag set loaded!', description: `"${set.name}" - ${set.tags.length} tags applied` })
    }
  }, [])

  // Delete tag set
  const handleDeleteSet = useCallback(
    (id: string) => {
      const updated = savedSets.filter((s) => s.id !== id)
      setSavedSets(updated)
      saveTagSets(updated)
    },
    [savedSets]
  )

  // Apply template
  const handleApplyTemplate = useCallback((template: ProductTemplate) => {
    setDescription(template.description)
    setSelectedTags([...template.tags])
    setHasAutoGenerated(true)
    setEtsyTitleEdit(null)
    toast({ title: `${template.name} template applied!`, description: `${template.tags.length} tags pre-filled` })
  }, [])

  // Smart Suggest handler
  const handleSmartSuggest = useCallback(async () => {
    const keyword = description.trim() || customTagInput.trim()
    if (!keyword) {
      toast({ title: 'Enter a keyword first', description: 'Type a product description or custom tag keyword' })
      return
    }
    if (!usage.canUse()) {
      setShowLimitPopup(true)
      return
    }
    // Rate limit: 1 request per 10 seconds
    const now = Date.now()
    if (now - lastSuggestTime < 10_000) {
      toast({ title: 'Please wait', description: 'Try again in a few seconds' })
      return
    }
    setLastSuggestTime(now)
    setIsSuggestingTags(true)
    setSuggestError(null)
    try {
      const sessionId = typeof window !== 'undefined' ? localStorage.getItem('artnew8-session-id') || '' : ''
      const res = await fetch('/api/ai/suggest-tags', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          keyword,
          platform: 'etsy',
          sessionId,
        }),
      })
      if (res.status === 429) {
        toast({ title: 'Please wait', description: 'Too many requests. Try again in a minute.' })
        return
      }
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Request failed' }))
        throw new Error(err.error || 'Request failed')
      }
      const data = await res.json()
      const newTags: string[] = (data.tags || []).filter(
        (t: string) => !selectedTags.includes(t.toLowerCase())
      )
      if (newTags.length === 0) {
        toast({ title: 'No new tags found', description: 'Your tags already cover the suggestions' })
        return
      }
      const remaining = ETSY_MAX_TAGS - selectedTags.length
      const toAdd = newTags.slice(0, remaining)
      usage.incrementUsage('tags', 'smart-suggest')
      setSelectedTags((prev) => [...prev, ...toAdd])
      toast({
        title: `${toAdd.length} tags suggested`,
        description: toAdd.slice(0, 3).join(', ') + (toAdd.length > 3 ? ` +${toAdd.length - 3} more` : ''),
      })
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong'
      setSuggestError(message)
      toast({ title: 'Suggestion failed', description: message, variant: 'destructive' })
    } finally {
      setIsSuggestingTags(false)
    }
  }, [description, customTagInput, selectedTags, usage, lastSuggestTime])

  // Export handlers
  const handleDownloadImage = useCallback(async () => {
    setIsExporting(true)
    try {
      await downloadAsImage('tag-results', 'artnew8-tags')
      toast({ title: 'Image downloaded!', description: 'Your tags have been saved as an image' })
    } catch {
      toast({ title: 'Export failed', description: 'Could not generate image. Try again.', variant: 'destructive' })
    }
    setIsExporting(false)
  }, [])

  const handleDownloadPDF = useCallback(async () => {
    setIsExporting(true)
    try {
      await downloadAsPDF('tag-results', 'artnew8-tags')
      toast({ title: 'PDF downloaded!', description: 'Your tags have been saved as a PDF' })
    } catch {
      toast({ title: 'Export failed', description: 'Could not generate PDF. Try again.', variant: 'destructive' })
    }
    setIsExporting(false)
  }, [])

  const tagCount = selectedTags.length
  const tagProgress = (tagCount / ETSY_MAX_TAGS) * 100
  const remaining = usage.getRemaining()

  const tagCountColor = useMemo(() => {
    if (tagCount >= ETSY_MAX_TAGS) return 'text-rose-500'
    if (tagCount >= ETSY_MAX_TAGS - 2) return 'text-amber-600'
    if (tagCount >= 8) return 'text-green-600'
    if (tagCount >= 5) return 'text-amber-600'
    return 'text-muted-foreground'
  }, [tagCount])

  const tagCountLabel = useMemo(() => {
    if (tagCount >= ETSY_MAX_TAGS) return 'Full!'
    if (tagCount >= ETSY_MAX_TAGS - 2) return 'Almost there'
    if (tagCount >= 8) return 'Great!'
    if (tagCount >= 5) return 'Good start'
    return 'Add more'
  }, [tagCount])

  const titleCharCount = displayTitle.length
  const titleCharColor = useMemo(() => {
    if (titleCharCount > ETSY_TITLE_MAX_CHARS) return 'text-red-500'
    if (titleCharCount >= 100) return 'text-green-600'
    if (titleCharCount >= 50) return 'text-amber-600'
    return 'text-muted-foreground'
  }, [titleCharCount])

  // ─── Render ──────────────────────────────────────────────────────────────────

  return (
    <div className="w-full max-w-6xl mx-auto">
      {/* Limit Popup */}
      <LimitPopup
        open={showLimitPopup}
        onClose={() => setShowLimitPopup(false)}
        onSupportClick={onSupportClick}
        remaining={remaining}
      />

      {/* Header */}
      <div className="text-center mb-6">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Tag className="size-7 text-rose-500" />
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bg-gradient-to-r from-rose-500 to-pink-500 bg-clip-text text-transparent">
            Tag &amp; Keyword Generator
          </h1>
          <Sparkles className="size-5 text-pink-500/70" />
        </div>
        <p className="text-muted-foreground text-sm sm:text-base max-w-xl mx-auto">
          Generate SEO-optimized tags for your Etsy, Amazon, or craft marketplace listings.
          Describe your product, browse categories, and build the perfect tag set.
        </p>
        <div className="flex items-center justify-center gap-2 mt-2 h-5">
          {autoSaved && (
            <motion.span
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="text-xs text-muted-foreground flex items-center gap-1"
            >
              <CheckCircle2 className="size-3 text-green-500" />
              Auto-saved
            </motion.span>
          )}
        </div>
      </div>

      {/* Shared data suggestion banner */}
      <AnimatePresence>
        {sharedSuggestion.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 px-4 py-3 rounded-lg bg-rose-50 border border-rose-200"
          >
            {sharedSuggestion.map((s, i) => (
              <p key={i} className="text-xs text-rose-700 flex items-center gap-1.5">
                <Lightbulb className="size-3.5 shrink-0" />
                {s}
              </p>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Usage remaining */}
      <div className="flex items-center justify-center gap-2 mb-6">
        <span className="text-xs text-muted-foreground">
          {remaining} tool {remaining === 1 ? 'use' : 'uses'} remaining today
        </span>
      </div>

      {/* ─── Tabs ──────────────────────────────────────────────────────────── */}
      <Tabs defaultValue="generate" className="space-y-6">
        <TabsList className="mx-auto w-full max-w-md">
          <TabsTrigger value="generate" className="gap-1.5">
            <Sparkles className="size-3.5" />
            Generate
          </TabsTrigger>
          <TabsTrigger value="refine" className="gap-1.5">
            <Target className="size-3.5" />
            Refine
          </TabsTrigger>
          <TabsTrigger value="export" className="gap-1.5">
            <Download className="size-3.5" />
            Export
          </TabsTrigger>
        </TabsList>

        {/* ═══════════════════════════════════════════════════════════════════
            TAB 1: GENERATE
            ═══════════════════════════════════════════════════════════════════ */}
        <TabsContent value="generate" className="space-y-6">
          {/* Quick Start Templates */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Zap className="size-4 text-rose-500" />
                Quick Start Templates
              </CardTitle>
              <CardDescription>
                Pick a product type to pre-fill common tags and get started fast.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-y-auto max-h-56">
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                  {PRODUCT_TEMPLATES.map((template) => (
                    <Tooltip key={template.id}>
                      <TooltipTrigger asChild>
                        <button
                          onClick={() => handleApplyTemplate(template)}
                          className="inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2.5 text-sm font-medium 
                            transition-all border cursor-pointer
                            bg-muted/50 text-muted-foreground border-transparent 
                            hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200"
                        >
                          {template.icon}
                          <span className="truncate">{template.name}</span>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        {template.tags.length} tags · {template.description.slice(0, 50)}...
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
            {/* Product Description Input */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="size-4 text-rose-500" />
                  Describe Your Product
                </CardTitle>
                <CardDescription>
                  Enter details and we&apos;ll suggest matching tags automatically.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Textarea
                  placeholder="e.g., Handmade paper flower birthday card with pink roses, vintage lace, and gold glitter accents"
                  value={description}
                  onChange={(e) => handleDescriptionChange(e.target.value)}
                  className="min-h-[100px] resize-y"
                />
                <div className="flex items-center gap-2 flex-wrap">
                  <Button
                    size="sm"
                    onClick={handleGenerate}
                    disabled={suggestedTags.length === 0 || !description.trim()}
                    className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white"
                  >
                    <Sparkles className="size-4" />
                    Auto-Suggest Tags
                    {suggestedTags.length > 0 && (
                      <Badge variant="secondary" className="ml-1 bg-white/20 text-white">
                        {suggestedTags.length}
                      </Badge>
                    )}
                  </Button>
                  {suggestedTags.length > 0 && (
                    <span className="text-xs text-muted-foreground">
                      {suggestedTags.filter((t) => !selectedTags.includes(t)).length} new tags available
                    </span>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Custom Tag Input + Category Browser */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Plus className="size-4 text-rose-500" />
                  Add Custom Tags
                </CardTitle>
                <CardDescription>
                  Type your own tags below, or browse categories to find more.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Custom tag input */}
                <div className="flex gap-2">
                  <Input
                    placeholder="Type a custom tag and press Enter..."
                    value={customTagInput}
                    onChange={(e) => setCustomTagInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault()
                        handleAddCustomTag()
                      }
                    }}
                    className="flex-1"
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleAddCustomTag}
                    disabled={!customTagInput.trim() || selectedTags.length >= ETSY_MAX_TAGS}
                    className="border-rose-200 text-rose-600 hover:bg-rose-50"
                  >
                    <Plus className="size-4" />
                  </Button>
                </div>

                {/* Smart Suggest */}
                {remaining > 0 && (
                  <div className="space-y-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleSmartSuggest}
                      disabled={isSuggestingTags || (!description.trim() && !customTagInput.trim())}
                      className="gap-1.5 border-amber-200 text-amber-700 hover:bg-amber-50"
                    >
                      {isSuggestingTags ? (
                        <>
                          <div className="size-3.5 animate-spin rounded-full border-2 border-amber-300 border-t-transparent" />
                          Suggesting...
                        </>
                      ) : (
                        <>
                          <Sparkles className="size-3.5" />
                          Smart Suggest
                        </>
                      )}
                    </Button>
                    {suggestError && (
                      <p className="text-xs text-destructive">{suggestError}</p>
                    )}
                  </div>
                )}

                <Separator />

                {/* Category Chips */}
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Browse by category:</p>
                  <div className="flex flex-wrap gap-2 overflow-hidden">
                    {allCategories.map((cat) => {
                      const isActive = activeCategoryId === cat.id
                      const tagCountInCat = cat.tags.length
                      const matchCount = cat.tags.filter((t) => matchedTags.has(t)).length
                      return (
                        <Tooltip key={cat.id}>
                          <TooltipTrigger asChild>
                            <button
                              onClick={() =>
                                setActiveCategoryId(isActive ? null : cat.id)
                              }
                              className={`
                                inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm sm:text-base font-medium 
                                transition-all border cursor-pointer
                                ${
                                  isActive
                                    ? 'bg-rose-50 text-rose-600 border-rose-200 shadow-sm'
                                    : 'bg-muted/50 text-muted-foreground border-transparent hover:bg-muted hover:text-foreground'
                                }
                              `}
                            >
                              <span>{cat.icon}</span>
                              <span>{cat.name}</span>
                              {matchCount > 0 && (
                                <Badge
                                  variant="secondary"
                                  className="ml-0.5 bg-rose-100 text-rose-600 text-xs px-1.5 py-0"
                                >
                                  {matchCount}
                                </Badge>
                              )}
                              <span className="text-xs text-muted-foreground">
                                ({tagCountInCat})
                              </span>
                            </button>
                          </TooltipTrigger>
                          <TooltipContent>
                            {matchCount > 0
                              ? `${matchCount} matching tag${matchCount !== 1 ? 's' : ''} found`
                              : `${tagCountInCat} tags available`}
                          </TooltipContent>
                        </Tooltip>
                      )
                    })}
                  </div>
                </div>

                {/* Tags in selected category */}
                {activeCategory && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Separator className="mb-3" />
                    <div>
                      <div className="flex items-center gap-2 mb-3">
                        <span className="text-sm sm:text-base">{activeCategory.icon}</span>
                        <h3 className="text-sm font-semibold">{activeCategory.name}</h3>
                        <span className="text-xs text-muted-foreground">
                          {activeCategory.tags.length} tags
                        </span>
                      </div>
                      <div className="overflow-y-auto max-h-64">
                        <div className="flex flex-wrap gap-2 overflow-hidden">
                          {sortedTags.map((tag) => {
                            const isSelected = selectedTags.includes(tag)
                            const isMatched = matchedTags.has(tag)
                            const isSeasonal = activeCategory.id === seasonalCategoryId
                            const meta = estimateTagMeta(tag)
                            return (
                              <Tooltip key={tag}>
                                <TooltipTrigger asChild>
                                  <button
                                    onClick={() =>
                                      isSelected ? removeTag(tag) : addTag(tag)
                                    }
                                    disabled={!isSelected && tagCount >= ETSY_MAX_TAGS}
                                    className={`
                                      inline-flex items-center gap-1.5 rounded-lg px-3 sm:px-4 py-1.5 sm:py-2 text-sm sm:text-base font-medium
                                      transition-all border cursor-pointer
                                      ${
                                        isSelected
                                          ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white border-rose-400 shadow-sm hover:from-rose-600 hover:to-pink-600'
                                          : isMatched
                                            ? 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                                            : 'bg-muted/50 text-muted-foreground border-transparent hover:bg-muted hover:text-foreground'
                                      }
                                      ${!isSelected && tagCount >= ETSY_MAX_TAGS ? 'opacity-40 cursor-not-allowed' : ''}
                                    `}
                                  >
                                    {isMatched && !isSelected && (
                                      <Sparkles className="size-3.5 text-rose-500 shrink-0" />
                                    )}
                                    <span>{tag}</span>
                                    {isSeasonal && !isSelected && (
                                      <TrendingUp className="size-3.5 text-pink-500/70 shrink-0" />
                                    )}
                                    {isSelected && (
                                      <X className="size-3.5 ml-0.5 shrink-0" />
                                    )}
                                  </button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <div className="space-y-1 text-xs">
                                    <p className="font-medium">{isSelected ? 'Click to remove' : 'Click to add'}</p>
                                    <p>{getCompetitionLabel(meta.competition)}</p>
                                    <p>{getVolumeLabel(meta.volume)}</p>
                                    <p className="text-muted-foreground">Platforms: {getPlatformNames(meta.platforms)}</p>
                                  </div>
                                </TooltipContent>
                              </Tooltip>
                            )
                          })}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Suggested tags (when no category is active) */}
                {!activeCategory && suggestedTags.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <div className="flex items-center gap-2 mb-3">
                        <Sparkles className="size-4 text-rose-500" />
                        <h3 className="text-sm font-semibold">Suggested for You</h3>
                        <span className="text-xs text-muted-foreground">
                          Based on your description
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-2 overflow-hidden">
                        {suggestedTags.map((tag) => {
                          const isSelected = selectedTags.includes(tag)
                          const meta = estimateTagMeta(tag)
                          return (
                            <Tooltip key={tag}>
                              <TooltipTrigger asChild>
                                <button
                                  onClick={() =>
                                    isSelected ? removeTag(tag) : addTag(tag)
                                  }
                                  disabled={!isSelected && tagCount >= ETSY_MAX_TAGS}
                                  className={`
                                    inline-flex items-center gap-1.5 rounded-lg px-3 sm:px-4 py-1.5 sm:py-2 text-sm sm:text-base font-medium
                                    transition-all border cursor-pointer
                                    ${
                                      isSelected
                                        ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white border-rose-400 shadow-sm'
                                        : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                                    }
                                    ${!isSelected && tagCount >= ETSY_MAX_TAGS ? 'opacity-40 cursor-not-allowed' : ''}
                                  `}
                                >
                                  <Sparkles className="size-3.5 text-rose-500 shrink-0" />
                                  <span>{tag}</span>
                                  {isSelected && <X className="size-3.5 ml-0.5 shrink-0" />}
                                </button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <div className="space-y-1 text-xs">
                                  <p className="font-medium">{isSelected ? 'Click to remove' : 'Click to add'}</p>
                                  <p>{getCompetitionLabel(meta.competition)}</p>
                                  <p>{getVolumeLabel(meta.volume)}</p>
                                  <p className="text-muted-foreground">Platforms: {getPlatformNames(meta.platforms)}</p>
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          )
                        })}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Seasonal Calendar */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Calendar className="size-4 text-rose-500" />
                Seasonal Calendar
              </CardTitle>
              <CardDescription>
                Plan ahead with seasonal keywords. Dots indicate peak selling months.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <SeasonalCalendar selectedTags={selectedTags} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══════════════════════════════════════════════════════════════════
            TAB 2: REFINE
            ═══════════════════════════════════════════════════════════════════ */}
        <TabsContent value="refine" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
            {/* Selected Tags + Actions */}
            <div className="lg:col-span-2 space-y-6">
              {/* Selected Tags Panel */}
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Tag className="size-4 text-rose-500" />
                      Selected Tags
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">{tagCountLabel}</span>
                      <span className={`text-sm sm:text-base font-bold ${tagCountColor}`}>
                        {tagCount} of {ETSY_MAX_TAGS}
                      </span>
                    </div>
                  </div>
                  <Progress value={tagProgress} className="h-2" />
                  <CardDescription>
                    {tagCount >= ETSY_MAX_TAGS
                      ? 'Tag limit reached! Remove a tag to add a different one.'
                      : `${ETSY_MAX_TAGS - tagCount} tag${ETSY_MAX_TAGS - tagCount !== 1 ? 's' : ''} remaining - fill them all for best Etsy SEO.`}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Duplicate warning */}
                  <AnimatePresence>
                    {similarTagPairs.length > 0 && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="px-3 py-2 rounded-lg bg-amber-50 border border-amber-200"
                      >
                        <div className="flex items-center gap-1.5 mb-1">
                          <AlertTriangle className="size-4 text-amber-600" />
                          <span className="text-sm font-medium text-amber-700">Similar tags detected</span>
                        </div>
                        {similarTagPairs.map(([a, b], i) => (
                          <p key={i} className="text-xs text-amber-600 ml-6">
                            &ldquo;{a}&rdquo; &amp; &ldquo;{b}&rdquo; are very similar - consider removing one
                          </p>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Tag quality summary */}
                  {selectedTags.length > 0 && (
                    <div className="flex items-center gap-3 text-xs">
                      <span className="flex items-center gap-1.5">
                        <span className="size-2.5 rounded-full bg-green-500" />
                        Strong: {tagQualityCounts.strong}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="size-2.5 rounded-full bg-amber-500" />
                        Medium: {tagQualityCounts.medium}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="size-2.5 rounded-full bg-red-400" />
                        Weak: {tagQualityCounts.weak}
                      </span>
                      <span className="ml-auto text-muted-foreground">
                        {tagCount} of {ETSY_MAX_TAGS}
                      </span>
                    </div>
                  )}

                  {/* Tags list with reorder */}
                  {selectedTags.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Tag className="size-8 mx-auto mb-2 opacity-40" />
                      <p className="text-sm">No tags selected yet</p>
                      <p className="text-xs mt-1">
                        Use the Generate tab to browse and select tags
                      </p>
                    </div>
                  ) : (
                    <div className="overflow-y-auto max-h-80">
                      <div className="space-y-2 pr-2">
                        {selectedTags.map((tag, index) => {
                          const quality = getTagQuality(tag)
                          const meta = estimateTagMeta(tag)
                          const qualityColor = quality === 'Strong'
                            ? 'bg-green-500'
                            : quality === 'Medium'
                              ? 'bg-amber-500'
                              : 'bg-red-400'
                          const borderColor = quality === 'Strong'
                            ? 'border-l-green-500'
                            : quality === 'Medium'
                              ? 'border-l-amber-500'
                              : 'border-l-red-400'

                          return (
                            <motion.div
                              key={tag}
                              layout
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: 10 }}
                              className={`
                                flex items-center gap-3 rounded-lg px-3 py-2.5 border overflow-hidden
                                border-l-4 ${borderColor}
                                bg-gradient-to-r from-rose-50/50 to-pink-50/50
                                border-rose-100
                              `}
                            >
                              {/* Reorder buttons */}
                              <div className="flex flex-col gap-0 shrink-0">
                                <button
                                  onClick={() => moveTag(index, 'up')}
                                  disabled={index === 0}
                                  className="text-muted-foreground hover:text-foreground disabled:opacity-20 p-0 leading-none"
                                >
                                  <ChevronUp className="size-3.5" />
                                </button>
                                <button
                                  onClick={() => moveTag(index, 'down')}
                                  disabled={index === selectedTags.length - 1}
                                  className="text-muted-foreground hover:text-foreground disabled:opacity-20 p-0 leading-none"
                                >
                                  <ChevronDown className="size-3.5" />
                                </button>
                              </div>

                              {/* Quality dot */}
                              <span className={`size-2.5 rounded-full ${qualityColor} shrink-0`} />

                              {/* Tag text */}
                              <span className="flex-1 font-medium text-sm sm:text-base min-w-0 break-words">{tag}</span>

                              {/* Platform badges */}
                              <PlatformBadges platforms={meta.platforms} size="lg" />

                              {/* Remove button */}
                              <button
                                onClick={() => removeTag(tag)}
                                className="text-muted-foreground hover:text-destructive transition-colors shrink-0"
                              >
                                <X className="size-4" />
                              </button>
                            </motion.div>
                          )
                        })}
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  {selectedTags.length > 0 && (
                    <div className="flex items-center gap-2 flex-wrap">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={clearTags}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="size-3.5" />
                        Clear All
                      </Button>
                      <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSaveDialogOpen(true)}
                        >
                          <Save className="size-3.5" />
                          Save Set
                        </Button>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Save Tag Set</DialogTitle>
                            <DialogDescription>
                              Give your tag set a name to save and reload later.
                            </DialogDescription>
                          </DialogHeader>
                          <Input
                            placeholder="e.g., Valentine's Cards 2025"
                            value={tagSetName}
                            onChange={(e) => setTagSetName(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSave()
                            }}
                          />
                          <DialogFooter>
                            <Button
                              onClick={handleSave}
                              disabled={!tagSetName.trim()}
                              className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white"
                            >
                              Save
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                      {savedSets.length > 0 && (
                        <Accordion type="single" collapsible className="w-full">
                          <AccordionItem value="saved" className="border-none">
                            <AccordionTrigger className="py-2 text-xs hover:no-underline">
                              <span className="flex items-center gap-1.5">
                                <FolderOpen className="size-3.5" />
                                Saved Sets ({savedSets.length})
                              </span>
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="overflow-y-auto max-h-48">
                                <div className="space-y-1.5 pr-2">
                                  {savedSets.map((set) => (
                                    <div
                                      key={set.id}
                                      className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-muted/50"
                                    >
                                      <button
                                        onClick={() => handleLoadSet(set)}
                                        className="text-sm font-medium hover:text-primary transition-colors text-left flex-1 cursor-pointer"
                                      >
                                        {set.name}
                                        <span className="text-xs text-muted-foreground ml-1">
                                          ({set.tags.length} tags)
                                        </span>
                                      </button>
                                      <button
                                        onClick={() => handleDeleteSet(set.id)}
                                        className="text-muted-foreground hover:text-destructive transition-colors"
                                      >
                                        <Trash2 className="size-3" />
                                      </button>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        </Accordion>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Related Keywords */}
              {selectedTags.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Lightbulb className="size-4 text-amber-500" />
                      Related Keywords
                    </CardTitle>
                    <CardDescription>
                      Tags you might also want based on your selections.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-y-auto max-h-52">
                      <div className="flex flex-wrap gap-2 overflow-hidden">
                        {selectedTags.slice(0, 5).map((tag) => {
                          const related = getRelatedTags(tag, allTags, selectedTags)
                          return related.map((rt) => {
                            const meta = estimateTagMeta(rt)
                            return (
                              <Tooltip key={`related-${rt}`}>
                                <TooltipTrigger asChild>
                                  <button
                                    onClick={() => addTag(rt)}
                                    disabled={tagCount >= ETSY_MAX_TAGS}
                                    className={`
                                      inline-flex items-center gap-1.5 rounded-lg px-3 sm:px-4 py-1.5 sm:py-2 text-sm sm:text-base font-medium
                                      transition-all border cursor-pointer
                                      bg-amber-50 text-amber-700
                                      border-amber-200
                                      hover:bg-amber-100
                                      ${tagCount >= ETSY_MAX_TAGS ? 'opacity-40 cursor-not-allowed' : ''}
                                    `}
                                  >
                                    <Plus className="size-3.5 shrink-0" />
                                    <span>{rt}</span>
                                  </button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <div className="space-y-1 text-xs">
                                    <p>Related to &ldquo;{tag}&rdquo; · Click to add</p>
                                    <p>{getCompetitionLabel(meta.competition)}</p>
                                    <p>{getVolumeLabel(meta.volume)}</p>
                                  </div>
                                </TooltipContent>
                              </Tooltip>
                            )
                          })
                        }).flat()}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Long-tail Keywords */}
              {longTailKeywords.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <TrendingUp className="size-4 text-rose-500" />
                      Long-tail Keyword Suggestions
                    </CardTitle>
                    <CardDescription>
                      Combine 2-3 tags into longer phrases for better SEO.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-y-auto max-h-52">
                      <div className="space-y-2 pr-2">
                        {longTailKeywords.map((kw, i) => (
                          <div
                            key={i}
                            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-muted/50 text-sm"
                          >
                            <span className="flex-1 break-words">{kw}</span>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <button
                                  onClick={() => {
                                    navigator.clipboard.writeText(kw)
                                    toast({ title: 'Keyword copied!', description: kw })
                                  }}
                                  className="text-muted-foreground hover:text-foreground transition-colors shrink-0"
                                >
                                  <Copy className="size-4" />
                                </button>
                              </TooltipTrigger>
                              <TooltipContent>Copy keyword</TooltipContent>
                            </Tooltip>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Right Column: Analytics + Audit */}
            <div className="space-y-6">
              {/* Listing Audit Score */}
              <Card className="overflow-hidden">
                <div className="h-1 bg-gradient-to-r from-rose-500 to-pink-500" />
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Target className="size-4 text-rose-500" />
                    Listing Audit Score
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col items-center gap-3">
                    <AuditScoreCard score={auditScore} />
                    <div className="w-full space-y-2 text-sm text-muted-foreground">
                      <div className="flex justify-between">
                        <span>Tag count</span>
                        <span className={tagCount >= ETSY_MAX_TAGS ? 'text-green-600 font-medium' : ''}>
                          {tagCount}/{ETSY_MAX_TAGS}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Quality distribution</span>
                        <span className="font-medium">
                          {tagQualityCounts.strong}S/{tagQualityCounts.medium}M/{tagQualityCounts.weak}W
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Category diversity</span>
                        <span className={categoryCoverage.size >= 4 ? 'text-green-600 font-medium' : ''}>
                          {categoryCoverage.size} categories
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Duplicates</span>
                        <span className={similarTagPairs.length === 0 ? 'text-green-600 font-medium' : 'text-amber-600 font-medium'}>
                          {similarTagPairs.length} pair{similarTagPairs.length !== 1 ? 's' : ''}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Tag Analytics Panel */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <BarChart3 className="size-4 text-rose-500" />
                    Tag Analytics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Quality Distribution */}
                  <div>
                    <p className="text-sm font-medium mb-2">Quality Distribution</p>
                    <div className="flex items-center gap-3">
                      <CSSPieChart
                        segments={[
                          { value: tagQualityCounts.strong, color: '#22c55e', label: 'Strong' },
                          { value: tagQualityCounts.medium, color: '#f59e0b', label: 'Medium' },
                          { value: tagQualityCounts.weak, color: '#ef4444', label: 'Weak' },
                        ]}
                      />
                      <div className="space-y-1.5 text-sm">
                        <div className="flex items-center gap-1.5">
                          <span className="size-2.5 rounded-full bg-green-500" />
                          <span>Strong ({tagQualityCounts.strong})</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="size-2.5 rounded-full bg-amber-500" />
                          <span>Medium ({tagQualityCounts.medium})</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="size-2.5 rounded-full bg-red-400" />
                          <span>Weak ({tagQualityCounts.weak})</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Competition Breakdown */}
                  <div>
                    <p className="text-sm font-medium mb-2">Competition Breakdown</p>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm w-16">Low</span>
                        <div className="flex-1 h-3 bg-muted/30 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-green-500 rounded-full transition-all duration-500"
                            style={{ width: `${selectedTags.length > 0 ? (competitionCounts.low / selectedTags.length) * 100 : 0}%` }}
                          />
                        </div>
                        <span className="text-sm w-6 text-right font-medium">{competitionCounts.low}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm w-16">Medium</span>
                        <div className="flex-1 h-3 bg-muted/30 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-amber-500 rounded-full transition-all duration-500"
                            style={{ width: `${selectedTags.length > 0 ? (competitionCounts.medium / selectedTags.length) * 100 : 0}%` }}
                          />
                        </div>
                        <span className="text-sm w-6 text-right font-medium">{competitionCounts.medium}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm w-16">High</span>
                        <div className="flex-1 h-3 bg-muted/30 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-red-500 rounded-full transition-all duration-500"
                            style={{ width: `${selectedTags.length > 0 ? (competitionCounts.high / selectedTags.length) * 100 : 0}%` }}
                          />
                        </div>
                        <span className="text-sm w-6 text-right font-medium">{competitionCounts.high}</span>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Category Coverage */}
                  <div>
                    <p className="text-sm font-medium mb-2">Category Coverage</p>
                    <div className="flex flex-wrap gap-1.5 overflow-hidden">
                      {allCategories.map((cat) => {
                        const isCovered = categoryCoverage.has(cat.id)
                        return (
                          <Tooltip key={cat.id}>
                            <TooltipTrigger asChild>
                              <span
                                className={`
                                  inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium border
                                  ${isCovered
                                    ? 'bg-rose-50 text-rose-600 border-rose-200'
                                    : 'bg-muted/30 text-muted-foreground/50 border-transparent'
                                  }
                                `}
                              >
                                {cat.icon} {cat.name}
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>
                              {isCovered ? 'Covered' : 'Not covered'}
                            </TooltipContent>
                          </Tooltip>
                        )
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* ═══════════════════════════════════════════════════════════════════
            TAB 3: EXPORT
            ═══════════════════════════════════════════════════════════════════ */}
        <TabsContent value="export" className="space-y-6">
          {/* Results section - wrapped for export capture */}
          <div id="tag-results" className="bg-white rounded-xl">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
              {/* Etsy Title Generator */}
              <Card className="overflow-hidden">
                <div className="h-1 bg-gradient-to-r from-rose-500 to-pink-500" />
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <FileText className="size-4 text-rose-500" />
                    Etsy Title Generator
                  </CardTitle>
                  <CardDescription>
                    Smart-ordered title from your tags. Edit to customize.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="relative">
                    <Textarea
                      value={displayTitle}
                      onChange={(e) => setEtsyTitleEdit(e.target.value)}
                      placeholder="Your Etsy title will appear here..."
                      className="min-h-[80px] resize-y pr-16 text-sm sm:text-base"
                    />
                    <div className="absolute top-2 right-2 flex flex-col items-end gap-0.5 pointer-events-none">
                      <span className={`text-xs font-bold bg-background/80 px-1 rounded ${titleCharColor}`}>
                        {titleCharCount}/{ETSY_TITLE_MAX_CHARS}
                      </span>
                      <div className="w-10 sm:w-12 h-1.5 bg-muted/30 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            titleCharCount > ETSY_TITLE_MAX_CHARS
                              ? 'bg-red-500'
                              : titleCharCount >= 100
                                ? 'bg-green-500'
                                : 'bg-amber-500'
                          }`}
                          style={{ width: `${Math.min((titleCharCount / ETSY_TITLE_MAX_CHARS) * 100, 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  {titleCharCount > ETSY_TITLE_MAX_CHARS && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertTriangle className="size-3" />
                      Title exceeds {ETSY_TITLE_MAX_CHARS} character limit
                    </p>
                  )}
                  {titleCharCount >= 100 && titleCharCount <= ETSY_TITLE_MAX_CHARS && (
                    <p className="text-xs text-green-600 flex items-center gap-1">
                      <CheckCircle2 className="size-3" />
                      Good title length for Etsy SEO
                    </p>
                  )}
                  <div className="flex gap-2" data-export-ignore>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEtsyTitleEdit(null)
                        toast({ title: 'Title reset', description: 'Reverted to auto-generated title' })
                      }}
                      disabled={etsyTitleEdit === null}
                    >
                      <RotateCcw className="size-3.5" />
                      Reset
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => {
                        if (!usage.canUse()) {
                          setShowLimitPopup(true)
                          return
                        }
                        usage.incrementUsage('tags', 'copy')
                        navigator.clipboard.writeText(displayTitle)
                        toast({ title: 'Title copied!', description: `${titleCharCount} characters` })
                      }}
                      className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white"
                    >
                      <Copy className="size-3.5" />
                      Copy Title
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Copy & Export Buttons */}
              <Card data-export-ignore>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Download className="size-4 text-rose-500" />
                    Copy &amp; Export
                  </CardTitle>
                  <CardDescription>
                    Copy tags in various formats or download as files.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Copy buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopy('comma')}
                      disabled={selectedTags.length === 0}
                      className="w-full"
                    >
                      <Copy className="size-3.5" />
                      {copied === 'comma' ? 'Copied!' : 'Comma'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopy('etsy')}
                      disabled={selectedTags.length === 0}
                      className="w-full"
                    >
                      <ShoppingBag className="size-3.5" />
                      {copied === 'etsy' ? 'Copied!' : 'Etsy Format'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopy('hashtags')}
                      disabled={selectedTags.length === 0}
                      className="w-full"
                    >
                      <Hash className="size-3.5" />
                      {copied === 'hashtags' ? 'Copied!' : 'Hashtags'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopy('csv')}
                      disabled={selectedTags.length === 0}
                      className="w-full"
                    >
                      <FileSpreadsheet className="size-3.5" />
                      {copied === 'csv' ? 'Copied!' : 'CSV Values'}
                    </Button>
                  </div>

                  <Separator />

                  {/* File export */}
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleExportCSV}
                      disabled={selectedTags.length === 0}
                      className="w-full"
                    >
                      <FileSpreadsheet className="size-3.5" />
                      Export CSV
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDownloadImage}
                      disabled={selectedTags.length === 0 || isExporting}
                      className="w-full"
                    >
                      <ImageIcon className="size-3.5" />
                      {isExporting ? 'Exporting...' : 'Download Image'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDownloadPDF}
                      disabled={selectedTags.length === 0 || isExporting}
                      className="w-full col-span-2"
                    >
                      <FileText className="size-3.5" />
                      {isExporting ? 'Exporting...' : 'Download PDF'}
                    </Button>
                  </div>

                  <Separator />

                  {/* Save/Load */}
                  <div className="flex gap-2">
                    <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSaveDialogOpen(true)}
                        disabled={selectedTags.length === 0}
                        className="flex-1"
                      >
                        <Save className="size-3.5" />
                        Save Set
                      </Button>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Save Tag Set</DialogTitle>
                          <DialogDescription>
                            Give your tag set a name to save and reload later.
                          </DialogDescription>
                        </DialogHeader>
                        <Input
                          placeholder="e.g., Valentine's Cards 2025"
                          value={tagSetName}
                          onChange={(e) => setTagSetName(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSave()
                          }}
                        />
                        <DialogFooter>
                          <Button
                            onClick={handleSave}
                            disabled={!tagSetName.trim()}
                            className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white"
                          >
                            Save
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                    {savedSets.length > 0 && (
                      <Accordion type="single" collapsible className="flex-1">
                        <AccordionItem value="saved" className="border-none">
                          <AccordionTrigger className="py-1 text-xs hover:no-underline">
                            <span className="flex items-center gap-1.5">
                              <FolderOpen className="size-3.5" />
                              Load Set ({savedSets.length})
                            </span>
                          </AccordionTrigger>
                          <AccordionContent>
                            <div className="overflow-y-auto max-h-48">
                              <div className="space-y-1 pr-2">
                                {savedSets.map((set) => (
                                  <div
                                    key={set.id}
                                    className="flex items-center justify-between gap-2 px-2 py-1.5 rounded-lg bg-muted/50"
                                  >
                                    <button
                                      onClick={() => handleLoadSet(set)}
                                      className="text-xs font-medium hover:text-primary transition-colors text-left flex-1 cursor-pointer"
                                    >
                                      {set.name} ({set.tags.length})
                                    </button>
                                    <button
                                      onClick={() => handleDeleteSet(set.id)}
                                      className="text-muted-foreground hover:text-destructive transition-colors"
                                    >
                                      <Trash2 className="size-3" />
                                    </button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Tag preview for export */}
            {selectedTags.length > 0 && (
              <Card className="mt-6">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Tag className="size-4 text-rose-500" />
                    Tag Preview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2 overflow-hidden">
                    {selectedTags.map((tag, i) => {
                      const meta = estimateTagMeta(tag)
                      const quality = getTagQuality(tag)
                      const qualityBorder = quality === 'Strong'
                        ? 'border-l-green-500'
                        : quality === 'Medium'
                          ? 'border-l-amber-500'
                          : 'border-l-red-400'
                      return (
                        <div
                          key={tag}
                          className="inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium
                            bg-gradient-to-r from-rose-50 to-pink-50
                            border border-rose-100 border-l-4"
                          style={{ borderLeftColor: quality === 'Strong' ? '#22c55e' : quality === 'Medium' ? '#f59e0b' : '#f87171' }}
                        >
                          <span>{tag}</span>
                          <PlatformBadges platforms={meta.platforms} />
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Tips Accordion */}
          <Card data-export-ignore>
            <CardContent className="pt-6">
              <Accordion type="multiple" className="w-full">
                <AccordionItem value="tips">
                  <AccordionTrigger className="text-sm font-medium">
                    <span className="flex items-center gap-2">
                      <Lightbulb className="size-4 text-amber-500" />
                      Tips for Better Tags
                    </span>
                  </AccordionTrigger>
                  <AccordionContent>
                    <ul className="space-y-1.5 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="size-3.5 text-green-500 mt-0.5 shrink-0" />
                        Use all {ETSY_MAX_TAGS} tags - every unfilled slot is a missed search opportunity
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="size-3.5 text-green-500 mt-0.5 shrink-0" />
                        Multi-word tags (3+ words) rank better in specific searches
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="size-3.5 text-green-500 mt-0.5 shrink-0" />
                        Low competition tags help you stand out in crowded categories
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="size-3.5 text-green-500 mt-0.5 shrink-0" />
                        Diversify across categories - product, material, occasion, recipient
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="size-3.5 text-green-500 mt-0.5 shrink-0" />
                        Avoid duplicates and similar tags - they waste limited slots
                      </li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="understanding">
                  <AccordionTrigger className="text-sm font-medium">
                    <span className="flex items-center gap-2">
                      <BarChart3 className="size-4 text-rose-500" />
                      Understanding Tag Quality
                    </span>
                  </AccordionTrigger>
                  <AccordionContent>
                    <ul className="space-y-1.5 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <span className="size-2 rounded-full bg-green-500 mt-1 shrink-0" />
                        <span><strong className="text-foreground">Strong</strong> - Multi-word tags with specific descriptors (e.g., &ldquo;handmade birthday card&rdquo;)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="size-2 rounded-full bg-amber-500 mt-1 shrink-0" />
                        <span><strong className="text-foreground">Medium</strong> - Two-word or moderate length tags (e.g., &ldquo;greeting card&rdquo;)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="size-2 rounded-full bg-red-400 mt-1 shrink-0" />
                        <span><strong className="text-foreground">Weak</strong> - Single short or very generic words (e.g., &ldquo;card&rdquo;)</span>
                      </li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="platforms">
                  <AccordionTrigger className="text-sm font-medium">
                    <span className="flex items-center gap-2">
                      <Globe className="size-4 text-sky-500" />
                      Multi-Platform Tags
                    </span>
                  </AccordionTrigger>
                  <AccordionContent>
                    <ul className="space-y-1.5 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <span className="text-orange-500 font-bold text-xs mt-0.5">E</span>
                        <span><strong className="text-foreground">Etsy</strong> - Best for handmade, vintage, and craft supplies</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-sky-500 font-bold text-xs mt-0.5">A</span>
                        <span><strong className="text-foreground">Amazon</strong> - Better for short, gift-oriented keywords</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-green-600 font-bold text-xs mt-0.5">S</span>
                        <span><strong className="text-foreground">Shopify</strong> - Works well for handmade and artisan keywords</span>
                      </li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Donation prompt - shown after results */}
      {selectedTags.length > 0 && (
        <ToolDonationPrompt onSupportClick={onSupportClick} />
      )}
    </div>
  )
}
