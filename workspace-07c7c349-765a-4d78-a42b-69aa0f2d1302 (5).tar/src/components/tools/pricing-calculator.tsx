'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import { useUsageTracker } from '@/hooks/use-usage-tracker'
import { useSharedData } from '@/hooks/use-shared-data'
import { PLATFORMS, calculatePlatformFees, CURRENCIES } from '@/lib/platform-fees'
import { createAutoSave, downloadAsImage, downloadAsPDF } from '@/lib/export-utils'
import { toast } from '@/hooks/use-toast'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Plus,
  Trash2,
  Calculator,
  Copy,
  Save,
  FolderOpen,
  Lightbulb,
  Check,
  X,
  Download,
  Ruler,
  Warehouse,
  Package,
  Coins,
  FileImage,
  FileText,
  PackageCheck,
  TrendingUp,
  ShieldCheck,
} from 'lucide-react'
import { LimitPopup } from '@/components/support/limit-popup'
import { ToolDonationPrompt } from '@/components/support/tool-donation-prompt'

// Types
interface MaterialItem {
  id: string
  name: string
  cost: number
  qty: number
}

interface PricingTemplate {
  id: string
  name: string
  materials: { name: string; cost: number; qty: number }[]
  hours: number
  hourlyRate: number
  overhead: number
  packagingCost: number
  quantity: number
  profitMargin: number
  currency: string
  category: string
  savedAt: string
}

interface PlatformResult {
  key: string
  name: string
  sellingPrice: number
  listingFee: number
  transactionFee: number
  paymentProcessing: number
  totalFees: number
  netProfit: number
}

// Category tips for competitor price comparison
const CATEGORY_TIPS: Record<string, { label: string; tip: string; avgMultiplier: string }> = {
  jewelry: {
    label: 'Jewelry',
    tip: 'Handmade jewelry typically sells at 2-4x material cost. Check Etsy sold listings for similar pieces to gauge your market.',
    avgMultiplier: '2.5-4x',
  },
  clothing: {
    label: 'Clothing & Accessories',
    tip: 'Handmade clothing commands premium pricing. Check similar Etsy/Instagram shops — quality fabric + labor usually justifies 2-3x markup.',
    avgMultiplier: '2-3x',
  },
  home_decor: {
    label: 'Home Decor',
    tip: 'Home decor items on Etsy average $25-80. Unique, personalized pieces can go much higher. Compare with similar listings on Etsy and Wayfair.',
    avgMultiplier: '2-3.5x',
  },
  paper_crafts: {
    label: 'Paper Crafts & Stationery',
    tip: 'Greeting cards typically sell for $4-8, invitations $2-5 each. Volume discounts are common — consider offering sets.',
    avgMultiplier: '3-5x',
  },
  bath_body: {
    label: 'Bath & Body',
    tip: 'Handmade soaps sell for $5-12 each, candles $15-35. Ingredient quality justifies premium pricing over mass-market brands.',
    avgMultiplier: '3-4x',
  },
  toys: {
    label: 'Toys & Games',
    tip: 'Handmade toys can command 2-3x mass-produced equivalents. Safety compliance adds value. Check Etsy and local craft fair pricing.',
    avgMultiplier: '2-3x',
  },
  art: {
    label: 'Art & Prints',
    tip: 'Original art pricing is highly variable. Consider size, medium, and your reputation. Prints typically sell at 0.5-1x the original per-square-inch rate.',
    avgMultiplier: 'Varies widely',
  },
  other: {
    label: 'Other Crafts',
    tip: 'Research similar items on Etsy, Amazon Handmade, and at craft fairs. A 2-3x markup over materials is a common starting point for handmade goods.',
    avgMultiplier: '2-3x',
  },
}

// Helpers
const genId = () => Math.random().toString(36).substring(2, 10)

const TEMPLATES_KEY = 'artnew8-pricing-templates'
const AUTOSAVE_KEY = 'artnew8-pricing-autosave'

function loadTemplates(): PricingTemplate[] {
  if (typeof window === 'undefined') return []
  try {
    const saved = localStorage.getItem(TEMPLATES_KEY)
    if (saved) return JSON.parse(saved)
  } catch { /* ignore */ }
  return []
}

function saveTemplates(templates: PricingTemplate[]) {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(TEMPLATES_KEY, JSON.stringify(templates))
  } catch { /* ignore */ }
}

function formatCurrency(amount: number, currencyCode: string): string {
  const currency = CURRENCIES.find(c => c.code === currencyCode)
  const symbol = currency?.symbol ?? '$'
  return `${symbol}${amount.toFixed(2)}`
}

// Auto-save state interface
interface AutoSaveState {
  materials: { name: string; cost: number; qty: number }[]
  hours: number
  hourlyRate: number
  overhead: number
  packagingCost: number
  quantity: number
  profitMargin: number
  currency: string
  productName: string
  category: string
}

export default function PricingCalculator({ onSupportClick }: { onSupportClick: () => void }) {
  // Usage tracker
  const { dailyUsage, maxDaily, incrementUsage, canUse, getRemaining } = useUsageTracker()
  const [showLimitPopup, setShowLimitPopup] = useState(false)

  // Shared data
  const { updateFromPricing } = useSharedData()

  // Form state
  const [productName, setProductName] = useState('')
  const [category, setCategory] = useState('other')
  const [materials, setMaterials] = useState<MaterialItem[]>([
    { id: genId(), name: '', cost: 0, qty: 1 },
  ])
  const [hours, setHours] = useState(2)
  const [hourlyRate, setHourlyRate] = useState(15)
  const [overhead, setOverhead] = useState(0)
  const [packagingCost, setPackagingCost] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [profitMargin, setProfitMargin] = useState(50)
  const [currency, setCurrency] = useState('USD')

  // Results
  const [results, setResults] = useState<PlatformResult[] | null>(null)
  const [totalCost, setTotalCost] = useState(0)
  const [basePrice, setBasePrice] = useState(0)

  // Templates — use lazy initializer to load from localStorage on first render
  const [templates, setTemplates] = useState<PricingTemplate[]>(() => {
    if (typeof window === 'undefined') return []
    return loadTemplates()
  })
  const [templateName, setTemplateName] = useState('')
  const [saveDialogOpen, setSaveDialogOpen] = useState(false)
  const [loadDialogOpen, setLoadDialogOpen] = useState(false)

  // Copy state
  const [copied, setCopied] = useState(false)

  // Auto-save indicator
  const [showAutoSaved, setShowAutoSaved] = useState(false)
  const autoSaveRef = useRef<ReturnType<typeof createAutoSave<AutoSaveState>> | null>(null)
  const autoSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Initialize auto-save
  useEffect(() => {
    autoSaveRef.current = createAutoSave<AutoSaveState>(
      AUTOSAVE_KEY,
      () => ({
        materials: materials.map(m => ({ name: m.name, cost: m.cost, qty: m.qty })),
        hours,
        hourlyRate,
        overhead,
        packagingCost,
        quantity,
        profitMargin,
        currency,
        productName,
        category,
      }),
      1000
    )
  }, [])

  // Auto-save on every form change
  useEffect(() => {
    if (!autoSaveRef.current) return
    autoSaveRef.current.save()
    // Show "Auto-saved" indicator after the debounce completes
    if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current)
    autoSaveTimerRef.current = setTimeout(() => setShowAutoSaved(true), 1200)
    return () => {
      if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current)
    }
  }, [materials, hours, hourlyRate, overhead, packagingCost, quantity, profitMargin, currency, productName, category])

  // Hide auto-saved indicator after 3 seconds
  useEffect(() => {
    if (!showAutoSaved) return
    const timer = setTimeout(() => setShowAutoSaved(false), 3000)
    return () => clearTimeout(timer)
  }, [showAutoSaved])

  // Auto-restore on mount
  const hasRestoredRef = useRef(false)
  useEffect(() => {
    if (hasRestoredRef.current || !autoSaveRef.current) return
    hasRestoredRef.current = true
    const saved = autoSaveRef.current.load()
    if (saved) {
      if (saved.materials?.length) {
        setMaterials(saved.materials.map(m => ({ ...m, id: genId() })))
      }
      if (saved.hours !== undefined) setHours(saved.hours)
      if (saved.hourlyRate !== undefined) setHourlyRate(saved.hourlyRate)
      if (saved.overhead !== undefined) setOverhead(saved.overhead)
      if (saved.packagingCost !== undefined) setPackagingCost(saved.packagingCost)
      if (saved.quantity !== undefined) setQuantity(saved.quantity)
      if (saved.profitMargin !== undefined) setProfitMargin(saved.profitMargin)
      if (saved.currency) setCurrency(saved.currency)
      if (saved.productName !== undefined) setProductName(saved.productName)
      if (saved.category) setCategory(saved.category)
    }
  }, [])

  // Material helpers
  const addMaterial = () => {
    setMaterials(prev => [...prev, { id: genId(), name: '', cost: 0, qty: 1 }])
  }

  const removeMaterial = (id: string) => {
    setMaterials(prev => prev.filter(m => m.id !== id))
  }

  const updateMaterial = (id: string, field: keyof MaterialItem, value: string | number) => {
    setMaterials(prev =>
      prev.map(m => (m.id === id ? { ...m, [field]: value } : m))
    )
  }

  // Calculate
  const handleCalculate = useCallback(() => {
    if (!canUse()) {
      setShowLimitPopup(true)
      return
    }

    const materialCost = materials.reduce((sum, m) => sum + (m.cost || 0) * (m.qty || 0), 0)
    const laborCost = (hours || 0) * (hourlyRate || 0)
    const cost = materialCost + laborCost + (overhead || 0) + (packagingCost || 0)
    const margin = profitMargin / 100
    const pricePerUnit = margin >= 1 ? cost : cost / (1 - margin)
    const totalPrice = pricePerUnit * (quantity || 1)

    const platformResults: PlatformResult[] = Object.entries(PLATFORMS).map(
      ([key, platform]) => {
        const fees = calculatePlatformFees(platform, totalPrice)
        return {
          key,
          name: platform.name,
          sellingPrice: totalPrice,
          listingFee: fees.listingFee,
          transactionFee: fees.transactionFee,
          paymentProcessing: fees.paymentProcessing,
          totalFees: fees.totalFees,
          netProfit: fees.netProfit,
        }
      }
    )

    const success = incrementUsage('pricing', 'calculate')
    if (!success) {
      setShowLimitPopup(true)
      return
    }

    setTotalCost(cost)
    setBasePrice(totalPrice)
    setResults(platformResults)

    // Update shared data for other tools
    updateFromPricing({
      productName: productName || undefined,
      materials: materials.map(m => ({ name: m.name, cost: m.cost, qty: m.qty })),
      totalCost: cost,
      sellingPrice: totalPrice,
      currency,
      profitMargin,
      hoursSpent: hours,
      hourlyRate,
    })
  }, [materials, hours, hourlyRate, overhead, packagingCost, quantity, profitMargin, canUse, incrementUsage, updateFromPricing, productName, currency])

  // Save template
  const handleSaveTemplate = () => {
    if (!templateName.trim()) return

    const template: PricingTemplate = {
      id: genId(),
      name: templateName.trim(),
      materials: materials.map(m => ({ name: m.name, cost: m.cost, qty: m.qty })),
      hours,
      hourlyRate,
      overhead,
      packagingCost,
      quantity,
      profitMargin,
      currency,
      category,
      savedAt: new Date().toISOString(),
    }

    const updated = [...templates, template]
    saveTemplates(updated)
    setTemplates(updated)
    setTemplateName('')
    setSaveDialogOpen(false)
  }

  // Load template — auto-calculate results
  const handleLoadTemplate = (template: PricingTemplate) => {
    setMaterials(template.materials.map(m => ({ ...m, id: genId() })))
    setHours(template.hours)
    setHourlyRate(template.hourlyRate)
    setOverhead(template.overhead)
    setPackagingCost(template.packagingCost || 0)
    setQuantity(template.quantity || 1)
    setProfitMargin(template.profitMargin)
    setCurrency(template.currency)
    setCategory(template.category || 'other')
    setLoadDialogOpen(false)

    // Auto-calculate after loading template
    const materialCost = template.materials.reduce((sum, m) => sum + (m.cost || 0) * (m.qty || 0), 0)
    const laborCost = (template.hours || 0) * (template.hourlyRate || 0)
    const cost = materialCost + laborCost + (template.overhead || 0) + (template.packagingCost || 0)
    const margin = template.profitMargin / 100
    const pricePerUnit = margin >= 1 ? cost : cost / (1 - margin)
    const totalPrice = pricePerUnit * (template.quantity || 1)

    const platformResults: PlatformResult[] = Object.entries(PLATFORMS).map(
      ([key, platform]) => {
        const fees = calculatePlatformFees(platform, totalPrice)
        return {
          key,
          name: platform.name,
          sellingPrice: totalPrice,
          listingFee: fees.listingFee,
          transactionFee: fees.transactionFee,
          paymentProcessing: fees.paymentProcessing,
          totalFees: fees.totalFees,
          netProfit: fees.netProfit,
        }
      }
    )

    setTotalCost(cost)
    setBasePrice(totalPrice)
    setResults(platformResults)

    // Show toast confirmation
    toast({
      title: 'Template Loaded',
      description: `"${template.name}" loaded and pricing calculated automatically.`,
    })
  }

  // Delete template
  const handleDeleteTemplate = (id: string) => {
    const updated = templates.filter(t => t.id !== id)
    saveTemplates(updated)
    setTemplates(updated)
  }

  // Copy results
  const handleCopyResults = () => {
    if (!results) return

    const curr = currency
    const qty = quantity || 1
    const pricePerUnit = basePrice / qty
    const breakEvenPrice = totalCost
    const wholesalePrice = basePrice * 0.5

    const lines = [
      `artnew8 studio - Pricing Calculator Results`,
      `==========================================`,
      ``,
      `Product: ${productName || 'Unnamed'}`,
      `Quantity: ${qty}`,
      `Total Cost: ${formatCurrency(totalCost, curr)}`,
      `Desired Profit Margin: ${profitMargin}%`,
      `Break-Even Price: ${formatCurrency(breakEvenPrice, curr)}`,
      `Price Per Unit: ${formatCurrency(pricePerUnit, curr)}`,
      `Total Revenue: ${formatCurrency(basePrice, curr)}`,
      `Wholesale Suggestion: ${formatCurrency(wholesalePrice, curr)}`,
      ``,
      `Platform Comparison:`,
      ...results.map(r => [
        ``,
        `  ${r.name}:`,
        `    Selling Price: ${formatCurrency(r.sellingPrice, curr)}`,
        `    Listing Fee: ${formatCurrency(r.listingFee, curr)}`,
        `    Transaction Fee: ${formatCurrency(r.transactionFee, curr)}`,
        `    Payment Processing: ${formatCurrency(r.paymentProcessing, curr)}`,
        `    Total Fees: ${formatCurrency(r.totalFees, curr)}`,
        `    Net Profit After Fees: ${formatCurrency(r.netProfit, curr)}`,
      ].join('\n')),
      ``,
      `Calculated with artnew8 studio - Free tools for handmade sellers`,
    ]

    navigator.clipboard.writeText(lines.join('\n')).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  // Export as Image
  const [exportingImg, setExportingImg] = useState(false)
  const [exportingPdf, setExportingPdf] = useState(false)

  // Market Research state
  const [isResearchingPrice, setIsResearchingPrice] = useState(false)
  const [marketResearch, setMarketResearch] = useState<{
    priceRange: { min: number; max: number; avg: number }
    sources: { name: string; url: string; price: string }[]
  } | null>(null)
  const [researchError, setResearchError] = useState<string | null>(null)

  // Market Research handler
  const handleMarketResearch = async () => {
    if (!productName?.trim()) {
      toast({ title: 'Enter a product name', description: 'Name your product to research market prices' })
      return
    }
    if (!canUse()) {
      setShowLimitPopup(true)
      return
    }
    setIsResearchingPrice(true)
    setResearchError(null)
    setMarketResearch(null)
    try {
      const sessionId = typeof window !== 'undefined' ? localStorage.getItem('artnew8-session-id') || '' : ''
      const res = await fetch('/api/ai/research-price', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          product: productName,
          category,
          sessionId,
        }),
      })
      if (res.status === 429) {
        toast({ title: 'Please wait', description: 'Too many requests. Try again in a minute.' })
        return
      }
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Request failed' }))
        throw new Error(err.error || 'Request failed')
      }
      const data = await res.json()
      incrementUsage('pricing', 'market-research')
      setMarketResearch({
        priceRange: data.priceRange || { min: 0, max: 0, avg: 0 },
        sources: data.sources || [],
      })
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong'
      setResearchError(message)
      toast({ title: 'Research failed', description: message, variant: 'destructive' })
    } finally {
      setIsResearchingPrice(false)
    }
  }

  const handleExportImage = async () => {
    const fileName = `pricing-${(productName || new Date().toISOString().split('T')[0]).replace(/\s+/g, '-').toLowerCase()}`
    setExportingImg(true)
    try {
      await downloadAsImage('pricing-results', fileName)
      toast({ title: 'Image downloaded!', description: 'Pricing results saved as image' })
    } catch (err) {
      console.error('Image export failed:', err)
      toast({ title: 'Export failed', description: 'Could not generate image. Please try again.', variant: 'destructive' })
    } finally {
      setExportingImg(false)
    }
  }

  // Export as PDF
  const handleExportPDF = async () => {
    const fileName = `pricing-${(productName || new Date().toISOString().split('T')[0]).replace(/\s+/g, '-').toLowerCase()}`
    setExportingPdf(true)
    try {
      await downloadAsPDF('pricing-results', fileName)
      toast({ title: 'PDF downloaded!', description: 'Pricing results saved as PDF' })
    } catch (err) {
      console.error('PDF export failed:', err)
      toast({ title: 'Export failed', description: 'Could not generate PDF. Please try again.', variant: 'destructive' })
    } finally {
      setExportingPdf(false)
    }
  }

  const remaining = getRemaining()

  // Derived values for results
  const qty = quantity || 1
  const pricePerUnit = results ? basePrice / qty : 0
  const breakEvenPrice = totalCost
  const wholesalePrice = basePrice * 0.5
  const totalRevenue = basePrice

  // Profit margin percentage after platform fees
  const getProfitColor = (netProfit: number) => {
    const profitPct = totalRevenue > 0 ? ((netProfit - totalCost) / totalRevenue) * 100 : 0
    if (profitPct > 30) return 'text-green-600'
    if (profitPct >= 15) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getProfitBgColor = (netProfit: number) => {
    const profitPct = totalRevenue > 0 ? ((netProfit - totalCost) / totalRevenue) * 100 : 0
    if (profitPct > 30) return 'bg-green-50 border-green-200'
    if (profitPct >= 15) return 'bg-yellow-50 border-yellow-200'
    return 'bg-red-50 border-red-200'
  }

  const getProfitBadgeVariant = (netProfit: number) => {
    const profitPct = totalRevenue > 0 ? ((netProfit - totalCost) / totalRevenue) * 100 : 0
    if (profitPct > 30) return 'default' as const
    if (profitPct >= 15) return 'secondary' as const
    return 'destructive' as const
  }

  // Find best platform by net profit
  const getBestPlatform = () => {
    if (!results || results.length === 0) return null
    return results.reduce((best, r) => r.netProfit > best.netProfit ? r : best, results[0])
  }

  const categoryTip = CATEGORY_TIPS[category] || CATEGORY_TIPS.other

  return (
    <div className="w-full max-w-4xl mx-auto px-2 sm:px-4 py-4 sm:py-8 space-y-4 sm:space-y-6">
      {/* Limit Popup */}
      <LimitPopup
        open={showLimitPopup}
        onClose={() => setShowLimitPopup(false)}
        onSupportClick={onSupportClick}
        remaining={remaining}
      />
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 text-primary">
          <Calculator className="size-7" />
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Smart Pricing Calculator</h1>
        </div>
        <p className="text-muted-foreground text-sm sm:text-base max-w-xl mx-auto">
          Calculate your handmade item pricing with material costs, labor, overhead, and platform fees — all in one place.
        </p>
        {/* Auto-save indicator */}
        {showAutoSaved && (
          <div className="flex items-center justify-center gap-1.5 text-sm text-muted-foreground animate-in fade-in-0 duration-300">
            <ShieldCheck className="size-3.5" />
            <span>Auto-saved</span>
          </div>
        )}
      </div>

      <Tabs defaultValue="calculator" className="w-full">
        <TabsList className="w-full sm:w-auto mx-auto grid grid-cols-2 sm:inline-flex">
          <TabsTrigger value="calculator">Calculator</TabsTrigger>
          <TabsTrigger value="templates">
            <FolderOpen className="size-4 mr-1" />
            Templates
          </TabsTrigger>
        </TabsList>

        <TabsContent value="calculator" className="space-y-6 mt-6">
          {/* Currency Selection + Actions Bar */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Label htmlFor="currency" className="text-base font-semibold whitespace-nowrap">Currency</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger id="currency" className="w-[140px]">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map(c => (
                    <SelectItem key={c.code} value={c.code}>
                      {c.symbol} {c.code} — {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              {/* Save Template */}
              <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Save className="size-4 mr-1" />
                    Save as Template
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Save Pricing Template</DialogTitle>
                    <DialogDescription>
                      Save your current inputs as a reusable template.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="template-name">Template Name</Label>
                      <Input
                        id="template-name"
                        placeholder="e.g., Greeting Card — Standard"
                        value={templateName}
                        onChange={e => setTemplateName(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && handleSaveTemplate()}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setSaveDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleSaveTemplate} disabled={!templateName.trim()}>
                      <Save className="size-4 mr-1" />
                      Save Template
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              {/* Load Template */}
              <Dialog open={loadDialogOpen} onOpenChange={setLoadDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <FolderOpen className="size-4 mr-1" />
                    Load
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Load Template</DialogTitle>
                    <DialogDescription>
                      Load a previously saved pricing template.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="max-h-96 overflow-y-auto custom-scrollbar space-y-3 py-2">
                    {templates.length === 0 ? (
                      <p className="text-muted-foreground text-sm text-center py-8">
                        No saved templates yet. Save your first one!
                      </p>
                    ) : (
                      templates.map(t => (
                        <div
                          key={t.id}
                          className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent/50 transition-colors"
                        >
                          <div className="min-w-0 flex-1">
                            <p className="font-medium text-base truncate">{t.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {t.materials.length} materials · {t.profitMargin}% margin · {new Date(t.savedAt).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="flex items-center gap-1 ml-3 shrink-0">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleLoadTemplate(t)}
                            >
                              <Download className="size-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteTemplate(t.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="size-4" />
                            </Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Product Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg sm:text-xl flex items-center gap-2">
                <span className="inline-flex items-center justify-center size-7 rounded-full bg-primary/10 text-primary text-xs font-bold">
                  <Package className="size-3.5" />
                </span>
                Product Info
              </CardTitle>
              <CardDescription>Name your product and select a category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="product-name">Product Name</Label>
                  <Input
                    id="product-name"
                    placeholder="e.g., Handmade Greeting Card"
                    value={productName}
                    onChange={e => setProductName(e.target.value)}
                    className="h-9"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger id="category" className="h-9">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(CATEGORY_TIPS).map(([key, val]) => (
                        <SelectItem key={key} value={key}>
                          {val.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Material Costs Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg sm:text-xl flex items-center gap-2">
                <span className="inline-flex items-center justify-center size-7 rounded-full bg-primary/10 text-primary text-xs font-bold"><Ruler className="size-3.5" /></span>
                Material Costs
              </CardTitle>
              <CardDescription>Add all materials used to create your item</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Header row for desktop */}
              <div className="hidden sm:grid sm:grid-cols-[1fr_120px_100px_40px] gap-3 text-sm font-medium text-muted-foreground px-1">
                <span>Material Name</span>
                <span>Cost per Unit</span>
                <span>Quantity</span>
                <span></span>
              </div>

              {materials.map((material) => (
                <div key={material.id} className="grid grid-cols-1 sm:grid-cols-[1fr_120px_100px_40px] gap-3 items-start">
                  <div className="space-y-1 min-w-0">
                    <Label className="sm:sr-only text-sm">Material Name</Label>
                    <Input
                      placeholder={`e.g., Cardstock paper`}
                      value={material.name}
                      onChange={e => updateMaterial(material.id, 'name', e.target.value)}
                      className="h-9"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="sm:sr-only text-sm">Cost per Unit ({CURRENCIES.find(c => c.code === currency)?.symbol ?? '$'})</Label>
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                      value={material.cost || ''}
                      onChange={e => updateMaterial(material.id, 'cost', parseFloat(e.target.value) || 0)}
                      className="h-9"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="sm:sr-only text-sm">Qty</Label>
                    <Input
                      type="number"
                      min="1"
                      step="1"
                      placeholder="1"
                      value={material.qty || ''}
                      onChange={e => updateMaterial(material.id, 'qty', parseInt(e.target.value) || 0)}
                      className="h-9"
                    />
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-9 w-9 text-muted-foreground hover:text-destructive shrink-0"
                    onClick={() => removeMaterial(material.id)}
                    disabled={materials.length <= 1}
                  >
                    <X className="size-4" />
                  </Button>
                </div>
              ))}

              <Button variant="outline" size="sm" onClick={addMaterial} className="w-full sm:w-auto">
                <Plus className="size-4 mr-1" />
                Add Material
              </Button>

              {materials.length > 0 && (
                <div className="flex justify-end">
                  <Badge variant="secondary" className="text-sm">
                    Materials total: {formatCurrency(
                      materials.reduce((sum, m) => sum + (m.cost || 0) * (m.qty || 0), 0),
                      currency
                    )}
                  </Badge>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Labor, Overhead & Packaging Section */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {/* Labor */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <span className="inline-flex items-center justify-center size-7 rounded-full bg-primary/10 text-primary text-xs font-bold">2</span>
                  Labor
                </CardTitle>
                <CardDescription>How much is your time worth?</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="hours">Hours Spent</Label>
                  <Input
                    id="hours"
                    type="number"
                    min="0"
                    step="0.25"
                    placeholder="0"
                    value={hours || ''}
                    onChange={e => setHours(parseFloat(e.target.value) || 0)}
                    className="h-9"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hourlyRate">Hourly Rate ({CURRENCIES.find(c => c.code === currency)?.symbol ?? '$'})</Label>
                  <Input
                    id="hourlyRate"
                    type="number"
                    min="0"
                    step="0.50"
                    placeholder="25.00"
                    value={hourlyRate || ''}
                    onChange={e => setHourlyRate(parseFloat(e.target.value) || 0)}
                    className="h-9"
                  />
                </div>
                <div className="flex justify-end">
                  <Badge variant="secondary" className="text-sm">
                    Labor: {formatCurrency((hours || 0) * (hourlyRate || 0), currency)}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Overhead */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <span className="inline-flex items-center justify-center size-7 rounded-full bg-primary/10 text-primary text-xs font-bold">3</span>
                  Overhead
                </CardTitle>
                <CardDescription>Fixed costs: rent, utilities, tool wear</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="overhead">Overhead Cost ({CURRENCIES.find(c => c.code === currency)?.symbol ?? '$'})</Label>
                  <Input
                    id="overhead"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    value={overhead || ''}
                    onChange={e => setOverhead(parseFloat(e.target.value) || 0)}
                    className="h-9"
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  Per-item share of rent, electricity, internet, tool wear-and-tear, etc.
                </p>
              </CardContent>
            </Card>

            {/* Packaging */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <span className="inline-flex items-center justify-center size-7 rounded-full bg-primary/10 text-primary text-xs font-bold">
                    <PackageCheck className="size-3.5" />
                  </span>
                  Packaging
                </CardTitle>
                <CardDescription>Boxes, bags, wrapping, labels</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="packagingCost">Packaging Cost ({CURRENCIES.find(c => c.code === currency)?.symbol ?? '$'})</Label>
                  <Input
                    id="packagingCost"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    value={packagingCost || ''}
                    onChange={e => setPackagingCost(parseFloat(e.target.value) || 0)}
                    className="h-9"
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  Per-item packaging: gift boxes, tissue paper, stickers, thank-you cards, etc.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Quantity & Profit Margin Section */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Quantity */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <span className="inline-flex items-center justify-center size-7 rounded-full bg-primary/10 text-primary text-xs font-bold">
                    <Coins className="size-3.5" />
                  </span>
                  Quantity
                </CardTitle>
                <CardDescription>How many items are you pricing at once?</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Number of Items</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    step="1"
                    placeholder="1"
                    value={quantity || ''}
                    onChange={e => setQuantity(parseInt(e.target.value) || 1)}
                    className="h-9"
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  Price per unit = total price / quantity. Useful for batch pricing or sets.
                </p>
              </CardContent>
            </Card>

            {/* Profit Margin */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <span className="inline-flex items-center justify-center size-7 rounded-full bg-primary/10 text-primary text-xs font-bold">4</span>
                  Profit Margin
                </CardTitle>
                <CardDescription>Set your desired profit margin percentage</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <Slider
                    value={[profitMargin]}
                    onValueChange={v => setProfitMargin(v[0])}
                    min={0}
                    max={99}
                    step={1}
                    className="flex-1"
                  />
                  <div className="w-20 text-right">
                    <span className="text-2xl font-bold text-primary">{profitMargin}%</span>
                  </div>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>0% — Break even</span>
                  <span>50%</span>
                  <span>99% — Maximum</span>
                </div>
                <p className="text-sm text-primary mt-1">
                  💡 Experts recommend 50-70% profit margin for handmade items to ensure sustainable pricing.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Calculate Button */}
          <div className="space-y-3">
            <Button
              size="lg"
              className="w-full text-base font-semibold h-12"
              onClick={handleCalculate}
              disabled={remaining <= 0}
            >
              <Calculator className="size-5 mr-2" />
              {remaining <= 0 ? 'Daily Limit Reached' : 'Calculate Pricing'}
            </Button>

            <p className="text-center text-sm text-muted-foreground">
              {remaining} calculation{remaining !== 1 ? 's' : ''} remaining today
            </p>
          </div>

          {/* Results Section */}
          {results && (
            <div id="pricing-results" className="space-y-6 animate-in fade-in-0 slide-in-from-bottom-4 duration-500">
              {/* Summary Card */}
              <Card className="border-primary/20">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">Pricing Summary</CardTitle>
                    <div className="flex items-center gap-2" data-export-ignore>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleCopyResults}
                      >
                        {copied ? (
                          <>
                            <Check className="size-4 mr-1 text-green-600" />
                            Copied!
                          </>
                        ) : (
                          <>
                            <Copy className="size-4 mr-1" />
                            Copy
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleExportImage}
                        disabled={exportingImg}
                      >
                        <FileImage className="size-4 mr-1" />
                        {exportingImg ? 'Exporting...' : 'Image'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleExportPDF}
                        disabled={exportingPdf}
                      >
                        <FileText className="size-4 mr-1" />
                        {exportingPdf ? 'Exporting...' : 'PDF'}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="min-w-0 text-center p-3 sm:p-4 rounded-lg bg-muted/50">
                      <p className="text-xs sm:text-sm text-muted-foreground uppercase tracking-wide font-semibold">Total Cost</p>
                      <p className="text-lg sm:text-2xl font-bold mt-1">{formatCurrency(totalCost, currency)}</p>
                      <p className="text-xs sm:text-sm text-muted-foreground mt-1 break-words">Materials + Labor + Overhead + Packaging</p>
                    </div>
                    <div className="min-w-0 text-center p-3 sm:p-4 rounded-lg bg-primary/5 border border-primary/10">
                      <p className="text-xs sm:text-sm text-muted-foreground uppercase tracking-wide font-semibold">Price Per Unit</p>
                      <p className="text-lg sm:text-2xl font-bold text-primary mt-1">{formatCurrency(pricePerUnit, currency)}</p>
                      <p className="text-xs sm:text-sm text-muted-foreground mt-1 break-words">Each item at {profitMargin}% margin</p>
                    </div>
                    <div className="min-w-0 text-center p-3 sm:p-4 rounded-lg bg-primary/5 border border-primary/10">
                      <p className="text-xs sm:text-sm text-muted-foreground uppercase tracking-wide font-semibold">Total Revenue</p>
                      <p className="text-lg sm:text-2xl font-bold text-primary mt-1">{formatCurrency(totalRevenue, currency)}</p>
                      <p className="text-xs sm:text-sm text-muted-foreground mt-1 break-words">For {qty} item{qty !== 1 ? 's' : ''}</p>
                    </div>
                    <div className="min-w-0 text-center p-3 sm:p-4 rounded-lg bg-muted/50">
                      <p className="text-xs sm:text-sm text-muted-foreground uppercase tracking-wide font-semibold">Desired Profit</p>
                      <p className="text-lg sm:text-2xl font-bold mt-1">{formatCurrency(basePrice - totalCost, currency)}</p>
                      <p className="text-xs sm:text-sm text-muted-foreground mt-1 break-words">Before platform fees</p>
                    </div>
                  </div>

                  {/* Break-Even & Wholesale */}
                  <Separator />
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <Warehouse className="size-5 text-orange-600 shrink-0" />
                      <div>
                        <p className="text-sm sm:text-base font-semibold">Break-Even Price</p>
                        <p className="text-sm text-muted-foreground">Minimum to cover costs (0% margin)</p>
                        <p className="text-xl font-bold text-orange-600">{formatCurrency(breakEvenPrice, currency)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-violet-50 border border-violet-200">
                      <Coins className="size-5 text-violet-600 shrink-0" />
                      <div>
                        <p className="text-sm sm:text-base font-semibold">Wholesale Suggestion</p>
                        <p className="text-sm text-muted-foreground">Typically 50% of retail price</p>
                        <p className="text-xl font-bold text-violet-600">{formatCurrency(wholesalePrice, currency)}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Platform Comparison */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">Platform Fee Comparison</CardTitle>
                  <CardDescription>
                    See how much you&apos;d actually earn on each platform
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-3 sm:px-6">
                  {/* Desktop table */}
                  <div className="hidden sm:block overflow-x-auto -mx-3 px-3 sm:mx-0 sm:px-0">
                    <table className="w-full text-base min-w-[640px]">
                      <thead>
                        <tr className="border-b text-left">
                          <th className="pb-3 font-medium text-muted-foreground whitespace-nowrap">Platform</th>
                          <th className="pb-3 font-medium text-muted-foreground text-right whitespace-nowrap">Selling Price</th>
                          <th className="pb-3 font-medium text-muted-foreground text-right whitespace-nowrap">Listing Fee</th>
                          <th className="pb-3 font-medium text-muted-foreground text-right whitespace-nowrap">Transaction Fee</th>
                          <th className="pb-3 font-medium text-muted-foreground text-right whitespace-nowrap">Processing Fee</th>
                          <th className="pb-3 font-medium text-muted-foreground text-right whitespace-nowrap">Total Fees</th>
                          <th className="pb-3 font-medium text-muted-foreground text-right whitespace-nowrap">Net Profit</th>
                          <th className="pb-3 font-medium text-muted-foreground text-right whitespace-nowrap">Margin</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.map(r => {
                          const profitPct = totalRevenue > 0 ? ((r.netProfit - totalCost) / totalRevenue) * 100 : 0
                          return (
                            <tr key={r.key} className={`border-b last:border-0 hover:bg-muted/30 transition-colors ${r.key === getBestPlatform()?.key ? 'bg-green-50/50' : ''}`}>
                              <td className="py-3 font-medium whitespace-nowrap">
                                {r.name}
                                {r.key === getBestPlatform()?.key && (
                                  <Badge className="ml-2 text-sm px-1.5 py-0 shrink-0" variant="default">Best</Badge>
                                )}
                              </td>
                              <td className="py-3 text-right whitespace-nowrap">{formatCurrency(r.sellingPrice, currency)}</td>
                              <td className="py-3 text-right text-muted-foreground whitespace-nowrap">{formatCurrency(r.listingFee, currency)}</td>
                              <td className="py-3 text-right text-muted-foreground whitespace-nowrap">{formatCurrency(r.transactionFee, currency)}</td>
                              <td className="py-3 text-right text-muted-foreground whitespace-nowrap">{formatCurrency(r.paymentProcessing, currency)}</td>
                              <td className="py-3 text-right font-medium text-destructive/80 whitespace-nowrap">
                                -{formatCurrency(r.totalFees, currency)}
                              </td>
                              <td className={`py-3 text-right font-bold whitespace-nowrap ${getProfitColor(r.netProfit)}`}>
                                {formatCurrency(r.netProfit, currency)}
                              </td>
                              <td className="py-3 text-right">
                                <Badge variant={getProfitBadgeVariant(r.netProfit)} className="text-sm px-1.5 py-0 shrink-0">
                                  {profitPct.toFixed(0)}%
                                </Badge>
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Mobile cards */}
                  <div className="sm:hidden space-y-3 -mx-1">
                    {results.map(r => {
                      const profitPct = totalRevenue > 0 ? ((r.netProfit - totalCost) / totalRevenue) * 100 : 0
                      return (
                        <div key={r.key} className={`rounded-lg border p-4 space-y-3 ${r.key === getBestPlatform()?.key ? 'border-green-300 bg-green-50/50' : ''}`}>
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 min-w-0">
                              <h4 className="font-semibold truncate">{r.name}</h4>
                              {r.key === getBestPlatform()?.key && (
                                <Badge className="text-sm px-1.5 py-0 shrink-0" variant="default">Best</Badge>
                              )}
                            </div>
                            <Badge variant={getProfitBadgeVariant(r.netProfit)} className="font-bold shrink-0">
                              {formatCurrency(r.netProfit, currency)}
                            </Badge>
                          </div>
                          <Separator />
                          <div className="grid grid-cols-2 gap-2 text-sm sm:text-base">
                            <div className="min-w-0">
                              <p className="text-muted-foreground text-sm">Selling Price</p>
                              <p className="font-medium truncate">{formatCurrency(r.sellingPrice, currency)}</p>
                            </div>
                            <div className="min-w-0">
                              <p className="text-muted-foreground text-sm">Total Fees</p>
                              <p className="font-medium text-destructive/80 truncate">-{formatCurrency(r.totalFees, currency)}</p>
                            </div>
                            <div className="min-w-0">
                              <p className="text-muted-foreground text-sm">Listing Fee</p>
                              <p className="truncate">{formatCurrency(r.listingFee, currency)}</p>
                            </div>
                            <div className="min-w-0">
                              <p className="text-muted-foreground text-sm">Transaction Fee</p>
                              <p className="truncate">{formatCurrency(r.transactionFee, currency)}</p>
                            </div>
                            <div className="min-w-0">
                              <p className="text-muted-foreground text-sm">Processing Fee</p>
                              <p className="truncate">{formatCurrency(r.paymentProcessing, currency)}</p>
                            </div>
                            <div className="min-w-0">
                              <p className="text-muted-foreground text-sm">Net Profit Margin</p>
                              <p className={`font-bold ${getProfitColor(r.netProfit)}`}>{profitPct.toFixed(0)}%</p>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Recommendation Box */}
              {(() => {
                const best = getBestPlatform()
                if (!best) return null
                const bestProfitPct = totalRevenue > 0 ? ((best.netProfit - totalCost) / totalRevenue) * 100 : 0
                return (
                  <div className={`flex items-start gap-3 p-4 rounded-lg border ${getProfitBgColor(best.netProfit)}`}>
                    <TrendingUp className={`size-5 shrink-0 mt-0.5 ${getProfitColor(best.netProfit)}`} />
                    <div className="text-sm sm:text-base">
                      <p className="font-medium text-foreground">
                        Recommendation: {best.name}
                      </p>
                      <p className="text-muted-foreground text-sm mt-1">
                        {best.name} gives you the highest net profit of {formatCurrency(best.netProfit, currency)} ({bestProfitPct.toFixed(0)}% margin after fees).
                        {bestProfitPct > 30 && ' Great margin — this platform works well for your pricing!'}
                        {bestProfitPct >= 15 && bestProfitPct <= 30 && ' Decent margin, but consider raising your price slightly for more sustainable profit.'}
                        {bestProfitPct < 15 && ' Low margin — consider increasing your price or reducing costs to improve profitability.'}
                      </p>
                    </div>
                  </div>
                )
              })()}

              {/* Per-platform insight */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">Platform Insights</CardTitle>
                  <CardDescription>What you need to know before you list</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {results.map(r => {
                    const desiredProfit = basePrice - totalCost
                    const actualProfit = r.netProfit - totalCost
                    const feeImpact = desiredProfit - actualProfit
                    return (
                      <div
                        key={r.key}
                        className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-2 min-w-0 flex-wrap">
                          <Badge variant={r.key === 'shopify' ? 'default' : 'outline'} className="shrink-0">
                            {r.name}
                          </Badge>
                          <span className="text-sm sm:text-base break-words">
                            To make <strong>{formatCurrency(desiredProfit, currency)}</strong> profit on {r.name}, sell at <strong>{formatCurrency(r.sellingPrice, currency)}</strong>
                          </span>
                        </div>
                        <span className="text-xs sm:text-sm text-muted-foreground">
                          (fees eat {formatCurrency(feeImpact, currency)} of profit)
                        </span>
                      </div>
                    )
                  })}
                </CardContent>
              </Card>

              {/* Category-specific competitor price comparison tip */}
              <div className="flex items-start gap-3 p-4 rounded-lg bg-blue-50 border border-blue-200">
                <Lightbulb className="size-5 text-blue-600 shrink-0 mt-0.5" />
                <div className="text-sm sm:text-base">
                  <p className="font-medium text-foreground">
                    Competitor Pricing Tip — {categoryTip.label}
                  </p>
                  <p className="text-muted-foreground text-sm mt-1">
                    {categoryTip.tip}
                  </p>
                  <p className="text-muted-foreground text-sm mt-1">
                    Average markup for this category: <strong className="text-foreground">{categoryTip.avgMultiplier}</strong> over material costs.
                    Your current markup is <strong className="text-foreground">{totalCost > 0 ? ((basePrice - totalCost) / totalCost).toFixed(1) : '0'}x</strong>.
                  </p>
                </div>
              </div>

              {/* Quick Price suggestion */}
              {totalCost > 0 && (
                <div className="flex items-start gap-3 p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <Lightbulb className="size-5 text-primary shrink-0 mt-0.5" />
                  <div className="text-sm sm:text-base">
                    <p className="font-medium text-foreground">
                      Quick Price Suggestion
                    </p>
                    <p className="text-muted-foreground text-sm mt-1">
                      Based on your total cost of {formatCurrency(totalCost, currency)}, a recommended price range is{' '}
                      <strong className="text-foreground">{formatCurrency(totalCost * 2, currency)} – {formatCurrency(totalCost * 3.33, currency)}</strong>{' '}
                      (50-70% margin). This ensures you cover costs and earn a sustainable wage.
                    </p>
                  </div>
                </div>
              )}

              {/* Market Research Button */}
              {remaining > 0 && (
                <div className="space-y-3">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleMarketResearch}
                    disabled={isResearchingPrice || !productName?.trim()}
                    className="gap-1.5 border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                  >
                    {isResearchingPrice ? (
                      <>
                        <div className="size-3.5 animate-spin rounded-full border-2 border-emerald-300 border-t-transparent" />
                        Researching...
                      </>
                    ) : (
                      <>
                        <TrendingUp className="size-3.5" />
                        Compare Market Prices
                      </>
                    )}
                  </Button>

                  {researchError && (
                    <p className="text-xs text-destructive">{researchError}</p>
                  )}

                  {/* Market Research Results Card */}
                  {marketResearch && (
                    <Card className="border-emerald-200 bg-emerald-50/50">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm sm:text-base flex items-center gap-2">
                          <TrendingUp className="size-4 text-emerald-600" />
                          Market Price Research
                        </CardTitle>
                        <CardDescription>
                          Prices for similar handmade {productName?.trim() || 'products'}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {/* Price Range */}
                        <div className="grid grid-cols-3 gap-2 text-center">
                          <div className="p-2 rounded-lg bg-background/80">
                            <p className="text-xs text-muted-foreground uppercase font-semibold">Low</p>
                            <p className="text-lg font-bold text-emerald-700">
                              {formatCurrency(marketResearch.priceRange.min, currency)}
                            </p>
                          </div>
                          <div className="p-2 rounded-lg bg-background/80">
                            <p className="text-xs text-muted-foreground uppercase font-semibold">Average</p>
                            <p className="text-lg font-bold text-emerald-700">
                              {formatCurrency(marketResearch.priceRange.avg, currency)}
                            </p>
                          </div>
                          <div className="p-2 rounded-lg bg-background/80">
                            <p className="text-xs text-muted-foreground uppercase font-semibold">High</p>
                            <p className="text-lg font-bold text-emerald-700">
                              {formatCurrency(marketResearch.priceRange.max, currency)}
                            </p>
                          </div>
                        </div>

                        {/* Your price comparison */}
                        {basePrice > 0 && marketResearch.priceRange.avg > 0 && (
                          <div className={`text-sm p-2 rounded-lg ${
                            basePrice > marketResearch.priceRange.max
                              ? 'bg-amber-100 text-amber-800'
                              : basePrice < marketResearch.priceRange.min
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-green-100 text-green-800'
                          }`}>
                            {basePrice > marketResearch.priceRange.max
                              ? `Your price (${formatCurrency(basePrice, currency)}) is above market range — consider if premium positioning is intended.`
                              : basePrice < marketResearch.priceRange.min
                                ? `Your price (${formatCurrency(basePrice, currency)}) is below market range — you may be underpricing your work.`
                                : `Your price (${formatCurrency(basePrice, currency)}) is within market range — great positioning!`
                            }
                          </div>
                        )}

                        {/* Sources */}
                        {marketResearch.sources.length > 0 && (
                          <div className="space-y-1.5">
                            <p className="text-xs text-muted-foreground font-semibold uppercase">Sources</p>
                            <div className="max-h-32 overflow-y-auto space-y-1 custom-scrollbar">
                              {marketResearch.sources.map((src, i) => (
                                <div key={i} className="flex items-center justify-between text-sm gap-2">
                                  <a
                                    href={src.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-primary hover:underline truncate min-w-0"
                                  >
                                    {src.name}
                                  </a>
                                  <span className="text-muted-foreground whitespace-nowrap font-medium">
                                    {src.price}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </div>
          )}
        </TabsContent>

        {/* Templates Tab */}
        <TabsContent value="templates" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Saved Templates</CardTitle>
              <CardDescription>
                Manage your pricing templates for quick reuse
              </CardDescription>
            </CardHeader>
            <CardContent>
              {templates.length === 0 ? (
                <div className="text-center py-12 space-y-3">
                  <FolderOpen className="size-12 text-muted-foreground/40 mx-auto" />
                  <div>
                    <p className="font-medium text-muted-foreground">No templates yet</p>
                    <p className="text-sm sm:text-base text-muted-foreground/70">
                      Use the Save button in the Calculator tab to create your first template
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto custom-scrollbar">
                  {templates.map(t => (
                    <div
                      key={t.id}
                      className="flex items-center justify-between p-4 rounded-lg border hover:bg-accent/30 transition-colors"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="font-medium truncate">{t.name}</p>
                        <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1 text-sm text-muted-foreground">
                          <span>{t.materials.length} material{t.materials.length !== 1 ? 's' : ''}</span>
                          <span>{t.hours}h @ {formatCurrency(t.hourlyRate, t.currency)}/hr</span>
                          <span>{t.profitMargin}% margin</span>
                          <span>{new Date(t.savedAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-4 shrink-0">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleLoadTemplate(t)}
                        >
                          <Download className="size-4 mr-1" />
                          Load
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteTemplate(t.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="size-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            {templates.length > 0 && (
              <CardFooter className="text-sm text-muted-foreground">
                {templates.length} template{templates.length !== 1 ? 's' : ''} saved
              </CardFooter>
            )}
          </Card>
        </TabsContent>
      </Tabs>

      {/* Footer credit */}
      <div className="text-center text-sm text-muted-foreground/60 pt-4 pb-2">
        artnew8 studio — Free pricing tools for handmade sellers
      </div>

      {/* Donation prompt - shown after results */}
      {results && results.length > 0 && (
        <ToolDonationPrompt onSupportClick={onSupportClick} />
      )}
    </div>
  )
}
