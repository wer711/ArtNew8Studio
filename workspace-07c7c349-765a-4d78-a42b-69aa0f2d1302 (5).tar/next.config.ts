import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  allowedDevOrigins: [
    "preview-chat-57483e63-6483-431a-a017-0b3401746b56.space-z.ai",
    ".space-z.ai",
  ],
};

export default nextConfig;
